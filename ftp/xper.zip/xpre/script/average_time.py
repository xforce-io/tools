import sys

if __name__ == "__main__" :
  accu=0
  num=0
  fp = open(sys.argv[1], "r")
  for line in fp :
    if -1 != line.find("OK") :
      pos = line.find("cost[")
      pos_2 = line.find("]", pos)
      accu += int(line[pos+5:pos_2])
      num += 1
  print "all[%d], avg[%f]" % (num, accu*1.0/num)
