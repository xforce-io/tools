#pragma once

#include "public.h"

namespace xlib {

class pattern_processor_t {
    private:
    typedef std::vector<pub::Slice> Patterns;

    public:
    bool init(
        const std::string& patterns_filepath, 
        size_t max_pattern_log_size,
        size_t max_pattern_size,
        size_t max_num_patterns);

    inline pub::Slice get_next_pattern();

    void clear();

    virtual ~pattern_processor_t() { clear(); }

    private:
    static pub::Slice _create_buf(
        const std::string& patterns_filepath, 
        size_t max_pattern_log_size);

    static void _create_patterns_from_buf(
        pub::Slice slice, 
        size_t max_pattern_size, 
        size_t max_num_patterns,
        std::vector<pub::Slice>& output);

    private:
    Patterns _patterns;
    int _cur_pattern;
};

pub::Slice pattern_processor_t::get_next_pattern() {
    _cur_pattern = (_cur_pattern+1) % _patterns.size();
    return _patterns[_cur_pattern];
}

}
