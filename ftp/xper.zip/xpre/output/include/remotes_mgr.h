#pragma once

#include <list>
#include "conf.h"

namespace xlib {

class remotes_mgr_t {
    public:

    static const int Connect = 2;

    static const int MaxFd = 102400;
    static const int InvalidFd = -1;
    static const size_t MaxNumFds = 1000;

    public:

    bool init();

    /*
     * brief : select an address and get an fd of that address
     * return: true: ok
     *        false: error happens
     *      Connect: need to connect
     */
    bool get_fd(int &fd, sockaddr_in& addr);

    inline void free_fd(int fd, int state);

    private:

    inline bool _check_connection(int sock);

    private:
    /* addr_index ==> fd */
    std::list<int> _fds[MaxNumRemotes];

    /* fd ==> addr_index */
    int _fd_to_index[MaxFd];
};

void remotes_mgr_t::free_fd(int fd, int state) {
    if(conf_s::is_long_conn) {
        int addr_index = _fd_to_index[fd];
        if(state && _fds[addr_index].size() < conf_s::num_long_conns_per_thread) {
            _fds[addr_index].push_back(fd);
        } else {
            _fd_to_index[fd] = InvalidFd;
            close(fd);
        }
    } else {
        close(fd);
    }
}

bool remotes_mgr_t::_check_connection(int sock) {
    char buf[1];
    ssize_t ret = recv(sock, buf, sizeof(buf), MSG_DONTWAIT);
    return (ret < 0 && (EWOULDBLOCK == errno || EAGAIN == errno)) ? true : false;
}

}
