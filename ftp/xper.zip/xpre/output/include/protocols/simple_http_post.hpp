#pragma once

#include <string.h>
#include "../protocol.hpp"

namespace xlib {

class simple_http_post_t : public protocol_t {
    public:
    static const uint32_t ReadBlock = 1024;

    public:
    inline bool init();

    inline bool construct_write_buf(IN const char* input, IN uint32_t len, IN const void* arg,
        IN char* output, INOUT uint32_t& size);

    inline int readsize_header(char* buf, uint32_t& len);
    inline int readsize_body(char *header, uint32_t size);
    inline bool validate_result(char *buf, uint32_t size);

    virtual ~simple_http_post_t() {}
};

bool simple_http_post_t::init() {
    return true;
}

bool simple_http_post_t::construct_write_buf(const char* input, uint32_t len, const void* arg, 
    char* output, uint32_t& size) {
    sockaddr_in* addr = (sockaddr_in*)arg;

    const char* path = input;
    const char* body = strchr(path, ' ');
    if (NULL==body) return false;
    ++body;

    int len_path = body-path-1;
    int len_body = len-len_path-1;

    strcpy(output, "POST ");
    uint32_t len_method = strlen(output);
    memcpy(output + len_method, path, len_path);
    strcpy(output + len_method + len_path, " HTTP/1.1\r\nUser-Agent: Xpre\r\nHost: ");

    char buf[4096];
    snprintf(buf, sizeof(buf), "%s:%d\r\nAccept: */*\r\nContent-Length: %d\r\n"
        "Content-Type: application/x-www-form-urlencoded\r\n\r\n", 
        inet_ntoa(addr->sin_addr), ntohs(addr->sin_port), len_body);

    strcat(output, buf);
    size = strlen(output);

    memcpy(output+size, body, len_body);
    size += len_body;
    DEBUG("%s size[%d]", output, size);
    return true;
}

int simple_http_post_t::readsize_header(char* buf, uint32_t& len) {
    if(len >= conf_s::max_page_size) return -1;

    buf[len] = '\0';
    if(NULL != strstr(buf, "\r\n")) {
        return 0;
    } else {
        return ReadBlock;
    }
}

int simple_http_post_t::readsize_body(char *header, uint32_t len) {
    UNUSE(header);
    UNUSE(len);
    return 0;
}

bool simple_http_post_t::validate_result(char *buf, uint32_t len) {
    if(len >= conf_s::max_page_size) return false;

    buf[len] = '\0';

    char* ret = strstr(buf, "HTTP/1.1 20");
    if(NULL != ret) {
        return true;
    } else {
        ret = strstr(buf, "HTTP/1.1 40");
        if(NULL != ret) return true;
        TRACE("simple_http_post_res[%s] len[%d]", buf, len);
        return false;
    }
}

}
