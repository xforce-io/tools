#pragma once

#include "../protocol.hpp"

//#define ONEWAY
namespace xlib {

class logtest_t : public protocol_t {
    public:
    inline bool construct_write_buf(IN const char* input, IN uint32_t len, 
        IN const void* arg, IN char* output, INOUT uint32_t& size);

    inline int readsize_header(char* buf, uint32_t& len);
    inline int readsize_body(char* header, uint32_t len);
    inline bool validate_result(char* buf, uint32_t len);

    virtual ~logtest_t() {}
};

bool logtest_t::construct_write_buf(const char* input, uint32_t len, 
    const void* arg, char* output, uint32_t& size) {
#ifndef ONEWAY
  UNUSE(arg);

  uint32_t tmp=htonl(len+16);
  memcpy(output, &tmp, 4);
  memset(output+4, 0, 12);
  memcpy(output+16, input, len);
  size = len+16;
#else
  UNUSE(arg);

  uint32_t tmp=htonl(len+16);
  memcpy(output, &tmp, 4);
  memset(output+4, 0, 4);
  tmp=3;
  memcpy(output+8, &tmp, 1);
  memset(output+9, 0, 7);
  memcpy(output+16, input, len);
  size = len+16;
#endif
  return true;
}

int logtest_t::readsize_header(char* buf, uint32_t& len) {
  UNUSE(buf);

  return 16-len;
}

int logtest_t::readsize_body(char *header, uint32_t len) {
  UNUSE(len);

  char buf[100];
  memcpy(buf, header, 4);
  buf[4]='\0';
  return ntohl(*((uint32_t*)buf))-16;
}

bool logtest_t::validate_result(char *buf, uint32_t len) {
  //if(buf[16]!='o' || buf[17]!='k') return false;
  size_t pos=0;
  char buffer[1024];
  for (size_t i=0; i<len-16; ++i) {
    pos += snprintf(buffer+pos, sizeof(buffer), "%lu ", (size_t)((unsigned char)(buf[16+i])));
  }
  return true;
}

}
