#pragma once

#include "public.h"
#include "tools.h"

namespace xlib {

class protocol_t;

class job_event_t {
    public:
    enum job_state_e {
        Init,
        Connect,
        Write,
        ReadHeader,
        ReadBody,
    };

    enum job_result_e {
        OK = 0,
        EpollctlFail,              //1
        EpollErrDouble,            //2
        EpollErrOther,             //3
        FailInsertIntoTimeoutHeap, //4
        FailToConnect,             //5
        InvalidHeader,             //6
        InvalidRes,                //7
        ReadErr,                   //8
        WriteErr,                  //9
        PeerClose,                 //10
        ProtocolErr,               //11
        StartOfProcess,            //12
        Timeout_1,                 //13
        Timeout_2,                 //14
        UnexpectedBranch,
    };

    public:
    job_event_t();

    bool init();

    bool reset(pub::Slice* job, int fd, const sockaddr_in& addr);

    /*
     * @brief : mark the state, and set _bytes and _offset 
     * @return : -1 : error
     *            0 : process ends
     *            1 : ok
     */
    int state(int state);
    int state() const { return _state; }

    int fd() const { return _fd; }
    sockaddr_in addr() const { return _addr; }

    size_t timeout_item() const { return _timeout_item; }
    void timeout_item(size_t timeout_item) { _timeout_item = timeout_item; }

    uint64_t start_time() const { return _start_time; }
    int bytes_have() const { return _offset; }
    int bytes_want() const { return _offset + _bytes; }

    int read();
    inline int write();

    inline void log_job(const char *reason, int64_t arg);

    virtual ~job_event_t();

    private:
    int _state;
    int _fd;
    sockaddr_in _addr;
    size_t _timeout_item;
    uint64_t _start_time;

    int _bytes;
    int _offset;

    private:
    bool _init;
    int _len_header;
    char *_buffer;
    protocol_t* _protocol;
};

int job_event_t::write() {
    int old_bytes = _bytes;
    int ret = tools_i::Write(_fd, _buffer+_offset, _bytes);
    _offset += old_bytes - _bytes;
    return ret;
}

void job_event_t::log_job(const char *reason, int64_t arg) {
    const char *job_state="";
    switch(_state) {
        case Init:       job_state = "INIT"       ; break;
        case Connect:    job_state = "CONNECT"    ; break;
        case ReadHeader: job_state = "READ_HEADER"; break;
        case ReadBody:   job_state = "READ_BODY"  ; break;
        case Write:      job_state = "WRITE"      ; break;
        default : break;
    }

    uint64_t end_time = pub::Time::GetCurrentUsec(false);
    NOTICE(
        "addr[%s|%d] state[%s] bytes[%d/%d] reason[%s] cost[%d] arg[%ld]", 
        inet_ntoa(_addr.sin_addr), ntohs(_addr.sin_port), job_state, 
        _offset, _offset+_bytes, reason, end_time - _start_time, arg);
}

}
