#pragma once

#include "public.h"
#include "conf.h"
#include "pattern_processor.h"
#include "protocol.hpp"
#include "scheduler.hpp"

namespace xlib {

/*
 * master issue job_list after it produces enough tasks into job_queue
 * slave takes job_list and erase num_tasks, then do tasks in job_queue
 */
struct job_list_t {
    int num_tasks;
    bool is_end;
    bool consumed;
};

template <typename T> class FixedMsgPipe;
struct job_list_t;
struct statics_t;

struct info_passed_to_slave_t {
    int id;         //id of the slave
    Pipe* job_queue;
    job_list_t* job_list;
    statics_t* statics;
};

class slave_t;

struct info_passed_to_master_t {
    pattern_processor_t* pattern_processor;
    std::vector<Pipe*>* job_queue;
    job_list_t* job_list;
    slave_t* slaves;
};

struct info_passed_to_statician_t {
    struct statics_t *statics;
    bool *end;
};

class globals_s {
    public:
    static bool init();
    static bool run();
    static void stop();

    static void *run_slave(void *arg);
    static void* run_master(void *arg);
    static void* run_statician(void *arg);

    inline static scheduler_i* scheduler();

    public:
    static double possi_master_render;
    static int is_master_on;   //whether master is still work

    private:
    static bool _init_scheduler();

    private:
    static pattern_processor_t _pattern_processor;
    static scheduler_i* _scheduler;
};

scheduler_i* globals_s::scheduler() { return _scheduler; }

}
