#pragma once

#include <list>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "lib/log/src/glog.h"
#include "lib/conf/src/conf.h"
#include "lib/public/public.h"

namespace xlib {

typedef pub::FixedMsgPipe<pub::Slice> Pipe;

const int MaxLenPath = 256;
const int MaxNumThread = 8;
const int MaxAccessLogSize = 2000000000;

}
