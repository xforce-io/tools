#pragma once

#include "public.h"
#include "conf.h"

namespace xlib {

class protocol_t {
    public:
    virtual bool init() { return true; }

    /*
     * write part
     */
    virtual bool construct_write_buf(IN const char* input, IN uint32_t len, 
        IN const void* arg, IN char *output, INOUT uint32_t& size) = 0;

    /*
     * read part
     */

    /*
     * @notice       : job_event ��֤��һ�ε��õ�len����ǰһ�εķ���ֵ��
     * @parameters : len : should return length of the header
     * @return : > 0 : num of bytes to be read
     *         == 0 : reading header ends, len return length of header
     *         < 0 : error happens
     */
    virtual int readsize_header(IN char* buf, INOUT uint32_t& len) = 0;

    /*
     * return : > 0 : size of body to be read
     *         == 0 : reading body ends
     *         < 0 : error happens
     */
    virtual int readsize_body(char* header, uint32_t len) = 0;

    /*
     * brief : validate the result content
     */
    virtual bool validate_result(char *buf, uint32_t len) = 0;

    virtual ~protocol_t() {}
};

}
