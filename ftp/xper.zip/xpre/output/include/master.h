#pragma once

#include <pthread.h>

#include "public.h"
#include "conf.h"
#include "globals.h"

namespace xlib {

class slave_t;
class pattern_processor_t;

class master_t {
    public:
    master_t() {}

    bool init(info_passed_to_master_t *info_passed_to_master);

    inline void run();

    private:
    bool _work_circle();
    void _produce_task();
    void _release_command(bool is_end);
    inline int _select_slave();
    inline bool _whether_to_render();

    private:
    slave_t *_slaves;

    pattern_processor_t* _pattern_processor;
    std::vector<Pipe*>* _job_queue;
    job_list_t *_job_list;
    /* if -1, means there are infinit tasks to be done */
    int _num_tasks_left;

    char* _pattern;
    char* _page;
    int* _num_task_per_slave;
};

void master_t::run() {
    while(true == _work_circle()) ;
}

bool master_t::_whether_to_render() {
    return (1.0 * rand() / RAND_MAX) < globals_s::possi_master_render;
}

}
