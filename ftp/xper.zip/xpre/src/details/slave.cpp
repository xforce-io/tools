#include <sys/epoll.h>

#include "../public.h"
#include "../tools.h"
#include "../conf.h"

#include "../slave.h"
#include "../job_event.h"

namespace xlib {

bool slave_t::init(info_passed_to_slave_t *info_passed_to_slave) {
    int ret;
    _id = info_passed_to_slave->id;

    _fd_epoll = epoll_create(10000);
    XLIB_FAIL_HANDLE_FATAL(_fd_epoll <= 0, "create_epoll_fd_reason[%m]");

    _job_queue = info_passed_to_slave->job_queue;
    _job_list = info_passed_to_slave->job_list;

    ret = _remotes_mgr.init();
    XLIB_FAIL_HANDLE_FATAL(true != ret, "init_remotes_mgr");

    _current_num_tasks = 0;
    _num_new_tasks = 0;
    _is_end = false;

    XLIB_NEW(_events, epoll_event [MaxNumEvents]);

    _pool_job_event = pub::PoolObjs<job_event_t>(InitSizePoolJobEvent, true);
    return true;

    ERROR_HANDLE:
    return false;
}

void slave_t::_wait_for_events(bool& wait, int& num_fds_ready) {
    uint64_t timeout;
    if(_current_num_tasks > 0) {
        time_t current_usec = pub::Time::GetCurrentUsec(false);
        for(;;) {
            std::pair<uint64_t, job_event_t*>* heap_item = _timeout_heap.Top();
            timeout = heap_item->first;
            if( int64_t(timeout) < current_usec ) {
                _timeout_heap.Pop();

                job_event_t *job_event = (job_event_t*)(heap_item->second);
                epoll_ctl(_fd_epoll, EPOLL_CTL_DEL, job_event->fd(), NULL);
                job_event->log_job("timeout_1", _current_num_tasks);
                _remotes_mgr.free_fd(job_event->fd(), false);
                _pool_job_event.Free(job_event);
                --_current_num_tasks;
                if(0 == _current_num_tasks) {
                    heap_item->first = current_usec;
                    timeout=current_usec;
                    break;
                }
            } else {
                break;
            }
        }

        TRACE("epoll_wait[%lu|%lu|%ld/ms] ret[%d]", 
            timeout, current_usec,
            (timeout - current_usec)/1000, num_fds_ready);
        num_fds_ready = epoll_wait(_fd_epoll, _events, MaxNumEvents,
            (timeout - current_usec) >> 10);

        if(num_fds_ready < 0) {
            WARN("invalid_epoll_wait_ret[%m]");
        }
        wait = true;
    } else {
        usleep(conf_s::idle_sleep_time);
        num_fds_ready = 0;
    }
}

bool slave_t::_add_new_tasks() {
    _get_tasks();
    if(_num_new_tasks > 0) {
        TRACE("slave_get_new_jobs[%d]", _num_new_tasks);

        epoll_event ev;
        job_event_t *job_event;
        int fd, ret;
        uint64_t timeout;
        size_t sign_of_item;
        sockaddr_in addr;
        for(int i = 0; i < _num_new_tasks; ++i) {
            pub::FixedMsgPipe<pub::Slice>::Msg* msg = _job_queue->RecieveMsg();
            if(NULL==msg) {
                FATAL("get_command_but_no_job");
                continue;
            }

            pub::Slice job = msg->msg_header;

            /* get fd */
            ret = _remotes_mgr.get_fd(fd, addr);
            if(remotes_mgr_t::Connect == ret || true == ret) { 
                ++_current_num_tasks;

                job_event = _pool_job_event.Get();
                ret = job_event->reset(&job, fd, addr);
                _job_queue->MsgConsumed();
                if(true != ret) goto END_OF_FOR_CIRCLE;

                if(job_event_t::Connect == ret) {
                    ret = job_event->state(job_event_t::Connect);
                    timeout = conf_s::connect_timeout + pub::Time::GetCurrentUsec(false);
                } else {
                    ret = job_event->state(job_event_t::Write);
                    timeout = conf_s::write_timeout + pub::Time::GetCurrentUsec(false);
                }

                if(ret <= 0) {
                    job_event->log_job("protocol_err_1", _current_num_tasks);
                    goto END_OF_FOR_CIRCLE;
                }

                ev.events = EPOLLOUT | EPOLLHUP | EPOLLERR;
                ev.data.ptr = job_event;
                ret = epoll_ctl(_fd_epoll, EPOLL_CTL_ADD, fd, &ev);
                if(ret < 0) {
                    FATAL("EPOLL_ADD_fail");
                    goto END_OF_FOR_CIRCLE;
                }

                /* registe timeout item */
                //FATAL("insert");
                _timeout_heap.Insert(timeout, job_event, sign_of_item);
                job_event->timeout_item(sign_of_item);
                continue;

                END_OF_FOR_CIRCLE :
                job_event->log_job("start", _current_num_tasks);
                _remotes_mgr.free_fd(fd, false);
                _pool_job_event.Free(job_event);
                --_current_num_tasks;
            } else {
                _job_queue->MsgConsumed();
                NOTICE(
                    "addr[%s|%d] state[Connect] _bytes[0/0] "
                    "reason[fail_to_connect] cost[0] arg[%ld]", 
                    inet_ntoa(addr.sin_addr), ntohs(addr.sin_port), 
                    _current_num_tasks);
            }
        }
        _num_new_tasks = 0;
    } else {
        if(0 == _current_num_tasks && true == _is_end) return false; 
    }
    return true;
}

void slave_t::_handle_events(int num_fds_ready, int wait) {
    int ret;
    uint64_t timeout;
    job_event_t* job_event;
    if(num_fds_ready > 0) {
        epoll_event ev;
        uint64_t old_timeout;
        std::pair<uint64_t, job_event_t*>* heap_item;
        size_t timeout_item;
        for(int i = 0; i < num_fds_ready; ++i) {
            job_event = (job_event_t*)_events[i].data.ptr;
            timeout_item = job_event->timeout_item();
            heap_item = _timeout_heap.Item(timeout_item);
            old_timeout = heap_item->first;
            _timeout_heap.Erase(timeout_item);

            /* 
             * collect events
             */
            if(EPOLLOUT == _events[i].events) {
                if(job_event_t::Connect == job_event->state()) {
                    socklen_t socklen = sizeof(ret);
                    if(0 != getsockopt(job_event->fd(), SOL_SOCKET, SO_ERROR, 
                        &ret, &socklen) || 0 != ret) {
                        TRACE("fail_to_connect[%m] fd[%d]", job_event->fd());
                        job_event->log_job("fail_to_connect", _current_num_tasks);
                        goto END_OF_JOB;
                    }

                    ret = job_event->state(job_event_t::Write);
                    if(ret <= 0) {
                        job_event->log_job("protocol_err_2", _current_num_tasks);
                        goto END_OF_JOB;
                    }

                    ev.events = EPOLLOUT | EPOLLHUP | EPOLLERR;
                    ev.data.ptr = job_event;
                    ret = epoll_ctl(_fd_epoll, EPOLL_CTL_MOD, job_event->fd(), &ev);
                    if(ret != 0) {
                        FATAL("epoll_ctrl_mod[%d] reason[%m]", 
                            job_event->fd());
                        job_event->log_job("epoll_ctl", _current_num_tasks);
                        goto END_OF_JOB;
                    }
                    
                    timeout = conf_s::write_timeout + pub::Time::GetCurrentUsec(false);
                } else {
                    ret = job_event->write();
                    if(0 == ret) {
                        /* registe read event */
                        ret = job_event->state(job_event_t::ReadHeader);
                        if(ret <= 0) {
                            if (0==ret) {
                              _end_event_ok(job_event);
                              continue;
                            }

                            job_event->log_job("protocol_err_3", _current_num_tasks);
                            goto END_OF_JOB;
                        }

                        ev.events = EPOLLIN | EPOLLHUP | EPOLLERR;
                        ev.data.ptr = job_event;
                        ret = epoll_ctl(_fd_epoll, EPOLL_CTL_MOD, job_event->fd(), 
                            &ev);
                        if(ret != 0) {
                            FATAL("epoll_ctrl_mod[%d] reason[%m]", 
                                job_event->fd());
                            job_event->log_job("epoll_ctl", _current_num_tasks);
                            goto END_OF_JOB;
                        }

                        timeout = conf_s::read_timeout + pub::Time::GetCurrentUsec(false);
                    } else if(tools_i::INCOMPLETE == ret) {
                        timeout = old_timeout;
                    } else {
                        job_event->log_job("write_error", _current_num_tasks);
                        goto END_OF_JOB;
                    }
                }
            } else if(EPOLLIN == _events[i].events) {
                ret = job_event->read();
                if(0 == ret) {
                    if(job_event_t::ReadBody == job_event->state()) {
                        _end_event_ok(job_event);
                        continue;
                    } else if(job_event_t::ReadHeader == job_event->state()) {
                        ret = job_event->state(job_event_t::ReadBody);
                        if(ret < 0) {
                            job_event->log_job((-2==ret) ? "invalid_res" : "invalid_header", _current_num_tasks);
                            goto END_OF_JOB;
                        } else if(0==ret) {
                          _end_event_ok(job_event);
                          continue;
                        }
                    } else {
                      FATAL("unexpected_branch");
                    }

                    timeout = old_timeout;
                } else if(tools_i::INVALID == ret) {
                    job_event->log_job("invalid_res", _current_num_tasks);
                    goto END_OF_JOB;
                } else if(tools_i::INCOMPLETE == ret) {
                    timeout = old_timeout;
                } else {
                    job_event->log_job("read_error", _current_num_tasks);
                    goto END_OF_JOB;
                }
            } else if((EPOLLHUP | EPOLLERR) == _events[i].events) {
                job_event->log_job("EPOLLDERR", _current_num_tasks);
                goto END_OF_JOB;
            } else {
                job_event->log_job("EPOLLERR_OTHER", _current_num_tasks);
                goto END_OF_JOB;
            }

            _timeout_heap.Insert(timeout, job_event, timeout_item);
            job_event->timeout_item(timeout_item);
            continue;

            END_OF_JOB:
            epoll_ctl(_fd_epoll, EPOLL_CTL_DEL, job_event->fd(), NULL);
            _remotes_mgr.free_fd(job_event->fd(), false);
            _pool_job_event.Free(job_event);
            --_current_num_tasks;
        }
    } else if(0 != _current_num_tasks && true == wait) {
    /* timeouts happens */
        std::pair<uint64_t, job_event_t*>* heap_item;
        heap_item = _timeout_heap.Top();
        job_event = heap_item->second;
        _timeout_heap.Pop();
        job_event->log_job("timeout_2", _current_num_tasks);
        epoll_ctl(_fd_epoll, EPOLL_CTL_DEL, job_event->fd(), NULL);

        _remotes_mgr.free_fd(job_event->fd(), false);
        _pool_job_event.Free(job_event);
        --_current_num_tasks;
    }
}

}
