//#include <google/profiler.h>

#include "lib/public/gmonitor/gmonitor.h"

#include "../public.h"
#include "../globals.h"
#include "../remotes_mgr.h"
#include "../master.h"
#include "../slave.h"
#include "../schedulers/scheduler_avg.hpp"

namespace xlib {

double globals_s::possi_master_render = 1.0;
int globals_s::is_master_on = 1;
pattern_processor_t globals_s::_pattern_processor;
scheduler_i* globals_s::_scheduler = NULL;

bool globals_s::init() {
    bool ret = pub::GMonitor::Init("conf/monitor.conf");
    XLIB_FAIL_HANDLE_FATAL(!ret, "fail_init_monitor")

    pub::MemProfile::SetFlag(true);

    ret = conf_s::init();
    XLIB_FAIL_HANDLE_FATAL(true != ret, "error_init_global_conf");

    TRACE("init_conf_succ");

    ret = _init_scheduler();
    XLIB_FAIL_HANDLE_FATAL(true != ret, "error_init_scheduler");

    TRACE("init_scheduler_succ");

    ret = _pattern_processor.init(
        conf_s::PatternFile,
        conf_s::max_pattern_log_size,
        conf_s::max_pattern_size,
        conf_s::max_num_patterns);
    XLIB_FAIL_HANDLE_FATAL(true != ret, "error_init_pattern_processor");

    TRACE("init_pattern_processor_succ");
    return true;

    ERROR_HANDLE:
    return false;
}

void globals_s::stop() {
  XLIB_DELETE(_scheduler)
}

void *globals_s::run_slave(void *arg) {
//    ProfilerRegisterThread();

    glog_s::init_in_thread();

    slave_t* slave = (slave_t*)arg;

    TRACE("slave[%d]: start to run", slave->id());
    slave->run();
    NOTICE("slave[%d] exit", slave->id());

    glog_s::close();
    return (void*)0;
}

void* globals_s::run_master(void *arg) {
//    ProfilerRegisterThread();

    glog_s::init_in_thread();

    TRACE("master_start");
    ((master_t*)arg)->run();
    NOTICE("master_exit");

    glog_s::close();
    return (void*)0;
}

bool globals_s::run() {
    std::vector<Pipe*> job_queue;
    job_list_t *job_list;

    /* init */
    for (size_t i=0; i < conf_s::num_slaves; ++i) {
      job_queue.push_back(new Pipe(conf_s::size_job_queue));
    }

    XLIB_NEW(job_list, job_list_t [conf_s::num_slaves]);
    for(uint32_t i = 0; i < conf_s::num_slaves; ++i) {
        job_list[i].num_tasks = 0;
        job_list[i].is_end = false;
        job_list[i].consumed = true;
    }

    /* start slaves */
    pthread_t *slave_pid;
    XLIB_NEW(slave_pid, pthread_t [conf_s::num_slaves]);
    slave_t *slaves;
    XLIB_NEW(slaves, slave_t [conf_s::num_slaves]);

    info_passed_to_slave_t *info_passed_to_slave;
    for(uint32_t i = 0; i < conf_s::num_slaves; ++i) {
        XLIB_NEW(info_passed_to_slave, info_passed_to_slave_t);
        info_passed_to_slave->id = i;
        info_passed_to_slave->job_queue = job_queue[i];
        info_passed_to_slave->job_list = &(job_list[i]);

        XLIB_FAIL_HANDLE_FATAL(true != slaves[i].init(info_passed_to_slave), 
            "error_init_slave[%d]", i);
        XLIB_FAIL_HANDLE_FATAL(0 != pthread_create(&slave_pid[i], NULL, run_slave, 
            slaves+i), "creating_slave_thread");
    } 

    /* start master */
    pthread_t master_pid;

    info_passed_to_master_t *info_passed_to_master;
    XLIB_NEW(info_passed_to_master, info_passed_to_master_t);
    info_passed_to_master->pattern_processor = &_pattern_processor;
    info_passed_to_master->job_queue = &job_queue;
    info_passed_to_master->job_list = job_list;
    info_passed_to_master->slaves = slaves;

    master_t *master;
    XLIB_NEW(master, master_t);
    XLIB_FAIL_HANDLE_FATAL(true != master->init(info_passed_to_master), 
        "error_init_master");
    XLIB_FAIL_HANDLE_FATAL(0 != pthread_create(&master_pid, NULL, run_master, master), 
        "creating_slave_thread");

    /* wait */
    TRACE("end_master_thread")
    pthread_join(master_pid, NULL);
    is_master_on = 0;
    for(uint32_t i = 0; i < conf_s::num_slaves; ++i) {
        pthread_join(slave_pid[i], NULL);
    }

    for (size_t i=0; i < job_queue.size(); ++i) {
      delete job_queue[i];
    }
    TRACE("end_slave_thread")
    return true;

    ERROR_HANDLE:
    return false;
}

bool globals_s::_init_scheduler() {
    if(conf_s::scheduler_kind == "avg") {
        scheduler_i* tmp_schedule;
        XLIB_NEW(tmp_schedule, scheduler_avg_i);
        _scheduler = tmp_schedule;
    } else {
        XLIB_FAIL_HANDLE_FATAL(true, "unsupported_scheduler[%s]", 
            conf_s::scheduler_kind.c_str());
    }
    return true;

    ERROR_HANDLE:
    return false;
}

}
