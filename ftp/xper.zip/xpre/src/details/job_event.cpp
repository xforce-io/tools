#include "../job_event.h"
#include "../protocols/logtest.hpp"
#include "../protocols/tcptest_10_10.hpp"
#include "../protocols/simple_http.hpp"
#include "../protocols/simple_http_post.hpp"

namespace xlib {

job_event_t::job_event_t() : 
  _init(false),
  _buffer(NULL),
  _protocol(NULL) {}

bool job_event_t::init() {
    bool ret;
    XLIB_NEW(_buffer, char [conf_s::max_page_size]);

    if(conf_s::protocol_kind == "tcptest_10_10") {
        XLIB_NEW(_protocol, tcptest_10_10_t);
    } else if(conf_s::protocol_kind == "logtest") {
        XLIB_NEW(_protocol, logtest_t);
    } else if(conf_s::protocol_kind == "simple_http") {
        XLIB_NEW(_protocol, simple_http_t);
    } else if(conf_s::protocol_kind == "simple_http_post") {
        XLIB_NEW(_protocol, simple_http_post_t);
    } else {
        XLIB_FAIL_HANDLE_FATAL(true, "unsupported_protocol[%s]", 
            conf_s::protocol_kind.c_str());
    }

    ret = _protocol->init();
    XLIB_FAIL_HANDLE_FATAL(true != ret, "fail_init_protocol");

    _init = true;
    return true;

    ERROR_HANDLE:
    _init = false;
    return false;
}

bool job_event_t::reset(pub::Slice* job, int fd, const sockaddr_in& addr) {
    XLIB_ASSERT(NULL != job);

    int ret;
    if(false == _init) {
        ret = init();
        if(false == _init) return false;
    }

    _state = Init;
    _fd = fd;
    _addr = addr;
    _start_time = pub::Time::GetCurrentUsec(false);

    uint32_t tmp;
    ret = _protocol->construct_write_buf(job->Data(), 
        job->Size(), &addr, _buffer, tmp);
    XLIB_FAIL_HANDLE_WARN(false == ret || tmp > conf_s::max_page_size, 
        "error_construct_write_buffer tmpp[%u]", tmp);
    _bytes = tmp;

    _offset = 0;
    _len_header = 0;
    return true;

    ERROR_HANDLE:
    return false;
}

int job_event_t::state(int state) {
    _state = state;
    if(ReadHeader == state) {
        uint32_t tmp = 0;
        _bytes = _protocol->readsize_header(_buffer, tmp);
        _offset = tmp;
        if(0 == _bytes) {
            _state = ReadBody;
            _bytes = _protocol->readsize_body(_buffer, 0);
        }
    } else if(ReadBody == state) {
        _bytes = _protocol->readsize_body(_buffer, _len_header);
        if(_bytes > 0) _bytes -= _offset-_len_header;

        if(0 == _bytes) {
            _offset = _len_header;
            bool ret = _protocol->validate_result(_buffer, _offset);
            return true==ret ? 0 : -2;
        }
    }

    if(_bytes > 0) {
        return 1;
    } else if(0==_bytes) {
      return 0;
    } else {
        FATAL("read_size_cannot_be_neg_or_zero[%d]", ReadBody);
        return -1;
    }
}

int job_event_t::read() {
    int old_bytes = _bytes;
    int ret = tools_i::Read(_fd, _buffer+_offset, _bytes);
    _offset += old_bytes - _bytes;
    if(0 != ret && tools_i::INCOMPLETE != ret) {
      return ret;
    }

    if(ReadBody == _state) {
        if(0 == ret) {
            ret = _protocol->validate_result(_buffer, _offset);
            return (true == ret) ? 0 : tools_i::INVALID;
        }
        return ret;
    } else {
        XLIB_ASSERT(ReadHeader == _state);

        uint32_t tmp = _offset;
        ret = _protocol->readsize_header(_buffer, tmp);
        _len_header = tmp;
        if(ret > 0) {
            _bytes = ret;
            return tools_i::INCOMPLETE;
        } else if(ret < 0) {
            FATAL("read_size_cannot_be_neg_or_zero");
            return tools_i::INVALID;
        }
        return 0;
    }
}

job_event_t::~job_event_t() {
  XLIB_DELETE(_protocol)
  XLIB_DELETE_ARRAY(_buffer)
}

}
