#include <unistd.h>
#include <getopt.h>
#include <pthread.h>
#include <time.h>

//#include "google/profiler.h"

#include "lib/log/src/glog.h"

#include "../public.h"
#include "../globals.h"

#include "../master.h"

#if defined(__DATE__) && defined(__TIME__)
static const char SERVER_BUILT[] = __DATE__ " " __TIME__;
#else
static const char SERVER_BUILT[] = "unknown";
#endif

using namespace xlib;

const char *VERSION_ID = "0.0.0.2";

static void print_version(void) {                       
        printf(" Version\t:\t%s\n", VERSION_ID);
        printf(" Built date\t:\t%s\n", SERVER_BUILT);
        printf(" By xp, enjoy!~\n");
}

void print_help(void)   {               
        printf( "%s", "usage\n");
        printf( "%s", "    --help     | -h     :      print help message\n");
        printf( "%s", "    --version  | -v     :      print version\n");
} 

#ifndef UT_TEST
int main(int argc, char **argv)
#else
int ut_main(int argc, char **argv)
#endif
{
    char c;
    const char* const short_options = "vh?"; 
    const struct option long_options[] = {
         {"help", no_argument, NULL, 'h'},
         {"version", no_argument, NULL, 'v'},
         {0, 0, 0, 0}
    };

    while ((c = getopt_long(argc, argv, short_options, long_options, NULL)) != -1) {
        switch (c) {
            case 'h':
                print_help();
                exit(1);
            case 'v':
                print_version();
                exit(1);
            default:
                print_help();
                exit(1);
        }
    }

    srand(1);

    const std::string conf_path = "./conf/xpre.conf";

    conf_t config;
    bool ret = config.init(conf_path);
    XLIB_FAIL_HANDLE_FATAL(true != ret, "error_load_conf[%s]", conf_path.c_str());
    ret = xlib::glog_s::init(conf_path);
    XLIB_FAIL_HANDLE_FATAL(true != ret, 
        "bad_syntax_conf_file[%s] glog_init", conf_path.c_str());

//    ProfilerStart("gprof");

    XLIB_FAIL_HANDLE_FATAL(true != globals_s::init(), "error_init_globals");
    XLIB_FAIL_HANDLE_FATAL(true != globals_s::run(), "error_run_test");
    globals_s::stop();

 //   ProfilerStop();
    glog_s::close();
    return 0;

    ERROR_HANDLE:
    glog_s::close();
    return 1;
}
