#include "../pattern_processor.h"
#include "../tools.h"
#include "../globals.h"

namespace xlib {

bool pattern_processor_t::init(
      const std::string& patterns_filepath, 
      size_t max_pattern_log_size,
      size_t max_pattern_size,
      size_t max_num_patterns) {
    clear();

    _cur_pattern=-1;

    pub::Slice slice = _create_buf(patterns_filepath, max_pattern_log_size);
    if (NULL == slice.Data()) return false;

    _create_patterns_from_buf(slice, max_pattern_size, max_num_patterns, _patterns);
    XLIB_FAIL_HANDLE_FATAL( 0 == _patterns.size(), "no_valid_pattern" )

    delete []const_cast<char*>(slice.Data());
    return true;

    ERROR_HANDLE:
    delete []const_cast<char*>(slice.Data());
    return false;
}

void pattern_processor_t::clear() {
  for (Patterns::const_iterator iter = _patterns.begin(); iter != _patterns.end(); ++iter) {
    free(CCAST<char*>(iter->Data()));
  }
  _patterns.clear();
}

pub::Slice pattern_processor_t::_create_buf(
        const std::string& patterns_filepath,
        size_t max_pattern_log_size) {
    int ret, file_size;
    struct stat file_state;
    char* buf;

    int fd = open(patterns_filepath.c_str(), O_RDONLY);
    XLIB_FAIL_HANDLE_FATAL(-1 == fd, "error in opening file[%s]", 
        conf_s::PatternFile.c_str());

    XLIB_FAIL_HANDLE_FATAL(-1 == fstat(fd, &file_state), 
        "error_in_state file[%s]", patterns_filepath.c_str());
    XLIB_FAIL_HANDLE_FATAL(int64_t(max_pattern_log_size) < file_state.st_size, 
        "pattern_log_too_big size[%d] max[%d]", file_state.st_size, max_pattern_log_size);
    XLIB_FAIL_HANDLE_FATAL(0 == file_state.st_size, "invalid_pattern_log_size[0]");

    XLIB_NEW(buf, char [file_state.st_size]);

    file_size = file_state.st_size;
    ret = tools_i::Read(fd, buf, file_size);
    XLIB_FAIL_HANDLE_FATAL(0 != ret, "fail_read_from[%s] ret[%d] errno[%d]", 
        patterns_filepath.c_str(), ret, errno);

    close(fd);
    return pub::Slice(buf, file_state.st_size);

    ERROR_HANDLE:
    if (fd>=0) close(fd);
    FATAL("fail_create_buf");
    return pub::Slice(NULL, 0);
}

void pattern_processor_t::_create_patterns_from_buf(
        pub::Slice buf,
        size_t max_pattern_size, 
        size_t max_num_patterns,
        std::vector<pub::Slice>& output) {
    const char* pattern = buf.Data();
    int64_t size_pattern;
    char* tmp_buf;

    output.clear();

    const char* pace = RCAST<const char*>(memchr( (const void*)pattern, ' ', buf.Size() ));

    while ( NULL!=pace && output.size() <= max_num_patterns ) {
        size_pattern = atoll(pattern);
        pace+=1;
        XLIB_FAIL_HANDLE_WARN(
            size_pattern<=0 || size_pattern >= int64_t(max_pattern_size),
            "invalid_pattern_file size_pattern[%d] offset[%d]", 
            size_pattern, pattern - buf.Data());

        if ( pace - buf.Data() + size_t(size_pattern) + 1 > buf.Size() ) {
            WARN("invalid_pattern offset[%d]", pattern - buf.Data());
            break;
        }

        tmp_buf = RCAST<char*>(malloc(size_pattern));
        memcpy(tmp_buf, pace, size_pattern);
        output.push_back(pub::Slice(tmp_buf, size_pattern));

        pattern = pace+size_pattern+1;
        pace = RCAST<const char*>(memchr( 
            (const void*)pattern, 
            ' ', 
            buf.Size() - ( CCAST<const char*>(pattern) - buf.Data() ) ));
        continue;

        ERROR_HANDLE:
        pattern = RCAST<const char*>(memchr( 
            (const void*)pace,
            '\n',
            buf.Size() - ( CCAST<const char*>(pace) - buf.Data() ) ));
        if(NULL!=pattern) {
            ++pattern;
            pace = RCAST<const char*>(memchr( 
                (const void*)pattern, 
                ' ', 
                buf.Size() - ( CCAST<const char*>(pattern) - buf.Data() ) ));
        } else {
            break;
        }
    }
}

}
