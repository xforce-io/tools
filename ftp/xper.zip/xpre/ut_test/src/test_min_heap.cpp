#include <gtest/gtest.h>

#include "../../src/data_structure/min_heap.hpp"

using namespace std;
using namespace xlib;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(min_heap, case1)
{
    min_heap_t<int> min_heap;
    ASSERT_TRUE(true == min_heap.init());

    int ret;
    int num_1 = 1, num_2 = 2, num_3 = 3, num_4 = 4, tmp_index;
    int64_t ret_1, ret_2, ret_3, ret_4;

    ret = min_heap.insert(1, &num_1, ret_1);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(3, &num_3, ret_3);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(2, &num_2, ret_2);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(4, &num_4, ret_4);
    ASSERT_TRUE(true == ret);

    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_1, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_2, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(3, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_3, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(2, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_4, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(4, tmp_index);
    /**/

    int key ;
    int* value;
    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, *value);
    min_heap.pop();

    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_2, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_3, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(2, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_4, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(3, tmp_index);
    /**/

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(2, *value);
    min_heap.pop();

    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_3, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_4, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(2, tmp_index);
    /**/

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(3, *value);
    min_heap.pop();
    
    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_4, tmp_index);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, tmp_index);
    ASSERT_EQ(1, min_heap._num_elements);
    /**/

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(4, *value);
    min_heap.pop();

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(false==ret);
    min_heap.pop();

    ret = min_heap.insert(3, &num_3, ret_3);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(1, &num_1, ret_1);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(4, &num_4, ret_4);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(2, &num_2, ret_2);
    ASSERT_TRUE(true == ret);

    min_heap.free((int64_t)ret_2);

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(1, *value);
    min_heap.pop();

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(3, *value);
    min_heap.pop();

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(4, *value);
    min_heap.pop();

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(false == ret);
    min_heap.pop();
}

TEST(min_heap, case2)
{
    min_heap_t<int> min_heap;
    ASSERT_EQ(true, min_heap.init());

    int ret;
    int num_1 = 1, num_2 = 2, num_3 = 3, tmp_index;
    int64_t ret_1, ret_2, ret_3;

    ret = min_heap.insert(1, &num_1, ret_1);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(3, &num_3, ret_3);
    ASSERT_TRUE(true == ret);

    ret = min_heap.insert(2, &num_2, ret_2);
    ASSERT_TRUE(true == ret);

    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_1, tmp_index);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(1, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_2, tmp_index);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(3, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_3, tmp_index);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(2, tmp_index);
    /**/

    int key ;
    int* value;
    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(1, *value);
    min_heap.pop();

    /* check */
    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_2, tmp_index);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(1, tmp_index);

    ret = min_heap._index_map.find((min_heap_item_t<int>*)ret_3, tmp_index);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(2, tmp_index);
    /**/
}

TEST(min_heap, realloc)
{
    min_heap_t<int> min_heap;
    ASSERT_TRUE(true == min_heap.init());

    int64_t ret_1;
    int ret, key;
    int* value;

    const int Mount = min_heap_t<int>::InitSizeHeap*2+2;
    int num[Mount] = {0, 1};
    for(int i = 0; i < Mount; ++i)
    {
        ret = min_heap.insert(i, &num[i], ret_1);
        ASSERT_TRUE(true == ret);
    }

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(0, *value);
    min_heap.pop();

    ret = min_heap.top(key, (void*&)value);
    ASSERT_TRUE(true == ret);
    ASSERT_EQ(1, *value);

    ASSERT_EQ(Mount-1, min_heap._num_elements);
}
