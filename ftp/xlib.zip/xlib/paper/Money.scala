object Money {
    def unless(op:=>Boolean, block:=>Unit) {
    }

    def main(args: Array[String]) {

    }
}

// vim: set ts=4 sw=4 et:
