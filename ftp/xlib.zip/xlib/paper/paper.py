import mpmath, time
import random

Range = 100000

record = {}

start = time.time()
for i in range(Range) :
  record[i] = i
stop = time.time()
print "cost %f" % (stop-start)

start = time.time()

for k in record.keys():
  i = random.randint(0, Range)

stop = time.time()
print "cost %f" % (stop-start)
