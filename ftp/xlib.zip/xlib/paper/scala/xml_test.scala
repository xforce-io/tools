import java.io._
import java.nio._
import scala.collection.mutable.Map
import scala.util.control.Breaks._

var xmlStr :xml.Node =
  <content name="test_content">
    <action name="test_action">
      <logger name="test_logger_0">
        <condition name="test_condition" />
        <agent name="test_agent" />
      </logger>
      <logger name="test_logger_1">
        <condition name="test_condition" />
        <agent name="test_agent" />
      </logger>
    </action>
    <action name="test_action_2">
      <logger>
        <condition name="test_condition" />
        <agent name="test_agent" />
      </logger>
    </action>
  </content>  

/*
var action_map = 
  (Map[String, xml.Node]() /: (xmlStr \ "content")) {
    (map, node) =>
      val name = (node \ "@name").toString
      println(name)
      map(name) = node
      map
  }

println(action_map.size)
*/



val node_content = xmlStr \ "action"
println(node_content.toString)
val node_action_0 = node_content(0)
println(node_action_0 \ "@name")

var i=0
breakable {
while (i<10) {
  i+=1
  if (i==5) break
}
}

val format = new java.text.SimpleDateFormat("yyyyMMddHHmm")
println(format.format(System.currentTimeMillis))
var file = new FileWriter("sample")
println("write")
println(file.write("haha"))
file.flush

val data = scala.io.Source.fromFile("sample").mkString
assert(data == "haha")

val buffer = ByteBuffer.allocate(100) 
val file_channel = new FileOutputStream("sample").getChannel()
val ret = file_channel.write(buffer)
println(ret)

val string = "f".concat("\n")
println(string(string.length-1))

var list = List()
list.::("123")
println(list.length)

val a = if (0!=2 && 0==1) 3 else 2
