#pragma once

#include "paper.h"
