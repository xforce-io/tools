#pragma once

#include "lib/public/public.h"

extern "C" {
#include "lua/lua.h"
#include "lua/lualib.h"
#include "lua/lauxlib.h"
};

namespace xlib {

typedef std::unordered_map<std::string, std::string*> Map;

inline static int GetField(lua_State* lua_state) {
  const Map* map = RCAST<const Map*>(lua_touserdata(lua_state, -1));
  const std::string* key = RCAST<const std::string*>(lua_touserdata(lua_state, -2));
  std::cout << "called " << *key << " " << map->size() << std::endl;

  const char** result = RCAST<const char**>(lua_touserdata(lua_state, -3));
  Map::const_iterator iter = map->find(*key);
  if ( map->end() == iter ) return 1;

  *result = iter->second->c_str();
  std::cout << "ha " << *result << std::endl;
  return 0;
}

static const struct luaL_Reg maplib[] = {
  {"getfield", GetField},
  {NULL, NULL},
};

inline int luaopen_map(lua_State* lua_state) {
  //luaL_newlib(lua_state, maplib);
  lua_pushcfunction(lua_state, GetField);
  lua_setglobal(lua_state, "getfield");
  return 1;
}

}
