#pragma once

class test {
 public: 
  test() {}

  template <typename T>
  void func(int a);

};

template <typename T>
void test::func(int a) {
  std::cout << "common" << std::endl;
}

template <>
void test::func<double>(int a) {
  std::cout << "specific" << std::endl;
}
