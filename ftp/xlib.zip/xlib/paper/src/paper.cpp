#include <iostream>
#include <fcntl.h>
#include <limits.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <vector>
#include <unordered_map>
#include <memory>
#include <unistd.h>
#include <sys/mman.h>
#include <errno.h>
#include <sys/times.h>
#include <math.h>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <stdint.h>
#include <typeinfo>
#include <tr1/memory>
//#include "public/basic/time.h"
#include <sys/statfs.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <iomanip>
#include <ucontext.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <openssl/md5.h>
#include <malloc.h>

int main() {
  timeval t1, t2;
  gettimeofday(&t1, NULL);

  std::unordered_map<int, int> map;
  std::cout << map.insert(std::make_pair(1, 2)).second << std::endl;
  std::cout << map.insert(std::make_pair(1, 3)).second << std::endl;

  gettimeofday(&t2, NULL);
  std::cout << (t2.tv_sec-t1.tv_sec) * 1000000 + (t2.tv_usec - t1.tv_usec) << std::endl; 
  return 0;
}
