-module(client).
-export([test/0]).

test() -> 
  {_, StartSec, StartMicroSec} = erlang:now(),
  Start = StartSec + StartMicroSec/1000000,
  test(10000),
  {_, StopSec, StopMicroSec} = erlang:now(),
  Stop = StopSec + StopMicroSec/1000000,
  io:format("~f~n", [Stop-Start]).

test(0) -> ok;
test(I) -> 
  pong = rpc:call('server_node@ZAM-DEV-02', server, ping, []),
  test(I-1).
