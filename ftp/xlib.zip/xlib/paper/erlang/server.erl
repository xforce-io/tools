-module(server).
-export([start/0,ping/0]).

start() ->
  register(server, spawn(fun()->loop() end)),
  wait().

ping() ->
  server ! {self(), ping},
  receive
    {From, pong} -> pong
  end.

loop() ->
  receive
    {From, ping} ->
      From ! {self(), pong},
      loop()
  end.

wait() -> receive die->void end.
