class Test {
    def what() {
        println("Test.test")
    }
}

object Test {

    type Rule = (String, Array[String]) => Boolean

    def Has(line :String, args :Array[String]) :Boolean = {
        if (args.length != 0) line.contains(args(0)) else false
    }

    def Haha() :Rule ={
        Has
    }

    def main(Array[String]) {
        println(Haha()("what", Array("w")))
    }
}

// vim: set ts=4 sw=4 et:
