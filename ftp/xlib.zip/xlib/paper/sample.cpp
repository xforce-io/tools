#include <stdio.h>
#include <string.h>
#include <stdlib.h>

using namespace std;

int main()
{
  char* a = new char[4];
  strcpy(a, "abc");
  void* p = a;
  printf("%lu\n", (*reinterpret_cast<size_t*>(a)));
  printf("%lu\n", (*static_cast<size_t*>(p)));
  printf("%lu\n", (size_t)(*static_cast<void**>(p)));
  return 0;
}
