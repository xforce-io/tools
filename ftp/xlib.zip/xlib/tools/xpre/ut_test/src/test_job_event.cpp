#include <gtest/gtest.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "../../src/globals.h"
#include "../../src/job_event.h"
#include "../../src/protocols/simple_http.hpp"

using namespace std;
using namespace xlib;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

void ready_for_read(job_event_t* job_event, bool ok, const char* buf, int len)
{
    if(true == ok)
    {
        FILE* fp =fopen("data/tmp", "w+");
        int fd = fileno(fp);
        EXPECT_TRUE(fd > 0);

        int ret = tools_i::Write(fd, buf, len);
        EXPECT_EQ(0, ret);

        close(fd);

        fd = open("data/tmp", O_RDONLY);
        EXPECT_TRUE(fd > 0);
        
        job_event->_fd = fd;
    }
    else
    {
        job_event->_fd = -1;
    }
}

void ready_for_write(job_event_t* job_event, bool ok, char* buf, int len)
{
    UNUSE(buf)
    UNUSE(len)
    if(true == ok)
    {
        FILE* fp =fopen("data/tmp", "w+");
        int fd = fileno(fp);

        EXPECT_TRUE(fd > 0);
        job_event->_fd = fd;
    }
    else
    {
        job_event->_fd = -1;
    }
}

TEST(init, all)
{
    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(protocol_kind[ ]*:\\).*$/\\1 tcptest_10_10/g' conf/xpre.conf; "
        "sed -i 's/^\\(max_page_size[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
    );

    int ret = globals_s::init();
    ASSERT_EQ(true, ret);

    job_event_t job_event;
    sockaddr_in addr;

    const char* kMsg = "aaaaaaaaaa";
    pub::Slice slice(kMsg, strlen(kMsg));
    ret = job_event.reset(&slice, 3, addr);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::Init, job_event._state);
    EXPECT_EQ(3, job_event._fd);

    ret = memcmp(job_event._buffer, kMsg, 10);
    EXPECT_EQ(0, ret);
    EXPECT_EQ(10, job_event._bytes);

    EXPECT_EQ(0, job_event._offset);

    globals_s::stop();
}

TEST(tcptest_10_10, all)
{
    /* init */
    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(protocol_kind[ ]*:\\).*$/\\1 tcptest_10_10/g' conf/xpre.conf; "
        "sed -i 's/^\\(max_page_size[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
    );

    int ret = globals_s::init();
    ASSERT_EQ(true, ret);

    job_event_t job_event;
    sockaddr_in addr;

    const char* kMsg = "bbbbbbbbbb";
    pub::Slice slice(kMsg, strlen(kMsg));
    ret = job_event.reset(&slice, 3, addr);
    EXPECT_EQ(true, ret);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadBody, job_event._state);
    EXPECT_EQ(job_event._bytes, 10);

    ready_for_read(&job_event, true, "bbbbbbbbbb", 10);
    ret = job_event.read();
    EXPECT_EQ(0, ret);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadBody, job_event._state);
    EXPECT_EQ(job_event._bytes, 10);

    ready_for_read(&job_event, false, "bbbbbbbbbb", 10);
    ret = job_event.read();
    EXPECT_NE(0, ret);

    close(job_event._fd);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadBody, job_event._state);
    EXPECT_EQ(job_event._bytes, 10);

    ready_for_read(&job_event, true, "bbbbbbbbb", 9);
    ret = job_event.read();
    EXPECT_EQ(tools_i::INCOMPLETE, ret);

    close(job_event._fd);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadBody, job_event._state);
    EXPECT_EQ(job_event._bytes, 10);

    ready_for_read(&job_event, true, "bbbbbbbbba", 10);
    ret = job_event.read();
    EXPECT_EQ(tools_i::INVALID, ret);

    close(job_event._fd);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadBody, job_event._state);
    EXPECT_EQ(job_event._bytes, 10);

    ready_for_read(&job_event, true, "bbbbbbbbbbbb", 12);
    ret = job_event.read();
    EXPECT_EQ(0, ret);

    close(job_event._fd);

    globals_s::stop();
}

TEST(simple_http, all)
{
    /* init */
    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(protocol_kind[ ]*:\\).*$/\\1 simple_http/g' conf/xpre.conf; "
        "sed -i 's/^\\(max_page_size[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
    );

    int ret = globals_s::init();
    ASSERT_EQ(true, ret);

    job_event_t job_event;
    sockaddr_in addr;

    pub::Slice job;
    ret = job_event.reset(&job, 3, addr);
    EXPECT_EQ(true, ret);

    /*******************************/
    ret = job_event.state(job_event_t::ReadHeader);
    EXPECT_EQ(true, ret);

    EXPECT_EQ(job_event_t::ReadHeader, job_event._state);
    int bytes = simple_http_t::ReadBlock;
    EXPECT_EQ(job_event._bytes, bytes);

    ready_for_read(&job_event, true, "aaa", 3);
    ret = job_event.read();
    EXPECT_EQ(tools_i::INCOMPLETE, ret);

    ready_for_read(&job_event, true, "Content-Length:4\n", 17);
    ret = job_event.read();
    EXPECT_EQ(tools_i::INCOMPLETE, ret);

    EXPECT_NE(job_event_t::ReadBody, job_event._state);

    ret = job_event.read();
    EXPECT_EQ(tools_i::INCOMPLETE, ret);

    ret = job_event.state(job_event_t::ReadBody);
    EXPECT_EQ(-2, ret);

    ret = job_event.read();
    EXPECT_EQ(tools_i::INVALID, ret);

    close(job_event._fd);

    globals_s::stop();
}
