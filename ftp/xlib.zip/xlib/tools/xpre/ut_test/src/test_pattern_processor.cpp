#include <gtest/gtest.h>
#include <iostream>

#include "../../src/pattern_processor.h"
#include "../../src/conf.h"
	
using namespace std;
using namespace xlib;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(pattern_processor, init_all)
{
    system("rm -rf data/patterns");

    pattern_processor_t pattern_processor;
    bool ret = pattern_processor.init("data/patterns", 0, 1, 1);
    ASSERT_TRUE(false==ret);

    system("touch data/patterns");
    system("echo '3 asd\n' > data/patterns");
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, pattern_processor._patterns.size());
    ASSERT_EQ(3, pattern_processor._patterns[0].Size());
    ASSERT_EQ(0, memcmp("asd", pattern_processor._patterns[0].Data(), 3));

    system("echo '3 asd\n\n\n' > data/patterns");
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, pattern_processor._patterns.size());
    ASSERT_EQ(3, pattern_processor._patterns[0].Size());
    ASSERT_EQ(0, memcmp("asd", pattern_processor._patterns[0].Data(), 3));

    system("echo '\n3 asd' > data/patterns");
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(1, pattern_processor._patterns.size());
    ASSERT_EQ(3, pattern_processor._patterns[0].Size());
    ASSERT_EQ(0, memcmp("asd", pattern_processor._patterns[0].Data(), 3));

    system("echo '\n\n' > data/patterns");
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_TRUE(false==ret);
}

TEST(pattern_processor, get_next_pattern_case1)
{
    system("cp conf/xpre_normal.conf conf/xpre.conf; ");
    bool ret = conf_s::init();
    ASSERT_EQ(true, ret);

    system("echo '\n3 asd\n\n10 abcdefghij\n7 abcdefg\n\n' > data/patterns");
    pattern_processor_t pattern_processor;
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_EQ(true, ret);

    pub::Slice slice;
    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(3, slice.Size());
    ASSERT_EQ(0, memcmp("asd", slice.Data(), 3));

    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(10, slice.Size());
    ASSERT_EQ(0, memcmp("abcdefghij", slice.Data(), 10));

    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(7, slice.Size());
    ASSERT_EQ(0, memcmp("abcdefg", slice.Data(), 7));

    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(3, slice.Size());
    ASSERT_EQ(0, memcmp("asd", slice.Data(), 3));
}

TEST(pattern_processor, get_next_pattern_case2)
{
    system("cp conf/xpre_normal.conf conf/xpre.conf; ");
    bool ret = conf_s::init();
    ASSERT_EQ(true, ret);

    system("echo 'sd\n10 abcdefghij\n7 abcdefg\n' > data/patterns");
    pattern_processor_t pattern_processor;
    ret = pattern_processor.init("data/patterns", 100, 100, 100);
    ASSERT_EQ(true, ret);

    pub::Slice slice;
    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(7, slice.Size());
    ASSERT_EQ(0, memcmp("abcdefg", slice.Data(), 7));

    slice = pattern_processor.get_next_pattern();
    ASSERT_EQ(7, slice.Size());
    ASSERT_EQ(0, memcmp("abcdefg", slice.Data(), 7));
}
