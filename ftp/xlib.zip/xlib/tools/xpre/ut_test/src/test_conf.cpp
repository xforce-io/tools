#include <gtest/gtest.h>
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../../src/conf.h"
	
using namespace std;
using namespace xlib;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(conf, all)
{
    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(num_slaves[ ]*:\\).*$/\\1 1/g' conf/xpre.conf; "
        "sed -i 's/^\\(pattern_file[ ]*:\\).*$/\\1 data\\/patterns/g' conf/xpre.conf; "
        "sed -i 's/^\\(max_page_size[ ]*:\\).*$/\\1 2048/g' conf/xpre.conf; "
        "sed -i 's/^\\(max_pattern_size[ ]*:\\).*$/\\1 1000/g' conf/xpre.conf; "
        "sed -i 's/^\\(size_job_queue[ ]*:\\).*$/\\1 1000000/g' conf/xpre.conf; "
        "sed -i 's/^\\(protocol_kind[ ]*:\\).*$/\\1 tcptest_10_10/g' conf/xpre.conf; "
        "sed -i 's/^\\(check_interval[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
        "sed -i 's/^\\(is_fixed_speed[ ]*:\\).*$/\\1 1/g' conf/xpre.conf; "
        "sed -i 's/^\\(fixed_speed[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
        "sed -i 's/^\\(num_downloads[ ]*:\\).*$/\\1 10000/g' conf/xpre.conf; "
        "sed -i 's/^\\(idle_sleep_time[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
        "sed -i 's/^\\(is_long_conn[ ]*:\\).*$/\\1 1/g' conf/xpre.conf; "
        "sed -i 's/^\\(num_long_conns_per_thread[ ]*:\\).*$/\\1 10/g' conf/xpre.conf; "
        "sed -i 's/^\\(connect_timeout[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
        "sed -i 's/^\\(read_timeout[ ]*:\\).*$/\\1 200/g' conf/xpre.conf; "
        "sed -i 's/^\\(write_timeout[ ]*:\\).*$/\\1 300/g' conf/xpre.conf; "
    );
    bool ret = conf_s::init();
    ASSERT_EQ(true, ret);
    ASSERT_EQ(1, conf_s::num_slaves);
    ASSERT_EQ(2048, conf_s::max_page_size);
    ASSERT_EQ(1000, conf_s::max_pattern_size);
    ASSERT_EQ(1000000, conf_s::size_job_queue);
    ASSERT_TRUE("tcptest_10_10" == conf_s::protocol_kind);
    ASSERT_EQ(100, conf_s::check_interval);
    ASSERT_EQ(1, conf_s::is_fixed_speed);
    ASSERT_EQ(100, conf_s::fixed_speed);
    ASSERT_EQ(10000, conf_s::num_downloads);
    ASSERT_EQ(100, conf_s::idle_sleep_time);
    ASSERT_EQ(1, conf_s::is_long_conn);
    ASSERT_EQ(10, conf_s::num_long_conns_per_thread);
    ASSERT_EQ(100000, conf_s::connect_timeout);
    ASSERT_EQ(200000, conf_s::read_timeout);
    ASSERT_EQ(300000, conf_s::write_timeout);
    ASSERT_EQ(1, conf_s::num_remotes);
    ASSERT_EQ(inet_addr("10.10.10.1"), conf_s::ip[0]);
    ASSERT_EQ(htons(8300), conf_s::port[0]);
}

TEST(conf, invalid)
{
    bool ret;
    char command_1[1000], command_2[1000], command[3000];
    char conf[100][100] = { \
        "num_slaves",
        "max_page_size",
        "max_pattern_size",
        "size_job_queue",
        "protocol_kind",
        "check_interval",
        "is_fixed_speed",
        "fixed_speed",
        "num_downloads",
        "idle_sleep_time",
        "is_long_conn",
        "num_long_conns_per_thread",
        "connect_timeout",
        "read_timeout",
        "write_timeout",
        "ip",
        "port",
    };
    strcpy(command_1, "cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(");
    strcpy(command_2, "[ ]*:\\).*$/\\1 /g' conf/xpre.conf; ");

    for(int i = 0; 0 != conf[i][0]; ++i)
    {
        snprintf(command, sizeof(command), "%s%s%s", command_1, conf[i], command_2);
        cout << command << endl;
        system(command);
        ret = conf_s::init();
        ASSERT_TRUE(false==ret);
    }
}

TEST(conf, speed_file)
{
    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(is_fixed_speed[ ]*:\\).*$/\\1 1/g' conf/xpre.conf; "
        "sed -i 's/^\\(fixed_speed[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
    );
    system("echo '12' > conf/speed");
    bool ret = conf_s::init();
    ASSERT_EQ(true, ret);
    
    int speed = conf_s::get_current_speed();
    ASSERT_EQ(100, speed);

    system("cp conf/xpre_normal.conf conf/xpre.conf; "
        "sed -i 's/^\\(is_fixed_speed[ ]*:\\).*$/\\1 0/g' conf/xpre.conf; "
        "sed -i 's/^\\(fixed_speed[ ]*:\\).*$/\\1 100/g' conf/xpre.conf; "
    );
    system("echo '12' > conf/speed");
    ret = conf_s::init();
    ASSERT_EQ(true, ret);
    
    speed = conf_s::get_current_speed();
    ASSERT_EQ(12, speed);
}
