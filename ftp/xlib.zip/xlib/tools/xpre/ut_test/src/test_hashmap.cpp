#include <gtest/gtest.h>

#include "../../src/data_structure/hashmap.hpp"

using namespace std;
using namespace xlib;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(hashmap, positive)
{
    int ret, value;
    hashmap_t<int, int> hashmap;
    ret = hashmap.init(12);
    ASSERT_EQ(true, ret);

    for(int i = 0; i < 50; ++i)
    {
        ret = hashmap.insert(i, i);
        ASSERT_EQ(true, ret);
    }

    ASSERT_EQ(50, hashmap._num_elements);
    ASSERT_EQ(12, hashmap._num_buckets);

    ASSERT_TRUE(false == hashmap.find(51, value));

    ret = hashmap.set(51, 10);
    ASSERT_TRUE(false==ret);

    for(int i = 0; i < 50; ++i)
    {
        ret = hashmap.find(i, value);
        ASSERT_EQ(true, ret);
        ASSERT_EQ(value, i);
    }

    ret = hashmap.set(41, 10);
    ASSERT_TRUE(true==ret);

    ret = hashmap.find(41, value);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(value, 10);

    hashmap.free(0);
    ret = hashmap.find(0, value);
    ASSERT_TRUE(false==ret);

    for(int i = 1; i < 50; ++i)
    {
        hashmap.free(i);
    }

    for(int i = 0; i < hashmap._num_buckets; ++i)
    {
        ASSERT_TRUE(hashmap._buckets[i].next == NULL);
    }

    ASSERT_EQ(0, hashmap._num_elements);
    ASSERT_EQ(12, hashmap._num_buckets);
}

TEST(hashmap, passive)
{
    hashmap_t<int, int> hashmap;
    ASSERT_TRUE(false == hashmap.init(0));
}
