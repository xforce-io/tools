#!/bin/sh
#/***************************************************************************
# * 
# * Copyright (c) 2010 Baidu.com, Inc. All Rights Reserved
# * 
# **************************************************************************/
 
 
 
#/**
# * @file autorun.sh
# * @author xuanbiao(com-qa@baidu.com)
# * @date 2010/01/22 13:24:48
# * @version $Revision: 1.2 $ 
# * @brief  BTest�Զ������ɹ��ߣ�wiki��ַ��http://com.baidu.com/twiki/bin/view/Test/Autorun
# *  
# **/


##! **********************  default conf ***********************

#ѡȡ���Լ�
CONF_PATTERN="test_*"

#ȫ��ͨ�ò���
CONF_COMMON_PARAMS=

#ִ�л����
CONF_ENV_PROJECT_BUILD=
#ִ�л�������
CONF_ENV_PROJECT_CLEAN=


#ִ��ʧ���˳�
CONF_ABORT_ON_FAIL=0

#��ʾ�����Ϣ��ֻ��ִ����Ч
CONF_DISPLAY_OUTPUT=0

#���xml��Ŀǰֻ��ִ����Ч
CONF_OUTPUT_XML=0

#����������Ŀ¼
CONF_REGRESS_OUTPUT="result"
CONF_CCOVER_OUTPUT="ccover"
CONF_VALGRIND_OUTPUT="valgrind"

#��mail�ռ���
CONF_MAILTO=

#log���ã�ָ����·��Ҫ����
CONF_LOG_FILE="autorun.log"
CONF_LOG_LEVEL=16

##! **********************  internal conf ***********************

MAIL_FROM="btest@baidu.com"

MAIL_CC="btest-mon@baidu.com"

#valgrind�������ڴ����ʱ���˳���
VALGRIND_ERROR_EXITCODE=9

#ִ�е������в���
AUTORUN_PARAMS=

##! **********************  atp default conf ***********************

#user[xuanbiao|other]
CONF_ATP_USER=

#password[123456|other] Ŀǰֻ֧���������ģ������õĻ������������ʾ����
#CONF_ATP_PASSWORD=

#server[beta|atp]
CONF_ATP_UPLOAD_SERVER="atp"

#module[public|other]
CONF_ATP_UPLOAD_MODULE=

#suite_from_root[/mcpack|other]
CONF_ATP_UPLOAD_ROOTSUITE=

#upload_case[yes|no]
CONF_ATP_UPLOAD_CASE="yes"

#case_type, default 3:����ִ��
CONF_ATP_UPLOAD_CASETYPE=3

#report xml file
CONF_ATP_UPLOAD_OUTPUT_XML="report.xml"

#run_report[yes|no]
CONF_ATP_UPLOAD_RUN_REPORT="yes"

#jobid
CONF_ATP_UPLOAD_RUN_JOBID=
##! **********************  autorun conf ***********************
VERSION="1.0.4.5"

MODULE_NAME="Autorun"
#MODULE_NAME=`basename $0`

LOG_FATAL=1
LOG_WARNING=2
LOG_NOTICE=4
LOG_TRACE=8
LOG_DEBUG=16
LOG_LEVEL_TEXT=(
	[1]="FATAL"
	[2]="WARNING"
	[4]="NOTICE"
	[8]="TRACE"
	[16]="DEBUG"
)

TTY_FATAL=1
TTY_PASS=2
TTY_TRACE=4
TTY_INFO=8
TTY_MODE_TEXT=(
	[1]="[FAIL ]"
	[2]="[PASS ]"
	[4]="[TRACE]"
	[8]=""
)

#0  OFF  
#1  ������ʾ  
#4  underline  
#5  ��˸  
#7  ������ʾ  
#8  ���ɼ� 

#30  40  ��ɫ
#31  41  ��ɫ  
#32  42  ��ɫ  
#33  43  ��ɫ  
#34  44  ��ɫ  
#35  45  �Ϻ�ɫ  
#36  46  ����ɫ  
#37  47  ��ɫ 
TTY_MODE_COLOR=(
	[1]="1;31"	
	[2]="1;32"
	[4]="0;36"	
	[8]="1;33"
)
WEB_MODE_COLOR=(
        [1]="RED"
        [2]="GREEN"
        [4]="DARKSLATEBLUE"
        [8]="BLUE"
)

##! **********************  usage and version ***********************
function Usage()
{
	echo "usage: $0"
	echo "       -f [conf]        : specify the configuration file, default conf file: conf_autorun.sh"
	echo "       -p pattern       : pattern for select test case"
	echo "       -b command       : build enviroment command"
	echo "       -e command       : clean enviroment command"
	echo "       -l               : show run list"
	echo "       -c [option]      : just compile, option for make"
	echo "       -w               : regard as fail if make warning"
	echo "       -r               : just run"
	echo "       -r0              : just run and no check the result"
	echo "       -t [option]      : compile and run, option for make"
	echo "       -i               : run only the tests whose name matches one of the positive patterns"
	#echo "       --xml            : output xml file, only for run"
	echo "       -s               : display output, only for run"
	echo "       -C0 project_dir  : get the ccover coverage, no compile"
	echo "       -C1 project_dir  : get the ccover coverage, compile and output test.cov"
	echo "       -V               : run valgrind check"
	echo "       -u               : upload case"
	echo "       -x               : abort on fail if set"
	echo "       -m to-addr       : send mail, multiple e-mail address ';' separated"
	echo "       -h               : show this help"
	echo "       -v               : show version"
	exit 0
}

function Version()
{
	echo "version = $VERSION"
	exit 0
}

##! **********************  read conf or xml file ***********************

##! @BRIEF: read conf file(e.g. xxx.sh��xxx.xml)
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => conf filename
##! @RETURN: 0 => success; >=1 => failure 
function ReadConf()
{
	local conf_name="$1"

	#WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO][enter]"
	#�ļ����������˳�
	if [ ! -f ${conf_name} ] 
	then
		#WriteLog $LOG_WARNING "[${FUNCNAME[0]}:$LINENO] conf:${conf_name} is not found!" 
		Print $TTY_FATAL "conf:${conf_name} is not found!"
		return 1
	fi

	local file_ext=${conf_name##*.}
	#�ж������ļ�����
	if [ "${file_ext}" == "xml" ]
	then
		#WriteLog $LOG_WARNING "[${FUNCNAME[0]}:$LINENO] xml file is not supported now!" 
		Print $TTY_FATAL "xml file is not supported now!"
		return 2
	else
		#WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] load conf:${conf_name}" 
		#shell�ű���ʽ�����ü���
		source ${conf_name}
	fi
	#WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO][leave]" 
	return 0
}

function ReadXml()
{
	return 0
}

##! @BRIEF: generate conf file(default name: conf_autorun.conf.demo)
##! @AUTHOR: xuanbiao
##! @RETURN: 0 => success; >=1 => failure 
function GenerateConf()
{
	return 0
}
##! **********************  build/clean Environment ***********************

function BuildProjectEnv()
{
	return 0
}
function CleanProjectEnv()
{
	return 0
}
function BuildCaseEnv()
{
	return 0
}
function CleanCaseEnv()
{
	return 0
}

##! **********************  select test case ***********************

##! @BRIEF: get all test case that match pattern
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => pattern
##! @OUT[string]: $2 => all test case name
##! @RETURN: 0 => sucess; 1 => failure
function GetTestCases()
{
	local pattern="$1"
	local tmp=`ls $pattern 2>/dev/null`

	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] pattern:($pattern)"
	eval $2=\"$tmp\"
	return 0
}
##! **********************  compiler and run ***********************

##! @BRIEF: search warning
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => log file of make
##! @RETURN: 0 => not warning; 1 => found warning
function  SearchWarning()
{
	local log_file="$1"
	local ret=0
	local line
	local path

	while read line
	do
		#line=${line//\`/\'}
		#���˵���warning���У�ֻ�Ǹ��ӵ���ʾ��Ϣ���ѣ�����ȡ·��
		path=`expr "$line" : '\(.\+\.[^:]*:[0-9]\+\): warning:.*'`
		[ $? -ne 0 ] && continue

		#����/usr�µ�warning����g++
		echo $path | grep "/usr/" >/dev/null
		[ $? -eq 0 ] && continue

		#�����ļ�������test��warning
		expr "${path##*/}" : '.*test.*' >/dev/null
		[ $? -eq 0 ] && continue

		#warning��Ϣ
		Print $TTY_TRACE "warning: $path"
		ret=1
	done < $log_file

	return $ret
}
##! @BRIEF: just compile
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => compile option
##! @IN[int] optional: $2 => search warning or not. 0=>not; 1=>yes
##! @RETURN: 0 => success; >=1 => failure 
function Compile()
{
	local option="$1"
	local b_search_warning=${2:-0}
	local result_dir="${CONF_REGRESS_OUTPUT}"
	local log_file="$result_dir/res_makefile.log"

	Print $TTY_TRACE "=============== make =============="
	Print $TTY_TRACE "make clean"

	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO]make clean"
	#make clean
	make clean

	#make
	#���resultĿ¼�������򴴽�
	[ ! -d $result_dir ] && mkdir $result_dir

	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO]make $option"
	Print $TTY_TRACE "make $option"
	#������warning����Ҫ��make������Ϣ�ض���log�ļ����Ա��һ������
	[ ${b_search_warning} -eq 1 ] && make $option 2>$log_file || make $option
	#�������ʧ���򷵻�
	if [ $? -ne 0 ]
	then
		WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO]make fail"
		Print $TTY_FATAL "Make fail!"
		return 1
	fi

	#����wanring
	if [ ${b_search_warning} -eq 1 ]
	then
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO]search warning from $log_file"
		SearchWarning "$log_file"
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO]Make ok, but warning:$log_file"
			Print $TTY_FATAL "Make ok, but warning! [$log_file]"
			return 2
		fi
	fi

	#����ɹ��Ż�
	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO]make ok"
	Print $TTY_PASS "Make ok!"
	return 0
}


function GenCoreFileList()
{
	local before_file_name="$1"
	local core_file_list=`ls core\.* 2>/dev/null`

	 > $before_file_name
	if [ $? -eq 0 ]
	then
		for core_file in $core_file_list
		do
			echo $core_file >> $before_file_name 
		done
	fi
}

function GetCoreFileName()
{
	local before_file_name="$1"
	local after_file_name="$2"

	RECENTLY_CORE_FILE_NAME=`sort $before_file_name $after_file_name | uniq -u`

	rm -f $before_file_name
	rm -f $after_file_name

	return
}



##! @BRIEF: ִ��ѡȡ�Ĳ��Լ�
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => pattern ѡȡģʽ
##! @IN[int]: $2 => mode 0=>not check; 1=>check
##! @IN[int]: $3 => report or not �Ƿ���ʾ�������
##! @IN[int]: $4 => send mail or not �Ƿ���mail
##! @IN[int]: $5 => upload case or not �Ƿ��ϴ�case
##! @RETURN: 0 => success; >=1 => failure 
function Run()
{
	local pattern="${1:-${CONF_PATTERN}}"
	local b_check="${2:-1}"
	local b_report="${3:-0}"
	local b_mail="${4:-0}"
	local b_upload="${5:-0}"
	local result_dir="${CONF_REGRESS_OUTPUT}"
	local log_file
	local ret

	RECENTLY_CORE_FILE_NAME=""
	local before_core_file_list="core_file_list.before"
	local after_core_file_list="core_file_list.after"

	local run_start_time
	local run_finish_time
	Print $TTY_TRACE "=============== run =============="

	#�����Ҫ�ϴ�case
	if [ $b_upload -eq 1 ] 
	then
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] load libautotest.sh"
		source libautotest.sh
		#����ʧ��
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] load libautotest.sh fail!"
			Print $TTY_FATAL "load libautotest.sh fail!"
			return 1
		fi
		#�򿪱���
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] open_report"
		open_report
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] open_report fail!"
			Print $TTY_FATAL "open_report fail!"
			return 1
		fi
		local tmp_xml_dir=`dirname $AT_LOGFILE`
		#���report.xml���Ǳ����ڵ�ǰĿ¼������Ϊ����·��������atpƽִ̨��
		if [ "$tmp_xml_dir" != "${PWD}" ]
		then
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] AT_LOGFILE:$AT_LOGFILE"
			CONF_ATP_UPLOAD_OUTPUT_XML=$AT_LOGFILE
		fi
	fi
	#���resultĿ¼�������򴴽�
	[ ! -d $result_dir ] && mkdir $result_dir

	run_start_time=`date "+%Y-%m-%d %H:%M:%S"`
	#�����
	if [ -n "${CONF_ENV_PROJECT_BUILD}" ] 
	then
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] build environment, command:${CONF_ENV_PROJECT_BUILD}"
		Print $TTY_TRACE "[ENV_PROJECT_BUILD] ${CONF_ENV_PROJECT_BUILD}"
		log_file="$result_dir/res_env_project_build.log"
		eval "${CONF_ENV_PROJECT_BUILD}" >$log_file 2>/dev/null
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] build environment fail, command:${CONF_ENV_PROJECT_BUILD}"
			Print $TTY_FATAL "[ENV_PROJECT_BUILD] ${CONF_ENV_PROJECT_BUILD} fail!"
			return 1
		fi
	fi

	local all_test_case_name
	local test_case_name
	local test_case_command
	local t_start
	local t_end
	#��ȡѡȡ�Ĳ��Լ�
	GetTestCases "$pattern" all_test_case_name

	local run_error_infos=()
	local run_total_count=0
	local run_error_count=0
	local run_case_cost=()
	local run_case_result=()

	local run_log_file=()
	#ִ��ѡȡ�Ĳ��Լ�
	echo "backtrace" > gdb.cmd
	echo "quit" >> gdb.cmd
	for test_case_name in $all_test_case_name
	do
		if [ -x $test_case_name ]
		then
			#���ǵ�pattern����������Ŀ¼�ĳ�������log����"/"�滻Ϊ"_"
			#��sub/test_xxx���滻��sub_test_xxx
			log_file="$result_dir/res_${test_case_name//\//_}.log"
			run_log_file[$run_total_count]=$log_file
			backtrace_file="$result_dir/res_${test_case_name//\//_}.backtrace.log"

			#��ȡִ��ǰ��ʱ��
			t_start=`date +%s`
			if [ -n "${CONF_COMMON_PARAMS}" ]
			then
				test_case_command="./${test_case_name} ${CONF_COMMON_PARAMS}"
			else
				test_case_command="./${test_case_name}"
			fi
			#AT_BEGINGSUITE
			if [ $b_upload -eq 1 ] 
			then
				test_case_command="${test_case_command} --gtest_output=atp:${CONF_ATP_UPLOAD_OUTPUT_XML}"
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] write_report \$AT_BEGINSUITE $test_case_name"
				write_report $AT_BEGINSUITE $test_case_name
				if [ $? -ne 0 ]
				then
					WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] write_report \$AT_BEGINSUITE $test_case_name fail!"
					Print $TTY_FATAL "write_report \$AT_BEGINSUITE $test_case_name fail!"
				fi
			elif [ ${CONF_OUTPUT_XML} -eq 1 ]
			then
				test_case_command="${test_case_command} --gtest_output=xml:$result_dir/res_${test_case_name//\//_}.xml"
			fi

			#ִ�о���ĳ���
			#WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] run command:${test_case_command}"
			#./${test_case_name} ${CONF_COMMON_PARAMS} >$log_file 2>&1
			#${test_case_command} >$log_file 2>&1
			if [ ${CONF_DISPLAY_OUTPUT} -eq 1 ]
			then
				eval "${test_case_command}"
				ret=$?
			else
				GenCoreFileList $before_core_file_list	
				eval "${test_case_command} >$log_file 2>&1"
				ret=$?
				if [ $ret -ne 0 ]
				then
					GenCoreFileList $after_core_file_list
					GetCoreFileName $before_core_file_list $after_core_file_list
					if [ "$RECENTLY_CORE_FILE_NAME" != "" ]
					then
						gdb ./${test_case_name} ${RECENTLY_CORE_FILE_NAME} --command=gdb.cmd > $backtrace_file 2>&1
					fi
				fi
			fi

			#AT_ENDSUITE
			if [ $b_upload -eq 1 ] 
			then
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] write_report \$AT_ENDSUITE ($test_case_name)"
				write_report $AT_ENDSUITE
				if [ $? -ne 0 ]
				then
					WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] write_report \$AT_ENDSUITE ($test_case_name) fail!"
					Print $TTY_FATAL "write_report \$AT_ENDSUITE ($test_case_name) fail!"
				fi
			fi

			#��ȡִ�к��ʱ��
			t_end=`date +%s`
			let t_end=t_end-t_start

			run_case_cost[$run_total_count]=${t_end}
			#�����Ҫ�жϳ���ɹ����
			if [ $b_check -ne 0 ]
			then
				if [ $ret -eq 0 ]
				then
					WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] ${test_case_command} run pass(${t_end}s)"
					Print $TTY_PASS "${test_case_command} Run ok! (${t_end}s)"
					run_case_result[$run_total_count]=0
				else
					WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] ${test_case_command} run fail(${t_end}s)"
					Print $TTY_FATAL "${test_case_command} Run fail! (${t_end}s)"
					run_case_result[$run_total_count]=1
					run_error_infos[$run_error_count]="${test_case_name} Run fail! [$log_file]"
					let run_error_count++
				fi
			else
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] ${test_case_command} run finish(${t_end}s)"
				Print $TTY_TRACE "${test_case_command} Run finish! (${t_end}s)"
			fi
			let run_total_count++
			
			#���������˳�
			if [ ${CONF_ABORT_ON_FAIL} -eq 1 ] && [ $run_error_count -gt 0 ]
			then
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] abort on fail"
				break
			fi
		fi
	done
	rm -f gdb.cmd

	#��������
	if [ -n "${CONF_ENV_PROJECT_CLEAN}" ] 
	then
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] clean environment, command:${CONF_ENV_PROJECT_BUILD}"
		Print $TTY_TRACE "[ENV_PROJECT_CLEAN] ${CONF_ENV_PROJECT_CLEAN}"
		log_file="$result_dir/res_env_project_clean.log"
		eval "${CONF_ENV_PROJECT_CLEAN}" >$log_file 2>/dev/null
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] clean environment fail, command:${CONF_ENV_PROJECT_BUILD}"
			Print $TTY_FATAL "[ENV_PROJECT_CLEAN] ${CONF_ENV_PROJECT_CLEAN} fail!"
			return 1
		fi
	fi
	run_finish_time=`date "+%Y-%m-%d %H:%M:%S"`

	#ͳ��ִ�и���
	CollectInfo "countofcases" ${run_total_count}
	#���������Ϣ
	if [ ${b_check} -ne 0 ] && [ ${b_report} -eq 1 ]
	then
		Report "run" $run_total_count $run_error_count run_error_infos 
	fi

	#��Ҫ�ϴ�case
	if [ $b_upload -eq 1 ] 
	then
		#WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] write_report \$AT_ENDSUITE (${CONF_ATP_UPLOAD_MODULE}:${CONF_ATP_UPLOAD_ROOTSUITE})"
		#write_report $AT_ENDSUITE
		#if [ $? -ne 0 ]
		#then
		#	WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] write_report \$AT_ENDSUITE (${CONF_ATP_UPLOAD_MODULE}:${CONF_ATP_UPLOAD_ROOTSUITE}) fail!"
		#	Print $TTY_FATAL "write_report \$AT_ENDSUITE (${CONF_ATP_UPLOAD_MODULE}:${CONF_ATP_UPLOAD_ROOTSUITE}) fail!"
		#	return 1
		#fi
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] close_report"
		close_report
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] close_report fail!"
			Print $TTY_FATAL "close_report fail!"
			return 1
		fi
		if [ -z "${CONF_ATP_PASSWORD}" ]
		then
			echo -n "Please input password for user '${CONF_ATP_USER}': "
			stty -echo
			#��ץCtrl + C�źţ����ⲻ����Ӱ���ն�~
			#trap 'echo "";stty echo; exit 1' TERM INT
			read  CONF_ATP_PASSWORD
			stty echo
			#trap 'exit 1' TERM INT
			echo ""
		fi
		#upper�Ƿ����
		#if [ ! -f upper ]
		#then
		#	WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] upper is not exist!"
		#	Print $TTY_FATAL "upper is not exist!"
		#	return 1
		#fi
		#�ϴ�case
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] rp_upper upload case and report"
		#rp_upper -u "${CONF_ATP_USER}" \
		rp_upper -u "${CONF_ATP_USER}" -p "${CONF_ATP_PASSWORD}" \
		-s "${CONF_ATP_UPLOAD_SERVER}" -f "${CONF_ATP_UPLOAD_OUTPUT_XML}" \
		-m "${CONF_ATP_UPLOAD_MODULE}" -r "${CONF_ATP_UPLOAD_ROOTSUITE}" \
		-c "${CONF_ATP_UPLOAD_CASE}" -t "${CONF_ATP_UPLOAD_CASETYPE}" \
		-R "${CONF_ATP_UPLOAD_RUN_REPORT}" -J "${CONF_ATP_UPLOAD_RUN_JOBID}" #>/dev/null 2>&1
		ret=$?
		if [ $ret -eq 127 ]
		then
			Print $TTY_FATAL "upper is not found!"
		elif [ $ret -eq 4 ]
		then
			Print $TTY_FATAL "login fail, password is wrong!"
		else
			if [ "${CONF_ATP_UPLOAD_CASE}" == "yes" ]
			then
				if [ $ret -eq 2 ] || [ $ret -eq 3 ]
				then
					Print $TTY_FATAL "upload case fail!"
				else
					Print $TTY_PASS "upload case sucess!"
				fi
			fi
			if [ "${CONF_ATP_UPLOAD_RUN_REPORT}" == "yes" ]
			then
				if [ $ret -eq 1 ] || [ $ret -eq 3 ]
				then
					Print $TTY_FATAL "upload report fail!"
				else
					Print $TTY_PASS "upload report sucess!"
				fi
			fi
		fi

	fi

	#����mail
	if [ ${b_mail} -eq 1 ] && [ -n "${CONF_MAILTO}" ]
	then
		local tmp_xml=$(mktemp)
		
		echo '<?xml version="1.0" encoding="utf-8"?>' >> $tmp_xml
		echo '<btest type="regress">' >> $tmp_xml

		local run_pass_count
		let run_pass_count=run_total_count-run_error_count
		local subject="[BTest] ��ɲ���ִ�У�${run_pass_count}��case�ɹ���${run_error_count}��caseʧ��"
		echo -e '\t<mail from="'${MAIL_FROM}'" to="'${CONF_MAILTO}'" cc="'${MAIL_CC}'" subject="'$subject'" />' >> $tmp_xml

		echo -e '\t<info user="'$USER'" machine="'$HOSTNAME'" path="'$PWD'" />' >> $tmp_xml
		local cmd=`basename $0`" $AUTORUN_PARAMS"
		echo -e '\t<run cmd="'$cmd'" start="'$run_start_time'" end="'$run_finish_time'" />' >> $tmp_xml
		echo -e '\t<regress tests="'${run_total_count}'" failures="'${run_error_count}'" disabled="0" errors="0">' >> $tmp_xml

		local count=0
		for test_case_name in $all_test_case_name
		do
			if [ -x $test_case_name ]
			then
				log_file=${run_log_file[$count]}
				if [ -n "${CONF_COMMON_PARAMS}" ]
				then
					test_case_command="./${test_case_name} ${CONF_COMMON_PARAMS}"
				else
					test_case_command="./${test_case_name}"
				fi
				echo -e '\t\t<testcase name="'$test_case_command'" status="'${run_case_result[$count]}'" time="'${run_case_cost[$count]}s'" log="'${log_file}'" /> ' >> $tmp_xml
				let count++
			fi
		done
		echo -e '\t</regress>' >> $tmp_xml
		echo '</btest>' >> $tmp_xml

		local report_xml="$result_dir/report_regress.xml"
		#ת����utf8��ʽ
		iconv -f gbk -t utf8 -o $report_xml $tmp_xml

		#����mail
		/home/xuanbiao/svn/com/btest/main/autorun/btest_mail.py $report_xml

		if [ $? -eq 0 ]
		then
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} sucess"
		else
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} fail"
		fi
		#local title="[BTest] ģ��${PWD}����˲���ִ�У�${run_pass_count}��case�ɹ���${run_error_count}��caseʧ��"
		#SendMail "$mailto" "$title" "$body" run_log_file
	fi
	return 0
}

##! **********************  run ccover  ***********************

##! @BRIEF: run ccover
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => project_dir��·������~public/mcpack
##! @IN[int]: $2 => compile or not
##! @RETURN: 0 => sucess; 1 => failure
function RunCcover()
{
	local project_dir="$1"
	local b_compile_project=${2:-0}
	local work_dir=`pwd`
	local result_dir="${CONF_CCOVER_OUTPUT}"
	local ret=0

	local run_start_time
	local run_finish_time
	Print $TTY_TRACE "=============== Run Ccover =============="

	#���·��Ϊ�ջ���Ŀ¼
	if [ -z $project_dir ] || [ ! -d $project_dir ]
	then
		WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] $project_dir is not a current directory"
		Print $TTY_FATAL "$project_dir is not a current directory!"
		return 1
	fi
	run_start_time=`date "+%Y-%m-%d %H:%M:%S"`
	#����ccover�汾��lib��
	if [ $b_compile_project -eq 1 ]
	then
		cd $project_dir
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] open ccover:cov01 -1"
		#����֮ǰ����COVBUILDZONE����Ӱ������session
		export COVBUILDZONE=`date +%s%N`
		#����ccover
		cov01 -1

		#����COVFILE��������
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] export COVFILE=${PWD}/test.cov"
		#export COVFILE=$project_dir/test.cov
		export COVFILE=${PWD}/test.cov

		#ת����Ŀ��·���������test.cov�ļ�
		rm test.cov 2>/dev/null

		local time
		local b_output_exist=0
		#�������ouputĿ¼�򱣴�
		if [ -d "output" ] 
		then
			time=`date +%s`
			mv output output_$time
			b_output_exist=1
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] backup output to output_$time($PWD)"
		fi
		#����ccover�汾��lib��
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] compile($PWD)"
		Compile
		#����ʧ�ܴ���
		if [ $? -ne 0 ]
		then
<<TXT
			if [ $b_output_exist -eq 1 ]
			then
				rm -rf output
				mv output_$time output
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] recover output_$time to output($PWD)"
			fi
TXT
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] compile error($PWD)"
			Print $TTY_FATAL "($project_dir) Compile error!"
			#�л���ԭ���Ĺ���Ŀ¼
			cd $work_dir
			return 3
		fi

		#�лص����Դ���·����������
		cd $work_dir

		#����֮ǰ���õ���ĿCOVFILE
		local prj_covfile=${COVFILE}
		#��������COVFILE����������������Ŀ¼��ccover��Ϣ����
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] export COVFILE=${PWD}/test.cov"
		export COVFILE=${PWD}/test.cov

		#����֮ǰ�Ȱ���ǰ��ɾ��
		rm test.cov 2>/dev/null
		#������Դ���
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] compile($PWD)"
		Compile "VERSION="
		#rm test.cov 2>/dev/null
		#�ָ���Ŀ��COVFILE
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] export COVFILE=${prj_covfile}"
		export COVFILE=${prj_covfile}

		#���в��Գ����ȡccover��Ϣ
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] run test case($PWD)"
		Run

<<TXT
		cd $project_dir
		#��ԭԭ����outputĿ¼
		if [ $b_output_exist -eq 1 ]
		then
			rm -rf output
			mv output_$time output
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] recover output_$time to output($PWD)"
		fi
TXT
		#�л���ԭ���Ĺ���Ŀ¼
		cd $work_dir
		#�ر�ccover
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] close ccover:cov01 -0"
		cov01 -0
	fi

	#����test.cov
	local prj_cov
	ProcessCovfile "$project_dir" "${work_dir}/${result_dir}"
	ret=$?
	prj_cov=(${REPLY[@]})
	run_finish_time=`date "+%Y-%m-%d %H:%M:%S"`

	#��ӡ����
	if [ $ret -eq 0 ]
	then
		ReportCcover "$opt_project_dir"
	fi

	#����mail
	if [ -n "${CONF_MAILTO}" ]
	then
		local tmp_xml=$(mktemp)
		
		echo '<?xml version="1.0" encoding="utf-8"?>' >> $tmp_xml
		echo '<btest type="ccover">' >> $tmp_xml

		local subject="[BTest] ���Ccoverͳ�ƣ�Function=${prj_cov[0]}��CD=${prj_cov[1]}"
		echo -e '\t<mail from="'${MAIL_FROM}'" to="'${CONF_MAILTO}'" cc="'${MAIL_CC}'" subject="'$subject'" />' >> $tmp_xml

		echo -e '\t<info user="'$USER'" machine="'$HOSTNAME'" path="'$PWD'" />' >> $tmp_xml
		local cmd=`basename $0`" $AUTORUN_PARAMS"
		echo -e '\t<run cmd="'$cmd'" start="'$run_start_time'" end="'$run_finish_time'" />' >> $tmp_xml
		echo -e '\t<ccover Function="'${prj_cov[0]}'" CD="'${prj_cov[1]}'" resultdir="'$result_dir'" />' >> $tmp_xml
		echo '</btest>' >> $tmp_xml

		local report_xml="$result_dir/report_ccover.xml"
		#ת����utf8��ʽ
		iconv -f gbk -t utf8 -o $report_xml $tmp_xml

		#����mail
		/home/xuanbiao/svn/com/btest/main/autorun/btest_mail.py $report_xml

		if [ $? -eq 0 ]
		then
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} sucess"
		else
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} fail"
		fi
		return 0

		#SendMail "$mailto" "$title" "$body" ccover_attachs
		#cat $output_dir/project_covsrc.txt | mutt -s "[Autorun] Ccover���" -a $output_dir/project_covsrc.html "${CONF_MAILTO}"
	fi
	return $ret
}

##! @BRIEF: ����test.cov�ļ�
##! @AUTHOR: xuanbiao
##! @IN[string] $1 => ��·������~public/mcpack
##! @IN[string] $2 => ���ccover���·��
##! @RETURN: 0 => sucess; 1 => failure
function ProcessCovfile()
{
	local project_dir="$1"
	local output_dir="$2"
	local work_dir=`pwd`

	#���û�������
	export COLUMNS=150
	#export COVSRCDIR=$project_dir

	if [ -z $project_dir ] || [ ! -d $project_dir ]
	then
		WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] $project_dir is not a current directory"
		Print $TTY_FATAL "$project_dir is not a current directory!"
		return 1
	fi

	#�ж��Ƿ�������COVFILE���ߵ�ǰĿ¼����test.cov�ļ�
	if [ -z ${COVFILE} ] && [ ! -f "$project_dir/test.cov" ]
	then
		if [ ! -f "$project_dir/test.cov" ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] COVFILE is not set and can't find test.cov in $project_dir"
			Print $TTY_FATAL "COVFILE is not set and can't find test.cov in $project_dir!"
			return 2
		else
			export COVFILE=$project_dir/test.cov
		fi
	fi

	#�������ccover�����Ŀ¼
	if [ ! -d $output_dir ] 
	then
		mkdir $output_dir
	fi

	#�л���project_dirĿ¼����
	cd $project_dir

	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] analyze ccover data"
	covsrc $project_dir --no-banner > $output_dir/"project_covsrc.txt"
	covsrc $project_dir --html --no-banner > $output_dir/"project_covsrc.html"

	local source
	local cur
	local out_covfn
	local out_covbr

	#��Ϊ�ú����ķ������ݣ����������ͷ�֧�ĸ�����
	#REPLY=(`covsrc . -c -k --no-banner | awk -F ',' '{print $4" "$7}'`)
	REPLY=(`tail -n 1 $output_dir/project_covsrc.txt | awk '{print $6,$11}'`)
	#��ȡ���е�Դ�ļ����������·��
	source=(`covsrc $project_dir -c -k --no-banner | awk -F '"' '{print $2;}' | xargs`)
	for((i=0; $i<${#source[@]}; i=$i+1))
	do
		#������Դ��һ�µ�Ŀ¼�ṹ
		cur=`dirname ${source[$i]}`
		mkdir -p $output_dir/$cur
		#��ȡ����ļ���
		out_covfn=`echo ${source[$i]} | sed -e 's/\(.*\)\.\(.*\)/\1_\2_covfn.html/g'`
		out_covbr=`echo ${source[$i]} | sed -e 's/\(.*\)\.\(.*\)/\1_\2_covbr.html/g'`
		#��html��ʽ���
		covfn ${source[$i]} --html --no-banner > $output_dir/$out_covfn
		if [ $? -ne 0 ]
		then
			Print $TTY_FATAL "covfn ${source[$i]} error!"
			WriteLog $LOG_WARNING "[${FUNCNAME[0]}:$LINENO] covfn ${source[$i]} error"
		fi
		covbr ${source[$i]} --html --no-banner > $output_dir/$out_covbr
		if [ $? -ne 0 ]
		then
			Print $TTY_FATAL "covbr ${source[$i]} error!"
			WriteLog $LOG_WARNING "[${FUNCNAME[0]}:$LINENO] covbr ${source[$i]} error"
		fi
		Print $TTY_TRACE "${source[$i]} done!"
		WriteLog $LOG_TRACE "[${FUNCNAME[0]}:$LINENO] ${source[$i]} done"
	done

	#�л���ԭ����Ŀ¼
	cd $work_dir

	return 0
}

##! **********************  run valgrind  ***********************

##! @BRIEF: run valgrind
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => pattern
##! @IN[string]: $2 => valgrind options ����valgrind�Ĳ���
##! @IN[int]: $3 => report or not �Ƿ���ʾ�������
##! @RETURN: 0 => sucess; 1 => failure
function RunValgrind()
{
	local pattern="${1:-${CONF_PATTERN}}"
	local options="$2"
	local b_report="${3:-0}"

	local b_default=0
	#local default_options="--error-exitcode=${VALGRIND_ERROR_EXITCODE} --leak-check=full --track-fds=yes"
	local default_options="--error-exitcode=${VALGRIND_ERROR_EXITCODE} --leak-check=full --track-fds=yes"
	local error_no
	local error_msg
	local result_dir="${CONF_VALGRIND_OUTPUT}"
	local log_file

	local run_start_time
	local run_finish_time
	Print $TTY_TRACE "=============== valgrind check =============="

	local version
	#�ж�valgrind�Ƿ����
	version=`valgrind --version 2>/dev/null`
	if [ $? -ne 0 ]
	then
		WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] Valgrind is not exist"
		Print $TTY_FATAL "Valgrind is not exist!"
		return 1
	fi
	#Print $TTY_INFO "valgrind version: $version"

	#����û�û�д�valgrind������ʹ��Ĭ�ϲ������
	if [ -z "$options" ]
	then
		options=$default_options
		b_default=1
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] default valgrind options:$options"
	fi

	#���resultĿ¼�������򴴽���Ŀ¼
	[ ! -d "$result_dir" ] && mkdir $result_dir

	run_start_time=`date "+%Y-%m-%d %H:%M:%S"`
	#�����
	if [ -n "${CONF_ENV_PROJECT_BUILD}" ] 
	then
		WriteLog $LOG_TRACE "[${FUNCNAME[0]}:$LINENO] build environment:${CONF_ENV_PROJECT_BUILD}"
		Print $TTY_TRACE "[ENV_PROJECT_BUILD] ${CONF_ENV_PROJECT_BUILD}"
		log_file="$result_dir/res_env_project_build.log"
		eval "${CONF_ENV_PROJECT_BUILD}" >$log_file 2>/dev/null
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] build environment fail:${CONF_ENV_PROJECT_BUILD}"
			Print $TTY_FATAL "[ENV_PROJECT_BUILD] ${CONF_ENV_PROJECT_BUILD} fail!"
			return 1
		fi
	fi

	local all_test_case_name
	local test_case_name
	local test_case_command
	local t_start
	local t_end
	#��ȡѡȡ�Ĳ��Լ�
	GetTestCases "$pattern" all_test_case_name

	local run_vg_error_infos=()
	local run_vg_total_count=0
	local run_vg_error_count=0

	local run_vg_case_cost=()
	local run_vg_case_result=()

	local run_vg_log_file=()
	#ִ��ѡȡ�Ĳ��Լ�
	for test_case_name in $all_test_case_name
	do
		if [ -x $test_case_name ]
		then
			#���ǵ�pattern����������Ŀ¼�ĳ�������log����"/"�滻Ϊ"_"
			#��sub/test_xxx���滻��sub_test_xxx
			log_file="$result_dir/vg_${test_case_name//\//_}.log"
			run_vg_log_file[$run_vg_total_count]=$log_file
			#��ȡִ��ǰ��ʱ��
			t_start=`date +%s`
			if [ -n "${CONF_COMMON_PARAMS}" ]
			then
				test_case_command="./${test_case_name} ${CONF_COMMON_PARAMS}"
			else
				test_case_command="./${test_case_name}"
			fi
			#ִ�о���ĳ���
			#valgrind $options ./${test_case_name} >/dev/null 2>$log_file
			#valgrind $options $test_case_command >/dev/null 2>$log_file
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] valgrind $options $test_case_command >/dev/null 2>$log_file"
			eval "valgrind $options $test_case_command >/dev/null 2>$log_file"
			ret=$?
			#��ȡִ�к��ʱ��
			t_end=`date +%s`
			let t_end=t_end-t_start

			run_vg_case_cost[$run_vg_total_count]=${t_end}

			#����valgrind���
			[ $b_default -eq 1 ] && ProcessValgrindResult $ret "$log_file" error_msg
			error_no=$?
			if [ $error_no -eq 0 ]
			then
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] $test_case_name <valgrind> check ok(${t_end}s)"
				Print $TTY_PASS "$test_case_name <valgrind> check ok! (${t_end}s)"
			else
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] $test_case_name <valgrind> check fail! Error: $error_msg(${t_end}s)"
				Print $TTY_FATAL "$test_case_name <valgrind> check fail! Error: $error_msg (${t_end}s)"
				run_vg_error_infos[$run_vg_error_count]="${test_case_name} <valgrind> check fail! Error: $error_msg [$log_file]"
				let run_vg_error_count++
			fi
			run_vg_case_result[$run_vg_total_count]=$error_no
			#��valgrind��log�ļ�ת����windows��ʶ���ʽ
			unix2dos $log_file >/dev/null 2>&1

			let run_vg_total_count++

			#���������˳�
			if [ ${CONF_ABORT_ON_FAIL} -eq 1 ] && [ $run_vg_error_count -gt 0 ]
			then
				WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] abort on fail"
				break
			fi
		fi
	done

	#��������
	if [ -n "${CONF_ENV_PROJECT_CLEAN}" ] 
	then
		WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] clean environment :${CONF_ENV_PROJECT_BUILD}"
		Print $TTY_TRACE "[ENV_PROJECT_CLEAN] ${CONF_ENV_PROJECT_CLEAN}"
		log_file="$result_dir/res_env_project_clean.log"
		eval "${CONF_ENV_PROJECT_CLEAN}" >$log_file 2>/dev/null
		if [ $? -ne 0 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] clean environment fail:${CONF_ENV_PROJECT_BUILD}"
			Print $TTY_FATAL "[ENV_PROJECT_CLEAN] ${CONF_ENV_PROJECT_CLEAN} fail!"
			return 1
		fi
	fi
	run_finish_time=`date "+%Y-%m-%d %H:%M:%S"`

	#ͳ��ִ�и���
	CollectInfo "countofcases" ${run_vg_total_count}
	#�������
	if [ ${b_report} -eq 1 ]
	then
		Report "valgrind" $run_vg_total_count $run_vg_error_count run_vg_error_infos 
	fi

	#����mail
	if [ -n "${CONF_MAILTO}" ]
	then
		local tmp_xml=$(mktemp)
		
		echo '<?xml version="1.0" encoding="utf-8"?>' >> $tmp_xml
		echo '<btest type="valgrind">' >> $tmp_xml

		local run_vg_pass_count
		let run_vg_pass_count=run_vg_total_count-run_vg_error_count
		local subject="[BTest] ���Valgrind��飺${run_vg_pass_count}��case�ɹ���${run_vg_error_count}��caseʧ��"
		echo -e '\t<mail from="'${MAIL_FROM}'" to="'${CONF_MAILTO}'" cc="'${MAIL_CC}'" subject="'$subject'" />' >> $tmp_xml

		echo -e '\t<info user="'$USER'" machine="'$HOSTNAME'" path="'$PWD'" />' >> $tmp_xml
		local cmd=`basename $0`" $AUTORUN_PARAMS"
		echo -e '\t<run cmd="'$cmd'" start="'$run_start_time'" end="'$run_finish_time'" />' >> $tmp_xml
		echo -e '\t<valgrind tests="'${run_vg_total_count}'" failures="'${run_vg_error_count}'" disabled="0" errors="0" params="'$options'">' >> $tmp_xml

		local count=0
		for test_case_name in $all_test_case_name
		do
			if [ -x $test_case_name ]
			then
				log_file=${run_vg_log_file[$count]}
				if [ -n "${CONF_COMMON_PARAMS}" ]
				then
					test_case_command="./${test_case_name} ${CONF_COMMON_PARAMS}"
				else
					test_case_command="./${test_case_name}"
				fi
				echo -e '\t\t<testcase name="'$test_case_command'" status="'${run_vg_case_result[$count]}'" time="'${run_vg_case_cost[$count]}s'" log="'${log_file}'" /> ' >> $tmp_xml
				let count++
			fi
		done
		echo -e '\t</valgrind>' >> $tmp_xml
		echo '</btest>' >> $tmp_xml

		local report_xml="$result_dir/report_valgrind.xml"
		#ת����utf8��ʽ
		iconv -f gbk -t utf8 -o $report_xml $tmp_xml

		#����mail
		/home/xuanbiao/svn/com/btest/main/autorun/btest_mail.py $report_xml

		if [ $? -eq 0 ]
		then
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} sucess"
		else
			WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] send mail to ${CONF_MAILTO} fail"
		fi
		return 0
		#local title="[BTest] ģ��${PWD}����˲���ִ�У�${run_pass_count}��case�ɹ���${run_error_count}��caseʧ��"
		#SendMail "$mailto" "$title" "$body" run_log_file
	fi
	return 0
}

##! @BRIEF: ����valgrind���
##! @AUTHOR: xuanbiao
##! @IN[int]: $1 => valgrind exit code
##! @IN[string]: $2 => valgrind log file name
##! @OUT[string]: $3 => error message
##! @RETURN: 0 => pass; 1 => fail
function ProcessValgrindResult()
{
	local exit_code=$1
	local log_file="$2"

	#�ڴ�й©���
	local key_mem_leak="LEAK SUMMARY"
	#�޷�ʹ��local�����Σ�����
	key_mem_lost=(
		"definitely lost"
		"possibly lost"
		"still reachable"
		"suppressed")
	local level_mem_leak_max=1

	#���й©���
	local key_fd_leak="FILE DESCRIPTORS: "
	#Ĭ�ϻ���ڱ�׼���롢��׼����ͱ�׼�������3�����
	local legal_fd_leak_num=3

	local tmpbuf
	local tmp
	local i

	if [ ! -f "$log_file" ]
	then
		eval $3=\"$log_file is not exist!\"
		return 5
	fi

	#�ж�valgrind exit code�Ƿ�����ڴ����
	if [ $exit_code -eq ${VALGRIND_ERROR_EXITCODE} ]
	then
		eval $3=\"memory error!\"
		return 1
	fi

	#�����Ƿ�����ڴ�й©
	#tmpbuf=`tail -n 10 $log_file | grep "$key_leak" 1>/dev/null 2>&1`
	tmpbuf=`tail -n 10 $log_file`
	#ƥ���ڴ�й©�ؼ��֣��ж��Ƿ���ܴ����ڴ�й©
	expr match "$tmpbuf" ".*${key_mem_leak}" >/dev/null 2>&1
	if [ $? -eq 0 ]
	then
		#�ж��ڴ�й©�ĵȼ�
		for(( i=0; i<${#key_mem_lost[@]}; i=$i+1 ))
		do
			tmp=`expr match "$tmpbuf" ".*${key_mem_lost[$i]}: \([0-9,]*\)"`
			[ $? -eq 0 ] && [ ${tmp:-"0"} != "0" ] && break
		done
		#�ڴ�й©�ȼ�<=level_leak_max����Ϊ�����ڴ�й©
		if [ $i -le $level_mem_leak_max ]
		then
			eval $3=\"memory leak! ${key_mem_lost[$i]} $tmp bytes!\"
			return 2
		fi
	fi

	#����Ƿ���ھ��й©
	tmpbuf=`grep "$key_fd_leak" $log_file`
	if [ $? -eq 0 ]
	then
		#�ӽ�βƥ��й©�ľ����
		tmp=`expr match "${tmpbuf}" ".*\([0-9]\+\)"`
		#й©�ľ�� > legal_fd_leak_num����Ϊ���й©
		if [ $? -eq 0 ] && [ ${tmp:-0} -gt $legal_fd_leak_num ]
		then
			eval $3=\"fd leak : $tmp open at exit!\"
			return 3
		fi
	fi

	#�ж�valgrind exit code�Ƿ�ִ��ʧ��
	if [ $exit_code -ne 0 ]
	then
		eval $3=\"run fail!\"
		return 4
	fi

	return 0
}

##! **********************  show result ***********************

##! @BRIEF: show the run list
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => pattern
##! @RETURN: 0 => sucess; 1 => failure
function ShowList()
{
	#local pattern="$1"
	local pattern="${1:-${CONF_PATTERN}}"
	local count=0

	Print $TTY_TRACE "run list"
	#�����
	[ -n "${CONF_ENV_PROJECT_BUILD}" ] && Print $TTY_INFO "[ENV_PROJECT_BUILD] ${CONF_ENV_PROJECT_BUILD}"

	#local all_test_case_name=`ls $pattern 2>/dev/null`
	local all_test_case_name
	local test_case_name
	local test_case_command
	GetTestCases "$pattern" all_test_case_name
	#ѡȡ��ִ��case
	for test_case_name in $all_test_case_name
	do
		if [ -x $test_case_name ]
		then
			if [ -n "${CONF_COMMON_PARAMS}" ]
			then
				test_case_command="${test_case_name} ${CONF_COMMON_PARAMS}"
			else
				test_case_command="${test_case_name}"
			fi
			#ִ�о���ĳ���
			Print $TTY_INFO "----  $test_case_command"
			let count++
		fi
	done
	#��������
	[ -n "${CONF_ENV_PROJECT_CLEAN}" ] && Print $TTY_INFO "[ENV_PROJECT_CLEAN] ${CONF_ENV_PROJECT_CLEAN}"

	#��ʾcase��
	if [ $count -eq 0 ]
	then
		Print $TTY_TRACE "No any case to run!!"
	else
		Print $TTY_TRACE "$count case to run!!"
	fi
	return 0
}

##! @BRIEF: report result
##! @AUTHOR: xuanbiao
##! @IN[string]: $1 => mode: run/valgrind
##! @IN[int]: $2 => count of run case ִ�е�case����
##! @IN[int]: $3 => count of error case ִ��ʧ�ܵ�case����
##! @IN[arr]: $4 => error infos
##! @RETURN: 0 => sucess; 1 => failure
function Report()
{
	local mode="$1"
	local report_total_count=$2
	local report_error_count=$3
	local report_error_infos=$4

	Print $TTY_TRACE "=============== report [$mode] ==============="

	#eval report_error_count=\${#$report_error_infos[@]}

	if [ $report_total_count -eq 0 ]
	then
		Print $TTY_TRACE "No any case to run!!"
		return 1
	fi

	if [ $report_error_count == 0 ]
	then
		Print $TTY_PASS "Run all case pass! Case total:$report_total_count"
	else
		Print $TTY_FATAL "Error total:$report_error_count | Case total:$report_total_count"
		local core_file_num=`ls core.* 2>/dev/null | wc -l`
		if [ $core_file_num -ne 0 ]
		then
			Print $TTY_FATAL "Core file:$core_file_num"
		fi
		local i
		local error_info
		for (( i=0; i<$report_error_count; i=$i+1 ))
		do
			eval error_info=\"\${$report_error_infos[\$i]}\"
			Print $TTY_INFO "${error_info}"
		done
	fi

	return 0
}

##! @BRIEF: report ccover result
##! @AUTHOR: xuanbiao
##! @IN[string] $1 => ��·������~public/mcpack
##! @IN[string] $2 => ccover���·��
##! @RETURN: 0 => sucess; 1 => failure
function ReportCcover()
{
	local project_dir="$1"
	local output_dir="${2:-${CONF_CCOVER_OUTPUT}}"
	local ret=0

	Print $TTY_TRACE "=============== report [ccover] =============="
	Print $TTY_INFO "see more in diretory \"${output_dir}\""
	#���$output_dir�´���project_covsrc.txt��ֱ����ʾ���������covsrc����
	if [ -f "$output_dir/project_covsrc.txt" ]
	then
		cat $output_dir/project_covsrc.txt
	else
		covsrc $project_dir
		ret=$?
		if [ $ret -ne 0 ]
		then
			Print $TTY_FATAL "Get report of ccover error!"
		fi
	fi

	return $ret
}

##! **********************  utils function ***********************

##! @BRIEF: send mail
##! @AUTHOR: xuanbiao
##! @IN[string] $1 => FUNCTION_ID
##! @IN[int] $2 => value
##! @RETURN: 0 => sucess; 1 => failure
function CollectInfo()
{
	local module="autorun"
	local function="$1"
	local value

	if [ -n "$2" ]
	then
		value="#$2"
	fi
	echo "${module}#${function}#"$(date "+%Y-%m-%d %H:%M:%S")${value} >> ~/.btest/.bteststat_$(date "+%Y-%m-%d").data
	return 0
}

##! @BRIEF: send mail
##! @AUTHOR: xuanbiao
##! @IN[string] $1 => mailto
##! @IN[string] $2 => title
##! @IN[string] $3 => content
##! @IN[arr] optional $4 => attachments
##! @RETURN: 0 => sucess; 1 => failure
function SendMail()
{
	local mailto="$1"
	local title="$2"
	local content="$3"
	local attach_arr=$4

	local ret
	#����ļ�����������max_file_num������
	local max_file_num=5
	local gzip_file
	local mail_attach_str
	local attachs=()

	#��������˸���
	if [ -n "$attach_arr" ]
	then
		attachs=(`eval "echo \"\\\${\$attach_arr[@]}\""`)
		#����һ���ļ���ֱ�Ӵ��������ccover�Ľ��
		if [ ${#attachs[@]} -eq 1 ] && [ -d ${attachs[0]} ]
		then
			gzip_file="${attachs[0]}.tar.gz"
			tar zcf $gzip_file ${attachs[@]}
			mail_attach_str="-a $gzip_file"
		elif [ ${#attachs[@]} -gt $max_file_num ]	#����max_file_num��������
		then
			#FIXME:�ļ������������·���Ұ���Ŀ¼��
			local dir=`dirname ${attachs[0]}`
			gzip_file="${dir}.tar.gz"
			tar zcf $gzip_file ${attachs[@]}
			mail_attach_str="-a $gzip_file"
		else
			for ((i=0; $i<${#attachs[@]}; i=$i+1))
			do
				mail_attach_str="$mail_attach_str -a ${attachs[$i]}"
			done
		fi
	fi
	#echo "attachs: $mail_attach_str"
	#echo -e "${content}" | mail -s "${title}" "${mailto}"
	#echo -e "<font color='red'>${content}</font>" | mutt -F tmp.muttrc -s "${title}" -a tmp.muttrc "${mailto}"
	#����Ϊ���ı���
	export LANG=zh_CN
	#����btest�ʼ���
	echo -e "${content}" | mutt -s "${title}" -c "btest-mon@baidu.com" ${mail_attach_str} ${mailto} >/dev/null 2>&1
	#echo -e "${content}" | mutt -s "${title}" ${mail_attach_str} ${mailto} >/dev/null 2>&1
	ret=$?
	if [ -n "${gzip_file}" ]
	then
		rm ${gzip_file} >/dev/null 2>&1
	fi
	#echo -e "<font color='red'>${content}</font>" | mutt -s "${title}" -a tmp.muttrc -e "my_hdr Content-Type: text/html" "${mailto}"

	return $ret
}
##! @BRIEF: open log
##! @AUTHOR: xuanbiao
##! @RETURN: 0 => sucess; 1 => failure
function OpenLog()
{
	if [ -n "${CONF_LOG_FILE}" ]
	then
		local dir=`pwd`
		#��������·�����ɾ���·��
		if [ "${CONF_LOG_FILE[0]}" != "/" ]
		then
			CONF_LOG_FILE="$dir/${CONF_LOG_FILE}"
		fi
		#��ȡdirname
		dir=`dirname ${CONF_LOG_FILE}`
		if [ ! -d "$dir" ]
		then
			Print $TTY_FATAL "path($dir) is not exist!"
			return 1
		fi
	fi
	return 0
}

##! @BRIEF: write log
##! @AUTHOR: xuanbiao
##! @IN[int]: $1 => log level
##! @IN[string]: $2 => message
##! @RETURN: 0 => sucess; 1 => failure
function WriteLog()
{
	local log_level=$1
	local message="$2"

	if [ $log_level -le ${CONF_LOG_LEVEL} ]
	then
		local time=`date "+%m-%d %H:%M:%S"`
		echo "${LOG_LEVEL_TEXT[$log_level]}: $time: ${MODULE_NAME} * $$ $message" >> ${CONF_LOG_FILE}
	fi
	return 0
}
##! @BRIEF: print info to tty
##! @AUTHOR: xuanbiao
##! @IN[int]: $1 => tty mode
##! @IN[string]: $2 => message
##! @RETURN: 0 => sucess; 1 => failure
function Print()
{
	local tty_mode=$1
	local message="$2"

	#echo -e "\e[${TTY_MODE_COLOR[$tty_mode]}m${TTY_MODE_TEXT[$tty_mode]} ${message}\e[m"
	echo -e "<FONT COLOR=${WEB_MODE_COLOR[$tty_mode]}> ${TTY_MODE_TEXT[$tty_mode]} ${message}</FONT>"
	return 0
}

##! @BRIEF: ��������
##! @AUTHOR: xuanbiao
##! @IN[int]: $1 => type:0=>no option;1=>optional;2=>must
##! @IN[string]: $2 => param
##! @IN[string]: $3 => option
##! @OUT[string]: $4 => option is set if need
##! @RETURN: n => offset to shift
function ProcessParam()
{
	local type=$1
	local param="$2"
	local option="$3"

	#����Ҫ��������������
	[ $type -eq 0 ] && return 0
	#�ж�option����
	case ${option:0:1} in
		-|"")	[ $type -eq 2 ] && echo "$param option requires an argument" && Usage
				return 1
				;;
		*)		eval $4=\"$option\"
				return 2
				;;
	esac

	return 0
}

Main()
{
	#���������в���

	#-f����
	local b_conf=0
	local opt_conf_file="conf_autorun.sh"
	#-p����
	local b_pattern=0
	local opt_pattern
	#-b����
	local b_env_prj_build=0
	local opt_env_prj_build
	#-e����
	local b_env_prj_clean=0
	local opt_env_prj_clean
	#-l����
	local b_list=0
	#-c����
	local b_compile=0
	local opt_compile_option
	#-w����
	local b_search_warning=0
	#-r����
	local b_run=0
	local b_run_check=1
	#-C����
	local b_run_ccover=0
	local b_compile_project=0
	local opt_project_dir
	#-V����
	local b_run_valgrind=0
	local opt_valgrind_options
	#-x����
	local b_abort_on_fail=0
	#-m����
	local b_mail=0
	local opt_mailto
	#-u����
	local b_upload=0
	#-g����
	local b_gen_conf=0
	#-i����
	local b_common_params=0
	local opt_common_params
	#--xml����
	local b_output_xml=0
	#-s����
	local b_display_output=0

	#���е������в���
	AUTORUN_PARAMS="$*"

	#���û�в������˳�
	[ $# -eq 0 ] && Usage
	
	#ѭ�����������в���
	while [ $# -gt 0 ]
	do
		case "$1" in
			-v)	Version
				shift
				;;
			-h) Usage
				shift
				;;
			#ָ�������ļ�����ѡ����-f [conf]��conf������xxx.sh��xxx.xml
			-f) b_conf=1
				ProcessParam 1 "$1" "$2" opt_conf_file
				shift $?
				;;
			#���Լ�ѡȡ����Ҫ����-p pattern
			-p)	b_pattern=1
				ProcessParam 2 "$1" "$2" opt_pattern
				shift $?
				;;
			#ִ�л��������Ҫ����-b command
			-b) b_env_prj_build=1
				ProcessParam 2 "$1" "$2" opt_env_prj_build
				shift $?
				;;
			#ִ�л�����������Ҫ����-e command
			-e) b_env_prj_clean=1
				ProcessParam 2 "$1" "$2" opt_env_prj_clean
				shift $?
				;;
			#��ӡ��ѡȡ�Ĳ��Լ���û�в���-l
			-l) b_list=1
				shift
				;;
			#����ѡ���ѡ����-c [option]��optionΪmake����
			-c)	b_compile=1
				ProcessParam 1 "$1" "$2" opt_compile_option
				shift $?
				;;
			#������waring��û�в���-w
			-w) b_search_warning=1
				shift
				;;
			#ִ��ѡ�û�в���-r
			-r)	b_run=1
				shift
				;;
			#�����ִ�гɹ����û�в���-r0
			-r0)	b_run=1
				b_run_check=0
				shift
				;;
			#���������ִ�У��ȼ���-c��-r����ѡ����-t [option]
			-t) b_compile=1
				b_run=1
				ProcessParam 1 "$1" "$2" opt_compile_option
				shift $?
				;;
			#Ccoverͳ��ѡ���Ҫ����-C dir��dirΪ����Ŀ������·��
			-C0)	b_run_ccover=1
				b_compile_project=0
				ProcessParam 2 "$1" "$2" opt_project_dir
				shift $?
				;;
			-C1)	b_run_ccover=1
				b_compile_project=1
				ProcessParam 2 "$1" "$2" opt_project_dir
				shift $?
				;;
			#Valgrind��飬��ѡ����-V [option]��optionΪvalgrind�Ĳ���
			-V) b_run_valgrind=1
				ProcessParam 1 "$1" "$2" opt_valgrind_options
				shift $?
				;;
			#���������˳�
			-x)	b_abort_on_fail=1
				shift
				;;
			#����mail����Ҫ����-m mailto��mailtoΪ��ȡ�ʼ����û�
			-m)	b_mail=1
				ProcessParam 2 "$1" "$2" opt_mailto
				shift $?
				;;
			#�ϴ�caseѡ�����Ҫ������������conf
			-u)	b_upload=1
				shift
				;;
			-g)	b_gen_conf=1
				shift
				;;
			#ȫ��filter����Ҫ��������ӦCONF_COMMON_PARAMS
			-i) b_common_params=1
				ProcessParam 2 "$1" "$2" opt_common_params
				shift $?
				;;
			#���xml�ļ�������Ҫ����
			--xml)	b_output_xml=1
				shift
				;;
			#��ʾ�����Ϣ������Ҫ����
			-s)	b_display_output=1
				shift
				;;
			--)	shift
				break
				;;
			*)	echo "Unkown option \"$1\""
				Usage
				;;
		esac
	done

	#�ռ���Ϣ
	[ ${b_conf} -eq 1 ] && CollectInfo "customedconf"
	[ ${b_pattern} -eq 1 ] && CollectInfo "selectcase"
	[ ${b_env_prj_build} -eq 1 ] || [ ${b_env_prj_clean} -eq 1 ] && CollectInfo "processenv"
	[ ${b_run} -eq 1 ] && CollectInfo "run"
	[ ${b_run_valgrind} -eq 1 ] && CollectInfo "valgrindcheck"
	[ ${b_run_ccover} -eq 1 ] && CollectInfo "ccover"
	[ ${b_upload} -eq 1 ] && CollectInfo "uploadcase"
	[ ${b_mail} -eq 1 ] && CollectInfo "mail"

	#����conf�ļ�demo
	#TODO����û��ʵ�֣�ʵ�ֺ���ͬʱ��usage����ʾ
	if [ ${b_gen_conf} -eq 1 ]
	then
		GenerateConf
		exit 0
	fi

	#����conf�ļ�������ʧ�����˳�
	if [ ${b_conf} -eq 1 ]
	then
		#��ȡ���û�Ӱ�쵽ȫ�ֱ��������ܷŵ���shell������
		ReadConf "${opt_conf_file}"
		if [ $? -ne 0 ]
		then
			exit 1
		fi
	fi
	#��log
	OpenLog || exit 1

	WriteLog $LOG_DEBUG "[${FUNCNAME[0]}:$LINENO] current work dir:${PWD}"
	#�ϴ�case������Ϣ����
	if [ ${b_upload} -eq 1 ]
	then
		#����Ƿ�ָ�����ã���Ҫָ������
		if [ ${b_conf} -ne 1 ]
		then
			WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] use -f conf for configure"
			Print $TTY_FATAL "use -f conf for configure"
			return 1
		fi
		#����Ƿ������Ӧ����
		if [ "${CONF_ATP_UPLOAD_CASE}" == "yes" ] || [ "${CONF_ATP_UPLOAD_RUN_REPORT}" == "yes" ]
		then
			if [ -z "${CONF_ATP_USER}" ]
			then
				WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] CONF_ATP_USER is not defined"
				Print $TTY_FATAL "CONF_ATP_UPLOAD_USER is not defined"
				return 1
			fi
			if [ "${CONF_ATP_UPLOAD_CASE}" == "yes" ]
			then
				if [ -z "${CONF_ATP_UPLOAD_MODULE}" ]
				then
					WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] CONF_ATP_UPLOAD_MODULE is not defined"
					Print $TTY_FATAL "CONF_ATP_UPLOAD_MODULE is not defined"
					return 1
				fi
				if [ -z "${CONF_ATP_UPLOAD_ROOTSUITE}" ]
				then
					WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] CONF_ATP_UPLOAD_ROOTSUITE is not defined"
					Print $TTY_FATAL "CONF_ATP_UPLOAD_ROOTSUITE is not defined"
					return 1
				fi
			fi
			if [ "${CONF_ATP_UPLOAD_RUN_REPORT}" == "yes" ]
			then
				if [ -z "${CONF_ATP_UPLOAD_RUN_JOBID}" ]
				then
					WriteLog $LOG_FATAL "[${FUNCNAME[0]}:$LINENO] CONF_ATP_UPLOAD_RUN_JOBID is not defined"
					Print $TTY_FATAL "CONF_ATP_UPLOAD_RUN_JOBID is not defined"
					return 1
				fi
			fi
		fi
	fi

	#���������ָ��������ʹ�������У�����ѡ��ָ�������û���Ĭ�ϵ�����
	#local pattern=${opt_pattern:-"${CONF_PATTERN}"}
	#local env_prj_build=${opt_env_prj_build:-"${CONF_ENV_PROJECT_BUILD}"}
	#local env_prj_clean=${opt_env_prj_clean:-"${CONF_ENV_PROJECT_CLEAN}"}
	CONF_PATTERN=${opt_pattern:-"${CONF_PATTERN}"}
	CONF_ENV_PROJECT_BUILD=${opt_env_prj_build:-"${CONF_ENV_PROJECT_BUILD}"}
	CONF_ENV_PROJECT_CLEAN=${opt_env_prj_clean:-"${CONF_ENV_PROJECT_CLEAN}"}
	CONF_MAILTO=${opt_mailto:-"${CONF_MAILTO}"}

	if [ ${b_common_params} -eq 1 ]
	then
		CONF_COMMON_PARAMS="--gtest_filter=${opt_common_params} ${CONF_COMMON_PARAMS}"
	fi

	if [ ${b_output_xml} -eq 1 ]
	then
		CONF_OUTPUT_XML=1
	fi

	#����������ֹ
	if [ ${b_abort_on_fail} -eq 1 ]
	then
		CONF_ABORT_ON_FAIL=1
	fi

	#��ʾ�����Ϣ
	if [ ${b_display_output} -eq 1 ]
	then
		CONF_DISPLAY_OUTPUT=1
	fi

	#��ʾִ���б�
	if [ ${b_list} -eq 1 ]
	then
		ShowList
		exit 0
	fi

	#���룬����ʧ�����˳�
	if [ ${b_compile} -eq 1 ]
	then
		Compile "$opt_compile_option" $b_search_warning || exit 1
	fi

	#�ϴ�case
	if [ ${b_upload} -eq 1 ]
	then
		#����Ҫ��mail
		Run "${CONF_PATTERN}" $b_run_check 1 0 1
	elif [ ${b_run} -eq 1 ]	#ִ��
	then
		Run "${CONF_PATTERN}" $b_run_check 1 1
	fi

	#ִ��
	#if [ ${b_run} -eq 1 ]
	#then
	#	Run "${CONF_PATTERN}" $b_run_check 1 1
	#fi

	#valgrind���
	if [ ${b_run_valgrind} -eq 1 ]
	then
		RunValgrind "${CONF_PATTERN}" "$opt_valgrind_options" 1
	fi

	#ccoverͳ��
	if [ ${b_run_ccover} -eq 1 ]
	then
		RunCcover "$opt_project_dir" $b_compile_project
		#[ $? -eq 0 ] && ReportCcover "$opt_project_dir"
	fi

	return 0
}

#echo $*
#echo "$@"

Main "$@"













