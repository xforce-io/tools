#pragma once

#include <stdint.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>

#include "public.h"
#include "lib/log/src/glog.h"

class tools_i
{
    public:
    enum io_r
    {
        INCOMPLETE = 1,
        INVALID = 2,
        PEERCLOSE = 3,
        OTHER = 4,
    };

    /*
     * return value: 0, everything id ok!
     *               INCOMPLETE, not enough bytes are wrote
     *               OTHER, unexpected error, refer to errno
     */
    inline static int Write(IN int fd, IN const char *buf, INOUT int &count);

    /*
     * return value: 0, everything id ok!
     *               INCOMPLETE, not enough bytes are read
     *               INVALID, result is invalid
     *               OTHER, unexpected error, refer to errno
     */
    inline static int Read(IN int fd, IN char *buf, INOUT int &count);

    inline static bool setnonblock(int fd);

    inline static bool get_ip(IN int fd, OUT char* ipstr, OUT size_t len);

    inline static int64_t str_to_ll(const char *str);
};

int tools_i::Write(int fd, const char *buf, int &count)
{
    int ret;
    while(count > 0) {
        ret = write(fd, CCAST<char*>(buf), count);
        if(ret > 0) { 
            count -= ret; 
            buf += ret; 
        } else if(ret < 0 && 
            (EAGAIN == errno || EWOULDBLOCK == errno || EINTR == errno)) {
            return INCOMPLETE;
        } else {
            WARN("write_error_ret[%d|%m]", ret);
            return OTHER;
        }
    }
    return 0;
}

int tools_i::Read(int fd, char *buf, int &count)
{
    int ret;
    while(count > 0) {
        ret = read(fd, buf, count);
        if(ret > 0) { 
            count -= ret; 
            buf += ret; 
        } else if(0 < ret) {
            if(EAGAIN == errno || EWOULDBLOCK == errno || EINTR == errno) {
                return INCOMPLETE;
            } else {
                WARN("read_error_ret[%d|%m]", ret);
                return OTHER;
            }
        } else {
            /*
             * Not PEERCLOSE for the case that we do not know how long the head is,
             * then we need to read a length longer than needed, return PEERCLOSE
             * here will cause read_error in this case
             */
            return INCOMPLETE;
        }
    }
    return 0;
}

bool tools_i::setnonblock(int fd)
{
    int ret = fcntl(fd, F_GETFL, 0);
    if(-1 != ret) {
        ret = fcntl(fd, F_SETFL, ret | O_NONBLOCK);
        if(-1 != ret) return true;
    }
    FATAL("set_nonblock_fail")
    return false;
}

bool tools_i::get_ip(int fd, char* ipstr, size_t len)
{
    in_addr in; 
    sockaddr_in addr;
    socklen_t addr_len = sizeof(sockaddr_in);
    int ret;

    XLIB_FAIL_HANDLE(fd < 0 || NULL == ipstr || INET_ADDRSTRLEN > len);

    ret = getpeername(fd, (sockaddr*)&addr, &addr_len);
    XLIB_FAIL_HANDLE_WARN(ret < 0, \
        "getpeername failed, errno[%m] fd[%d]", fd);

    in.s_addr = addr.sin_addr.s_addr;
    
    XLIB_FAIL_HANDLE_WARN(NULL == inet_ntop(AF_INET, &in, ipstr, INET_ADDRSTRLEN), \
        "get ip failed, errno=%m");

    /* ��ipstrĩβ��0����֤�ַ�����ӡ�� */
    ipstr[INET_ADDRSTRLEN-1] = 0;
    return true;

    ERROR_HANDLE:
    return false;
}

int64_t tools_i::str_to_ll(const char *str)
{
    if (NULL == str || '\0' == str[0]) return -1;

    char *endptr;
    int64_t tmp = strtol(str, &endptr, 10);
    if ('\0' != *endptr ||
        LONG_MAX == tmp || 
        LONG_MIN == tmp ||
        tmp < 0) return -1;
    return tmp;
}
