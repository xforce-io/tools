#pragma once

namespace xlib {

class scheduler_i {
    public:
    virtual int calc_checktime(int speed) = 0;

    virtual ~scheduler_i() {}
};

}
