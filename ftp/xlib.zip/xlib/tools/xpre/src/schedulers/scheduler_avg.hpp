#pragma once

namespace xlib {

class scheduler_avg_i : public scheduler_i {
    public:
    int calc_checktime(int speed);
};

int scheduler_avg_i::calc_checktime(int speed) {
    return conf_s::check_interval*1000000/speed;
}

}
