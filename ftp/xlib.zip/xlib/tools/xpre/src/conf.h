#pragma once

#include <sys/socket.h>
#include <netinet/in.h>

#include "public.h"

namespace xlib {

const uint32_t SizeSpeedBuf = 10;
const uint32_t MaxNumRemotes = 100;

class conf_s {
    typedef std::string string_t;

    public:
    static const string_t PatternFile;
    static const string_t SpeedFile;
    static const string_t ResultFile;
    static const string_t RecordFile;

    public:
    static bool init();

    /* unit of speed is num_queries per sec */
    static inline int get_current_speed();

    public:
    static uint32_t num_slaves;
    static uint32_t max_page_size;
    static uint32_t max_pattern_log_size;
    static uint32_t max_pattern_size;
    static uint32_t max_num_patterns;
    static uint64_t size_job_queue;
    static string_t protocol_kind;
    static string_t scheduler_kind;
    static uint32_t check_interval;
    static uint32_t is_fixed_speed;
    static uint32_t fixed_speed;
    static uint32_t num_downloads;
    static uint32_t idle_sleep_time;
    static uint32_t is_long_conn;
    static uint32_t num_long_conns_per_thread;
    static in_addr_t ip[MaxNumRemotes];
    static uint32_t port[MaxNumRemotes];
    static uint32_t num_remotes;
    static uint32_t connect_timeout;
    static uint32_t read_timeout;
    static uint32_t write_timeout;

    /* static related */
    static uint32_t static_level;
    static uint32_t max_query_stats;
    static uint32_t record_output_interval;
};

inline int conf_s::get_current_speed() {
    if(is_fixed_speed) return fixed_speed;

    int ret;
    char speed_buf[SizeSpeedBuf];
    FILE *fp = fopen(SpeedFile.c_str(), "r");
    if(NULL == fp) {
        FATAL("fail_open[%s] reason[%m]", SpeedFile.c_str());
        return 0;
    }

    if( NULL == fgets(speed_buf, SizeSpeedBuf, fp) || (ret = atoi(speed_buf)) <= 0 ) {
        fclose(fp);
        return 0;
    }
    fclose(fp);
    return ret;
}

}
