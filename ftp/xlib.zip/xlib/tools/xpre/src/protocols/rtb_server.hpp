#pragma once

#include "../protocol.hpp"

class rtbserver_t : public protocol_t
{
    public:
    inline bool construct_write_buf(IN const char* input, IN uint32_t len, 
        IN const void* arg, IN char* output, INOUT uint32_t& size);

    inline int readsize_header(char* buf, uint32_t& len);

    inline int readsize_body(char* header, uint32_t len);

    inline bool validate_result(char* buf, uint32_t len);
};

bool rtbserver_t::construct_write_buf(const char* input, uint32_t len, 
    const void* arg, char* output, uint32_t& size)
{
    memcpy(output, input, len);
    size = len;
    return true;
}

int rtbserver_t::readsize_header(char* buf, uint32_t& len)
{
    UNUSE(buf);
    len = 0;
    return 0;
}

int rtbserver_t::readsize_body(char *header, uint32_t len)
{
    UNUSE(header);
    UNUSE(len);
    return 2;
}

bool rtbserver_t::validate_result(char *buf, uint32_t len)
{
    return true;
}
