#pragma once

#include "../protocol.hpp"

namespace xlib {

class simple_http_t : public protocol_t {
    public:
    static const uint32_t ReadBlock = 1024;

    public:
    inline bool init();

    inline bool construct_write_buf(IN const char* input, IN uint32_t len, IN const void* arg,
        IN char* output, INOUT uint32_t& size);

    inline int readsize_header(char* buf, uint32_t& len);
    inline int readsize_body(char *header, uint32_t size);
    inline bool validate_result(char *buf, uint32_t size);

    virtual ~simple_http_t() {}
};

bool simple_http_t::init() {
    return true;
}

bool simple_http_t::construct_write_buf(const char* input, uint32_t len, const void* arg, 
    char* output, uint32_t& size) {
    sockaddr_in* addr = (sockaddr_in*)arg;

    strcpy(output, "GET ");
    uint32_t len_method = strlen(output);
    memcpy(output + len_method, input, len);
    strcpy(output + len_method + len, " HTTP/1.1\r\nUser-Agent: Xpre\r\nHost: ");

    char buf[100];
    snprintf(buf, sizeof(buf), "%s:%d\r\n\r\n", 
        inet_ntoa(addr->sin_addr), ntohs(addr->sin_port));

    strcat(output, buf);
    size = strlen(output);
    DEBUG("%s size[%d]", output, size);
    return true;
}

int simple_http_t::readsize_header(char* buf, uint32_t& len) {
    if(len >= conf_s::max_page_size) return -1;

    buf[len] = '\0';
    //NOTICE("len %d %s", len, buf);
    if(NULL != strstr(buf, "\r\n\r\n")) {
        return 0;
    } else {
        return ReadBlock;
    }
}

int simple_http_t::readsize_body(char *header, uint32_t len) {
    UNUSE(header);
    UNUSE(len);
    return 0;
}

bool simple_http_t::validate_result(char *buf, uint32_t len) {
    if(len >= conf_s::max_page_size) return false;

    buf[len] = '\0';

    char* ret = strstr(buf, "200");
    if(NULL != ret) {
        return NULL != strstr(buf, "OK") ? true : false;
    } else {
        ret = strstr(buf, "302");
        if (NULL!=ret) return true;
        return false;
    }
}

}
