#pragma once

#include "../protocol.hpp"

namespace xlib {
 
class tcptest_10_10_t : public protocol_t {
    public:
    inline bool construct_write_buf(IN const char* input, IN uint32_t len, 
        IN const void* arg, IN char* output, INOUT uint32_t& size);
    inline int readsize_header(char* buf, uint32_t& len);
    inline int readsize_body(char* header, uint32_t len);
    inline bool validate_result(char* buf, uint32_t len);

    virtual ~tcptest_10_10_t() {}
};

bool tcptest_10_10_t::construct_write_buf(const char* input, uint32_t len, 
    const void* arg, char* output, uint32_t& size) {
    UNUSE(input);
    UNUSE(len);
    UNUSE(arg);
    memset(output, 'a', 10);
    size = 10;
    return true;
}

int tcptest_10_10_t::readsize_header(char* buf, uint32_t& len) {
    UNUSE(buf);
    len = 0;
    return 0;
}

int tcptest_10_10_t::readsize_body(char *header, uint32_t len) {
    UNUSE(header);
    UNUSE(len);
    return 10;
}

bool tcptest_10_10_t::validate_result(char *buf, uint32_t len) {
    if(10!=len) return false;
    for(int i = 0; i < 10; ++i) {
        if(buf[i] != 'b') return false;
    }
    return true;
}

}
