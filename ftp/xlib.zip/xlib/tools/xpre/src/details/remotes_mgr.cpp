#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#include "../public.h"
#include "../tools.h"
#include "../remotes_mgr.h"

namespace xlib {

bool remotes_mgr_t::init() { return true; }

bool remotes_mgr_t::get_fd(int &fd, sockaddr_in& addr) {
    static unsigned int seed=0;
    int addr_index = rand_r(&seed) % conf_s::num_remotes, ret;

    bzero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = conf_s::ip[addr_index];
    addr.sin_port = conf_s::port[addr_index];

    if(conf_s::is_long_conn && _fds[addr_index].size() > 0) {
        fd = _fds[addr_index].front();
        _fds[addr_index].pop_front();
        
        ret = _check_connection(fd);
        if(true==ret) {
            return true;
        } else {
            close(fd);
        }
    }

    fd = socket(AF_INET, SOCK_STREAM, 0);
    XLIB_FAIL_HANDLE_WARN(fd<0, "create_socket reason[%s]", strerror(errno));

    ret = tools_i::setnonblock(fd);
    XLIB_FAIL_HANDLE_WARN(true!=ret, "set_socket_nonblock");

    ret = connect(fd, (struct sockaddr*)&addr, sizeof(addr));

    if(conf_s::is_long_conn) {
        _fd_to_index[fd] = addr_index;
    }

    if(-1 == ret) {
        XLIB_FAIL_HANDLE(errno != EINPROGRESS);
        return Connect;
    }
    return true;

    ERROR_HANDLE:
    return false;
}

}
