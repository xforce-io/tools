#include <sys/stat.h>

#include "../public.h"
#include "../tools.h"
#include "../globals.h"
#include "../master.h"
#include "../pattern_processor.h" 

namespace xlib {

const int MaxNumSlaves = 10;
const int DefaultSizeAddrSeq = 2000000;

bool master_t::init(info_passed_to_master_t *info_passed_to_master) {
    _pattern_processor = info_passed_to_master->pattern_processor;
    _job_queue = info_passed_to_master->job_queue;
    _job_list = info_passed_to_master->job_list;

    /*believe in the number in conf */
    if(0 == conf_s::num_downloads) {
        _num_tasks_left = -1;
    } else {
        _num_tasks_left = conf_s::num_downloads;
    }

    XLIB_NEW(_pattern, char [conf_s::max_pattern_size]);
    XLIB_NEW(_page, char [conf_s::max_page_size]);
    XLIB_NEW(_num_task_per_slave, int [conf_s::num_slaves]);
    memset(_num_task_per_slave, 0, conf_s::num_slaves
        * sizeof(*_num_task_per_slave));

    _slaves = info_passed_to_master->slaves;
    return true;
}

bool master_t::_work_circle() {
    /*
     * check_time: time corresponding to check_interval, us
     */
    pub::Time::UpdateTimer();

    /* set state */
    static uint64_t check_time, deadline = pub::Time::GetCurrentUsec(false);
    static int old_speed = -1;

    int speed = conf_s::get_current_speed();
    if(speed != old_speed) {
        if(0 == speed) {
            usleep(conf_s::idle_sleep_time);
            FATAL("invalid_speed");
            return true;
        }

        check_time = globals_s::scheduler()->calc_checktime(speed);
        deadline = pub::Time::GetCurrentUsec(false);
    }
    deadline += check_time;
    old_speed = speed;

    uint64_t start_time = pub::Time::GetCurrentUsec(false);

    /* produce tasks */
    _produce_task();

    /* release command */
    _release_command(false);

    pub::Time::UpdateTimer();

    if(0 == _num_tasks_left) {
        _release_command(true);
        return false;
    }

    uint64_t end_time = pub::Time::GetCurrentUsec(false);
    /* actually (deadline - end_time - (end_time - start_time)) */
    int64_t sleep_time = deadline + start_time - (end_time << 1);

    NOTICE("master: now[%lu] cost[%lu] sleep_time[%ld]", 
        end_time, end_time - start_time, sleep_time);
    if(sleep_time > 0) usleep(sleep_time);
    return true;
}

void master_t::_produce_task() {
    int num_tasks = (-1 == _num_tasks_left || (int)conf_s::check_interval <= _num_tasks_left) 
        ? conf_s::check_interval : _num_tasks_left;
    TRACE("master: num_tasks[%d] num_tasks_left[%d]", 
        num_tasks, _num_tasks_left);
    while(num_tasks > 0) {
        pub::Slice pattern = _pattern_processor->get_next_pattern();

        int slave = _select_slave();
        bool ret = (*_job_queue)[slave]->SendMsg(pattern);
        if(!ret) {
            TRACE("master: sleep[%d]", conf_s::idle_sleep_time);
            usleep(conf_s::idle_sleep_time);
            continue;
        }

        ++_num_task_per_slave[slave];
        --num_tasks;
        if(_num_tasks_left > 0) --_num_tasks_left;
    }
}

void master_t::_release_command(bool is_end) {
    uint32_t i;
    if(false == is_end) {
        for(i = 0; i < conf_s::num_slaves; ++i) {
            if(0 == _num_task_per_slave[i]) continue;

            if(true == _job_list[i].consumed) {
                TRACE("master: issue_to_slave[%d] num_tasks[%d]", 
                    i, _num_task_per_slave[i]);

                _job_list[i].num_tasks = _num_task_per_slave[i];
                _job_list[i].consumed = false;
                _num_task_per_slave[i] = 0;

            }
        }
    } else {
        while(1) {
            for(i = 0; i < conf_s::num_slaves; ++i) {
                if(0 != _num_task_per_slave[i]) { break; }
            }

            if(i == conf_s::num_slaves) {
                break;
            } else {
                usleep(conf_s::idle_sleep_time);
                _release_command(false);
            }
        }

        for(i = 0; i < conf_s::num_slaves; ++i) {
            _job_list[i].is_end = true;
        }
    }
}

int master_t::_select_slave() {
    size_t min = (*_job_queue)[0]->SizeMsgReady(), min_index = 0;
    for(uint32_t i = 1; i < conf_s::num_slaves; ++i) {
        if( (*_job_queue)[i]->SizeMsgReady() < min ) {
            min = (*_job_queue)[i]->SizeMsgReady();
            min_index = i;
        }
    }
    return min_index;
}

}
