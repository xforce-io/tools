#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include "../public.h"
#include "../conf.h"

namespace xlib {

const conf_s::string_t conf_s::PatternFile = "data/patterns";
const conf_s::string_t conf_s::SpeedFile = "conf/speed";
const conf_s::string_t conf_s::ResultFile = "data/result";
const conf_s::string_t conf_s::RecordFile = "data/record";

uint32_t conf_s::num_slaves;
uint32_t conf_s::max_page_size;
uint32_t conf_s::max_pattern_log_size;
uint32_t conf_s::max_pattern_size;
uint32_t conf_s::max_num_patterns;
uint64_t conf_s::size_job_queue;
conf_s::string_t conf_s::protocol_kind;
conf_s::string_t conf_s::scheduler_kind;
uint32_t conf_s::check_interval;
uint32_t conf_s::is_fixed_speed;
uint32_t conf_s::fixed_speed;
uint32_t conf_s::num_downloads;
uint32_t conf_s::idle_sleep_time;
uint32_t conf_s::is_long_conn;
uint32_t conf_s::num_long_conns_per_thread;
in_addr_t conf_s::ip[MaxNumRemotes];
uint32_t conf_s::port[MaxNumRemotes];
uint32_t conf_s::num_remotes;
uint32_t conf_s::connect_timeout;
uint32_t conf_s::read_timeout;
uint32_t conf_s::write_timeout;
uint32_t conf_s::static_level;
uint32_t conf_s::max_query_stats;
uint32_t conf_s::record_output_interval;

bool conf_s::init() {
    xlib::conf_t conf;
    bool ret;
    int error;

    XLIB_FAIL_HANDLE_FATAL(false == conf.init("conf/xpre.conf"), 
        "error in loading conf file[conf/xpre.conf]");

    ret = conf.get_uint32("num_slaves", num_slaves, 1, 100);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set num_slaves in config file to [%u]", num_slaves);

    struct stat tmp_stat;
    error = stat(PatternFile.c_str(), &tmp_stat);
    XLIB_FAIL_HANDLE_FATAL(0 != error, 
        "bad_pattern_file[%s]", PatternFile.c_str());
        
    ret = conf.get_uint32("max_page_size", max_page_size, 1, 1024*1024);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set max_page_size in config file to [%u]", max_page_size);

    ret = conf.get_uint32("max_pattern_log_size", max_pattern_log_size, 1, 1<<31);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set max_pattern_log_size in config file to [%u]", max_pattern_log_size);

    ret = conf.get_uint32("max_pattern_size", max_pattern_size, 1, 1024*1024);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set max_pattern_size in config file to [%u]", max_pattern_size);

    ret = conf.get_uint32("max_num_patterns", max_num_patterns, 1, 1024*1024);
    XLIB_FAIL_HANDLE(true != ret);
    NOTICE("set max_num_patterns in config file to [%u]", max_num_patterns);

    ret = conf.get_uint64("size_job_queue", size_job_queue, 0, 
        (static_cast<uint64_t>(1) << 32));
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set size_job_queue in config file to [%lu]", size_job_queue);

    ret = conf.get_str("protocol_kind", protocol_kind);
    XLIB_FAIL_HANDLE(true != ret);
    XLIB_FAIL_HANDLE_FATAL(
        "tcptest_10_10" != protocol_kind && 
        "logtest" != protocol_kind &&
        "simple_http_post" != protocol_kind &&
        "simple_http" != protocol_kind, 
        "bad_protocol_kind[%s]", protocol_kind.c_str());
    NOTICE("set protocol_kind in config file to [%s]", protocol_kind.c_str());

    ret = conf.get_str("scheduler_kind", scheduler_kind);
    XLIB_FAIL_HANDLE(true != ret);     
    XLIB_FAIL_HANDLE_FATAL("avg" != scheduler_kind,
        "bad_scheduler_kind[%s]", scheduler_kind.c_str());
    NOTICE("set scheduler_kind in config file to [%s]", scheduler_kind.c_str());

    ret = conf.get_uint32("check_interval", check_interval, 1, 1000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set check_interval in config file to [%u]", check_interval);

    ret = conf.get_uint32("is_fixed_speed", is_fixed_speed, 0, 1);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set is_fixed_speed in config file to [%u]", is_fixed_speed);

    error = stat(SpeedFile.c_str(), &tmp_stat);
    XLIB_FAIL_HANDLE_FATAL(0 != error, "bad_speed_file[%s]", SpeedFile.c_str());

    ret = conf.get_uint32("fixed_speed", fixed_speed, 1, 500000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set fixed_speed in config file to [%u]", fixed_speed);

    ret = conf.get_uint32("num_downloads", num_downloads, 0);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set num_downloads in config file to [%u]", num_downloads);

    ret = conf.get_uint32("idle_sleep_time", idle_sleep_time, 1, 1000000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set idle_sleep_time in config file to [%u]", idle_sleep_time);

    ret = conf.get_uint32("is_long_conn", is_long_conn, 0, 1);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set is_long_conn in config file to [%u]", is_long_conn);

    ret = conf.get_uint32("num_long_conns_per_thread", num_long_conns_per_thread);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set num_long_conns_per_thread in config file to [%u]", num_long_conns_per_thread);

    ret = conf.get_uint32("connect_timeout", connect_timeout, 0, 3000000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set connect_timeout in config file to [%u]", connect_timeout);
    connect_timeout *= 1000;

    ret = conf.get_uint32("read_timeout",read_timeout, 0, 3000000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set read_timeout in config file to [%u]", read_timeout);
    read_timeout *= 1000;

    ret = conf.get_uint32("write_timeout", write_timeout, 0, 3000000);
    XLIB_FAIL_HANDLE(true != ret);     
    NOTICE("set write_timeout in config file to [%u]", write_timeout);
    write_timeout *= 1000;

    num_remotes = conf.get_subconf_len("remote");
    XLIB_FAIL_HANDLE_FATAL(0 == num_remotes || num_remotes > MaxNumRemotes,
        "invalid_num_remotes[%u/%u]", num_remotes, MaxNumRemotes);

    for(uint32_t i = 0; i < num_remotes; ++i) {
        ret = conf.get_subconf_uint32("remote", i, "port", port[i], 1, 65535);
        XLIB_FAIL_HANDLE_FATAL(true != ret, "no remote.%d.port in config file", i);
        port[i] = htons(static_cast<uint16_t>(port[i]));
        NOTICE("set remote.%u.port in config file to [%u]", i, port[i]);

        string_t tmp;
        ret = conf.get_subconf_str("remote", i, "ip", tmp);
        XLIB_FAIL_HANDLE_FATAL(true != ret, "no remote.%d.ip in config file", i);

        ip[i] = inet_addr(tmp.c_str());
        XLIB_FAIL_HANDLE_FATAL(ip[i] <= 0 || -1 == (int)ip[i], 
            "invalid_remote_ip[%d|%d]", i, ip[i]);
        NOTICE("set remote.%d.ip in config file to [%s]", i, tmp.c_str());
    }
    return true;

    ERROR_HANDLE:
    return false;
}

}
