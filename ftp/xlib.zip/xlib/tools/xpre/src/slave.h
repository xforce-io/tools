#pragma once

#include <pthread.h>
#include <sys/epoll.h>

#include "lib/public/heap/heap.hpp"

#include "public.h"
#include "master.h"
#include "job_event.h"
#include "remotes_mgr.h"

namespace xlib {

class slave_t {
    public:
    static const int InitSizePoolJobEvent = 1000;
    static const int MaxNumEvents = 100000;

    public:
    slave_t() {}

    bool init(info_passed_to_slave_t *info_passed_to_slave);
    inline int id() const { return _id; }
    inline int current_num_tasks() const { return _current_num_tasks; }
    inline void run();

    private:
    inline void _get_tasks();
    void _wait_for_events(bool& wait, int& num_fds_ready);
    bool _add_new_tasks();
    void _handle_events(int num_fds_ready, int wait);
    inline void _end_event_ok(job_event_t* job_event);

    private:
    int _id;
    int _fd_epoll;

    Pipe* _job_queue;
    job_list_t* _job_list;
    remotes_mgr_t _remotes_mgr;
    epoll_event* _events;

    int _current_num_tasks;
    int _num_new_tasks;
    int _deadline;
    bool _is_end;

    statics_t *_statics;

    private:
    pub::PoolObjs<job_event_t> _pool_job_event;
    pub::SimpleKVHeap<uint64_t, job_event_t*> _timeout_heap;
};

void slave_t::_get_tasks() {
    if(!_job_list->consumed) {
        _num_new_tasks = _job_list->num_tasks;
        _job_list->consumed = true;
    }

    if(_job_list->is_end) {
        _is_end = true;
    }
}

void slave_t::run() {
    while(true) {
//        int64_t t1 = time_s::get_current_time();
        TRACE("slave_circle");

        int num_fds_ready;
        bool wait = false;
        _wait_for_events(wait, num_fds_ready);

        pub::Time::UpdateTimer();
//        int64_t t2 = time_s::get_current_time();
        //NOTICE("consume_1[%d] %d", t2-t1, _current_num_tasks);

        bool ret = _add_new_tasks();
        if(false == ret) return;

//        pub::Time::UpdateTimer();
//        int64_t t3 = time_s::get_current_time();
        //NOTICE("consume_2[%d] %d", t3-t2, _current_num_tasks);

        _handle_events(num_fds_ready, wait);

//        pub::Time::UpdateTimer();
//        int64_t t4 = time_s::get_current_time();
        //NOTICE("consume_3[%d] %d", t4-t3, _current_num_tasks);
    }
}

void slave_t::_end_event_ok(job_event_t* job_event) {
    TRACE("_end_event_ok");
    job_event->log_job("OK", _current_num_tasks);
    epoll_ctl(_fd_epoll, EPOLL_CTL_DEL, job_event->fd(), NULL);
    _remotes_mgr.free_fd(job_event->fd(), true);
    _pool_job_event.Free(job_event);
    --_current_num_tasks;
}

}
