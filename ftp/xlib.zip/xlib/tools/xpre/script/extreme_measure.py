#!/home/xupeng02/software/bin/python

import signal

#############################################

Base=40

Step=10

#sec
Interval=10

Standard=0.9999

########################################

import os, time, sys, pdb

def onsignal_intr(signum, frame) :
  os.system("killall -9 xpre")

if __name__ == "__main__" :
  print "\n\n**************************\n\n"
  print "Base : %d" % Base
  print "Step: %d" % Step 
  print "Interval: %d" % Interval 
  print "Standard: %f\n" % Standard
  print "**************************\n\n"

  signal.signal(signal.SIGINT, onsignal_intr)

  os.system(
      "sed -i 's/^\(is_fixed_speed[ ]*:\).*$/\\1 0/g' conf/xpre.conf; "
      "sed -i 's/^\(num_downloads[ ]*:\).*$/\\1 0/g' conf/xpre.conf; "
      "echo 1 > conf/speed; "
      "killall -9 xpre; "
      "./bin/xpre &"
      )

  pattern = "reason["
  len_pattern = len(pattern)
  speed = Base
  while True :
    os.system(
      "echo %d > conf/speed; "
      ":> log/xpre.log; :> log/xpre.log.wf" % speed
    )
    
    time.sleep(Interval)

    all = 0
    ok = 0

    fp = open("log/xpre.log", "r");
    for line in fp :
      ret = line.find(pattern)
      if -1 != ret :
        all += 1
        if line[ret + len_pattern : ret + len_pattern + 2] == "OK" : 
          ok += 1
    
    if 0 == all :
      print "process ends"
      os.system("killall -9 xpre")
      sys.exit(0)

    ratio = 1.0*ok/all

    print "speed[%8d] ok[%8d] all[%8d] ratio[%10f]" % (speed, ok, all, ratio)

    if ratio < Standard :
      os.system("killall -9 xpre")
      sys.exit(0) 
    
    speed += Step
