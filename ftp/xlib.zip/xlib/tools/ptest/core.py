import sys, os, time, hashlib, pdb
from configer import configer
from timer import ptest_timer
import file_maker
from exception import *
from basic_test import test
from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL, log

timeline_dir = "/output/"
timeline_res_dir = "/result/"
dir_lib = os.path.dirname(os.path.abspath(__file__))

######################################
# init

def init() :
    sys.path.append(os.getcwd())

    configer.init()

    logfile_name = configer.get_conf_item("ptest", "logfile")
    if False == logfile_name : return False

    log.init(logfile_name)

######################################
# create tests

def create_tests() :
    test_names = configer.get_test_names()
    if False == test_names : CRITICAL("bad syntax of conf file: no entry for testnames"); return False

    tests = {}
    for item in test_names : 

        tests[item] = []

        #break if this item is blank
        ret = configer.get_testcase_names(item)
        if False == ret : CRITICAL("[fatal] bad syntax of conf file: no entry for [%s] -> cases" % item ); return False

        for item_2 in ret : tests[item] += [item_2]

    for test_name in test_names : 
        if os.path.isdir(test_name) : 
            print "%s exists, ignore ~~" % test_name
            continue

        if	os.system("mkdir %s/" % test_name) or \
            os.system("mkdir %s/data" % test_name) or \
            os.system("mkdir %s/prepare" % test_name) or \
            os.system("mkdir %s/env" % test_name) or \
            os.system("mkdir %s/output" % test_name) or \
            os.system("mkdir %s/result" % test_name)  or \
            os.system("touch %s/__init__.py" % test_name) :
            log = ("error in creating ptest directory tree")
            CRITICAL(log); print log
            return False

        file_maker.create_file("test_script", "%s/%s.py" % (test_name, test_name), [dir_lib] + tests[test_name])
        INFO("succeed in creating test %s" % test_name)

    print ("succeed in creating all tests, :-)")
    return True		

######################################
# run tests

def run_a_test(test_name, testcase_name, test_class) :
    INFO("case [%s] start, desc [%s]" % (testcase_name, test_class.__doc__))

    try :
        obj = test_class(test_name, testcase_name)
        obj.config()
        obj.record_log()
    except TEST_EXCEPTION, e: CRITICAL(e); return 0, 1

    num_succ = 0; num_fail = 0
    while test.current_round <= test.round :

        try :
            if 1 != test.round :
                round_info = "round %d : %s" % (test.current_round, test.rounds_names[test.current_round-1])
                INFO(round_info); WARNING(round_info)

            ret = obj.prepare()
            if True != ret :
                WARNING("Error in prepare stage in test %s testcase %s" % (test_name, testcase_name))
                num_fail += 1; test.current_round += 1; continue

            time_start = time.time()
            ret = obj.run()
            time_end = time.time()
            if True != ret :
                WARNING("Error in run stage in test %s testcase %s" % (test_name, testcase_name))
                num_fail += 1; test.current_round += 1; continue

            obj.analysis()

            test.timeline_analysis(test.cwd + timeline_dir, test.cwd + timeline_res_dir)

            ret = obj.check()
            if True != ret :
                WARNING("Error in check stage in test %s testcase %s" % (test_name, testcase_name))
                num_fail += 1; test.current_round += 1; continue

            num_succ += 1
            INFO("Succ in running test %s testcase %s in round %d consuming %f" % \
                (test_name, testcase_name, test.current_round, time_end - time_start))

        except TEST_EXCEPTION, e: 
            num_fail += 1
            INFO("Fail in running test %s testcase %s in round %d" % (test_name, testcase_name, test.current_round))

        test.current_round += 1

    return num_succ, num_fail

def find_func_in_(test_name, callback, case_name):

    #import module
    module = __import__("%s.%s" % (test_name, test_name), globals(), locals(), ["*"])

    num_succ = 0
    num_fail = 0

    INFO("start test %s" % test_name)

    #pre tests
    if True != module.pre_test() :
        log = "fail in executing pre-test script of test %s" % test_name
        CRITICAL(log); print log; return

    #run tests now
    for item in dir(module) :
        test_class = eval("module.%s" % item)
        if item[:5] == "test_" \
          and type(object) == type(test_class) \
          and ( case_name==None or case_name== item[5:] ) :
            succ, fail = callback(test_name, item[5:], test_class)
            num_succ += succ; num_fail += fail
	
    #post tests
    if True != module.post_test() :
        log = "fail in executing post-test script of test %s" % test_name
        CRITICAL(log); print log; return

    log = ("In all %d tests succ/fail %d/%d in test %s" % (num_succ + num_fail, num_succ, num_fail, test_name))
    INFO(log); print log

    test.report()

def run_tests(test_names = None, case_name = None) :
    if None == test_names :
        test_names = configer.get_test_names()
        if False == test_names : return False
        
        for item in test_names :
            filename = "%s/%s.py" % (item, item)    
            file_maker.check_and_update("test_script", filename)

    for test_name in test_names : 
        find_func_in_(test_name, run_a_test, case_name)

    return True	
