#subsegment should be like
#'''
#content
#'''

basic = \
(
'''
### start of the segment ###
''',

'''
import random, sys, pdb
from os import chdir, path
from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL, UNEXPECTED, REGISTER_NEW_LOGGER
from basic_test import test, REGISTE_TIMER, REGISTE_TIMER_MARKS, SET_ROUND, GET_CURRENT_ROUND, SET_REPORT
from judgement import *
from os_ops import *
sys.path.append("%s")
''',

'''
test.cwd = path.dirname(path.abspath(__file__))                                       
''',
    
'''
DATA_DIR = test.cwd + "/data/"                                                       
PREPARE_DIR = test.cwd + "/prepare/"                                                
ENV_DIR = test.cwd + "/env/"                                                       
OUTPUT_DIR = test.cwd + "/output/"                                                
RESULT_DIR = test.cwd + "/result/"                                               
'''
,

'''
def pre_test() :                                                                
''',

'''
    #global pre-test handle                                                    
    ##########################################################

    return True
''',

'''
def post_test() :
''',

'''
    #global post-test handle                                                 
    ##########################################################

    return True
''',

'''
### end of the segment ###
''',
)

per_test =  \
(
'''
### start of the segment ###
''',

'''
class test_%s(test):                                                    

    #please add description for the test here
    ##############################################

    #__init__() is forbidden here, or the result is undefined !            

''',

'''
    def config(self) :                                                       
''',

'''
        #please add configuration for your test here, which will be logged into report
        ##############################################################################
        #REGISTE_TIMER(timer_name, col_time, log_timeline, output_timeline)
        #REGISTE_TIMER_MARKS(timer_name, event_name, list_marks)
        #REGISTER_NEW_LOGGER(filename, levelname, format = logging.DEFAULT_FORMAT)

        #SET_ROUND(1)

        #SET_REPORT("report")

        #please add parameters for your test here, which will be logged into report
        ##############################################################################
        pass
''',        

'''
    def prepare(self) :                                                 
''',

'''
        #test data dir prepare, please work under DATA_DIR             
        chdir(DATA_DIR)                                               
        #####################################################

        #test prepare dir prepare, please work under PREPARE_DIR     
        chdir(PREPARE_DIR)                                          
        ##########################################################

        #test env dir prepare, please work under ENV_DIR           
        chdir(ENV_DIR)                                            
        ###################################################

        #test output dir prepare, please work under OUTPUT_DIR   
        chdir(OUTPUT_DIR)                                       
        ###################################################

        #test result dir prepare, please work under RESULT_DIR 
        chdir(RESULT_DIR)                                     
        ###################################################

        return True
''',

'''
    def run(self) :                                          
''',

'''
        #run test, please work under ENV_DIR                
        chdir(ENV_DIR)                                     
        ###########################################

        return True
''',
    
'''
    def analysis(self) :                                  
''',

'''
        #analysis output of the test, work under OUTPUT_DIR
        chdir(OUTPUT_DIR)                                 
        ##########################################################
''',

'''
    def check(self):                                     
''',

'''
        #check result of the test, work under OUTPUT_DIR
        chdir(RESULT_DIR)                              
        #######################################################

        return True
''', 

'''
### end of the segment ###

'''
)

template = ( basic, per_test )

if __name__ == '__main__' : 
    print basic, per_test
