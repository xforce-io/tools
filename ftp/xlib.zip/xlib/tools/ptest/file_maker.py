import os 
import template
from exception import *
import pdb

def create_file(template_name, file, args) :

    script = template.make_new_script(template_name,  num_repeat=len(args)-1, arguments=args)

    fp = open(file, "w")
    fp.write(script)
    fp.write("#"+template.get_md5sum_template(template_name))

def update_file(template_name, file) :

    fp = open(file, "r")
    script = template.make_updated_script(template_name, fp)

    fp.close()
    fp = open(file, "w")
    fp.write(script)
    fp.write("#"+template.get_md5sum_template(template_name))

def check_and_update(template_name, file) :

    #check version
    md5sum_templ = template.get_md5sum_template(template_name)

    fp = open(file, "r")
    fp.seek(-1 * len(md5sum_templ) - 1, os.SEEK_END)
    md5sum_script = fp.read(len(md5sum_templ) + 1)
    if md5sum_script[0] == "#" : md5sum_script = md5sum_script[1:]
    else : md5sum_script = md5sum_script[:-1]    

    if md5sum_script != md5sum_templ : 
        print "different version for file %s, need upgrade(Y/n)" % file 
        answer = raw_input()
        while answer != "Y" and answer != "n" : answer = raw_input()

        if answer == "Y" : update_file(template_name, file)
        else : raise USER_EXCEPTION("file[%s] old version ptest script" % file)    

if __name__ == "__main__" : 
    pass
