import string, time, pdb
from timer import ptest_timer
from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL
from configer import configer
from exception import *

report_dir = "/result/"

######################################
# base class of the test classes

class test(object) :

    ########
    #data

    #test.times
    cwd = ""                        #the cwd of the current test
    report_name = ""

    #number_unexpected

    ########
    #methods

    def __init__(self, test_name, testcase_name) : 

        ptest_timer.reset()
        test.test_name = test_name
        test.testcase_name = testcase_name
        test.round = 1
        test.rounds_names = []
        test.current_round = 1
        test.number_unexpected = 0


    @staticmethod
    def timeline_analysis(timeline_log_dir, timeline_res_dir) : 
        
        if True != ptest_timer.timeline_analysis(timeline_log_dir, timeline_res_dir) : return
        if test.current_round == test.round : ptest_timer.timeline_summary(timeline_res_dir)

    @staticmethod
    def report() :        

        if "" == test.report_name or type(test.report_name) != type("") : return 

        logfile_name = configer.get_conf_item("ptest", "logfile")
        if False == logfile_name : 
            log = "error in open log file"
            UNEXPECTED(log); raise USER_EXCEPTION(log)

        fin = open(test.cwd + "/../log/" + logfile_name, "r")    
        fout = open(test.cwd + report_dir + test.report_name + time.strftime("%y_%m_%d_%H_%M_%S", time.localtime()), "w")

        start = 0
        pos = 0
        token = "start test "
        for line in fin :    
            if -1 != line.find(token) : start = pos
            pos += 1    
        
        fin.seek(0)

        pos = 0
        for line in fin :
            if pos >= start : fout.write(line)
            pos += 1

        fin.close()
        fout.close()    

    def record_log(self) :
        config_log = ''
        dict_self = self.__dict__
        for config in dict_self :
            config_log += (str(config) + ' => ' + str(dict_self[config]) + ' | ')    
        INFO("configuration[ "+config_log+"]")    

###########
#user api
###########

def REGISTE_TIMER(timer_name, col_time, log_timeline, output_timeline) : 
    ptest_timer.register_timer(timer_name, col_time, log_timeline, output_timeline)

def REGISTE_TIMER_MARKS(timer_name, event_name, list_marks) : 
    ptest_timer.register_timer_marks(timer_name, event_name, list_marks)

def SET_ROUND(round, rounds_names = []) : 

    if type(round) != type(0) or round <= 0 : 
        WARNING("[warning]: invalid round parameter for set_times, set times to 1")
        round = 1

    test.round = round

    if [] != rounds_names and ( type(rounds_names) != type([]) or len(rounds_names) != round ) :   
        WARNING("[warning]: invalid round parameter for rounds_names, set rounds_names to []"); 
        rounds_names = [""] * round
        return

    rounds_names = [""] * round
    test.rounds_names = rounds_names
    for i in range(round) : test.rounds_names[i] = str(test.rounds_names[i])

def GET_CURRENT_ROUND() : 
    return test.current_round

def SET_REPORT(name) :
    test.report_name = name    
