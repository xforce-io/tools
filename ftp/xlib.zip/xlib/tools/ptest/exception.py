class TEST_EXCEPTION(Exception):
    def __init__(self, value="test exception"): self.value = value
    def __str__(self): return repr(self.value)

class ASSERT_EXCEPTION(Exception):
    def __init__(self, value="assert exception"): self.value = value
    def __str__(self): return repr(self.value)

class USER_EXCEPTION(Exception):
    def __init__(self, value="user exception"): self.value = value
    def __str__(self): return repr(self.value)

class OTHER_EXCEPTION(Exception):
    def __init__(self, value="other exception"): self.value = value
    def __str__(self): return repr(self.value)
