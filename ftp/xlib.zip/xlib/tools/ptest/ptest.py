#!/home/freeman/software/bin/python

import sys, pdb
import core
from exception import *

if __name__ == "__main__" :

    try :
        if len(sys.argv) <= 1 or ("r" != sys.argv[1] and "c" != sys.argv[1] and "v" != sys.argv[1]) :    
            print "Usage: python ptest.py [(c)reate|(r)un *test_name|(v)ersion]"
            sys.exit(1)

        if "v" == sys.argv[1] or "version" == sys.argv[1] :
            print "Test platform from superxup. Version 0.1.2"
            sys.exit(0)    

        if False == core.init() :
            print "error in creating ptest"; sys.exit(2)

        if ("c" == sys.argv[1] or "create" == sys.argv[1]) and 2 == len(sys.argv) :
            if True != core.create_tests() :
                print "error in creating ptest"; sys.exit(3)
            sys.exit(0)    

        if "r" == sys.argv[1] or "run" == sys.argv[1] :
            if 2 == len(sys.argv) :
                if True != core.run_tests() : 
                    print "error in running ptest"; sys.exit(4)
                else : sys.exit(0)
            elif 3 == len(sys.argv) :        
                core.run_tests([sys.argv[2]])    
                sys.exit(0)
            elif 4 == len(sys.argv) :
                core.run_tests([sys.argv[2]], sys.argv[3])
                sys.exit(0)
            else :
                print "invalid parameter to ptest run"
                sys.exit(1)

    except TEST_EXCEPTION, e : print e
    except ASSERT_EXCEPTION, e : print e
    except USER_EXCEPTION, e : print e
    except OTHER_EXCEPTION, e : print e
    except TEST_EXCEPTION, e : print e
