import os, sys, logging, pdb
from configer import configer

class log(object):

    ########
    #data
    
    logger = ""  #logger, initialized in log.py
    current_log_level = {"notset":0, "debug":10, "info":20, "warning":30, "error":40, "critical":50, "unexpected":60}

    MAX_USER_LEVEL = 100
    INC_USER_LEVEL = 10
    DEFAULT_FORMAT = '[%(levelname)10s] %(asctime)s %(filename)16s[line:%(lineno)d] %(message)s'

    #########
    #method

    @staticmethod
    def init(logfile_name) :

        os.system("mkdir log &> /dev/null")

        logging.addLevelName(log.current_log_level['unexpected'], "UNEXPECTED")

        log.logger = logging.getLogger("ptest")
        log.logger.setLevel(logging.DEBUG)

        formatter = logging.Formatter(log.DEFAULT_FORMAT)

        #########################
        # debug log handle 
        handle = logging.FileHandler("log/"+logfile_name +".debug", "a")
        handle.setLevel(logging.DEBUG)
        handle.setFormatter(formatter)
        log.logger.addHandler(handle)

        #########################
        # common log handle 
        handle = logging.FileHandler("log/"+logfile_name, "a")
        handle.setFormatter(formatter)

        class info_log_filter(logging.Filter) :
            def filter(self, record) :
                if record.levelno == logging.INFO : return True
                else : return False    

        info_filter = info_log_filter()
        handle.addFilter(info_filter)
        log.logger.addHandler(handle)

        #########################
        # warning log handle 
        handle = logging.FileHandler("log/"+logfile_name+".wf", "a")
        handle.setFormatter(formatter)

        class warning_log_filter(logging.Filter) :
            def filter(self, record) :
                if record.levelno >= logging.WARNING and record.levelno <= log.current_log_level["unexpected"]: return True
                else : return False    

        warning_filter = warning_log_filter()
        handle.addFilter(warning_filter)
        log.logger.addHandler(handle)

        ########################
        # register unexpected
        def unexpected(msg) : log.logger._log(log.current_log_level["unexpected"], msg, args=None, exc_info=None, extra=None)
        globals()["UNEXPECTED"] = unexpected

#############
# user api
#############

def REGISTER_NEW_LOGGER(filename, levelname, format = log.DEFAULT_FORMAT) :
    
    if levelname in log.current_log_level : log.logger.warning("levelname %s exists now." % levelname); return 

    log.current_log_level[levelname] = log.MAX_USER_LEVEL
    log.MAX_USER_LEVEL += log.INC_USER_LEVEL

    logging.addLevelName(log.current_log_level[levelname], levelname)

    handle = logging.FileHandler("log/" + filename, "a")
    formatter = logging.Formatter(format)
    handle.setFormatter(formatter)

    class user_log_filter(logging.Filter) :
        def filter(self, record) :
            if record.levelname == levelname : return True
            else : return False

    log_filter = user_log_filter()           
    handle.addFilter(log_filter)
    log.logger.addHandler(handle)

    def tmp(msg) : log.logger._log(log.current_log_level[levelname], msg, args=None, exc_info=None, extra=None)
    globals()[levelname] = tmp

def INFO(msg) : log.logger._log(logging.INFO, msg, args=None, exc_info=None, extra=None)

def DEBUG(msg) : log.logger._log(logging.DEBUG, msg, args=None, exc_info=None, extra=None)

def WARNING(msg) : log.logger._log(logging.WARNING, msg, args=None, exc_info=None, extra=None)

def ERROR(msg) : log.logger._log(logging.ERROR, msg, args=None, exc_info=None, extra=None)

def CRITICAL(msg) : log.logger._log(logging.CRITICAL, msg, args=None, exc_info=None, extra=None)
