from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL, UNEXPECTED
from basic_test import test
from exception import *

####################
# common judgements
######################

EXPECTS='''
def EXPECT_%s(%s, msg = "") :
    if %s : 
        test.number_unexpected += 1
        if "" == msg : msg = "%s" %% (%s)
        UNEXPECTED(msg)
'''        
exec( EXPECTS % ( "ZR",        "obj",     "0 != obj",               "%s is not equal to 0",            "str( obj)" ) )
exec( EXPECTS % ( "NZ",        "obj",     "0 == obj",                   "%s is equal to 0",            "str( obj)" ) )
exec( EXPECTS % ( "EQ", "obj1, obj2", "obj1 != obj2",            "%s and %s are not equal", "str(obj1), str(obj2)" ) )
exec( EXPECTS % ( "GT", "obj1, obj2", "obj1 <= obj2",          "%s is not greater than %s", "str(obj1), str(obj2)" ) )
exec( EXPECTS % ( "GE", "obj1, obj2", "obj1  < obj2", "%s is not greater or equal than %s", "str(obj1), str(obj2)" ) )
exec( EXPECTS % ( "LT", "obj1, obj2", "obj1 >= obj2",             "%s is not less than %s", "str(obj1), str(obj2)" ) )
exec( EXPECTS % ( "LE", "obj1, obj2", "obj1  > obj2",    "%s is not less or equal than %s", "str(obj1), str(obj2)" ) )

ASSERTS='''
def ASSERT_%s(%s, msg = "") :
    if %s : 
        if "" == msg : msg = "%s" %% (%s)
        UNEXPECTED(msg)
        raise TEST_EXCEPTION("ASSERT_%s %%s fail" %% (%s) )
'''        

exec( ASSERTS % ( "ZR",        "obj",     "0 != obj",               "%s is not equal to 0",            "str(obj )", "ZR", "           str( obj)" ) )
exec( ASSERTS % ( "NZ",        "obj",     "0 == obj",                   "%s is equal to 0",            "str(obj )", "NZ", "           str( obj)" ) )
exec( ASSERTS % ( "EQ", "obj1, obj2", "obj1 != obj2",            "%s and %s are not equal", "str(obj1), str(obj2)", "EQ", "str(obj1), str(obj2)" ) )
exec( ASSERTS % ( "GT", "obj1, obj2", "obj1 <= obj2",          "%s is not greater than %s", "str(obj1), str(obj2)", "GT", "str(obj1), str(obj2)" ) )
exec( ASSERTS % ( "GE", "obj1, obj2", "obj1  < obj2", "%s is not greater or equal than %s", "str(obj1), str(obj2)", "GE", "str(obj1), str(obj2)" ) )
exec( ASSERTS % ( "LT", "obj1, obj2", "obj1 >= obj2",             "%s is not less than %s", "str(obj1), str(obj2)", "LT", "str(obj1), str(obj2)" ) )
exec( ASSERTS % ( "LE", "obj1, obj2", "obj1  > obj2",    "%s is not less or equal than %s", "str(obj1), str(obj2)", "LE", "str(obj1), str(obj2)" ) )

###########################
# File judgements
############################

# assert 'line' is a part of certain line in file filepath  
def EXPECT_LINE_IN_FILE(line, filepath) :

    try: fp = open(filepath, "r")
    except Exception, e :
        test.number_unexpected += 1
        UNEXPECTED( "EXPECT_LINE_IN_FILE %s %s fail, reason is : fail in opening file %s" % (line, filepath, filepath) )
        return 

    for a_line in fp :
        if -1 != a_line.find(line) : return
    
    test.number_unexpected += 1
    UNEXPECTED( "EXPECT_LINE_IN_FILE %s %s fail, reason is : no line %s in file %s" % (line, filepath, line, filepath) )

# assert 'line' is a part of certain line in file filepath  
def ASSERT_LINE_IN_FILE(line, filepath) :

    try: fp = open(filepath, "r")
    except Exception, e :
        UNEXPECTED( "ASSERT_LINE_IN_FILE %s %s fail, reason is : fail in opening file %s" % (line, filepath, filepath) )
        raise TEST_EXCEPTION( "ASSERT_LINE_IN_FILE %s %s fail" % (filepath, line) )

    for a_line in fp :
        if -1 != a_line.find(line) : return
    
    UNEXPECTED( "ASSERT_LINE_IN_FILE %s %s fail, reason is : no line %s in file %s" % (line, filepath, line, filepath) )
    raise TEST_EXCEPTION( "ASSERT_LINE_IN_FILE %s %s fail" % (filepath, line) )
