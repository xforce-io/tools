import os, sys, pdb
import ConfigParser

class configer(object):

    ########
    #data

    config_parser = ""

    #########
    #method

    @staticmethod
    def init() :    
        #read list of test names from conf file into 'test_names', and validate them
        if False == os.path.isfile("ptest.conf") : print "no ptest.conf"; sys.exit(1)

        try:
            configer.config_parser = ConfigParser.ConfigParser()
            configer.config_parser.read("ptest.conf")
        except Exception : print "bad syntax for ptest.conf"; sys.exit(1)
    
    @staticmethod
    def get_conf_item(title, item_name) :
        try: ret = configer.config_parser.get(title, item_name)
        except Exception : ret = '' 

        if '' == ret : print ("bad syntax of conf file: no entry for [%s] -> %s" % (title, item_name)); return False
        return ret    

    # return test names in config files
    # @return: return list containing test names if succeed, else return False
    @staticmethod
    def get_test_names() :
        ret = configer.get_conf_item("ptest", "tests")
        if False == ret : return False
        else : return ret.split()

    @staticmethod
    def get_testcase_names(test_name) :
        ret = configer.get_conf_item(test_name, "cases")
        if False == ret : return False
        else : return ret.split()	
