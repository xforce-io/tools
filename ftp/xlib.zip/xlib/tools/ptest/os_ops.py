import sys, subprocess, os, pdb
from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL, UNEXPECTED
from exception import *

HANDLE_IGNORE = 0
HANDLE_WARNING = 1
HANDLE_UNEXPECTED = 2

def modify_bg_cmd(cmd) :
    # I don't know why, but it really works, without this modification, a "... &" cmd won't work in
    # check_output function
    #if cmd[-1] == '&' : return "`" + cmd[:-1] + "` &> /dev/null &" 
    if cmd[-1] == '&' : return cmd[:-1] + " &> /dev/null &" 
    return cmd    

# call os processes
def CALL(cmd, handle_unexpected = HANDLE_UNEXPECTED, expect_non_zero = 0) :

    if type(cmd) != type("") :
        log = "type of 1st parameter of CALL should be string"
        UNEXPECTED(log); raise TEST_EXCEPTION(log)

    #strip blanks at the head and end of cmd
    len_cmd = len(cmd)
    for i in range(len_cmd) :
        if ' ' == cmd[0] : cmd = cmd[1:]
        else : break    
    len_cmd = len(cmd)
    for i in range(len_cmd) :
        if ' ' == cmd[-1] : cmd = cmd[:-1]
        else : break    

    cmd = modify_bg_cmd(cmd)        

    try:
        retcode = subprocess.check_output(cmd, shell=True)
    except subprocess.CalledProcessError, e :
        if expect_non_zero : 
            DEBUG("expected : ret of cmd[%s] is %s" % (cmd, e.returncode))
            return None
            
        log = "not expected : cmd[%s] output[%s] retcode[%s]" % (cmd, e.output, e.returncode)
        if HANDLE_UNEXPECTED == handle_unexpected :
            UNEXPECTED(log); raise TEST_EXCEPTION(log)
        elif HANDLE_WARNING == handle_unexpected : 
            WARNING(log)
        else : 
            DEBUG(log)    
        return None
    
    if expect_non_zero :
        log = "not expected : succeed in excuting cmd[%s]" % cmd
        if HANDLE_UNEXPECTED == handle_unexpected :
            UNEXPECTED(log); raise TEST_EXCEPTION(log)
        elif HANDLE_WARNING == handle_unexpected : 
            WARNING(log)   
        else : 
            DEBUG(log)    
    else :    
        DEBUG("expected : succeed in excuting cmd[%s]" % cmd)
    return retcode[:-1]
    
################
# remote process

def establish_relation(account) :
        
    if 0 != os.system("ls ~/.ssh/id_rsa.pub &> /dev/null") :
        CALL("mkdir ~/.ssh &> /dev/null; rm -rf ~/.ssh/id_rsa", HANDLE_IGNORE)
        CALL("ssh-keygen -t rsa -f ~/.ssh/id_rsa -P '' -N ''", HANDLE_IGNORE)

    CALL("ssh %s 'mkdir ~/.ssh &> /dev/null'" % account, HANDLE_IGNORE)
    CALL("scp ~/.ssh/id_rsa.pub %s:~/.ssh/authorized_keys" % account, HANDLE_IGNORE)
    CALL("ssh %s 'chmod 600 ~/.ssh/authorized_keys &> /dev/null'" % account, HANDLE_IGNORE)
    CALL("ssh %s 'chmod 700 ~/.ssh &> /dev/null'" % account, HANDLE_IGNORE)

def SSH(account, cmd_list, handle_unexpected = HANDLE_UNEXPECTED) :

    if type(cmd_list) != type([]) :
        log = "cmd_list must be a list"
        UNEXPECTED(log); raise TEST_EXCEPTION(log)

    if 0 == len(cmd_list) : return None

    #ssh_cmd = 'ssh %s \"%s\"'
    ssh_cmd = 'ssh %s \'%s\''
    establish_relation(account)
    if 1 == len(cmd_list) : 
        if type(cmd_list[0]) == type("") : 
            return CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[0])))
        elif 2 == len(cmd_list[0]) : 
            return CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[0][0])), cmd_list[0][1])
        elif 3 == len(cmd_list[0]) :  
            return CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[0][0])), cmd_list[0][1], cmd_list[0][2])
        else :
            log = "error cmd_list[%s] to SSH" % str(cmd_list)
            UNEXPECTED(log); raise TEST_EXCEPTION(log)
    else : 
        cwd = "~"                    #the current dir in the remote machine
        pos = 0
        len_cmds = len(cmd_list)

        def modify_cwd(old_dir, new_dir) :
            if "/" == new_dir[0] or "~" == new_dir[0] :
                return new_dir
            elif "./" == new_dir[:2] or "../" == new_dir[:3] :  #if "cd dir", dir ~= ./
                return old_dir + "/" + new_dir

        argc_current = 0
        #state machine
        while pos <= len_cmds :
            if pos == len_cmds or type(cmd_list[pos]) == type("") :
                if 1 == argc_current : 
                    if cmd_list[pos - 1][:3] == "cd " : 
                        cwd = modify_cwd(cwd, cmd_list[pos - 1][3:])
                        ret = CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[pos - 1])))
                    else :     
                        ret = CALL(ssh_cmd % (account, "".join(["cd ", cwd, ";", modify_bg_cmd(cmd_list[pos - 1]) ])))
                    argc_current = 1
                elif 2 == argc_current : 
                    if cmd_list[pos - 2][:3] == "cd " : 
                        cwd = modify_cwd(cwd, cmd_list[pos - 2][3:])
                        ret = CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[pos - 2])), cmd_list[pos - 1])
                    else :     
                        ret = CALL(ssh_cmd % (account, "".join(["cd ", cwd, ";", modify_bg_cmd(cmd_list[pos - 2]) ])), cmd_list[pos - 1])
                    argc_current = 1    
                elif 3 == argc_current : 
                    if cmd_list[pos - 3][:3] == "cd " : 
                        cwd = modify_cwd(cwd, cmd_list[pos - 3][3:])
                        ret = CALL(ssh_cmd % (account, modify_bg_cmd(cmd_list[pos - 3])), cmd_list[pos - 2], cmd_list[pos - 1])
                    else :     
                        ret = CALL(ssh_cmd % (account, "".join([ "cd ", cwd, ";", modify_bg_cmd(cmd_list[pos - 3]) ])), cmd_list[pos - 2], cmd_list[pos - 1])
                    argc_current = 1    
                elif 0 == argc_current : 
                    argc_current += 1    
                else :
                    log = "error cmd_list[%s] to SSH" % str(cmd_list)
                    UNEXPECTED(log); raise TEST_EXCEPTION(log)
            elif type(cmd_list[pos]) == type(0) :   
                argc_current += 1
            else :
                log = "syntax of SSH [%s] is invalid" % str(cmd_list)
                UNEXPECTED(log); raise TEST_EXCEPTION(log)

            pos += 1    
        return ret    

def SCP(addr1, addr2, handle_unexpected = HANDLE_UNEXPECTED) :            

    def kind_addr(addr) :
        if 0 == os.system("ls %s &> /dev/null" % addr) : return 0
        elif addr.find(":") != -1 : return 1    
        else : return 2

    if kind_addr(addr1) == 0 and kind_addr(addr2) == 1 :
        account = addr2[:addr2.find(":")]    
    elif kind_addr(addr2) == 0 and kind_addr(addr1) == 1 :    
        account = addr1[:addr1.find(":")]    
    else : 
        log = "parameter wrong addr1[%s] addr2[%s]" % (addr1, addr2)
        UNEXPECTED(log); raise TEST_EXCEPTION(log)

    establish_relation(account)
    return CALL("scp -r %s %s" % (addr1, addr2), handle_unexpected)
