import sys, string, pdb
from logger import INFO, DEBUG, WARNING, ERROR, CRITICAL

class timer(object) :
    
    def __init__(self, col_time, log_timeline, output_timeline) :
        self.col_time = col_time
        self.log_timeline = log_timeline
        self.output_timeline = output_timeline
        self.list_marks = {}

        self.timeline = []              #interval in a process, a process is a seq of events which is registed by user
        self.timeline_in_a_test = []
        self.time_intervals = []         #the intervals in all tests

class ptest_timer(object) :

    #########
    #data 

    timers = {}

    #########
    #methods

    @staticmethod
    def reset() : 
        ptest_timer.timers = {}

    @staticmethod
    def register_timer(timer_name, col_time, log_timeline, output_timeline) : 
        
        if ( type(col_time) != type(0) or 0 > col_time ) or \
             (type("") != type(log_timeline) or "" == log_timeline) or \
             (type("") != type(output_timeline) or "" == output_timeline) :
            WARNING("invalid parameter for register_timer: timer_name[%s]" % timer_name)
            return

        ptest_timer.timers[timer_name] = timer(col_time, log_timeline, output_timeline);

    @staticmethod
    def register_timer_marks(timer_name, event_name, list_marks) : 

        if (timer_name in ptest_timer.timers) != True :
            WARNING("invalid parameter for register_timer_marks : no registed timer_name[%s], ignore~" % (timer_name)) 
            return

        timer = ptest_timer.timers[timer_name]

        if type([]) != type(list_marks) or 0 == len(list_marks): 
            WARNING("invalid parameter for register_timer_marks : timer_name[%s] event_name[%s], ignore~" % (timer_name, event_name)) 
            return

        for mark in list_marks :
            if ( type([]) != type(mark) ) or ( 2 != len(mark) ) or \
                ( type(0) != type(mark[0]) or mark[0] < 0 ) or ( type("") != type(mark[1]) ) or ( "" == mark[1] ) :
                WARNING("invalid parameter for register_timer_marks : timer_name[%s] event_name[%s], ignore~" % (timer_name, event_name)) 
                return

        key = len(timer.list_marks)
        timer.list_marks[key] = {"event_name" : event_name, "list_marks" : list_marks}

    @staticmethod
    def timeline_analysis(timeline_log_dir, timeline_res_dir) :

        if ptest_timer.timers == {} : return False

        for timer_name in ptest_timer.timers :
            timer = ptest_timer.timers[timer_name]

            #analysis and dump timeline 
            fp = open(timeline_log_dir + "/" + timer.log_timeline, "r")
            for line in fp :
                row = line.split()
                len_row = len(row)

                match = 1
                key = len(timer.timeline)
                for mark in timer.list_marks[key]["list_marks"] :
                    if len_row <= mark[0] or mark[1] != row[mark[0]]: match = 0; break
                
                if 1 == match :
                    timer.timeline += [ [timer.list_marks[key]["event_name"], string.atof(row[timer.col_time])] ]
                    if len(timer.list_marks) == key + 1 :

                        timer.timeline_in_a_test += [ timer.timeline ]
                        timer.timeline = []
                        continue

                #weather to reset
                match = 1
                for mark in timer.list_marks[0]["list_marks"] :
                    if len_row <= mark[0] or mark[1] != row[mark[0]]: match = 0; break

                if 1 == match : 
                    timer.timeline = [ [timer.list_marks[0]["event_name"], string.atof(row[timer.col_time])] ]
                    continue
                    
            fp.close()

            fp = open(timeline_res_dir + "/" + timer.output_timeline, "a")

            fp.write("\ntimer %s\n\n" % timer_name)
            for timeline in timer.timeline_in_a_test :

                time_interval = []
                fp.write("\n%40s%16s%30s" % ("events", "time", "time_interval"))
                len_timeline = len(timeline)
                for index in range(len_timeline): 
                    if 0 != index : 
                        interval = timeline[index][1] - timeline[index-1][1]
                        time_interval += [ interval ]
                        fp.write("%30f" % interval)
                    fp.write("\n%40s %15s" % (timeline[index][0], timeline[index][1]))

                timer.time_intervals += [ time_interval ]    
            fp.close()

            timer.timeline_in_a_test = []

        return True    

    @staticmethod
    def timeline_summary(timeline_res_dir) :

        for timer_name in ptest_timer.timers :
            timer = ptest_timer.timers[timer_name]

            if 0 == len(timer.time_intervals) : continue
            #output analysis result to timer.output_timeline

            num_intervals = len(timer.time_intervals[0])
            num_processes = len(timer.time_intervals)
            interval_in_all = [ 0 for i in range(num_intervals) ]
            for item in timer.time_intervals :
                for index in range(num_intervals) :
                    interval_in_all[index] += item[index]

            fp = open(timeline_res_dir + "/" + timer.output_timeline, "a")
            fp.write("\ntimer %s\n" % timer_name)
            fp.write("\nnum_processes: %d \n" % num_processes)
            fp.write("\narverage intervals: \n")
            for index in range(num_intervals) : fp.write("%f\t" % (interval_in_all[index]*1.0/num_processes))
            fp.write("\nintervals in all: \n")
            for index in range(num_intervals) : fp.write("%f\t" % (interval_in_all[index]*1.0))
            fp.close()
