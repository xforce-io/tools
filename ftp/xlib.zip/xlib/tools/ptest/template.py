import templates.test_script
from exception import *
import hashlib
import pdb

templates = { "test_script" : templates.test_script.template }
SKELETON_BEGIN = "## this content below must not be modified!! ##"
SKELETON_END = "## this content above must not be modified!! ##"

def decorate_skeleton_line(subsegment) :
    return '\n' + SKELETON_BEGIN + subsegment + SKELETON_END + '\n'

def make_segment_script(segment, data) :
    script = ""
    len_seg = len(segment)
    pos = 0
    if data != None :
        while pos < len_seg :    
            if data[pos] != None : subseg = data[pos]
            else : subseg = segment[pos]
            
            if pos % 2 == 0 : subseg = decorate_skeleton_line(subseg)
            script += subseg
            pos += 1    
    else :        
        while pos < len_seg :    
            if pos % 2 == 0 : script += decorate_skeleton_line(segment[pos])
            else : script += segment[pos]    
            pos += 1    
    return script

#if len(template[1]) == 2, means that the second template is one used circly
def make_template_script(template, data=None, num=0, args=None) :
    if len(template) == 1 : 
        script = make_segment_script(template[0], data)
    elif len(template) == 2 : 
        pos = len(template[0])
        len_sec_seg = len(template[1])
        if data != None :
            script = make_segment_script(template[0], data[:pos])
            len_data = len(data)
            while pos < len_data :
                ret = make_segment_script(template[1], data[pos:])
                pos += len_sec_seg
                script += ret
        else :
            script = make_segment_script(template[0], None)
            for i in range(num) : script += make_segment_script(template[1], None)
    
    if args == None :  return script
    else : return (script % tuple(args[:script.count("%s")]))    

#read out a data array from fp according to a segment
# return : if read eof,return None
def get_test_script_segment(segment, fp) :
    line = fp.readline()
    if line == '' : return None

    #############################################
    #skip the first blank line if there is 
    is_blank_line = 1
    for c in line :
        if c not in '\n\t\r ' : is_blank_line = 0; break
    if is_blank_line == 1 : line = fp.readline()
    #############################################

    data = []
    len_seg = len(segment)
    if len_seg % 2 == 0 : raise ASSERT_EXCEPTION("segment size[%d]" % len_seg) 

    if line[:-1] != SKELETON_BEGIN : return None

    line = fp.readline()
    if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_END")
    while line[:-1] != SKELETON_END : 
        line = fp.readline()
        if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_END")
    data += [None]

    pos = 1    
    while pos < len_seg :

        part = ''
        line = fp.readline()
        if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_BEGIN")
        while line[:-1] != SKELETON_BEGIN: 
            part += line    
            line = fp.readline()
            if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_END")
        if part != '' : data += [part[:-1]]   #eliminate the last '\n'
        else : data += [None]    

        line = fp.readline()
        if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_END")
        while line[:-1] != SKELETON_END : 
            line = fp.readline()
            if line == '' : raise USER_EXCEPTION("unexpected eof : when looking for SKELETON_END")
        data += [None]
   
        pos += 2
    return data

def get_test_script_content(template, fp) :
    data = get_test_script_segment(template[0], fp)
    ret = get_test_script_segment(template[1], fp)
    while ret != None :
        data += ret 
        ret = get_test_script_segment(template[1], fp)
    return data

###################### public ##############################################

def make_new_script(template_name, num_repeat=0, arguments=None) :
    template = templates[template_name]
    return make_template_script(template, args=arguments, num = num_repeat)

def make_updated_script(template_name, fp) :
    template = templates[template_name]
    test_script_content = get_test_script_content(template, fp)
    return make_template_script(template, data=test_script_content)         #there should be no "%s" in skeleton part of a template

def get_md5sum_template(template_name) :
    template = templates[template_name]
    md5_generator = hashlib.md5()
    for segment in template :
        i=0
        for item in segment: 
            if i%2 == 0 : md5_generator.update(item)
            i+=1
    return md5_generator.hexdigest()

if __name__ == '__main__' : 
    a =  \
'''
asf
svadv
vfvf
'''
    print decorate_skeleton_line(a) 
