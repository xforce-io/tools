import os, logging, traceback
import hashlib
import pdb

class father(object) :

    def report(self) :
        pdb.set_trace()
        print self.func.__func__.func_code.co_names

class temp(father) :
    print "temp"

    def func(self) :
        self.a = 1
        b = 2
        temp.c = 2


def hello() : 
    print "hello"


t = temp()

t.func()

t.report()
