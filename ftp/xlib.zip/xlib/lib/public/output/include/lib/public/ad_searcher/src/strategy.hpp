template <typename context_t>
class strategy_t
{
    public:
    explicit strategy_t(const std::string& strategy_name)
        : _strategy_name(strategy_name) {}

    const std::string& name() { return _strategy_name; }

    virtual bool reset() { return true; }

    /*
     * @return : >0  : process in the channel should end
     *           ==0 : process in the channel should come to the next strategy
     *           <0  : error in process
     */
    virtual int run(context_t* context) = 0;

    private:
    const std::string _strategy_name;
};
