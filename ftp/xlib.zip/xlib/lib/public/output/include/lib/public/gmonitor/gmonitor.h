#pragma once

#include "monitor.h"

namespace xlib { namespace monitor {
class Monitor;
}}

namespace xlib { namespace pub {

class GMonitor {
 public:
  static bool Init(const std::string& conf_path);
  static monitor::Monitor& Get() { return *monitor_; }
  static void Tini();

 private:
  static monitor::Monitor* monitor_; 
};

}}
