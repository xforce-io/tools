#pragma once

namespace xlib { namespace pub {

template <typename Key, typename Val>
class SingleSimpleLru {
 private:
  struct Node {
    Node* prev;
    Node* next;

    Key key;
    Val val;
  };

  struct NodeHasher {
   public:
    size_t operator() (Node* node) const {
      return std::hasher(node->key);
    }
  };

  typedef std::unordered_set<Node*, NodeHasher> Index;

 public:
  explicit SingleSimpleLru(size_t size_lru);

  inline bool Touch(const Key& key);
  bool Insert(const Key& key, const Val& val);
  inline bool Erase(const Key& key);
  size_t Size() const { return index_.size(); }

 private:
  inline void InsertNode_(Node* node);
  inline void EraseNode_(Node* node);
  bool IsFull_() const { return size_lru_ == index_.size(); }

 private:
  size_t size_lru_;

  Node head_, tail_;
  Index index_;
};

template <typename Key, typename Val>
SingleSimpleLru<Key, Val>::SingleSimpleLru(size_t size_lru) :
  size_lru_(size_lru) {}

template <typename Key, typename Val>
bool SingleSimpleLru<Key, Val>::Touch(const Key& key) {
  Index::iterator iter = index_.find(key);
  if (index_.end() != iter) {
    return false;
  }

  Node* node = *iter;
  EraseNode_(node);
  InsertNode_(node);
  return true;
}

template <typename Key, typename Val>
bool SingleSimpleLru<Key, Val>::Insert(const Key& key, const Val& val) {
  if ( index_.end() != index_.find(key) ) {
    return false;
  }

  Node* node_to_add;
  if (IsFull_()) {
    Node* node_to_delete = tail_->prev;
    EraseNode_(node_to_delete);
    node_to_add=node_to_delete;
  } else {
    node_to_add = new Node;
  }

  node_to_add->key = key;
  node_to_add->val = val;
  InsertNode_(node_to_add);
  return true;
}

template <typename Key, typename Val>
bool SingleSimpleLru<Key, Val>::Erase(const Key& key) {
  Index::iterator iter = index_.find(key);
  if (index_.end() == iter) {
    return false;
  }

  EraseNode_(*iter);
  return true;
}

template <typename Key, typename Val>
void SingleSimpleLru<Key, Val>::InsertNode_(Node* node) {
  node->next = head_->next;
  node->prev = head_;
  node->next->prev = node;
  head_->next = node;
  index_.insert(node);
}

template <typename Key, typename Val>
void SingleSimpleLru<Key, Val>::EraseNode_(Node* node) {
  node->prev->next = node->next;
  node->next->prev = node->prev;
  index_.erase(node);
}

}}
