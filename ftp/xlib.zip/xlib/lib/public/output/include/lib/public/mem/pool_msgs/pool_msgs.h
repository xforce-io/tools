#ifndef XLIB_PUBLIC_BASIC_MEM_POOL_MSGS_H
#define XLIB_PUBLIC_BASIC_MEM_POOL_MSGS_H

#include <vector>
#include "public/basic/pool_objs.hpp"
#include "../../msg.hpp"

namespace xlib { namespace pub {

/* RAII */
class PoolMsgs
{
 public:
  typedef pub::PoolObjsInit<Msg, Msg::InitParam> Pool;

 public:
  static const size_t kDefaultPoolAllocSize = 100*1024;

 public:
  /*
   * pair contains <upbound, step>
   */
  explicit PoolMsgs(
      const std::vector< std::pair<size_t, size_t> >& conf) : 
    conf_(conf),  
    num_pools_(0),  
    init_(false) {}

  inline Msg* Get(size_t size);
  inline void Free(Msg* msg);
  virtual ~PoolMsgs() {}

 private:
  bool Init_();

 private:
  //const
  std::vector< std::pair<size_t, size_t> > conf_;
  ///

  size_t num_pools_; 
  std::vector<Pool> pools_;
  std::vector<size_t> len_to_pool_index_;
  size_t max_msg_size_;

  bool init_;
};

Msg* PoolMsgs::Get(size_t size)
{
  XLIB_RAII_INIT(NULL)

  if (size<=max_msg_size_) {
    return pools_[len_to_pool_index_[size]].Get();
  } else {
    return NULL;
  }
}

void PoolMsgs::Free(Msg* msg) 
{
  XLIB_RAII_INIT()
  return pools_[len_to_pool_index_[msg->size]].Free(msg);
}

}}

#endif
