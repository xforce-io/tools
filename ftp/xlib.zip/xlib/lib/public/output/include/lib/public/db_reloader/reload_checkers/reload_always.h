#pragma once

namespace xlib { namespace pub {

class ReloadAlways {
 public:
  explicit ReloadAlways(const void* /*params*/) {}
  int ToLoad() { return 0; }
};

}}
