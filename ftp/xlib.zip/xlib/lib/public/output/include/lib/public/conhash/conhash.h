#ifndef XLIB_PUBLIC_BASIC_CONHASH_H
#define XLIB_PUBLIC_BASIC_CONHASH_H

#include <ostream>
#include <tr1/unordered_map>
#include "public/common.h"
#include "base_conhash.h"

namespace xlib { namespace pub {

struct ConhashNode
{
  char* name;
  size_t id;
};

class ConhashIterator
{
 public: 
  ConhashIterator(Conhash& conhash) : 
      conhash_(conhash),
      conhash_interval_(NULL) {}

  ConhashIterator operator++();
  ConhashIterator operator++(int);
  const char* operator*();

 private:
  ///const
  Conhash& conhash_; 
  //

  ConhashInterval* conhash_interval_;
};

class Conhash
{
 public:
  explicit Conhash();

  int AddNode(char* name, size_t weight);
  ConhashIterator GetNode();
  ConhashIterator GetNext(ConhashIterator iterator);

 private:
  BaseConhash base_conhash_;
//  std::tr1::unordered_map<size_t, std::string> id_to_name_;
//  std::tr1::unordered_map< std::pair<size_t, size_t>, size_t > virtual_id_to_id_;
  std::tr1::unordered_map<size_t, std::string*> virtual_id_to_name_;

  size_t current_id_;
  size_t current_virtual_id_;

  friend std::ostream& operator<<(std::ostream& oss, const Conhash& conhash);
};

}}

#endif
