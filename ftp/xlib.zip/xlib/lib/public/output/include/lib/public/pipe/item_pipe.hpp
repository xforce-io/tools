#ifndef XLIB_PUBLIC_TOOLS_PIPE_ITEM_PIPE_H
#define XLIB_PUBLIC_TOOLS_PIPE_ITEM_PIPE_H

#include <list>
#include "public/common.h"
#include "public/basic/pool_objs.hpp"
#include "unidirection_pipe.hpp"

namespace xlib { namespace pub
{

template<typename msg_t>
class item_pipe_t
{
 public:
  typedef std::list<msg_t*> msgs_list_t;

 public:
  static const double DefaultResizeFactor = 2;
  static const size_t DefaultMaxNumObjs = 0xffffffff;

 public:
  explicit item_pipe_t(
      size_t init_num_objs=1, 
      bool to_resize=false, 
      size_t max_num_objs=DefaultMaxNumObjs);

  size_t num_free_msgs() const { return _pool_objs.NumObjsLeft(); }
  size_t num_all_msgs() const { return _pool_objs.NumObjsAll(); }

  /*
   * @sender interfaces
   */
 public:
  inline msg_t* get_msg();
  void send_msg(msg_t* msg);
  inline void free_msgs();
  void shutdown_sender() { _tobe_consumed.close_sender(); }

 private:
  inline void _free_msgs(msgs_list_t& msgs_list);

  /*
   * @reciever interfaces
   */
 public:
  void recieve_msgs(msgs_list_t& msgs_list) 
  { _tobe_consumed.recieve_msgs(msgs_list); }

  void return_msg(msgs_list_t& msgs_list);

  /*
   * @brief: need this interface because we have to
   *          fetch all data in two lists 
   */

  bool shutdown_reciever(msgs_list_t& msgs_list)
  { return _tobe_consumed.close_reciever(msgs_list); }

  inline bool close_pipe(msgs_list_t& msgs_list);

 private:
  //const
  size_t _init_num_objs;
  bool _to_resize;
  size_t _max_num_objs; 
  ///

  PoolObjs<msg_t> _pool_objs;

  unidirection_pipe_t<msg_t> _tobe_consumed;
  unidirection_pipe_t<msg_t> _tobe_freed;
};

template<typename msg_t>
item_pipe_t<msg_t>::item_pipe_t(
    size_t init_num_objs, 
    bool to_resize, 
    size_t max_num_objs)
{ 
  _pool_objs = PoolObjs<msg_t>(
      init_num_objs,
      PoolObjs<msg_t>::kDefaultMemPerBlock,
      to_resize,
      max_num_objs/
          (PoolObjs<msg_t>::kDefaultMemPerBlock/sizeof(msg_t)));
}

template<typename msg_t>
msg_t* item_pipe_t<msg_t>::get_msg() 
{ 
  msg_t* msg = _pool_objs.Get(); 
  if(NULL == msg) _tobe_consumed.send_msg(NULL);
  return msg;
}

template<typename msg_t>
void item_pipe_t<msg_t>::send_msg(msg_t* msg) 
{ 
  bool ret = _tobe_consumed.send_msg(msg); 
  if(false == ret) _pool_objs.Free(msg);
}

template<typename msg_t>
void item_pipe_t<msg_t>::free_msgs()
{
  msgs_list_t msgs_list;
  _tobe_freed.recieve_msgs(msgs_list);
  _free_msgs(msgs_list);
}

template<typename msg_t>
void item_pipe_t<msg_t>::return_msg(msgs_list_t& msgs_list)
{
  while(false == msgs_list.empty()) {
    msg_t* msg = msgs_list.front();
    msgs_list.pop_front();
    _tobe_freed.send_msg(msg);
  }
}

template<typename msg_t>
bool item_pipe_t<msg_t>::close_pipe(msgs_list_t& msgs_list)
{
  if(false == _tobe_consumed.is_reciever_closed()) return false;

  return_msg(msgs_list);
  _tobe_freed.close_sender();
  _tobe_freed.close_reciever(msgs_list);
  _free_msgs(msgs_list);
  return true;
}

template<typename msg_t>
void item_pipe_t<msg_t>::_free_msgs(msgs_list_t& msgs_list)
{
  while(false == msgs_list.empty()) {
    msg_t* msg = msgs_list.front();
    msgs_list.pop_front();
    _pool_objs.Free(msg);
  }
}

}}

#endif
