#pragma once

#include <cstddef>
#include <new>
#include <vector>
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <atomic>
#include <assert.h>

#include <limits>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <sys/epoll.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <errno.h>

#include <ucontext.h>
#include <unistd.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/prctl.h>
#include <sys/syscall.h>

#include <malloc.h>

#include "mem_profile.h"
#include "gmonitor/gmonitor.h"

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif

#ifndef INOUT
#define INOUT
#endif

#ifndef UNUSE
#define UNUSE(arg) { (void)(arg); }
#endif

#ifndef DISALLOW_COPY_AND_ASSIGN
#define DISALLOW_COPY_AND_ASSIGN(type_name) \
	type_name(const type_name&); \
	void operator=(const type_name &);
#endif

#ifndef RCAST
#define RCAST reinterpret_cast
#endif

#ifndef SCAST
#define SCAST static_cast
#endif

#ifndef CCAST
#define CCAST const_cast
#endif

#ifndef likely
#define likely(x) __builtin_expect ((x), true)
#endif

#ifndef unlikely
#define unlikely(x) __builtin_expect ((x), false)
#endif

#ifndef XLIB_FAIL_HANDLE
#define XLIB_FAIL_HANDLE(expr) \
  do { \
    if (unlikely(expr)) goto ERROR_HANDLE; \
  } while(0);
#endif

#ifndef XLIB_FAIL_HANDLE_AND_SET
#define XLIB_FAIL_HANDLE_AND_SET(expr, set) \
  do { \
    if (unlikely(expr)) { \
      set; \
      goto ERROR_HANDLE; \
    } \
  } while(0);
#endif

#ifndef XLIB_FAIL_HANDLE_STDOUT
#define XLIB_FAIL_HANDLE_STDOUT(expr, fmt, arg...) \
  do { \
    if(unlikely(expr)) { \
        printf(fmt, ##arg); \
        goto ERROR_HANDLE; \
    } \
  } while(0);
#endif

#ifndef XLIB_FAIL_HANDLE_CONTINUE
#define XLIB_FAIL_HANDLE_CONTINUE(expr) \
  if (unlikely(expr)) { \
    continue; \
  }
#endif

#ifndef XLIB_FAIL_HANDLE_WARN_CONTINUE
#define XLIB_FAIL_HANDLE_WARN_CONTINUE(expr, str) \
  if (unlikely(expr)) { \
    WARN(str); \
    continue; \
  }
#endif

#ifndef XLIB_FAIL_HANDLE_FATAL_CONTINUE
#define XLIB_FAIL_HANDLE_FATAL_CONTINUE(expr, str) \
  if (unlikely(expr)) { \
    FATAL(str); \
    continue; \
  }
#endif

#ifndef XLIB_ASSERT
#define XLIB_ASSERT(expr) \
  assert(expr);
#endif

#ifdef DEBUG_MODE

  #ifndef XLIB_BUG
  #define XLIB_BUG(expr) \
    XLIB_ASSERT(!(expr))
  #endif

  #ifndef XLIB_BUG_FATAL
  #define XLIB_BUG_FATAL(expr, str) \
    FATAL(str); \
    XLIB_BUG(expr)
  #endif

#else

  #ifndef XLIB_BUG
  #define XLIB_BUG(expr) \
    ;
  #endif

  #ifndef XLIB_BUG_FATAL
  #define XLIB_BUG_FATAL(expr, str) \
    ;
  #endif

#endif

#ifndef XLIB_STOP
#define XLIB_STOP(expr) \
  XLIB_ASSERT(!(expr))
#endif

#ifndef XLIB_STOP_FATAL
#define XLIB_STOP_FATAL(expr, str) \
  FATAL(str); \
  XLIB_BUG(expr)
#endif

#ifndef XLIB_NEW
#define XLIB_NEW(member, constructor) \
  do { \
    member = ::new (std::nothrow) constructor; \
    if (xlib::pub::MemProfile::GetFlag()) { \
      char buf[kMaxSizeMemProfilekey]; \
      sprintf(buf, "new_%s_%d", __FILE__, __LINE__); \
      xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
    } \
  } while(0);
#endif

#ifndef XLIB_NEW_DECL
#define XLIB_NEW_DECL(member, type, constructor) \
  type* member = ::new (std::nothrow) constructor; \
  if (xlib::pub::MemProfile::GetFlag()) { \
    char buf[kMaxSizeMemProfilekey]; \
    sprintf(buf, "new_%s_%d", __FILE__, __LINE__); \
    xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
  }
#endif

#ifndef XLIB_NEW_AND_RET
#define XLIB_NEW_AND_RET(type) \
  do { \
    type* member = ::new (std::nothrow) type; \
    if (xlib::pub::MemProfile::GetFlag()) { \
      char buf[kMaxSizeMemProfilekey]; \
      sprintf(buf, "new_%s_%d", __FILE__, __LINE__); \
      xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
    } \
    return member; \
  } while(0);
#endif

#ifndef XLIB_MALLOC
#define XLIB_MALLOC(member, type, size) \
  do { \
    member = reinterpret_cast<type>(::malloc(size)); \
    if (xlib::pub::MemProfile::GetFlag()) { \
      char buf[kMaxSizeMemProfilekey]; \
      sprintf(buf, "new_%s_%d", __FILE__, __LINE__); \
      xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
    } \
    XLIB_ASSERT(NULL!=member) \
  } while(0);
#endif

#ifndef XLIB_REALLOC
#define XLIB_REALLOC(new_member, old_member, type, size) \
  do { \
    new_member = reinterpret_cast<type>(::realloc(old_member, size)); \
    XLIB_ASSERT(NULL!=new_member) \
  } while(0);
#endif

#ifndef XLIB_DELETE
#define XLIB_DELETE(member) \
  do { \
    if (likely(NULL!=member)) { \
      if (xlib::pub::MemProfile::GetFlag()) { \
        char buf[kMaxSizeMemProfilekey]; \
        sprintf(buf, "delete_%s_%d", __FILE__, __LINE__); \
        xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
      } \
      delete member; \
      member=NULL; \
    } \
  } while(0);
#endif

#ifndef XLIB_DELETE_ARRAY
#define XLIB_DELETE_ARRAY(member) \
  do { \
    if (likely(NULL!=member)) { \
      if (xlib::pub::MemProfile::GetFlag()) { \
        char buf[kMaxSizeMemProfilekey]; \
        sprintf(buf, "delete_%s_%d", __FILE__, __LINE__); \
        xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
      } \
      delete [] member; \
      member=NULL; \
    } \
  } while(0);
#endif

#ifndef XLIB_FREE
#define XLIB_FREE(member) \
  do { \
    if(likely(NULL!=member)) { \
      if (xlib::pub::MemProfile::GetFlag()) { \
        char buf[kMaxSizeMemProfilekey]; \
        sprintf(buf, "delete_%s_%d", __FILE__, __LINE__); \
        xlib::pub::GMonitor::Get().Inc("mem_profile", buf, malloc_usable_size(member)); \
      } \
      ::free(member); \
      member=NULL; \
    } \
  } while(0);
#endif

#ifndef XLIB_RAII_CHECK
#define XLIB_RAII_CHECK(ret) \
  if (unlikely(!init_)) { return ret; }
#endif

#ifndef XLIB_RAII_INIT
#define XLIB_RAII_INIT(ret) \
  if (unlikely(!init_) && unlikely(!Init_())) { return ret; }
#endif

#ifndef XLIB_RAII_SUPER_INIT
#define XLIB_RAII_SUPER_INIT(ret) \
  if (unlikely(!Super::init_) && unlikely(!Init_())) { return ret; }
#endif

#ifndef XLIB_CONCAT
#define XLIB_CONCAT(X, Y) X##Y
#endif

#ifndef XLIB_STATIC_ASSERT
#define XLIB_STATIC_ASSERT(expr) \
  enum { \
    Assert = sizeof(CompileTimeError<(expr)!=0>), \
  };
#endif

#ifndef XLIB_STATIC_ASSERT_MSG
#define XLIB_STATIC_ASSERT_MSG(expr, msg) \
  enum { \
    XLIB_CONCAT(ERROR_##msg, __LINE__) = \
      sizeof(CompileTimeError<expr != 0 >) \
  }
#endif
/**/

/*
 * CAS
 */
#ifndef CAS
#define CAS(ptr, oldval, newval) \
  __sync_val_compare_and_swap(ptr, oldval, newval)
#endif

#ifndef CAS_bool
#define CAS_bool(ptr, oldval, newval) \
  __sync_bool_compare_and_swap(ptr, oldval, newval)
#endif

/*
 * memory barriers
 */
#ifndef MB
#define MB() \
  __asm__ __volatile__("mfence":::"memory");
#endif

namespace xlib {

class NoneType {};

static const size_t kMaxSizeMemProfilekey=512;

/*
 * static assert, from loki
 */
template<int> struct CompileTimeError;
template<> struct CompileTimeError<true> {};

}
