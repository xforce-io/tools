#pragma once

#include <sstream>
#include "../../common.h"

namespace xlib { namespace pub {

/*
 * @notice : (1) no pool is used here, libs such as tcmalloc should be used to 
 *           speed up the process of insert and erase
 *           (2) remove `virtual` from destruct function to save memory, this class 
 *           should not be inherited
 */
class SimpleTrie
{
 public:
  static const size_t kMaxNumChildren=128;

 public:
  explicit SimpleTrie();

  int Insert(const char* buf, size_t len_buf);
  bool Erase(const char* buf, size_t len_buf);
  inline bool Find(const char* buf, size_t len_buf) const;
  inline bool HasPrefixOf(const char* buf, size_t len_buf) const;
  void Clear();

  ~SimpleTrie();

 private: 
  /*
   * @return : >0 : this node should be deleted
   *          ==0 : succ
   *           <0 : no such string
   */
  int Erase_(const char* buf, size_t len_buf);
  inline bool IterToNextNode_(char child_index, const SimpleTrie** iter_trie) const;

 private:
  uint16_t num_children_;
  uint16_t child_index_;
  uint32_t refcnt_;
  union {
    SimpleTrie* child_;
    SimpleTrie** children_;
  };

  friend std::ostringstream& operator<<(std::ostringstream& oss, 
      const SimpleTrie& simple_trie);
};

bool SimpleTrie::Find(const char* buf, size_t len_buf) const
{
  const char* buf_tmp = buf;
  size_t len_tmp = len_buf;
  const SimpleTrie* iter_trie = this;
  while ( unlikely(0!=len_tmp) ) {
    if (!IterToNextNode_(*buf_tmp, &iter_trie)) return false;

    ++buf_tmp;
    --len_tmp;
  }
  return iter_trie->refcnt_>0 ? true : false;
}

bool SimpleTrie::HasPrefixOf(const char* buf, size_t len_buf) const
{
  const char* buf_tmp = buf;
  size_t len_tmp = len_buf;
  const SimpleTrie* iter_trie = this;
  for (;;) {
    if ( unlikely(iter_trie->refcnt_>0) ) return true;
    if (0==len_tmp || true != IterToNextNode_(*buf_tmp, &iter_trie)) return false;
 
    ++buf_tmp;
    --len_tmp;
  }
  return false;
}

bool SimpleTrie::IterToNextNode_(char child_index, const SimpleTrie** iter_trie) const
{
  if (1 == (*iter_trie)->num_children_) {
    if (child_index == (*iter_trie)->child_index_) {
      *iter_trie = (*iter_trie)->child_;
    } else {
      return false;
    }
  } else if ((*iter_trie)->num_children_>1) {
    if (NULL != (*iter_trie)->children_[static_cast<int>(child_index)]) {
      *iter_trie = (*iter_trie)->children_[static_cast<int>(child_index)];
    } else {
      return false;
    }
  } else {
    return false;
  }
  return true;
}

std::ostringstream& operator<<(std::ostringstream& oss, const SimpleTrie& simple_trie);

}}
