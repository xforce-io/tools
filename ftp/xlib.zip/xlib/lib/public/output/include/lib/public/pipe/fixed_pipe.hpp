#pragma once

#include "../common.h"
#include "../xmemcpy.hpp"

namespace xlib { namespace pub {

template <typename MsgHeader>
struct FixedMsgPipeMsg {
  MsgHeader msg_header;
  int64_t len;
  char msg[];
};

template <typename MsgHeader>
class FixedMsgPipe {
 public:
  typedef FixedMsgPipeMsg<MsgHeader> Msg;
  
 public:
  explicit FixedMsgPipe(size_t size_pipe);

  /* 
   * @sender interfaces
   */
  bool SendMsg(const MsgHeader& msg_header, const char* msg=NULL, size_t len_msg=0);

  //the following two interfaces should be called in pair,
  inline char* ReserveSpaceForNewMsg(size_t len_msg);
  bool SendMsg(const MsgHeader& msg_header, size_t len_msg);

  inline size_t SizeMsgReady() const;

  /* 
   * @reciever interfaces 
   */
  inline FixedMsgPipeMsg<MsgHeader>* RecieveMsg();
  inline void MsgConsumed(); 

  virtual ~FixedMsgPipe();

 private:
  bool Init_();

  bool HasSpaceForMsg_(size_t len_msg);

  /*
   * judge whether the msg under reciever_pace_ is a valid todo one
   */
  inline bool HasTodoFixedMsgPipeMsg_() ;

 private:
  size_t size_pipe_;
  char* pipe_;
  char* reciever_pace_;
  char* sender_pace_;
  char* end_of_pipe_;
  size_t msg_offset_; //the offset of msg member in FixedMsgPipeMsg struct

  bool init_;
};

template <typename MsgHeader>
FixedMsgPipe<MsgHeader>::FixedMsgPipe(size_t size_pipe) :
    size_pipe_(size_pipe),
    reciever_pace_(NULL),
    sender_pace_(NULL),
    init_(false) {}

template <typename MsgHeader>
bool FixedMsgPipe<MsgHeader>::SendMsg(
    const MsgHeader& msg_header,
    const char *msg, 
    size_t len_msg) {
  XLIB_RAII_INIT(false)

  bool ret = HasSpaceForMsg_(len_msg);
  if (unlikely(false==ret)) return false;

  (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->msg_header = msg_header;
  (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->len = 
    SCAST<int64_t>(len_msg);

  if (likely(0!=len_msg)) {
    xmemcpy(
        (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->msg, 
        msg, 
        len_msg);
  }
  sender_pace_ += len_msg+msg_offset_;
  return true;
}

template <typename MsgHeader>
char* FixedMsgPipe<MsgHeader>::ReserveSpaceForNewMsg(size_t len_msg) {
  XLIB_RAII_INIT(NULL)

  return HasSpaceForMsg_(len_msg) ? sender_pace_+msg_offset_ : NULL;
}

template <typename MsgHeader>
bool FixedMsgPipe<MsgHeader>::SendMsg(const MsgHeader& msg_header, size_t len_msg) {
  XLIB_RAII_INIT(false)

  (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->msg_header = msg_header;
  (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->len =
    SCAST<int64_t>(len_msg);
  sender_pace_ += msg_offset_+len_msg;
  return true;
}

template <typename MsgHeader>
size_t FixedMsgPipe<MsgHeader>::SizeMsgReady() const {
  return sender_pace_>=reciever_pace_ ? 
      sender_pace_-reciever_pace_ : 
      sender_pace_ + size_pipe_ - reciever_pace_;
}

template <typename MsgHeader>
FixedMsgPipeMsg<MsgHeader>* FixedMsgPipe<MsgHeader>::RecieveMsg() { 
  return true == HasTodoFixedMsgPipeMsg_() ? 
    RCAST<FixedMsgPipeMsg<MsgHeader>*>(reciever_pace_) : 
    NULL; 
}

template <typename MsgHeader>
void FixedMsgPipe<MsgHeader>::MsgConsumed() { 
  XLIB_RAII_INIT()
  reciever_pace_ += 
    msg_offset_ + (RCAST<FixedMsgPipeMsg<MsgHeader>*>(reciever_pace_))->len; 
}

template <typename MsgHeader>
FixedMsgPipe<MsgHeader>::~FixedMsgPipe() {
  if (true==init_) delete [] pipe_;
}

template <typename MsgHeader>
bool FixedMsgPipe<MsgHeader>::Init_() {
  pipe_ = new (std::nothrow) char [size_pipe_];
  if (NULL==pipe_) return false;

  reciever_pace_ = sender_pace_ = pipe_;
  end_of_pipe_ = size_pipe_ + pipe_;
  msg_offset_ = offsetof(FixedMsgPipeMsg<MsgHeader>, msg);

  init_=true;
  return true;
}

template <typename MsgHeader>
bool FixedMsgPipe<MsgHeader>::HasSpaceForMsg_(size_t len_msg) {
  size_t size_need = msg_offset_+len_msg;
  if (sender_pace_>=reciever_pace_) {
    if (sender_pace_+size_need <= end_of_pipe_) {
      return true;
    } else if (pipe_+size_need < reciever_pace_) {
      if(sender_pace_+msg_offset_ <= end_of_pipe_) {
        (RCAST<FixedMsgPipeMsg<MsgHeader>*>(sender_pace_))->len = -1;
      }

      sender_pace_=pipe_;
      return true;
    }
  } else if (reciever_pace_>sender_pace_
      && sender_pace_+size_need < reciever_pace_) {
    return true;
  }
  return false;
}

template <typename MsgHeader>
bool FixedMsgPipe<MsgHeader>::HasTodoFixedMsgPipeMsg_() {
  /* 
   * if ((FixedMsgPipeMsg*)reciever_pace_)->len >= 0,
   * there must be a msg waiting for reciever
   */
  if(reciever_pace_<sender_pace_) { 
    return true;
  } else if(sender_pace_==reciever_pace_) { 
    return false;
  } else if(reciever_pace_+msg_offset_ > end_of_pipe_ 
      || (RCAST<FixedMsgPipeMsg<MsgHeader>*>(reciever_pace_))->len < 0) {
    reciever_pace_=pipe_;
    return (sender_pace_==reciever_pace_) ? false : true; 
  } else { 
    return true; 
  }
}

}}
