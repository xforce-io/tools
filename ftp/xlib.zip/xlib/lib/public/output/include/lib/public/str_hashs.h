#pragma once

#include "common.h"

namespace zmt { namespace freq_count {

class StrHashs {
 public:
  typedef uint32_t (*StrHashF)(const char*);

 public:
  static const size_t kNumStrHashs = 10;

 public: 
  explicit StrHashs(size_t num);

  /*
   * @return: -1 if error happened
   */
  inline uint32_t Hash(size_t i, const char* str) const;

 public: 
  inline static uint32_t SDBMHash(const char* str);
  inline static uint32_t RSHash(const char* str);
  inline static uint32_t JSHash(const char* str);
  inline static uint32_t PJWHash(const char* str);
  inline static uint32_t ELFHash(const char* str);
  inline static uint32_t BKDRHash(const char* str);
  inline static uint32_t DJBHash(const char* str);
  inline static uint32_t APHash(const char* str);
  inline static uint32_t DEKHash(const char* str);
  inline static uint32_t FNVHash(const char* str);

 private:
  size_t num_;

 private:
  static StrHashF funcs_[kNumStrHashs]; 
};

uint32_t StrHashs::Hash(size_t i, const char* str) const {
  if ((i < num_) && (i < kNumStrHashs)) {
    return funcs_[i](str);
  } else {
    return -1;
  }
}

uint32_t StrHashs::SDBMHash(const char* str) {
  uint32_t hash=0;
  while (*str) {
    hash = (*str++) + (hash<<6) + (hash<<16) - hash;
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::RSHash(const char* str) {
  uint32_t b=378551;
  uint32_t a=63689;
  uint32_t hash=0;
  while (*str) {
    hash = hash*a + (*str++);
    a*=b;
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::JSHash(const char* str) {
  uint32_t hash = 1315423911;
  while (*str) {
    hash ^= ((hash<<5) + (*str++) + (hash>>2));
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::PJWHash(const char* str) {
  const uint32_t kBitsInUnsigedInt = sizeof(uint32_t) * 8;
  const uint32_t kThreeQuarters = (kBitsInUnsigedInt*3) / 4;
  const uint32_t kOneEighth = kBitsInUnsigedInt/8;
  const uint32_t kHighBits = (0xFFFFFFFF) << (kBitsInUnsigedInt-kOneEighth);
  uint32_t hash=0;
  uint32_t test=0;
  while (*str) {
    hash = (hash<<kOneEighth) + (*str++);
    if (0 != (test = (hash & kHighBits))) {
      hash = ((hash ^ (test>>kThreeQuarters)) & (~kHighBits));
    }
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::ELFHash(const char* str) {
  uint32_t hash=0;
  uint32_t x=0;
  while (*str) {
    hash = (hash<<4) + (*str++);
    if (0 != (x = (hash&0xF0000000L))) {
      hash ^= (x>>24);
      hash &= ~x;
    }
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::BKDRHash(const char* str) {
  const uint32_t kSeed=131;
  uint32_t hash=0;
  while (*str) {
    hash = hash*kSeed + (*str++);
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::DJBHash(const char* str) {
  uint32_t hash = 5381;
  while (*str) {
    hash += (hash<<5) + (*str++);
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::APHash(const char* str) {
  uint32_t hash=0;
  for (int i=0; *str; ++i) {
    if (!(i&1)) {
      hash ^= ((hash<<7) ^ (*str++) ^ (hash>>3));
    } else {
      hash ^= (~(hash<<11) ^ (*str++) ^ (hash>>5));
    }
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::DEKHash(const char* str) {
  const size_t kLenStr = strlen(str);
  uint32_t hash=kLenStr;
  for (size_t i=0; i<kLenStr; ++i) {
    hash = ((hash<<5) ^ (hash>>27) ^ str[i]);
  }
  return hash&0x7FFFFFFF;
}

uint32_t StrHashs::FNVHash(const char* str) {
  const uint32_t kFNVPrime = 0x811C9DC5;
  const size_t kLenStr = strlen(str);
  uint32_t hash=0;
  for (size_t i=0; i<kLenStr; ++i) {
    hash *= kFNVPrime;
    hash ^= str[i];
  }
  return hash&0x7FFFFFFF;
}

}}
