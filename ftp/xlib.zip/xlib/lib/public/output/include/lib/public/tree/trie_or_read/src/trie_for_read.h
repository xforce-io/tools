#ifndef XLIB_PUBLIC_BASE_TREES_TRIE_FOR_READ_H
#define XLIB_PUBLIC_BASE_TREES_TRIE_FOR_READ_H

#include "public/common.h"
#include "public/basic/pool_objs.hpp"

namespace xlib { namespace basic {

struct TrieChildCache
{
  static const size_t kSizeCacheNode=3;

  uint8_t size;
  char next_char[SizeCacheNode];
  TrieForRead* next[SizeCacheNode]
};

/*
 * @notice : no pool is used here, libs such as tcmalloc should be used to 
 *           speed up the process of insert and erase
 */
class TrieForRead
{
 public:
  explicit TrieForRead();

  int Insert(char* buf, size_t len_buf);
  int Erase(char* buf, size_t len_buf);
  bool Find(char* buf, size_t len_buf);

  virtual ~TrieForRead();

 private:
  /*
   * @return : 0:succ | 1:dupkey | -1:fail(no mem)
   * @notice : modify next_ and refcnt_
   */
  int InsertToChild_(IN char* buf, IN size_t len_buf, OUT TrieForRead** next_node);

 private:
  union {
    TrieForRead* single;
    TrieChildCache* cache;
    TrieForRead** normal;
    struct {}* check_null;
  } next_;

  uint8_t count_;
  char low_bound_;
  size_t refcnt_;
};

}}

#endif
