#pragma once

#include "../common.h"

namespace xlib { namespace pub {

class VersionManagerBase {
 public:
  virtual int CreateAndFreezeNewVersion()=0;
  virtual void* operator[] (size_t index) const=0;
  virtual ~VersionManagerBase() {}
};

template <typename DBType, typename ReloadChecker>
class VersionManager : public VersionManagerBase {
 public:
  static const size_t kInvalidVersion = size_t(-1); 

 public:
  explicit VersionManager();
  bool Init(const std::string& db_name, 
      void* db_params,
      void* reload_checker_params,
      size_t num_versions);

  int CreateAndFreezeNewVersion();
  bool CreateNewVersion();
  void FreezeNewVersion();

  size_t GetLatestVersion() const { return current_version_; }
  const DBType& GetWritableDB() const { return *(dbs_[writable_version_]); }
  DBType& GetWritableDB() { return *(dbs_[writable_version_]); }
  const DBType& GetDB() const { return *(dbs_[current_version_]); }
  void* operator[] (size_t index) const;

  virtual ~VersionManager();
 
 private:
  //const
  std::string db_name_;
  void* db_params_;
  void* reload_checker_params_;
  size_t num_versions_;
  ///

  size_t current_version_;
  size_t writable_version_;
  bool to_load_when_create_new_version_;
  DBType** dbs_;

  ReloadChecker* reload_checker_;
};

template <typename DBType, typename ReloadChecker>
VersionManager<DBType, ReloadChecker>::VersionManager() : 
  writable_version_(kInvalidVersion),
  to_load_when_create_new_version_(true),
  dbs_(NULL),
  reload_checker_(NULL) {}

template <typename DBType, typename ReloadChecker>
bool VersionManager<DBType, ReloadChecker>::Init(
    const std::string& db_name, 
    void* db_params,
    void* reload_checker_params,
    size_t num_versions) {
  db_name_=db_name;
  db_params_=db_params;
  reload_checker_params_=reload_checker_params;
  num_versions_=num_versions;

  XLIB_FAIL_HANDLE(num_versions_<2)

  current_version_=0;
  XLIB_NEW(dbs_, DBType* [num_versions_])
  memset(dbs_, 0, sizeof(*dbs_) * num_versions_);
  for (size_t i=0; i<num_versions_; ++i) {
    XLIB_NEW(dbs_[i], DBType)
  }

  for (size_t i=0; i<num_versions_; ++i) {
    bool ret = dbs_[i]->Init(db_name_, db_params_);
    XLIB_FAIL_HANDLE(!ret)
  }

  XLIB_NEW(reload_checker_, ReloadChecker(reload_checker_params_))
  return true;

  ERROR_HANDLE:
  if (NULL != dbs_) {
    for (size_t i=0; i<num_versions_; ++i) XLIB_DELETE(dbs_[i]);
    delete [] dbs_;
    dbs_=NULL;
  }
  return false;
}

template <typename DBType, typename ReloadChecker>
int VersionManager<DBType, ReloadChecker>::CreateAndFreezeNewVersion() {
  if (0 != reload_checker_->ToLoad()) return current_version_;

  size_t next_version = (current_version_+1) % num_versions_;
  bool ret = dbs_[next_version]->Load(*(dbs_[current_version_]));
  if (ret) {
    current_version_ = next_version;
    return current_version_;
  } else {
    return -1;
  }
}

template <typename DBType, typename ReloadChecker>
bool VersionManager<DBType, ReloadChecker>::CreateNewVersion() {
  if (unlikely(kInvalidVersion != writable_version_)) {
    return false;
  }

  writable_version_ = (current_version_+1) % num_versions_;
  if (to_load_when_create_new_version_) {
    bool ret = dbs_[writable_version_]->Load(*(dbs_[current_version_]));
    if (ret) {
      to_load_when_create_new_version_=false;
      return true;
    } else {
      writable_version_=kInvalidVersion;
      return false;
    }
  } else {
    return true;
  }
}

template <typename DBType, typename ReloadChecker>
void VersionManager<DBType, ReloadChecker>::FreezeNewVersion() {
  if (kInvalidVersion==writable_version_) {
    return;
  }

  if (0 == reload_checker_->ToLoad()) {
    current_version_=writable_version_;
    to_load_when_create_new_version_=true;
  }
  writable_version_=kInvalidVersion;
}

template <typename DBType, typename ReloadChecker>
void* VersionManager<DBType, ReloadChecker>::operator[] (
    size_t index) const {
  return SCAST<void*>(dbs_[index]);
}

template <typename DBType, typename ReloadChecker>
VersionManager<DBType, ReloadChecker>::~VersionManager() {
  if (NULL != dbs_) {
    for (size_t i=0; i<num_versions_; ++i) {
      XLIB_DELETE(dbs_[i]);
    }
    delete [] dbs_;
  }
  XLIB_DELETE(reload_checker_)
}

}}
