#pragma once

#include "../common.h"
#include "reload_checkers/reload_per_interval.h"
#include "reload_checkers/reload_when_modified.h"

namespace xlib { namespace pub {

class DataBase {
 public:
  virtual bool Init(const std::string& name, void* init_params)=0;
  inline bool Load(DataBase& prev_db);

  virtual ~DataBase() {}

 protected:
  ///const
  std::string db_name_;
  //

 protected:
  inline void Init_(const std::string& db_name); 
  virtual void Reset_() {}
  virtual bool Load_(DataBase& prev_db)=0;
};

bool DataBase::Load(DataBase& prev_db) {
  Reset_();
  return Load_(prev_db);
}

void DataBase::Init_(const std::string& db_name)  {
  db_name_=db_name;
}

}}
