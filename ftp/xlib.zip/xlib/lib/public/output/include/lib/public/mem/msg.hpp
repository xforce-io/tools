#ifndef XLIB_PUBLIC_BASIC_MSG_HPP
#define XLIB_PUBLIC_BASIC_MSG_HPP

#include "public/common.h"

namespace xlib { namespace pub {

struct Msg
{
 public:
  typedef size_t InitParam;

 public:
  explicit Msg() : buf(NULL) {}
  inline bool Init(const InitParam& init_param);
  virtual ~Msg() { XLIB_FREE(buf); }

 public:
  char* buf;
  size_t size;
};

bool Msg::Init(const InitParam& init_param) 
{
  size=init_param;
  return NULL != (buf = static_cast<char*>(malloc(init_param)));
}

}}

#endif
