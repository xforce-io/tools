#ifndef XLIB_PUBLIC_BASIC_PIPE_SIMPLE_MSG_PIPE_H
#define XLIB_PUBLIC_BASIC_PIPE_SIMPLE_MSG_PIPE_H

#include "public/common.h"

namespace xlib
{

/*
 * @notice : RAII object
 */
template <typename Msg>
class SimpleMsgPipe
{
 public:
  explicit SimpleMsgPipe(size_t size_pipe) : 
    size_pipe_(size_pipe/sizeof(Msg)*sizeof(Msg)),
    pipe_(NULL),
    reciever_pace_(NULL),
    sender_pace_(NULL),
    init_(false) {}

  /* 
   * @sender interfaces
   */
  bool SendMsg(const Msg& msg);
  inline size_t SizeMsgReady() const;

  /* 
   * @reciever interfaces 
   */
  Msg* RecieveMsg();
  void MsgConsumed();

  virtual ~SimpleMsgPipe();

 private:
  bool Init_();

  /*
   * judge whether the msg under reciever_pace_ is a valid todo one
   */
  inline bool HasTodoMsg_();

 private:
  ///RAII args
  size_t size_pipe_;
  //

  char* pipe_;
  char* reciever_pace_;
  char* sender_pace_;
  char* end_of_pipe_;

  bool init_;
};

template <typename Msg>
bool SimpleMsgPipe<Msg>::SendMsg(const Msg& msg)
{
  XLIB_RAII_INIT(false)
  //reset sender_pace_ if it comes to the end
  if (sender_pace_==end_of_pipe_) {
      if (pipe_==reciever_pace_) return false;
      sender_pace_=pipe_;
  }

  if (sender_pace_+sizeof(Msg) == reciever_pace_) return false;

  *(reinterpret_cast<Msg*>(sender_pace_)) = msg;
  sender_pace_ += sizeof(Msg);
  return true;
}

template <typename Msg>
size_t SimpleMsgPipe<Msg>::SizeMsgReady() const
{
  return sender_pace_>=reciever_pace_ ? 
      sender_pace_-reciever_pace_ : 
      sender_pace_ + size_pipe_ - reciever_pace_;
}

template <typename Msg>
Msg* SimpleMsgPipe<Msg>::RecieveMsg()
{
  XLIB_RAII_INIT(NULL)
  return true==HasTodoMsg_() ? reinterpret_cast<Msg*>(reciever_pace_) : NULL; 
}

template <typename Msg>
void SimpleMsgPipe<Msg>::MsgConsumed()
{ 
  XLIB_RAII_INIT()
  reciever_pace_ += sizeof(Msg); 
}

template <typename Msg>
SimpleMsgPipe<Msg>::~SimpleMsgPipe()
{
  XLIB_DELETE_ARRAY(pipe_)
}

template <typename Msg>
bool SimpleMsgPipe<Msg>::Init_()
{
  XLIB_NEW(pipe_, char [size_pipe_]);
  reciever_pace_ = sender_pace_ = pipe_;
  end_of_pipe_ = size_pipe_+pipe_;
  init_=true;
  return true;

  ERROR_HANDLE:
  return false;
}

template <typename Msg>
bool SimpleMsgPipe<Msg>::HasTodoMsg_() { 
  if(reciever_pace_<sender_pace_) {
      return true;
  } else if(sender_pace_==reciever_pace_) {
      return false;
  } else if(reciever_pace_==end_of_pipe_) {
      reciever_pace_=pipe_;
      return (sender_pace_==reciever_pace_) ? false : true; 
  } else {
      return true;
  }
}

}

#endif
