#pragma once

#include "../../common.h"

namespace xlib { namespace pub {

class ReloadPerInterval {
 public:
  struct InitParams {
    time_t load_interval_in_sec;
  };

 public: 
  inline explicit ReloadPerInterval(const void* params) :
      reload_interval_in_us_(
          SCAST<const InitParams*>(params)->load_interval_in_sec*1000000),
      last_reload_time_in_us_(0) {}

  inline int ToLoad();
 
 private: 
  ///const
  time_t reload_interval_in_us_;
  //

  time_t last_reload_time_in_us_;
};

int ReloadPerInterval::ToLoad() {
  timeval time;
  gettimeofday(&time, NULL);
  time_t now = time.tv_sec*1000000 + time.tv_usec;
  if (now < last_reload_time_in_us_+reload_interval_in_us_) return 1;

  last_reload_time_in_us_ = now;
  return 0;
}

}}
