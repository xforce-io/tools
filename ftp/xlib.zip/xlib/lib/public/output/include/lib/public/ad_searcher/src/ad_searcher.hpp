template <typename context_t>
class ad_searcher_t
{
    public:
    ad_searcher_t(const std::vector<channel_t<context_t>*>& channels) 
        : _channels(channels), 
          _num_channels(channels.length()),
          _copied_contexts(NULL) {}

    bool init();

    /*
     * @notice : size of channel_selector should be at least _num_channels
     */
    bool run(context_t* context, bool* channel_selector);

    private:
    virtual bool _schedule();

    virtual bool _reset() = 0;

    virtual bool _merge() = 0;

    private:
    const std::vector<channel_t<context_t>*> _channels;
    const uint32_t _num_channels;
    context_t** _copied_contexts;
    bool* _channel_selector;
};

template <typename context_t>
bool ad_searcher_t<context_t>::init()
{
    XLIB_NEW(_copied_contexts, context_t* [_num_channels]);
    memset(_copied_contexts, 0, sizeof(context_t*) * _num_channels);
    for (uint32_t i=1; i<_num_channels; ++i) {
        XLIB_NEW(_copied_contexts[i], context_t);
    }
    return true;

    ERROR_HANDLE:
    if (NULL != _copied_contexts) {
        for (uint32_t i=0; i<_num_channels; ++i) {
            XLIB_DELETE(_copied_contexts[i])
        }
    }
    delete [] _copied_contexts;
    return false;
}

template <typename context_t>
bool ad_searcher_t<context_t>::run(context_t* context, bool* channel_selector)
{
    _channel_selector = channel_selector;

    _reset();

    _copied_contexts[0] = context;
    for (uint32_t i=1; i<_num_channels; ++i) {
        if (NULL == _channel_selector || true == _channel_selector[i]) {
            _copied_contexts[i] = _copied_contexts[0];
        }
    }

    bool ret = _schedule();
    XLIB_FAIL_HANDLE(false == ret);

    ret = _merge();
    XLIB_FAIL_HANDLE(false == ret);
    return true;

    ERROR_HANDLE:
    return false;
}

template <typename context_t>
bool ad_searcher_t<context_t>::_schedule()
{
    for (int i=0; i<_num_channels; ++i) {
        if (NULL == _channel_selector || true == _channel_selector[i]) {
            _channels[i]->context(_copied_contexts[i]);

            XLIB_FAIL_HANDLE(true != _channels[i]->pre());
            XLIB_FAIL_HANDLE(true != _channels[i]->run());
            XLIB_FAIL_HANDLE(true != _channels[i]->post());
        }
    }
    return true;

    ERROR_HANDLE:
    return false;
}
