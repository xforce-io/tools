#pragma once

#include "../common.h"

namespace xlib { namespace pub {

/*
 * untested
 */
template <typename MsgHeader>
struct SPMCFixedPipeMsg {
 public:
  static const uint32_t kMaskStatus = (static_cast<uint32_t>(1) << 31);
 
 public: 
  MsgHeader msg_header;
  uint32_t len;
  char msg[];
};

template <typename MsgHeader>
class SPMCFixedPipe {
 public:
  typedef SPMCFixedPipeMsg<MsgHeader> Msg;

 public:
  explicit SPMCFixedPipe(size_t size_pipe);

  /* 
   * @sender interfaces
   */
  bool SendMsg(const MsgHeader& msg_header, const char* msg=NULL, size_t len_msg=0);

  //the following two interfaces should be called in pair,
  //inline char* ReserveSpaceForNewMsg(size_t len_msg);
  //bool SendMsg(const MsgHeader& msg_header, size_t len_msg);

  inline size_t SizeMsgReady() const;

  /* 
   * @reciever interfaces 
   */
  inline Msg* RecieveMsg();
  inline void MsgConsumed(Msg* msg); 

  virtual ~SPMCFixedPipe();

 private:
  bool Init_();

  char* HasSpaceForMsg_(char* sender_pace, size_t len_msg);
  void SetUnused(Msg* msg) { msg->len |= Msg::kMaskStatus; }
  bool IsUnused(Msg* msg) { return msg->len & Msg::kMaskStatus; }

 private:
  size_t size_pipe_;
  char* pipe_;
  char* reciever_pace_from_;
  char* reciever_pace_to_;
  char* sender_pace_;
  char* end_of_pipe_;
  size_t msg_offset_; //the offset of msg member in SPMCFixedPipeMsg struct

  bool init_;
};

template <typename MsgHeader>
SPMCFixedPipe<MsgHeader>::SPMCFixedPipe(size_t size_pipe) :
    size_pipe_(size_pipe),
    pipe_(NULL),
    reciever_pace_from_(NULL),
    reciever_pace_to_(NULL),
    sender_pace_(NULL),
    init_(false) {}

template <typename MsgHeader>
bool SPMCFixedPipe<MsgHeader>::SendMsg(
    const MsgHeader& msg_header,
    const char *msg, 
    size_t len_msg) {
  XLIB_RAII_INIT(false)

  bool ret = HasSpaceForMsg_(len_msg);
  if (unlikely(false==ret)) return false;

  (RCAST<Msg*>(sender_pace_))->msg_header = msg_header;
  (RCAST<Msg*>(sender_pace_))->len = SCAST<int64_t>(len_msg);

  if (likely(0!=len_msg)) {
    memcpy( (RCAST<Msg*>(sender_pace_))->msg, msg, len_msg );
  }
  sender_pace_ += len_msg+msg_offset_;
  return true;
}

/*
template <typename MsgHeader>
char* SPMCFixedPipe<MsgHeader>::ReserveSpaceForNewMsg(size_t len_msg) {
  XLIB_RAII_INIT(NULL)

  return HasSpaceForMsg_(len_msg) ? sender_pace_+msg_offset_ : NULL;
}

template <typename MsgHeader>
bool SPMCFixedPipe<MsgHeader>::SendMsg(const MsgHeader& msg_header, size_t len_msg) {
  XLIB_RAII_INIT(false)

  (RCAST<Msg*>(sender_pace_))->msg_header = msg_header;
  (RCAST<Msg*>(sender_pace_))->len = SCAST<int64_t>(len_msg);
  sender_pace_ += msg_offset_+len_msg;
  return true;
}
*/

template <typename MsgHeader>
size_t SPMCFixedPipe<MsgHeader>::SizeMsgReady() const {
  return reciever_pace_to_<=sender_pace_ ? 
      sender_pace_-reciever_pace_to_ : 
      sender_pace_+size_pipe_-reciever_pace_to_;
}

template <typename MsgHeader>
SPMCFixedPipeMsg<MsgHeader>* SPMCFixedPipe<MsgHeader>::RecieveMsg() { 
  std::cout << size_t(reciever_pace_to_-pipe_) << " " << size_t(sender_pace_-pipe_) << std::endl;
  bool ret;
  char* tmp_recieve_pace_to=reciever_pace_to_;
  if (tmp_recieve_pace_to<sender_pace_) { 
    ret = CAS_bool(&reciever_pace_to_, tmp_recieve_pace_to, 
        reciever_pace_to_ + msg_offset_ + RCAST<Msg*>(reciever_pace_to_)->len);
    return ret ? RCAST<Msg*>(tmp_recieve_pace_to) : NULL;
  } else if (sender_pace_==tmp_recieve_pace_to) { 
    return NULL;
  } else if (reciever_pace_to_+msg_offset_ > end_of_pipe_ 
      || (uint32_t(-1) == (RCAST<Msg*>(reciever_pace_to_))->len) ) {
    CAS_bool(&reciever_pace_to_, tmp_recieve_pace_to, pipe_);

    if (sender_pace_==reciever_pace_to_) return NULL;
     
    ret = CAS_bool(&reciever_pace_to_, pipe_, 
        pipe_ + msg_offset_ + RCAST<Msg*>(reciever_pace_to_)->len);
    return ret ? RCAST<Msg*>(pipe_) : NULL;
  } else { 
    ret = CAS_bool(&reciever_pace_to_, tmp_recieve_pace_to, 
        reciever_pace_to_ + msg_offset_ + RCAST<Msg*>(reciever_pace_to_)->len);
    return ret ? RCAST<Msg*>(tmp_recieve_pace_to) : NULL;
  }
}

template <typename MsgHeader>
void SPMCFixedPipe<MsgHeader>::MsgConsumed(Msg* msg) { 
  XLIB_RAII_INIT()

  SetUnused(msg);
  if (unlikely(reciever_pace_from_ != RCAST<const char*>(msg))) {
    return;
  }

  do {
    reciever_pace_from_ += msg_offset_ + 
      ((RCAST<Msg*>(reciever_pace_from_))->len & ~Msg::kMaskStatus); 

    if ( reciever_pace_from_!=reciever_pace_to_
        && ( reciever_pace_from_+msg_offset_ > end_of_pipe_ 
            || uint32_t(-1) == (RCAST<Msg*>(reciever_pace_from_))->len ) ) {
      reciever_pace_from_=pipe_;
    }
  } while ( reciever_pace_from_!=reciever_pace_to_ 
      && IsUnused(RCAST<Msg*>(reciever_pace_from_)) );
}

template <typename MsgHeader>
SPMCFixedPipe<MsgHeader>::~SPMCFixedPipe() {
  XLIB_DELETE_ARRAY(pipe_)
}

template <typename MsgHeader>
bool SPMCFixedPipe<MsgHeader>::Init_() {
  pipe_ = new (std::nothrow) char [size_pipe_];
  if (NULL==pipe_) return false;

  reciever_pace_from_=reciever_pace_to_=sender_pace_=pipe_;
  end_of_pipe_ = pipe_+size_pipe_;
  msg_offset_ = offsetof(Msg, msg);

  init_=true;
  return true;
}

template <typename MsgHeader>
bool SPMCFixedPipe<MsgHeader>::HasSpaceForMsg_(size_t len_msg) {
  size_t size_need = msg_offset_+len_msg;
  if (sender_pace_>=reciever_pace_from_) {
    if (sender_pace_+size_need <= end_of_pipe_) {
      return true;
    } else if (pipe_+size_need < reciever_pace_from_) {
      if(sender_pace_+msg_offset_ <= end_of_pipe_) {
        (RCAST<Msg*>(sender_pace_))->len = -1;
      }
      sender_pace_=pipe_;
      return true;
    }
  } else if (sender_pace_<reciever_pace_from_
      && sender_pace_+size_need < reciever_pace_from_) {
    return true;
  }  
  return false;
}

}}
