#pragma once

#include "../common.h"
#include "version_manager.hpp"
#include "database.h"
#include "reload_checkers/reload_checkers.h"

namespace xlib { namespace pub {

class DBReloader {
 public:
  static const size_t kMaxNumVMs = 100;
  static const size_t kDefaultCheckNumVersions = 2;
  static const time_t kDefaultCheckIntervalInSec = 1;

 public:
  explicit DBReloader(
      const std::string& name,
      size_t num_versions=kDefaultCheckNumVersions, 
      time_t check_interval_in_sec=kDefaultCheckIntervalInSec);

  /*
   * @return : a id of the db allocated by DBReloader
   *           if -1, fails
   */
  template <typename DBType, typename ReloadChecker>
  int RegistDB(
      const std::string &db_name, 
      void* db_params,
      void* reload_checker_params);

  inline void* GetDB(size_t id) const;
  inline bool StartReloadThread(); 

  virtual ~DBReloader();
 
 private:
  inline bool CreateNewVersion_();

 private:
  static void* ReloadThread_(void*); 

 private:
  //const 
  std::string name_;
  size_t num_versions_;
  time_t check_interval_in_sec_;
  ///

  size_t num_dbs_;

  /*
   * under assumption that sizeof(VersionManager<T>) are the same
   */
  VersionManagerBase* version_managers_[kMaxNumVMs];
  size_t latest_version_[2][kMaxNumVMs];
  size_t current_latest_version_index_;
  pthread_t pid_;
  bool end_;
};

template <typename DBType, typename ReloadChecker>
int DBReloader::RegistDB(
    const std::string& db_name, 
    void* db_params, 
    void* reload_checker_params) {
  bool ret;
  VersionManager<DBType, ReloadChecker>* tmp = 
    new (std::nothrow) VersionManager<DBType, ReloadChecker>;
  XLIB_FAIL_HANDLE(NULL==tmp)

  ret = tmp->Init(db_name, db_params, reload_checker_params, num_versions_);
  XLIB_FAIL_HANDLE(true!=ret)

  version_managers_[num_dbs_] = tmp;
  return num_dbs_++;

  ERROR_HANDLE:
  XLIB_DELETE(tmp);
  return -1;
}

void* DBReloader::GetDB(size_t id) const {
  size_t latest_version = latest_version_[current_latest_version_index_][id];
  return (*version_managers_[id])[latest_version];
}

bool DBReloader::StartReloadThread() {
  return 0 == pthread_create(&pid_, NULL, ReloadThread_, this);
}

}}
