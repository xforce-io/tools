#pragma once

#include "../common.h"

namespace xlib { namespace pub {

class Sys {
 public: 
  static pid_t GetTid() { return syscall(SYS_gettid); }
  static size_t GetVmRSS(pid_t pid);
};

}}
