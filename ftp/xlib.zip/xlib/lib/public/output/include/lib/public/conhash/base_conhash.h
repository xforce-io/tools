#ifndef XLIB_PUBLIC_BASIC_CONHASH_BASE_CONHASH_H
#define XLIB_PUBLIC_BASIC_CONHASH_BASE_CONHASH_H

#include <map>
#include "public/common.h"

namespace xlib { namespace pub {

struct ConhashInterval
{
  int left;
  int right;
  int sign;

  ConhashInterval* next;

  struct Comp {
    bool operator()(
        ConhashInterval* intvl_1, 
        ConhashInterval* intvl_2);
  };
};

class BaseConhash 
{
 public:
  typedef std::map<
      ConhashInterval*, 
      ConhashInterval*, 
      ConhashInterval::Comp> IndexIntervals;

 public:
  static const size_t kMaxNumNodes=1000*1000;
  static const size_t kMaxNumIntervals=1000*1000*10;

 public:
  explicit BaseConhash();

  bool AddNode(int sign);
  ConhashInterval* GetRandInterval();
  inline ConhashInterval* GetIntervalAfter(ConhashInterval* current_interval);

 private:
  bool Init_();
  bool SplitInterval_(ConhashInterval** interval, int sign);

 private:
  ConhashInterval head_;
  size_t num_intervals_;
  size_t num_nodes_;
  bool* map_nodes_;
  ConhashInterval*** tmp_intervals_;
  IndexIntervals index_intervals_;

  bool init_;
};

ConhashInterval* BaseConhash::GetIntervalAfter(ConhashInterval* current_interval)
{
  XLIB_RAII_INIT(NULL)
  return (NULL!=current_interval->next) ? current_interval->next : head_.next;
}

}}

#endif
