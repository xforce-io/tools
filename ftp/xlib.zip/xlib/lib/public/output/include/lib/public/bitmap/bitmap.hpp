#ifndef PUBLIC_BASIC_BITMAP_H
#define PUBLIC_BASIC_BITMAP_H

#include <sstream>
#include <string.h>

#define BITMAP_MASK(pos) ( ((size_t)1) << ((pos) % BitInABlock) )
#define BITMAP_WORD(pos) ( bits_[(pos) / BitInABlock] )

namespace xlib { namespace pub
{

class bitmap_iterator_t;

class bitmap_t
{
  public:
  struct init_param_t 
  {
    size_t init_bytes;
    size_t buffer_bytes;
  };

  public:
  static const size_t BitInABlock = 64;
  static const size_t BitInAByte = 8;
  static const size_t BytesInABlock = 8;
  static const size_t DefaultAllocUnit = (1<<20) * BitInAByte; //1M

  public:
  bitmap_t() {}

  virtual ~bitmap_t();

  public:
  bool init(const init_param_t& init_param);
  void reset() { memset((char*)bits_, 0, size_bytes_); }
  bool clear_bit(size_t pos);
  bool set_bit(size_t pos);
  bool test_bit(size_t pos) const;
  size_t get_size_bits() const { return size_bits_; }
  inline bitmap_iterator_t begin() const;
  inline bitmap_iterator_t end() const;
  inline size_t get_num_bits() const;
  bool intersect(const bitmap_t& bitmap);

  public:
  bool _resize(size_t new_size_bits);

  static size_t _bytes_used(size_t nbits) 
  { return (nbits+BitInABlock-1)*BytesInABlock/BitInABlock; }

  private:
  int64_t* bits_;
  int64_t* end_;
  size_t size_bits_;
  size_t size_bytes_;
  size_t buffer_bit_;

  friend std::ostringstream& operator<<(std::ostringstream& oss, const bitmap_t& bitmap);
};

class bitmap_iterator_t
{
  public:
  bitmap_iterator_t(const bitmap_t& bitmap, bool is_begin) :
    bitmap_(bitmap),
    block_pointer_(is_begin ? bitmap.bits_ : bitmap.end_),
    pos_in_block_(-1),
    pos_in_bits_(-1) {}

  size_t operator*() const { return pos_in_bits_; }

  void move_to_next();
  bitmap_iterator_t& operator++();
  bitmap_iterator_t operator++(int);
  bool operator==(const bitmap_iterator_t& bitmap_iterator) const;
  bool operator!=(const bitmap_iterator_t& bitmap_iterator) const;

  private:
  const bitmap_t& bitmap_;
  int64_t* block_pointer_;
  int64_t pos_in_block_;
  int64_t pos_in_bits_;
};

std::ostringstream& operator<<(std::ostringstream& oss, const bitmap_t& bitmap);

bitmap_t::~bitmap_t()
{
  if (NULL != bits_) delete [] bits_;
}

bool bitmap_t::init(const init_param_t& init_param)
{
  if (0 == init_param.init_bytes || 0 == init_param.buffer_bytes) return false;

  size_bits_ = init_param.init_bytes*BitInAByte;
  size_bytes_ = bitmap_t::_bytes_used(size_bits_);
  bits_ = (int64_t*)malloc(size_bytes_);
  if (NULL == bits_) return false;

  end_ = bits_+size_bytes_/BytesInABlock;
  buffer_bit_ = init_param.buffer_bytes*BitInAByte;

  reset();
  return true;
}

bool bitmap_t::clear_bit(size_t pos)
{
  if (pos >= size_bits_) return false;

  BITMAP_WORD(pos) &= ~BITMAP_MASK(pos);
  return true;
}

bool bitmap_t::set_bit(size_t pos) 
{
  if (pos >= size_bits_) {
    if (false == _resize(pos)) return false;
  }

  BITMAP_WORD(pos) |= BITMAP_MASK(pos);
  return true;
}

bool bitmap_t::test_bit(size_t pos) const
{
  if (pos >= size_bits_) return false;
  
  return (BITMAP_WORD(pos) & BITMAP_MASK(pos)) != 0;  
}

bitmap_iterator_t bitmap_t::begin() const 
{ 
  bitmap_iterator_t bitmap_iterator = bitmap_iterator_t(*this, true); 
  bitmap_iterator.move_to_next(); //find the first
  return bitmap_iterator;
}

bitmap_iterator_t bitmap_t::end() const 
{ 
  return bitmap_iterator_t(*this, false); 
}

bool bitmap_t::_resize(size_t size_bits)
{
  size_t new_size_bits = size_bits+buffer_bit_;
  size_t new_size_bytes = bitmap_t::_bytes_used(new_size_bits);
  printf("resize_to[%lu]\n", new_size_bytes);
  int64_t* new_bits = (int64_t*)realloc(bits_, new_size_bytes);
  if (NULL == new_bits) return false;

  memset((char*)new_bits+size_bytes_, 0, new_size_bytes-size_bytes_);

  bits_ = new_bits;
  size_bits_ = new_size_bits;
  size_bytes_ = new_size_bytes;
  end_ = bits_+size_bytes_/BytesInABlock;
  return true;
}

size_t bitmap_t::get_num_bits() const
{
  bitmap_iterator_t iter = begin();
  size_t count = 0;
  while (iter++ != end()) ++count;
  return count;
}

bool bitmap_t::intersect(const bitmap_t& bitmap)
{
  size_t guests_size_bits = bitmap.get_size_bits();
  if (get_size_bits() < guests_size_bits) {
    bool ret = set_bit(guests_size_bits);
    if (false == ret) return false;
  }

  size_t num_blocks = size_bytes_/BytesInABlock;
  for (size_t i=0; i<num_blocks; ++i) bits_[i] &= bitmap.bits_[i];
  return true;
}

std::ostringstream& operator<<(std::ostringstream& oss, const bitmap_t& bitmap)
{
  for (size_t i=0; i<bitmap._bytes_used(bitmap.size_bits_); ++i) {
    if (i % 20 == 0) oss << std::endl << std::setw(6) << i*8 << " ";
    oss << (0 != (((char*)bitmap.bits_)[i] & 1))
      << (0 != (((char*)bitmap.bits_)[i] & 2))
      << (0 != (((char*)bitmap.bits_)[i] & 4))
      << (0 != (((char*)bitmap.bits_)[i] & 8))
      << (0 != (((char*)bitmap.bits_)[i] & 16))
      << (0 != (((char*)bitmap.bits_)[i] & 32))
      << (0 != (((char*)bitmap.bits_)[i] & 64))
      << (0 != (((char*)bitmap.bits_)[i] & 128))
      << " ";
  }
  return oss;
}

void bitmap_iterator_t::move_to_next() 
{
  if (63 == pos_in_block_) {
    ++block_pointer_;
    pos_in_block_ = 0;
  } else {
    ++pos_in_block_;
  }
  ++pos_in_bits_;

  int64_t ret;
  for (;;) {
    size_t i;
    for (i=pos_in_block_; i<bitmap_t::BitInABlock; ++i) {
      switch(i) {
        case  0 : ret = ( (*block_pointer_) & 0x0000000000000001); break;
        case  1 : ret = ( (*block_pointer_) & 0x0000000000000002); break;
        case  2 : ret = ( (*block_pointer_) & 0x0000000000000004); break;
        case  3 : ret = ( (*block_pointer_) & 0x0000000000000008); break;
        case  4 : ret = ( (*block_pointer_) & 0x0000000000000010); break;
        case  5 : ret = ( (*block_pointer_) & 0x0000000000000020); break;
        case  6 : ret = ( (*block_pointer_) & 0x0000000000000040); break;
        case  7 : ret = ( (*block_pointer_) & 0x0000000000000080); break;
        case  8 : ret = ( (*block_pointer_) & 0x0000000000000100); break;
        case  9 : ret = ( (*block_pointer_) & 0x0000000000000200); break;
        case 10 : ret = ( (*block_pointer_) & 0x0000000000000400); break;
        case 11 : ret = ( (*block_pointer_) & 0x0000000000000800); break;
        case 12 : ret = ( (*block_pointer_) & 0x0000000000001000); break;
        case 13 : ret = ( (*block_pointer_) & 0x0000000000002000); break;
        case 14 : ret = ( (*block_pointer_) & 0x0000000000004000); break;
        case 15 : ret = ( (*block_pointer_) & 0x0000000000008000); break;
        case 16 : ret = ( (*block_pointer_) & 0x0000000000010000); break;
        case 17 : ret = ( (*block_pointer_) & 0x0000000000020000); break;
        case 18 : ret = ( (*block_pointer_) & 0x0000000000040000); break;
        case 19 : ret = ( (*block_pointer_) & 0x0000000000080000); break;
        case 20 : ret = ( (*block_pointer_) & 0x0000000000100000); break;
        case 21 : ret = ( (*block_pointer_) & 0x0000000000200000); break;
        case 22 : ret = ( (*block_pointer_) & 0x0000000000400000); break;
        case 23 : ret = ( (*block_pointer_) & 0x0000000000800000); break;
        case 24 : ret = ( (*block_pointer_) & 0x0000000001000000); break;
        case 25 : ret = ( (*block_pointer_) & 0x0000000002000000); break;
        case 26 : ret = ( (*block_pointer_) & 0x0000000004000000); break;
        case 27 : ret = ( (*block_pointer_) & 0x0000000008000000); break;
        case 28 : ret = ( (*block_pointer_) & 0x0000000010000000); break;
        case 29 : ret = ( (*block_pointer_) & 0x0000000020000000); break;
        case 30 : ret = ( (*block_pointer_) & 0x0000000040000000); break;
        case 31 : ret = ( (*block_pointer_) & 0x0000000080000000); break;
        case 32 : ret = ( (*block_pointer_) & 0x0000000100000000); break;
        case 33 : ret = ( (*block_pointer_) & 0x0000000200000000); break;
        case 34 : ret = ( (*block_pointer_) & 0x0000000400000000); break;
        case 35 : ret = ( (*block_pointer_) & 0x0000000800000000); break;
        case 36 : ret = ( (*block_pointer_) & 0x0000001000000000); break;
        case 37 : ret = ( (*block_pointer_) & 0x0000002000000000); break;
        case 38 : ret = ( (*block_pointer_) & 0x0000004000000000); break;
        case 39 : ret = ( (*block_pointer_) & 0x0000008000000000); break;
        case 40 : ret = ( (*block_pointer_) & 0x0000010000000000); break;
        case 41 : ret = ( (*block_pointer_) & 0x0000020000000000); break;
        case 42 : ret = ( (*block_pointer_) & 0x0000040000000000); break;
        case 43 : ret = ( (*block_pointer_) & 0x0000080000000000); break;
        case 44 : ret = ( (*block_pointer_) & 0x0000100000000000); break;
        case 45 : ret = ( (*block_pointer_) & 0x0000200000000000); break;
        case 46 : ret = ( (*block_pointer_) & 0x0000400000000000); break;
        case 47 : ret = ( (*block_pointer_) & 0x0000800000000000); break;
        case 48 : ret = ( (*block_pointer_) & 0x0001000000000000); break;
        case 49 : ret = ( (*block_pointer_) & 0x0002000000000000); break;
        case 50 : ret = ( (*block_pointer_) & 0x0004000000000000); break;
        case 51 : ret = ( (*block_pointer_) & 0x0008000000000000); break;
        case 52 : ret = ( (*block_pointer_) & 0x0010000000000000); break;
        case 53 : ret = ( (*block_pointer_) & 0x0020000000000000); break;
        case 54 : ret = ( (*block_pointer_) & 0x0040000000000000); break;
        case 55 : ret = ( (*block_pointer_) & 0x0080000000000000); break;
        case 56 : ret = ( (*block_pointer_) & 0x0100000000000000); break;
        case 57 : ret = ( (*block_pointer_) & 0x0200000000000000); break;
        case 58 : ret = ( (*block_pointer_) & 0x0400000000000000); break;
        case 59 : ret = ( (*block_pointer_) & 0x0800000000000000); break;
        case 60 : ret = ( (*block_pointer_) & 0x1000000000000000); break;
        case 61 : ret = ( (*block_pointer_) & 0x2000000000000000); break;
        case 62 : ret = ( (*block_pointer_) & 0x4000000000000000); break;
        case 63 : ret = ( (*block_pointer_) & 0x8000000000000000); break;
        default : break;
      }

      if (0 != ret) {
        pos_in_bits_ += i-pos_in_block_;
        pos_in_block_ = i;
        return;
      }
    }

    pos_in_bits_ += i-pos_in_block_;
    ++block_pointer_;
    pos_in_block_ = 0;
    while (block_pointer_ != bitmap_.end_ 
        && 0 == *block_pointer_) {
      ++block_pointer_;
      pos_in_bits_ += bitmap_t::BitInABlock;
    }

    if (block_pointer_ == bitmap_.end_) {
      pos_in_block_ = -1;
      pos_in_bits_ = -1;
      return;
    }
  }
}

bitmap_iterator_t& bitmap_iterator_t::operator++()
{
  move_to_next();
  return *this;
}

bitmap_iterator_t bitmap_iterator_t::operator++(int)
{
  bitmap_iterator_t iter = *this;    
  move_to_next();
  return iter;
}

bool bitmap_iterator_t::operator==(const bitmap_iterator_t& bitmap_iterator) const
{
  return block_pointer_ == bitmap_iterator.block_pointer_
      && pos_in_block_ == bitmap_iterator.pos_in_block_
      && pos_in_bits_ == bitmap_iterator.pos_in_bits_;
}

bool bitmap_iterator_t::operator!=(const bitmap_iterator_t& bitmap_iterator) const
{
  return !operator==(bitmap_iterator);
}

}}

#undef BITMAP_MASK
#undef BITMAP_WORD

#endif
