#pragma once

#include "common.h"
#include "mp_tools.hpp"

namespace xlib { namespace pub {

class String {
 public: 
  inline static bool StrToInt(const char *str, int& result);
  inline static bool StrToInt64(const char *str, int64_t& result);
  inline static void ExtractDomainFromUrl(IN const std::string& url, OUT std::string& domain);

  inline static void SplitStr(const std::string& str, char sep, std::vector<std::string>& vals);
  inline static void SplitStr(const char* str, char sep, std::vector<std::string>& vals);

  template <typename T>
  inline static bool SplitNum(const std::string& str, char sep, std::vector<T>& vals);

  template <typename T>
  static bool SplitNum(const char* str, char sep, std::vector<T>& vals);
};

bool String::StrToInt(const char *str, int& result) {
  int64_t result_int64;
  bool ret = StrToInt64(str, result_int64);
  if (true==ret && result_int64<=INT_MAX && result_int64 >=INT_MIN) {
    result=static_cast<int>(result_int64);
    return true;
  } else {
    return false;
  }
}

bool String::StrToInt64(const char *str, int64_t& result) {
  if (NULL==str || '\0' == str[0]) return false;

  char *endptr;
  int64_t tmp = strtol(str, &endptr, 10);
  if (str==endptr || LONG_MAX==tmp || LONG_MIN==tmp) return false;
  result=tmp;
  return true;
}

void String::ExtractDomainFromUrl(IN const std::string& url, OUT std::string& domain) {
  static const char kPrefixHttp[] = "http://";
  static const char kPrefixHttps[] = "https://";
  size_t start, end;
  if (0 == url.compare(0, sizeof(kPrefixHttp)-1, kPrefixHttp)) {
    if (url.length() < sizeof(kPrefixHttp)) { domain=""; return; }  
    start = sizeof(kPrefixHttp)-1;
  } else if(0 == url.compare(0, sizeof(kPrefixHttps)-1, kPrefixHttps)) {
    if (url.length() < sizeof(kPrefixHttps)) { domain=""; return; }
    start = sizeof(kPrefixHttps)-1;
  } else {
    if (0 == url.length()) { domain=""; return; }
    start=0;
  }

  end = url.find('/', start);
  if (std::string::npos == end) end = url.length();

  domain = url.substr(start, end-start);
}

void String::SplitStr(const std::string& str, char sep, std::vector<std::string>& vals) {
  SplitStr(str.c_str(), sep, vals);
}

void String::SplitStr(const char* str, char sep, std::vector<std::string>& vals) {
  vals.clear();

  std::string tmp_str;
  const char *ptr_0=str, *ptr_1=ptr_0;
  while (true) {
    while ('\0' != *ptr_1 && sep != *ptr_1) {
      ++ptr_1;
    }

    tmp_str.assign("");
    tmp_str.append(ptr_0, ptr_1-ptr_0);
    vals.push_back(tmp_str);

    if ('\0' == *ptr_1) break;
    ptr_0 = ++ptr_1;
  }
}

template <typename T>
bool String::SplitNum(const std::string& str, char sep, std::vector<T>& vals) {
  return SplitNum(str.c_str(), sep, vals);
}

template <typename T>
bool String::SplitNum(const char* str, char sep, std::vector<T>& vals) {
  vals.clear();

  int64_t tmp_int;
  double tmp_double;
  char* end_ptr;
  const char *ptr_0=str, *ptr_1=ptr_0;
  while (true) {
    while ('\0' != *ptr_1 && sep != *ptr_1) {
      ++ptr_1;
    }

    if (unlikely(ptr_0==ptr_1)) {
      if ('\0' == *ptr_0) break;
      ptr_0 = ++ptr_1;
      continue;
    }

    if (std::numeric_limits<T>::is_integer){
      tmp_int = strtoll(ptr_0, &end_ptr, 10);
      if ( true != Range<T>::Check(tmp_int) ) return false;
      vals.push_back(tmp_int);
    } else {
      tmp_double = strtod(ptr_0, &end_ptr);
      if ( true != Range<T>::Check(tmp_double) ) return false;
      vals.push_back(tmp_double);
    }

    if ( (sep != *end_ptr && '\0' != *end_ptr)) {
      return false;
    }

    if ('\0' == *ptr_1) break;
    ptr_0 = ++ptr_1;
  }
  return true;
}

}}
