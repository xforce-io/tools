#pragma once 

#include "../../common.h"

namespace xlib { namespace pub {

class Buffer {
 public:
  inline Buffer();
  inline bool Init(double ratio_expand=1.3, double ratio_shrink=0.5);
  inline void Set(const char* buf, size_t len, size_t pos=0);
  void SetLen(size_t len) { len_=len; }
  inline void Reserve(size_t len);
  void Clear() { len_=0; }

  const char* Start() const { return buf_; }
  char* Start() { return buf_; }
  const char* Stop() const { return buf_+len_; }
  char* Stop() { return buf_+len_; }
  size_t Len() const { return len_; }
  size_t Size() const { return size_; }
  
  virtual ~Buffer();

 private:

 private:
  double ratio_expand_;
  double ratio_shrink_;

  char* buf_;
  size_t len_;
  size_t size_;
};

Buffer::Buffer() :
  buf_(NULL),
  len_(0),
  size_(0) {}

bool Buffer::Init(double ratio_expand, double ratio_shrink) {
  ratio_expand_=ratio_expand;
  ratio_shrink_=ratio_shrink;
  return true;
}

void Buffer::Set(const char* buf, size_t len, size_t pos) {
  Reserve(len+pos);
  memcpy(buf_+pos, buf, len);
}

void Buffer::Reserve(size_t size) {
  if (size>size_) {
    buf_ = RCAST<char*>(realloc(buf_, size));
    size_=size;
  }
}

}}
