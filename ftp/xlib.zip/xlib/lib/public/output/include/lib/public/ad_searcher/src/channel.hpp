template <typename context_t>
class channel_t
{
    public:
    explicit channel_t(
        const std::string& channel_name,
        const std::vector<strategy_t<context_t>*>& strategies)
        : _channel_name(channel_name), 
          _num_strategies(strategies.length()),
          _strategies(strategies) {}

    const std::string& name() { return _channel_name; }

    void context(context_t* context) { _current_context = context; }

    virtual bool pre() { return true; }

    bool run();

    virtual bool post() { return true; }

    private:
    const std::string _channel_name;
    const std::vector<strategy_t<context_t>*> _strategies;
    const uint32_t _num_strategies;
    context_t* _current_context;
};

template <typename context_t>
bool channel_t<context_t>::run()
{
    for(uint32_t i=0; i<_num_strategies; ++i) {
        int ret = _strategies[i]->run(_current_context);   
        if (0==ret) {
            continue;
        } else if(ret<0) {
            FATAL(true, "error_process_context[%lu] strategy[%s] in_channel[%s]", 
                _current_context->id, _strategies[i]->name().c_str(), _channel_name.c_str());
            return false;
        } else {
            return true;
        }
    }
    return true;
}
