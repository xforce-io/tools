#pragma once

#include "single_simple_lru.hpp"

namespace xlib { namespace pub {

template <typename Key, typename Val>
class SimpleLru {
 private:
  static const size_t kMinSizePerArea = 10;
  
 public:
  SimpleLru();

  bool Init(size_t size_lru, size_t num_areas=1);

  inline bool Touch(const Key& key);
  inline bool Insert(const Key& key, const Val& val);
  inline bool Erase(const Key& key);

  ~SimpleLru();

 private:
  inline size_t GetArea(const Key& key) const;

 private: 
  size_t num_areas_;

  SpinLock* locks_;
  SingleSimpleLru<Key, Val>* lrus_;
};

template <typename Key, typename Val>
SimpleLru<Key, Val>::SimpleLru() :
  locks_(NULL),
  lrus_(NULL) {}

template <typename Key, typename Val>
bool SimpleLru<Key, Val>::Init(size_t size_lru, size_t num_areas) {
  if (size_lru/num_areas < kMinSizePerArea) {
    return false;
  }

  num_areas_=num_areas;
  locks_ = new SpinLock [num_areas_];
  lrus_ = new SingleSimpleLru<Key, Val>(size_lru) [num_areas_];
  return true;
}

template <typename Key, typename Val>
bool SimpleLru<Key, Val>::Touch(const Key& key) {
  size_t area = GetArea(key);

  if (!locks_[area].Lock()) {
    return false;
  }

  bool ret = lrus_[area].Touch(key);
  locks_[area].Unlock();
  return ret;
}

template <typename Key, typename Val>
bool SimpleLru<Key, Val>::Insert(const Key& key, const Val& val) {
  size_t area = GetArea(key);

  if (!locks_[area].Lock()) {
    return false;
  }

  bool ret = lrus_[area].Insert(key, val);
  locks_[area].Unlock();
  return ret;
}

template <typename Key, typename Val>
bool SimpleLru<Key, Val>::Erase(const Key& key) {
  size_t area = GetArea(key);

  if (!locks_[area].Lock()) {
    return false;
  }

  bool ret = lrus_[area].Erase(key);
  locks_[area].Unlock();
  return ret;
}

template <typename Key, typename Val>
SimpleLru<Key, val>::~SimpleLru() {
  delete [] lrus_;
  delete [] locks_;
}

}}
