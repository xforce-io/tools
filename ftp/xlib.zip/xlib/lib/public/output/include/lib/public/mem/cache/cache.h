#ifndef XLIB_PUBLIC_BASIC_MEM_CACHE_H
#define XLIB_PUBLIC_BASIC_MEM_CACHE_H

#include "public/public.h"

namespace xlib { namespace pub {

class Cache {
 private:
  static const size_t kSizeAllocBlock=(1<<20);
  static const size_t kMaxLenInteger=20;

 public: 
  explicit Cache();

  const void* Buf() const { return buf_; }
  bool Append(const void* buf, size_t size);
  bool Append(char c);
  bool Append(size_t i);
  bool Append(int i);
  void Reset() { len_=0; }

  virtual ~Cache();

 private:
  void* buf_;
  size_t len_;
  size_t size_;
};

}}

#endif
