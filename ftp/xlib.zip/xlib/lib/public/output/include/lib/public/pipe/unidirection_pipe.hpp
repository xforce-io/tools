#ifndef XLIB_LIB_UNIDIRECTION_PIPE_H
#define XLIB_LIB_UNIDIRECTION_PIPE_H

#include <list>
#include "public/common.h"

namespace xlib 
{

template<typename msg_t>
class unidirection_pipe_t
{
 public:
  typedef std::list<msg_t*> msgs_list_t;

 public:
  explicit unidirection_pipe_t() : 
    _recieved(true), 
    _close_sender(false), 
    _close_reciever(false) {}

  inline bool send_msg(msg_t* msg);
  inline void recieve_msgs(msgs_list_t& list);
  void close_sender() { _close_sender = true; }
  inline bool close_reciever(msgs_list_t& list);
  inline bool is_sender_closed() const { return _close_sender; }
  inline bool is_reciever_closed() const { return _close_reciever; }

 private:
  bool _recieved;
  msgs_list_t _candidates;
  msgs_list_t _bus_stop;
  bool _close_sender;
  bool _close_reciever;
};

template<typename msg_t>
bool unidirection_pipe_t<msg_t>::send_msg(msg_t* msg)
{
  if(true==_close_sender && NULL!=msg) return false;

  if(false==_recieved) {
      if(NULL!=msg) _candidates.push_back(msg);
  } else {
    msg_t* tmp;
    while(false == _candidates.empty()) {
      tmp = _candidates.front();
      _candidates.pop_front();
      _bus_stop.push_back(tmp);
    }

    if(NULL!=msg) _bus_stop.push_back(msg);
    _recieved = false;
  }
  return true;
}

template<typename msg_t>
void unidirection_pipe_t<msg_t>::recieve_msgs(msgs_list_t& list)
{
  if(true==_recieved || true==_close_reciever) return;

  msg_t* tmp;
  while(false == _bus_stop.empty()) {
    tmp = _bus_stop.front();
    _bus_stop.pop_front();
    list.push_back(tmp);
  }
  _recieved=true;
}

template<typename msg_t>
bool unidirection_pipe_t<msg_t>::close_reciever(msgs_list_t& list)
{
  if(false==_close_sender) return false;

  recieve_msgs(list); send_msg(NULL); recieve_msgs(list);
  _close_reciever = true;
  return true;
}

}

#endif
