#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../src/ptr/delay_del_ptr.hpp"

using namespace xlib::pub;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_delay_del_ptr, all) {
  int a=0, b=1, c=2;
  DelayDelPtr<int> delay_del_ptr(NULL, false, 1);
  ASSERT_TRUE(NULL == delay_del_ptr.Get());
  ASSERT_EQ(0, delay_del_ptr.GetLatestVersion());
  
  delay_del_ptr.Change(a);
  delay_del_ptr.Change(b);
  ASSERT_EQ(1, *delay_del_ptr);
  ASSERT_EQ(0, *(delay_del_ptr.Get(0)));
  ASSERT_EQ(1, *(delay_del_ptr.Get(1)));
  ASSERT_EQ(1, delay_del_ptr.GetLatestVersion());

  sleep(2);
  delay_del_ptr.Change(c);
  ASSERT_TRUE(NULL == delay_del_ptr.Get(0));
  ASSERT_EQ(1, *(delay_del_ptr.Get(1)));
  ASSERT_EQ(2, *delay_del_ptr);
}
