#include <gtest/gtest.h>

#include "../../../../../src/sys/thread/thread_privacy/thread_privacy.h"

using namespace std;
using namespace xlib::pub;

int main(int argc, char **argv) {
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

struct Sample {
  typedef int InitParams;
  explicit Sample(const InitParams& param) :
  element(param) {}

  int element;
};

TEST(thread_privacy, test) {
  ThreadPrivacy thread_privacy;
  void* res = thread_privacy.Get(1);
  ASSERT_TRUE(NULL==res);

  bool first_create;
  res = thread_privacy.Get<int>(1, &first_create);
  *(static_cast<int*>(res)) = 2;
  ASSERT_EQ(true, first_create);

  res = thread_privacy.Get<int>(1, NULL);
  ASSERT_TRUE(NULL!=res);
  ASSERT_EQ(*(static_cast<int*>(res)), 2);

  res = thread_privacy.Get<int>(1, &first_create);
  ASSERT_TRUE(!first_create);

  ////////////////////////////////////////
  res = thread_privacy.Get(2);
  ASSERT_TRUE(NULL==res);

  int param = 123;
  res = thread_privacy.Get<Sample>(2, Sample(param), &first_create);
  ASSERT_TRUE(NULL!=res);
  ASSERT_EQ(*(static_cast<int*>(res)), 123);
  ASSERT_TRUE(first_create);
}
