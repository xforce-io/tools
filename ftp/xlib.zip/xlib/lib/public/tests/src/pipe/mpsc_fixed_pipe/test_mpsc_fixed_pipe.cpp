#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../../src/pipe/mpsc_fixed_pipe/mpsc_fixed_pipe.hpp"
#include "../../../../src/public.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  //srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

struct MsgHeader {
  explicit MsgHeader(time_t k) : key(k) {}
  time_t key;
};

typedef MPSCFixedPipe<MsgHeader> Pipe;

TEST(test_mpsc_fixed_msg_pipe, test_encoder) {
  ASSERT_EQ(Pipe::DecodeSenderPaceVersion_(Pipe::EncodeSenderPace_(NULL, 1)), 1);
}

TEST(test_mpsc_fixed_msg_pipe, single_thread_simple_cases) {
  static const std::string kStr = "ab";
  Pipe msg_pipe;
  bool ret = msg_pipe.Init(100, 10, 0);
  ASSERT_TRUE(ret);

  ret = msg_pipe.SendMsg(MsgHeader(0), kStr.c_str(), kStr.size());
  ASSERT_TRUE(ret);

  Pipe::Msg* msg = msg_pipe.ReceiveMsg();
  ASSERT_TRUE(NULL!=msg);
  ASSERT_TRUE('a' == msg->content[0]);
}

TEST(test_mpsc_fixed_msg_pipe, single_thread_all) {
  int ret;
  const int kMaxLenMsg=256;
  char msg[kMaxLenMsg];
  for(uint64_t size_msg_pipe=300; size_msg_pipe<1000; size_msg_pipe+=3) {
    Pipe msg_pipe;

    ret = msg_pipe.Init(size_msg_pipe, kMaxLenMsg);
    ASSERT_TRUE(ret);
    //std::cout << "new round" << round++ << std::endl;

    int master_msg=0, reciever_msg=0;
    for(int i=0; i<1000; i++) {
      bool is_master = rand()%2; 
      if(true == is_master) {
        snprintf(msg, 100, "%d", master_msg);

        int size_msg = rand() % (kMaxLenMsg-100) + 100;
        ret = msg_pipe.SendMsg(MsgHeader(0), msg, size_msg);
        if(ret) ++master_msg;
      } else {
        Pipe::Msg* msg = msg_pipe.ReceiveMsg();
        if(NULL == msg) {
          ASSERT_EQ(master_msg, reciever_msg);
          continue;
        } else {
          //std::cout << " recieve_msg " 
          //    << size_t(msg) << " " << msg->content << " " << i << std::endl;
          ASSERT_EQ(reciever_msg, atoi(msg->content));

          ++reciever_msg;
          msg_pipe.MsgConsumed();
        }
      }
    }
  }
}

struct Params {
  size_t num_tokens;

  Pipe* pipe;
  size_t* token;
};

void* Sender(void* arg) {
  Params* params = RCAST<Params*>(arg);
  size_t num_tokens = params->num_tokens;
  Pipe& pipe = *(params->pipe);
  size_t& token = *(params->token);

  while (true) {
    size_t cur_token=token;
    if (cur_token==num_tokens) break;

    bool ret = CAS_bool(&token, cur_token, cur_token+1);
    if (!ret) continue;

    while (true) {
      ret = pipe.SendMsg(
          MsgHeader(Time::GetCurrentUsec(true)), 
          RCAST<const char*>(&cur_token), 
          sizeof(cur_token));
      if (ret) break;
    }
  }
  return NULL;
}

TEST(test_mpsc_fixed_msg_pipe, multi_threads_all) {
  static const size_t kNumTokens=10000000;
  static const size_t kNumThreads=5;

  size_t token=0;
  time_t* map = new time_t [kNumTokens];
  bzero(map, sizeof(time_t) * kNumTokens);
  size_t recved=0;
  Pipe pipe;
  int ret = pipe.Init(159900, 8);
  ASSERT_TRUE(ret);

  pthread_t threads[kNumThreads];
  Params params = (struct Params){.num_tokens=kNumTokens, .pipe=&pipe, .token=&token};
  for (size_t i=0; i<kNumThreads; ++i) {
    int ret = pthread_create(&(threads[i]), NULL, Sender, &params);
    ASSERT_EQ(ret, 0);
  }

  std::stringstream ss;

  Pipe::Msg* msg;
  while (recved<kNumTokens) {
    msg = pipe.ReceiveMsg(1);
    if (NULL==msg) continue;

    size_t pos;
    memcpy(&pos, msg->content, sizeof(pos));
    ASSERT_TRUE(!map[pos]);
    if (pos>=kNumTokens) {
      std::cout << "overflow[" << pos << "]" << std::endl;
    }
    ASSERT_TRUE(pos<kNumTokens);
    map[pos] = Time::GetCurrentUsec(true) - msg->msg_header.key;
    ++recved;
    pipe.MsgConsumed();
  }

  for (size_t i=0; i<kNumThreads; ++i) {
    pthread_join(threads[i], NULL);
  }

  time_t max_time=0;
  for (size_t i=0; i<kNumTokens; ++i) {
    max_time = std::max(max_time, map[i]);
  }
  std::cout << max_time << std::endl;

  msg = pipe.ReceiveMsg();
  ASSERT_TRUE(NULL==msg);

  delete [] map;
}
