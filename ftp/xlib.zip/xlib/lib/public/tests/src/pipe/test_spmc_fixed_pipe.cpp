#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../src/pipe/mpsc_fixed_pipe.hpp"

using namespace xlib::pub;

int main(int argc, char** argv) {
  //srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

struct MsgHeader {
  explicit MsgHeader(int k) : key(k) {}
  int key;
};

typedef MPSCFixedPipe<MsgHeader> Pipe;

/*
TEST(test_mpsc_fixed_msg_pipe, single_thread_simple_cases) {
  static const std::string kStr = "ab";
  Pipe msg_pipe(100);
  bool ret = msg_pipe.SendMsg(MsgHeader(0), kStr.c_str(), kStr.size());
  ASSERT_TRUE(ret);

  MPSCFixedPipeMsg<MsgHeader>* msg = msg_pipe.RecieveMsg();
  ASSERT_TRUE(NULL!=msg);
  ASSERT_TRUE('a' == msg->msg[0]);
}

TEST(test_mpsc_fixed_msg_pipe, single_thread_all) {
  bool ret;
  const int max_len_msg=1024;
  char msg[max_len_msg];
  for(uint64_t size_msg_pipe=30; size_msg_pipe<10000; size_msg_pipe+=3) {
    Pipe msg_pipe(size_msg_pipe);

    int master_msg=0, reciever_msg=0;
    for(int i=0; i<1000; i++) {
      bool is_master = rand()%2; 
      if(true == is_master) {
        snprintf(msg, 100, "%d", master_msg);

        int size_msg = rand() % (max_len_msg-100) + 100;
        ret = msg_pipe.SendMsg(MsgHeader(0), msg, size_msg);
        if(true == ret) ++master_msg;
      } else {
        MPSCFixedPipeMsg<MsgHeader>* msg = msg_pipe.RecieveMsg();
        if(NULL == msg) {
          ASSERT_EQ(master_msg, reciever_msg);
          continue;
        } else {
          //std::cout << "recieve_msg " << size_t(msg) << " " << msg->msg << std::endl;
          ASSERT_EQ(reciever_msg, atoi(msg->msg));

          ++reciever_msg;
          msg_pipe.MsgConsumed(msg);
        }
      }
    }
  }
}
*/

struct Params {
  size_t num_tokens;

  Pipe* pipe;
  size_t* token;
};

void* Sender(void* arg) {
  Params* params = RCAST<Params*>(arg);
  size_t num_tokens = params->num_tokens;
  Pipe& pipe = *(params->pipe);
  size_t& token = *(params->token);

  while (true) {
    size_t cur_token = token;
    if (cur_token==num_tokens) break;

    bool ret = CAS_bool(&token, cur_token, cur_token+1);
    if (!ret) continue;

    while (!pipe.SendMsg(MsgHeader(0), RCAST<const char*>(&cur_token), sizeof(cur_token))) {
      usleep(1);
    }
  }
  return NULL;
}

TEST(test_mpsc_fixed_msg_pipe, multi_threads_all) {
  static const size_t kNumTokens=10000;
  static const size_t kNumThreads=2;

  size_t token=0;
  bool* map = new bool [kNumTokens];
  bzero(map, sizeof(bool) * kNumTokens);
  size_t recved=0;
  Pipe pipe(1000);

  pthread_t threads[kNumThreads];
  Params params = (struct Params){.num_tokens=kNumTokens, .pipe=&pipe, .token=&token};
  for (size_t i=0; i<kNumThreads; ++i) {
    int ret = pthread_create(&(threads[i]), NULL, Sender, &params);
    ASSERT_EQ(ret, 0);
  }

  Pipe::Msg* msg;
  while (token < kNumTokens/2) {
    msg = pipe.RecieveMsg();
    if (NULL==msg) continue;

    size_t pos = *(RCAST<size_t*>(msg->msg));
    std::cout << "get_msg " << pos << " " << size_t(RCAST<char*>(msg) - pipe.pipe_) << std::endl;
    ASSERT_TRUE(!map[pos]);
    map[pos] = true;
    ++recved;
  }

  for (size_t i=0; i<kNumThreads; ++i) {
    pthread_join(threads[i], NULL);
  }

  do {
    msg = pipe.RecieveMsg();
    if (NULL==msg) break;

    ASSERT_TRUE(!map[*(RCAST<size_t*>(msg->msg))]);
    map[*(RCAST<size_t*>(msg->msg))] = true;
    ++recved;
  } while(true);
  ASSERT_EQ(recved, kNumTokens);

  delete [] map;
}
