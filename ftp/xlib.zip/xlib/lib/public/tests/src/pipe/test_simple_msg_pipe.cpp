#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../src/simple_msg_pipe.hpp"

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_simple_fixed_msg_pipe, all)
{
  for(uint64_t size_msg_pipe = 30; size_msg_pipe < 10000; size_msg_pipe += 3) {
    xlib::SimpleMsgPipe<int> msg_pipe(size_msg_pipe);

    int master_msg = 0, reciever_msg = 0;
    for(int i=0; i<1000; i++) {
      bool is_master = rand()%2;
      if(true==is_master) {
        //printf("put %d\n", master_msg);
        bool ret = msg_pipe.SendMsg(master_msg);
        if(true==ret) ++master_msg;
      } else {
        int* msg = msg_pipe.RecieveMsg();
        if(NULL==msg) {
          ASSERT_EQ(master_msg, reciever_msg);
          continue;
        } else {
          //printf("get %d\n", *msg);
          ASSERT_EQ(reciever_msg, *msg);

          ++reciever_msg;
          msg_pipe.MsgConsumed();
        }
      }
    }
  }
}
