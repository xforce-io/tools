#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../src/item_pipe.hpp"

using namespace xlib::pub;

struct msg_t { int mem; };

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_item_pipe, send_msg_and_recieve_msg)
{
  item_pipe_t<msg_t> item_pipe(5);
  msg_t *msg;

  //insert 5 items enough mem
  for(int i = 0; i < 5; i++) {
    msg = item_pipe.get_msg();
    ASSERT_TRUE(NULL != msg);
    item_pipe.send_msg(msg);
  }

  msg = item_pipe.get_msg();
  ASSERT_TRUE(NULL==msg);

  std::list<msg_t*> list;
  //consume a item
  item_pipe.recieve_msgs(list);
  ASSERT_EQ(1, list.size());

  for(int i = 0; i < 1000-5-1; ++i) {
    msg = item_pipe.get_msg();
    ASSERT_TRUE(NULL == msg);
  }

  //free a item
  item_pipe.return_msg(list);
  item_pipe.free_msgs();
  ASSERT_EQ(item_pipe._pool_objs.NumObjsLeft(), 1);

  //produce an item
  msg = item_pipe.get_msg();
  ASSERT_TRUE(NULL != msg);
  ASSERT_EQ(item_pipe._pool_objs.NumObjsLeft(), 0);
}

TEST(test_item_pipe, close_ops)
{
  item_pipe_t<msg_t> item_pipe(5);
  bool ret;
  msg_t *first_msg, *second_msg, *msg;
  item_pipe_t<msg_t>::msgs_list_t msgs_list;

  //get and send a msg
  first_msg = item_pipe.get_msg();
  ASSERT_TRUE(NULL != first_msg);
  item_pipe.send_msg(first_msg);

  //could not shutdown reciever before shutdown_sender
  ret = item_pipe.shutdown_reciever(msgs_list);
  ASSERT_EQ(0, msgs_list.size());
  ASSERT_TRUE(false == ret);
  item_pipe.recieve_msgs(msgs_list);
  ASSERT_EQ(1, msgs_list.size());

  //shutdown sender cause fail sendings
  second_msg = item_pipe.get_msg();
  ASSERT_TRUE(NULL != second_msg);
  item_pipe.send_msg(second_msg);
  item_pipe.shutdown_sender();
  msg = item_pipe.get_msg();
  ASSERT_TRUE(NULL != msg);
  item_pipe.send_msg(msg);

  //could not close pipe before close reciever
  ret = item_pipe.close_pipe(msgs_list);
  ASSERT_TRUE(false == ret);

  //close_reciever
  ret = item_pipe.shutdown_reciever(msgs_list);
  ASSERT_EQ(2, msgs_list.size());
  ASSERT_TRUE(true == ret);
  ASSERT_EQ(item_pipe._pool_objs.NumObjsLeft(), 3);

  //return msgs
  ret = item_pipe.close_pipe(msgs_list);
  ASSERT_TRUE(true == ret);
  ASSERT_EQ(item_pipe._pool_objs.NumObjsLeft(), 5);
}
