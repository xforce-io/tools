#include <pthread.h>
#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../src/unidirection_pipe.hpp"

using namespace xlib;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

TEST(test_unidirection_pipe, send_msg_and_recieve_msgs)
{
    unidirection_pipe_t<int>::msgs_list_t list;
    xlib::unidirection_pipe_t<int> unidirection_pipe;
    bool ret;

    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    unidirection_pipe.recieve_msgs(list);
    ASSERT_EQ(1, list.size());
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    unidirection_pipe.recieve_msgs(list);
    ASSERT_EQ(3, list.size());
    ret = unidirection_pipe.send_msg(NULL);
    ASSERT_EQ(true, ret);
    unidirection_pipe.recieve_msgs(list);
    ASSERT_EQ(4, list.size());
}

TEST(test_unidirection_pipe, close_reciever_positive)
{
    unidirection_pipe_t<int>::msgs_list_t list;
    xlib::unidirection_pipe_t<int> unidirection_pipe;
    bool ret;

    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    unidirection_pipe.recieve_msgs(list);
    ASSERT_EQ(1, list.size());
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_EQ(true, ret);
    unidirection_pipe.close_sender();
    ret = unidirection_pipe.close_reciever(list);
    ASSERT_EQ(true, ret);
    ASSERT_EQ(4, list.size());
}

TEST(test_unidirection_pipe, close_reciever_passive)
{
    unidirection_pipe_t<int>::msgs_list_t list;
    xlib::unidirection_pipe_t<int> unidirection_pipe;
    bool ret = unidirection_pipe.close_reciever(list);
    ASSERT_TRUE(false == ret);
    unidirection_pipe.close_sender();
    ret = unidirection_pipe.send_msg(new int);
    ASSERT_TRUE(false == ret);
}
