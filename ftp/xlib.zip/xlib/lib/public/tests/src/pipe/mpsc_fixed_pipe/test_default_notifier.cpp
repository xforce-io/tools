#include "gtest/gtest.h"
#include "../../../../src/pipe/mpsc_fixed_pipe/default_notifier.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  //srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

static const size_t kTimesTest=10;
static const size_t kNumDefaultNotifiers = 10;

void* Wait(void* args) {
  DefaultNotifier* notifier = RCAST<DefaultNotifier*>(args);
  for (size_t i=0; i<kTimesTest; ++i) {
    int ret = notifier->Wait(100);
    if (1!=ret) {
      std::cout << "ret " << ret << std::endl;
    }
  }
  return NULL;
}

void* Send(void* args) {
  DefaultNotifier* notifier = RCAST<DefaultNotifier*>(args);
  for (size_t i=0; i<kTimesTest; ++i) {
    if (!(i%10000)) std::cout << i << std::endl;
    notifier->Notify();
  }
  return NULL;
}

TEST(test_notify, all) {
  DefaultNotifier notifier;
  int ret = notifier.Init();
  ASSERT_TRUE(ret);

  pthread_t waiter;
  ret = pthread_create(&waiter, NULL, Wait, &notifier);
  ASSERT_TRUE(0==ret);

  pthread_t notifiers[kNumDefaultNotifiers];
  for (size_t i=0; i<kNumDefaultNotifiers; ++i) {
    ret = pthread_create(&(notifiers[i]), NULL, Send, &notifier);
    ASSERT_TRUE(0==ret);
  }

  for (size_t i=0; i<kNumDefaultNotifiers; ++i) {
    pthread_join(notifiers[i], NULL);
  }
  pthread_join(waiter, NULL);
}
