#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../src/pipe/fixed_pipe.hpp"

using namespace xlib::pub;

int main(int argc, char** argv) {
  srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

struct MsgHeader {
  explicit MsgHeader(int k) : key(k) {}
  int key;
};

TEST(test_fixed_msg_pipe, reserve_space) {
  static const std::string kStr = "ab";
  FixedMsgPipe<MsgHeader> msg_pipe(100);
  char* ptr = msg_pipe.ReserveSpaceForNewMsg(kStr.size() + 10);
  ASSERT_TRUE(NULL!=ptr);
  memcpy(ptr, kStr.c_str(), kStr.size());
  bool ret = msg_pipe.SendMsg(MsgHeader(0), kStr.size());
  ASSERT_TRUE(ret);

  FixedMsgPipeMsg<MsgHeader>* msg = msg_pipe.RecieveMsg();
  ASSERT_TRUE(NULL!=msg);
  ASSERT_TRUE('a' == msg->msg[0]);
}

TEST(test_fixed_msg_pipe, non_zero_size_msg) {
  bool ret;
  const int max_len_msg = 1024;
  char msg[max_len_msg];
  for(uint64_t size_msg_pipe = 30; size_msg_pipe < 10000; size_msg_pipe += 3) {
    FixedMsgPipe<MsgHeader> msg_pipe(size_msg_pipe);

    int master_msg = 0, reciever_msg = 0;
    for(int i = 0; i < 1000; i++) {
      bool is_master = rand()%2; 
      if(true == is_master) {
        snprintf(msg, 100, "%d", master_msg);

        int size_msg = rand() % (max_len_msg - 100) + 100;
        ret = msg_pipe.SendMsg(MsgHeader(0), msg, size_msg);
        if(true == ret) ++master_msg;
      } else {
        FixedMsgPipeMsg<MsgHeader>* msg = msg_pipe.RecieveMsg();
        if(NULL == msg) {
          ASSERT_EQ(master_msg, reciever_msg);
          continue;
        } else {
          ASSERT_EQ(reciever_msg, atoi(msg->msg));

          ++reciever_msg;
          msg_pipe.MsgConsumed();
        }
      }
    }
  }
}

TEST(test_fixed_msg_pipe, zero_size_msg) {
  bool ret;
  for(uint64_t size_msg_pipe = 30; size_msg_pipe < 10000; size_msg_pipe += 3) {
    FixedMsgPipe<MsgHeader> msg_pipe(size_msg_pipe);

    int master_msg = 0, reciever_msg = 0;
    for(int i = 0; i < 1000; i++) {
      bool is_master = rand()%2; 
      if(true == is_master) {
        ret = msg_pipe.SendMsg(MsgHeader(master_msg), NULL, 0);
        if(true == ret) ++master_msg;
      } else {
        FixedMsgPipeMsg<MsgHeader>* msg = msg_pipe.RecieveMsg();
        if(NULL == msg) {
          ASSERT_EQ(master_msg, reciever_msg);
          continue;
        } else {
          ASSERT_EQ(reciever_msg, msg->msg_header.key);

          ++reciever_msg;
          msg_pipe.MsgConsumed();
        }
      }
    }
  }
}
