#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../public/src/string.hpp"

using namespace xlib::pub;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_string, all) {
  std::string url;
  std::string domain;

  url = "http:/"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "http:");

  url = "http://"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "");

  url = "https://"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "");

  url = "https://a"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "a");

  url = "https://b/"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "b");

  url = "http://a"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "a");

  url = "http://b/"; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "b");

  url = ""; domain = "|";
  String::ExtractDomainFromUrl(url, domain);
  ASSERT_TRUE(domain == "");
}

TEST(TestSplitStr, all) {
  std::string str = "ab,,bs";
  std::vector<std::string> vec;
  String::SplitStr(str, ',', vec);
  ASSERT_TRUE(3 == vec.size());
  ASSERT_TRUE(0 == strcmp("ab", vec[0].c_str()));
  ASSERT_TRUE(0 == strcmp("", vec[1].c_str()));
  ASSERT_TRUE(0 == strcmp("bs", vec[2].c_str()));

  str = "qps,max,dist_50(0-100)";
  String::SplitStr(str, ',', vec);
  ASSERT_TRUE(3 == vec.size());
  ASSERT_TRUE(0 == strcmp("qps", vec[0].c_str()));
  ASSERT_TRUE(0 == strcmp("max", vec[1].c_str()));
}

TEST(TestSplitNum, positive) {
  std::string str = "527019,399400,";
  std::vector<int> vec;
  bool ret = String::SplitNum<int>(str, ',', vec);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(2), vec.size());

  str = "527.019,,399.400,";
  std::vector<double> vec_d;
  ret = String::SplitNum<double>(str, ',', vec_d);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(2), vec_d.size());
  ASSERT_TRUE(527.02 > vec_d[0] && 527.018 < vec_d[0]);
  ASSERT_TRUE(399.401 > vec_d[1] && 399.399 < vec_d[1]);

  str = "";
  ret = String::SplitNum<int>(str, ',', vec);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(0), vec.size());
}

TEST(TestSplitNum, passive) {
  std::string str = "1,2,3000,";
  std::vector<int8_t> vec;
  bool ret = String::SplitNum<int8_t>(str, ',', vec);
  ASSERT_TRUE(!ret);
}
