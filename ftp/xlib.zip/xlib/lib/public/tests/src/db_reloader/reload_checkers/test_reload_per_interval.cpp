#include "gtest/gtest.h"
#include "../../../../src/db_reloader/reload_checkers/reload_per_interval.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_reload_per_interval, init) {
  ReloadPerInterval::InitParams init_params = (struct ReloadPerInterval::InitParams){ 1 };
  ReloadPerInterval reload_per_interval(&init_params);
  int ret = reload_per_interval.ToLoad();
  ASSERT_EQ(0, ret);
  usleep(1);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
  sleep(1);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(0, ret);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
}
