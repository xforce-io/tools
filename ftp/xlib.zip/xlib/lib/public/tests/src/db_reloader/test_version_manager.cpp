#include "gtest/gtest.h"
#include "../../../src/db_reloader/version_manager.hpp"
#include "../../../src/db_reloader/database.h"

using namespace xlib::pub;

struct DBInitParams {
  void* reload_checker_params;
};

class DBTested : public DataBase {
 public:
  typedef DataBase Super;

 public:
  bool Init(const std::string& db_name, void* /*params*/) {
    Super::Init_(db_name);
    return true;
  }

  size_t GetCount() const { return count_; }

 private:
  bool Load_(Super&) { ++count_; return true; }
 
 private:
  static size_t count_; 
};

size_t DBTested::count_=0;

class TestVersionManager : public ::testing::Test {
 protected:
  virtual ~TestVersionManager() {} 
  virtual void SetUp() {
    system("rm -rf data/test_db_reloader/; mkdir -p data/test_db_reloader/;"
        " touch data/test_db_reloader/sample");
  }

  virtual void TearDown() {}
};

int main(int argc, char** argv) {
  srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST_F(TestVersionManager, Init) {
  ReloadWhenModified::InitParams reload_checker_params;
  reload_checker_params.monitored_filepath = "data/test_db_reloader/";

  VersionManager<DBTested, ReloadWhenModified> vm;
  bool ret = vm.Init("db_test", NULL, &reload_checker_params, 1);
  ASSERT_TRUE(false==ret);

  VersionManager<DBTested, ReloadWhenModified> vm_2;
  ret = vm_2.Init("db_test", NULL, &reload_checker_params, 2);
  ASSERT_TRUE(true==ret);
}

TEST_F(TestVersionManager, CreateAndFreezeNewVersion) {
  ReloadWhenModified::InitParams reload_checker_params;
  reload_checker_params.monitored_filepath = "data/test_db_reloader/sample";

  VersionManager<DBTested, ReloadWhenModified> vm;
  bool ret = vm.Init("db_test", NULL, &reload_checker_params, 2);
  ASSERT_TRUE(true==ret);

  ASSERT_EQ(1, vm.CreateAndFreezeNewVersion());
  ASSERT_EQ(1, vm.CreateAndFreezeNewVersion());
  sleep(1.5);
  system("touch data/test_db_reloader/sample");
  ASSERT_EQ(0, vm.CreateAndFreezeNewVersion());
  ASSERT_EQ(0, vm.CreateAndFreezeNewVersion());
  sleep(1.5);
  system("touch data/test_db_reloader/sample");
  ASSERT_EQ(1, vm.CreateAndFreezeNewVersion());
}

TEST_F(TestVersionManager, create_and_freeze) {
  ReloadWhenModified::InitParams reload_checker_params;
  reload_checker_params.monitored_filepath = "data/test_db_reloader/sample";

  VersionManager<DBTested, ReloadWhenModified> vm;
  bool ret = vm.Init("db_test", NULL, &reload_checker_params, 2);
  ASSERT_TRUE(true==ret);

  ASSERT_TRUE(true == vm.CreateNewVersion());

  size_t orig_count = vm.GetDB().GetCount();
  ASSERT_TRUE(false == vm.CreateNewVersion());
  vm.FreezeNewVersion();
  ASSERT_TRUE(true == vm.CreateNewVersion());
  ASSERT_EQ(vm.GetDB().GetCount(), orig_count+1);
  vm.FreezeNewVersion();
  ASSERT_TRUE(true == vm.CreateNewVersion());
  ASSERT_EQ(vm.GetDB().GetCount(), orig_count+1);
  sleep(1.5);
  system("touch data/test_db_reloader/sample");
  vm.FreezeNewVersion();
  ASSERT_TRUE(true == vm.CreateNewVersion());
  ASSERT_EQ(vm.GetDB().GetCount(), orig_count+2);
}
