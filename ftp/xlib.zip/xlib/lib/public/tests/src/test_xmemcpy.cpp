#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../public/src/public.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_xmemcpy, all) {
  static const size_t kSizeTested=1000;
  char a[kSizeTested];
  char b[kSizeTested];
  Timer timer1, timer2;
  for (size_t i=0; i<kSizeTested; ++i) {
    timer1.Start(true);
    for (size_t j=0; j<1000; ++j) memcpy(a, b, i);
    timer1.Stop(true);

    timer2.Start(true);
    for (size_t j=0; j<1000; ++j) xmemcpy(a, b, i);
    timer2.Stop(true);

    std::cout << "test[" << i << "] [" << timer1.TimeUs() << "|" << timer2.TimeUs() << "]" << std::endl;
  }
}
