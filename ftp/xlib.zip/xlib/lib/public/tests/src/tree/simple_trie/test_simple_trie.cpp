#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../../src/tree/simple_trie/simple_trie.h"
#include "../../../../src/time/time.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

void make_random_str(std::string& str, size_t size=30, size_t range=128) {
  str = std::string();
  for (size_t i=0; i<static_cast<size_t>(size); ++i) {
    str += char(rand()%range);
  }
}

void print_count(const SimpleTrie& simple_trie) {
  if (1 == simple_trie.num_children_) {
    std::cout << 1 << std::endl;
  } else {
    std::cout << simple_trie.num_children_ << std::endl;
    for (size_t i=0; i<128; ++i) {
      if (NULL != simple_trie.children_[i]) {
        print_count(*(simple_trie.children_[i]));
      }
    }
  }
}

TEST(test_simple_trie, all) {
  SimpleTrie simple_trie;
  int ret = simple_trie.Insert("abc", 3);
  ASSERT_EQ(ret, 0);
  ret = simple_trie.Insert("abd", 3);
  ASSERT_EQ(ret, 0);
  ret = simple_trie.Insert("bcde", 4);
  ASSERT_EQ(ret, 0);

  std::ostringstream oss;
  oss << simple_trie;
  printf("%s\n", oss.str().c_str());

  ret = simple_trie.Find("abd", 3);
  ASSERT_EQ(ret, true);

  ret = simple_trie.Erase("add", 3);
  ASSERT_EQ(ret, false);

  ret = simple_trie.Erase("abd", 3);
  ASSERT_EQ(ret, true);

  ret = simple_trie.HasPrefixOf("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("eabc", 4);
  ASSERT_EQ(ret, false);
  ret = simple_trie.HasPrefixOf("abcd", 4);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("bcde", 4);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("bcdes", 5);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("abcdes", 5);
  ASSERT_EQ(ret, true);

  simple_trie.Clear();
  ret = simple_trie.Insert("abc", 3);
  ASSERT_EQ(ret, 0);
  ret = simple_trie.Insert("abc", 3);
  ASSERT_TRUE(ret>0);
  ret = simple_trie.Insert("abd", 3);
  ASSERT_EQ(ret, 0);
  ret = simple_trie.Insert("bcde", 4);
  ASSERT_EQ(ret, 0);
  ret = simple_trie.Find("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.Find("abe", 3);
  ASSERT_EQ(ret, false);
  ret = simple_trie.HasPrefixOf("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("abcd", 4);
  ASSERT_EQ(ret, true);
  ret = simple_trie.HasPrefixOf("eabc", 4);
  ASSERT_EQ(ret, false);
  ret = simple_trie.Erase("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.Find("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.Erase("abc", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.Find("abc", 3);
  ASSERT_EQ(ret, false);
  ret = simple_trie.Erase("abc", 3);
  ASSERT_EQ(ret, false);
  ret = simple_trie.Erase("abd", 3);
  ASSERT_EQ(ret, true);
  ret = simple_trie.Erase("bcde", 4);
  ASSERT_EQ(ret, true);
  ASSERT_EQ(simple_trie.num_children_, 0);
}

TEST(test_simple_trie, pressure) {
  SimpleTrie simple_trie;
  std::string str;
  for (size_t i=0; i<10000; ++i) {
    make_random_str(str, 10, 50);
    int ret = simple_trie.Insert(str.c_str(), str.length());
    ASSERT_TRUE(ret>=0);
  }

  for (size_t i=0; i<1000; ++i) {
    make_random_str(str);
    simple_trie.Find(str.c_str(), str.length());
  }

  static const size_t kFindTimes=10000000;
  std::vector<std::string> strs;
  strs.resize(kFindTimes);
  for (size_t i=0; i<kFindTimes; ++i) {
    make_random_str(strs[i], 30, 50);
  }

  size_t match=0;
  Timer t;
  t.Start(true);
  for (size_t i=0; i<kFindTimes; ++i) {
    match += simple_trie.HasPrefixOf(strs[i].c_str(), strs[i].length());
  }
  t.Stop(true);
  std::cout << t.TimeUs() 
    << " qps[" 
    << 1.0*kFindTimes/t.TimeUs()*1000000 
    << "] match[" 
    << match
    << "]"
    << std::endl;
}

TEST(test_simple_trie, memcheck) {
  SimpleTrie simple_trie;
  std::string str;
  for (size_t i=0; i<1000000; ++i) {
    make_random_str(str);
    int ret = simple_trie.Insert(str.c_str(), str.length());
    ASSERT_TRUE(ret>=0);
  }
  std::cout << "end" << std::endl;
  sleep(10);
  simple_trie.Clear();
}
