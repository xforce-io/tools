#include <gtest/gtest.h>
#include <queue>

#include "../../../src/heap/heap.hpp"

using namespace std;
using namespace xlib::pub;

int main(int argc, char **argv) {
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(heap, simple_SimpleKVHeapest_case1) {
  SimpleKVHeap<int, int*> heap;

  int key_1 = 1, key_2 = 2, key_3 = 3, key_4 = 4;
  int num_1 = 1, num_2 = 2, num_3 = 3, num_4 = 4;
  size_t ret_1, ret_2, ret_3, ret_4;

  heap.Insert(key_1, &num_1, ret_1);
  heap.Insert(key_3, &num_3, ret_3);
  heap.Insert(key_2, &num_2, ret_2);
  heap.Insert(key_4, &num_4, ret_4);

  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_1)->index, 1);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_2)->index, 3);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_3)->index, 2);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_4)->index, 4);
  /**/

  std::pair<int, int*>* value;
  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(1, *((*value).second));
  heap.Pop();

  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_2)->index, 1);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_3)->index, 2);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_4)->index, 3);
  /**/

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(2, *((*value).second));
  heap.Pop();

  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_3)->index, 1);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_4)->index, 2);
  /**/

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(3, *((*value).second));
  heap.Pop();
  
  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_4)->index, 1);
  ASSERT_EQ(1, heap.num_items_);
  /**/

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(4, *((*value).second));
  heap.Pop();

  value = heap.Top();
  ASSERT_TRUE(NULL==value);
  heap.Pop();

  heap.Insert(key_3, &num_3, ret_3);
  heap.Insert(key_1, &num_1, ret_1);
  heap.Insert(key_4, &num_4, ret_4);
  heap.Insert(key_2, &num_2, ret_2);

  heap.Erase(ret_2);

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(1, *((*value).second));
  heap.Pop();

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(3, *((*value).second));
  heap.Pop();

  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(4, *((*value).second));
  heap.Pop();

  value = heap.Top();
  ASSERT_TRUE(NULL==value);
}

TEST(heap, simple_SimpleKVHeapest_case2) {
  SimpleKVHeap<int, int*> heap;

  int key_1 = 1, key_2 = 2, key_3 = 3;
  int num_1 = 1, num_2 = 2, num_3 = 3;
  size_t ret_1, ret_2, ret_3;

  heap.Insert(key_1, &num_1, ret_1);
  heap.Insert(key_3, &num_3, ret_3);
  heap.Insert(key_2, &num_2, ret_2);

  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_1)->index, 1);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_2)->index, 3);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_3)->index, 2);
  /**/

  std::pair<int, int*>* value;
  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(1, *((*value).second));
  heap.Pop();

  /* check */
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_2)->index, 1);
  ASSERT_EQ(RCAST<HeapItem<int*>*>(ret_3)->index, 2);
  /**/
}

TEST(heap, simple_SimpleKVHeapest_update) {
  SimpleKVHeap<int, int*> heap;

  int key_1 = 1, key_2 = 2, key_3 = 3;
  int num_1 = 1, num_2 = 2, num_3 = 3;
  size_t ret_1, ret_2, ret_3;

  heap.Insert(key_1, &num_1, ret_1);
  heap.Insert(key_3, &num_3, ret_3);
  heap.Insert(key_2, &num_2, ret_2);

  std::pair<int, int*> val(4, &num_1);
  heap.Update(ret_1, val);

  std::pair<int, int*>* value;
  value = heap.Top();
  ASSERT_TRUE(NULL!=value);
  ASSERT_EQ(2, *((*value).second));
  heap.Pop();
}

TEST(heap, all) {
  srand(time(NULL));
  for (size_t i=0; i<100000; ++i) {
    std::cout << "test " << i << std::endl;
    
    //srand(20);

    SimpleKVHeap<int, int*> heap;

    const size_t kNumOps = 1000;
    const size_t kMaxVal =1000;

    size_t* signs = new size_t [kNumOps];
    bzero(signs, sizeof(signs[0]) * kNumOps);

    int* keys = new int [kNumOps];

    int min=kMaxVal;
    for (size_t i=0; i<kNumOps; ++i) {
      keys[i] = rand() % kMaxVal;
      if (keys[i] < min) min = keys[i];
    }

    std::unordered_multiset<int> set;
    std::priority_queue<int, vector<int>, greater<int> > pqueue;

    int* num = new int [kNumOps];
    for(size_t i=0; i<kNumOps; ++i) {
      if (0 == rand() % 10) {
        //std::cout << "insert " << keys[i] << std::endl;
        heap.Insert(keys[i], &num[i], signs[i]);
        set.insert(keys[i]);
      } else {
        size_t index_choosen = rand() % kNumOps;
        if (signs[index_choosen]) {
          //std::cout << "erase " << keys[index_choosen] << std::endl;
          heap.Erase(signs[index_choosen]);

          std::unordered_multiset<int>::iterator iter = set.find(keys[index_choosen]);
          set.erase(iter);
          signs[index_choosen] = 0;
        }
      }
    }

    std::unordered_multiset<int>::const_iterator iter;
    for (iter = set.begin(); iter != set.end(); ++iter) {
      pqueue.push(*iter);
    }

    ASSERT_EQ(pqueue.size(), heap.Size());

    size_t size = pqueue.size();
    for (size_t i=0; i < size; ++i) {
      //std::cout << i << " " << pqueue.top() << " " << heap.Top()->first << std::endl; 
      ASSERT_TRUE(pqueue.top() == heap.Top()->first);
      pqueue.pop();
      heap.Pop();
    }

    ASSERT_TRUE(NULL == heap.Top());
    ASSERT_EQ(0, pqueue.size());
    ASSERT_EQ(0, heap.Size());

    delete [] num;
    delete [] keys;
    delete [] signs;
  }
}
