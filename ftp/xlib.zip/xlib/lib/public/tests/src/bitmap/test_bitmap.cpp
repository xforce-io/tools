#include <time.h>
#include <sstream>

#include "gtest/gtest.h"
#include "../../src/bitmap.hpp"

using namespace xlib::pub;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(bitmap, bitmap)
{
  bitmap_t bitmap;
  bitmap_t::init_param_t init_param = (bitmap_t::init_param_t){1, 0};
  ASSERT_TRUE(false == bitmap.init(init_param));
  init_param = (bitmap_t::init_param_t){1, 10};
  ASSERT_TRUE(true == bitmap.init(init_param));
  ASSERT_TRUE(bitmap.get_size_bits() == 8);
  bitmap.reset();
  ASSERT_TRUE(0 == bitmap.get_num_bits());

  ASSERT_TRUE(true == bitmap.set_bit(100));
  ASSERT_TRUE(bitmap.get_size_bits() == 100+bitmap.buffer_bit_);
  ASSERT_TRUE(1 == bitmap.get_num_bits());

  ASSERT_TRUE(true == bitmap.set_bit(4));
  time_t t1, t2;
  t1 = time(NULL);
  for (size_t i=0; i<1; ++i) {
    int random = rand() % 10000;
    if (random == 4 || random == 100) continue;
    ASSERT_TRUE(true == bitmap.set_bit(random));
    ASSERT_TRUE(3 == bitmap.get_num_bits());
    ASSERT_TRUE(true == bitmap.clear_bit(random));
  }
  t2 = time(NULL);

  std::ostringstream oss;
  oss << bitmap;
  printf("%s\n cost[%lu]", oss.str().c_str(), t2-t1);
}

TEST(bitmap, iterator)
{
  bitmap_t bitmap;
  bitmap_t::init_param_t init_param = (bitmap_t::init_param_t){1, 1};
  ASSERT_TRUE(true == bitmap.init(init_param));
  int seq[] = {0, 3, 7, 9, 16, 17, 22, 24, 30, 31, 32, 33, 1000, 2000, 3000};
  for (size_t i=0; i<sizeof(seq)/sizeof(*seq); ++i) {
    ASSERT_EQ(true, bitmap.set_bit(seq[i]));
  }
  
  std::ostringstream oss;
  oss << bitmap;
  printf("%s\n", oss.str().c_str());

  bitmap_iterator_t iter = bitmap.begin();
  for (size_t i=0; i<sizeof(seq)/sizeof(*seq); ++i) {
    ASSERT_EQ(seq[i], *iter++);
  }
  ASSERT_TRUE(bitmap.end() == iter);
  ASSERT_EQ(sizeof(seq)/sizeof(*seq), bitmap.get_num_bits());
}

//TODO: add cases
TEST(bitmap, intersect)
{
}
