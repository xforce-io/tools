#include "gtest/gtest.h"
#include "../../../public/src/sys/sys.h"

using namespace xlib::pub;

int main(int argc, char** argv) {
  srand(time(NULL));
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_getvmrss, all) {
  ASSERT_TRUE(Sys::GetVmRSS(getpid()) > 0);
}
