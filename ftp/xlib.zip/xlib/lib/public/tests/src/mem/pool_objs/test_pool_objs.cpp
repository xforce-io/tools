#include "gtest/gtest.h"
#include "../../src/pool_objs.hpp"

using namespace xlib::pub;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

struct Sample {
 public:
  explicit Sample() : init(false) {}
  bool init;
};

TEST(test_init, init_positive) {
  PoolObjs<Sample> pool_objs(101, 100, true, 10);
  pool_objs.Free(NULL);

  ASSERT_EQ(pool_objs.num_blocks_alloc_, size_t(2));
  ASSERT_EQ(true, pool_objs.to_resize_);
  ASSERT_EQ(size_t(2), pool_objs.current_row_);
  ASSERT_EQ(size_t(0), pool_objs.current_col_);

  PoolObjs<Sample> pool_objs_2;
  Sample* sample = pool_objs_2.Get();
  ASSERT_TRUE(NULL != sample);
  pool_objs_2.Free(sample);

  ASSERT_EQ(pool_objs_2.num_blocks_alloc_, size_t(1));
  ASSERT_EQ(true, pool_objs_2.to_resize_);
  ASSERT_EQ(size_t(1), pool_objs_2.current_row_);
  ASSERT_EQ(size_t(0), pool_objs_2.current_col_);
}

TEST(test_init, init_passive) {
  PoolObjs<Sample> pool_objs(101, 0, true, 10);
  ASSERT_TRUE(NULL == pool_objs.Get());
  PoolObjs<Sample> pool_objs_2(101, 10, true, 0);
  ASSERT_TRUE(NULL == pool_objs_2.Get());
}

TEST(test_get_free, no_resize) {
  PoolObjs<Sample> pool_objs(100, 100, false, 2);

  Sample* objs[200];
  int i;
  for(i=0; i<100; ++i) {
    objs[i] = pool_objs.Get();
    ASSERT_TRUE(NULL != objs[i]);
  }

  ASSERT_EQ(size_t(0), pool_objs.current_row_);
  ASSERT_EQ(size_t(0), pool_objs.current_col_);
  ASSERT_EQ(size_t(1), pool_objs.num_blocks_alloc_);
  ASSERT_EQ(size_t(100), pool_objs.NumObjsAlloc());

  objs[i] = pool_objs.Get();
  ASSERT_TRUE(NULL == objs[i]);

  for(i=0; i<100; ++i) {
    pool_objs.Free(objs[i]);
  }
}

TEST(test_get_free, resize_all) {
  Sample sample;
  sample.init = true;
  PoolObjsInit<Sample> pool_objs(sample, 100, 100, true, 2);

  Sample* objs[200];
  int i;
  for(i=0; i<100; ++i) {
    objs[i] = pool_objs.Get();
    ASSERT_TRUE(NULL != objs[i]);
    ASSERT_EQ(objs[i]->init, true);
  }

  ASSERT_EQ(size_t(0), pool_objs.current_row_);
  ASSERT_EQ(size_t(0), pool_objs.current_col_);
  ASSERT_EQ(size_t(1), pool_objs.num_blocks_alloc_);

  objs[i] = pool_objs.Get();
  ASSERT_TRUE(NULL != objs[i]);
  pool_objs.Free(objs[i]);
  ASSERT_TRUE(NULL != objs[i]);
  objs[i] = pool_objs.Get();
  ASSERT_TRUE(NULL != objs[i]);

  ASSERT_EQ(size_t(0), pool_objs.current_row_);
  ASSERT_EQ(size_t(99), pool_objs.current_col_);
  ASSERT_EQ(size_t(2), pool_objs.num_blocks_alloc_);

  for (i=101; i<200; ++i) {
    objs[i] = pool_objs.Get();
    ASSERT_TRUE(NULL != objs[i]);
  }

  objs[i] = pool_objs.Get();
  ASSERT_TRUE(NULL == objs[i]);

  for (i=0; i<200; ++i) {
    pool_objs.Free(objs[i]);
  }
  ASSERT_EQ(size_t(2), pool_objs.current_row_);
  ASSERT_EQ(size_t(0), pool_objs.current_col_);
  ASSERT_EQ(size_t(2), pool_objs.num_blocks_alloc_);

  objs[0] = pool_objs.Get();
  ASSERT_TRUE(NULL != objs[0]);

  ASSERT_EQ(size_t(1), pool_objs.current_row_);
  ASSERT_EQ(size_t(99), pool_objs.current_col_);
  ASSERT_EQ(size_t(2), pool_objs.num_blocks_alloc_);

  pool_objs.Free(objs[0]);
}

TEST(test_get_free, extra_obj) {
  PoolObjs<int> pool;
  int* extra_obj = new int;
  pool.Free(extra_obj);
}
