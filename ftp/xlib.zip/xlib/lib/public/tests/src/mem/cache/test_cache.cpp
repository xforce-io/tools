#include "gtest/gtest.h"
#include "../../src/cache.h"

using namespace xlib::pub;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_cache, test_buf) {
  Cache cache;
  ASSERT_TRUE(true == cache.Append("asd", 3));
  ASSERT_TRUE(0 == memcmp(cache.buf_, "asd", 3));
  ASSERT_TRUE(3 == cache.len_);
  ASSERT_TRUE(Cache::kSizeAllocBlock == cache.size_);
}

TEST(test_cache, test_char) {
  Cache cache;
  ASSERT_TRUE(true == cache.Append('a'));
  ASSERT_TRUE(0 == memcmp(cache.buf_, "a", 1));
  ASSERT_TRUE(1 == cache.len_);
  ASSERT_TRUE(Cache::kSizeAllocBlock == cache.size_);
}

TEST(test_cache, test_size_t) {
  Cache cache;
  size_t s=12;
  ASSERT_TRUE(true == cache.Append(s));
  ASSERT_TRUE(0 == memcmp(cache.buf_, "12", 2));
  ASSERT_TRUE(2 == cache.len_);
  ASSERT_TRUE(Cache::kSizeAllocBlock == cache.size_);
}

TEST(test_cache, test_int) {
  Cache cache;
  int s=1234567;
  ASSERT_TRUE(true == cache.Append(s));
  ASSERT_TRUE(0 == memcmp(cache.buf_, "1234567", 7));
  ASSERT_TRUE(7 == cache.len_);
  ASSERT_TRUE(Cache::kSizeAllocBlock == cache.size_);
}

TEST(test_cache, test_all_kinds) {
  Cache cache;
  const char* buf = "abc";
  int i=123;
  size_t s=456;
  char c='e';
  ASSERT_TRUE(true == cache.Append(i));
  ASSERT_TRUE(true == cache.Append(s));
  ASSERT_TRUE(true == cache.Append(c));
  ASSERT_TRUE(true == cache.Append(buf, 3));
  ASSERT_TRUE(true == cache.Append(i));
  ASSERT_TRUE(0 == memcmp(cache.buf_, "123456eabc123", 13));
  ASSERT_TRUE(13 == cache.len_);
  ASSERT_TRUE(Cache::kSizeAllocBlock == cache.size_);
}

TEST(test_cache, realloc) {
  Cache cache;
  const size_t kLen=1000000;
  for (size_t i=0; i<kLen; ++i) {
    ASSERT_TRUE(true == cache.Append("0123456789", 10));
  }

  for (size_t i=0; i<kLen; ++i) {
    ASSERT_TRUE( (i%10 + '0') == size_t(reinterpret_cast<const char*>(cache.Buf())[i]));
  }
}
