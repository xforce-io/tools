#include "gtest/gtest.h"
#include "../../src/pool_msgs.h"

using namespace xlib::pub;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_pool_msgs, init_passive)
{
  std::vector< std::pair<size_t, size_t> > conf;
  PoolMsgs pool_msgs(conf);
  ASSERT_TRUE(NULL == pool_msgs.Get(1));

  conf.push_back(std::pair<size_t, size_t>(1, 2));
  pool_msgs = PoolMsgs(conf);
  ASSERT_TRUE(NULL == pool_msgs.Get(1));

  conf.push_back(std::pair<size_t, size_t>(1, 0));
  pool_msgs = PoolMsgs(conf);
  ASSERT_TRUE(NULL == pool_msgs.Get(1));

  conf.clear();
  conf.push_back(std::pair<size_t, size_t>(10, 2));
  conf.push_back(std::pair<size_t, size_t>(10, 5));
  pool_msgs = PoolMsgs(conf);
  ASSERT_TRUE(NULL == pool_msgs.Get(1));

  conf.clear();
  conf.push_back(std::pair<size_t, size_t>(4, 2));
  conf.push_back(std::pair<size_t, size_t>(7, 3));
  conf.push_back(std::pair<size_t, size_t>(15, 4));
  pool_msgs = PoolMsgs(conf);
  ASSERT_TRUE(true == pool_msgs.Init_());
  for (size_t i=1; i<=2; ++i) {
    ASSERT_EQ(pool_msgs.len_to_pool_index_[i], 1);
  }
  for (size_t i=3; i<=4; ++i) {
    ASSERT_EQ(pool_msgs.len_to_pool_index_[i], 2);
  }
  for (size_t i=5; i<=7; ++i) {
    ASSERT_EQ(pool_msgs.len_to_pool_index_[i], 3);
  }
  for (size_t i=8; i<11; ++i) {
    ASSERT_EQ(pool_msgs.len_to_pool_index_[i], 4);
  }
  for (size_t i=12; i<15; ++i) {
    ASSERT_EQ(pool_msgs.len_to_pool_index_[i], 5);
  }
  
  std::vector< std::pair<size_t, size_t> > test_pairs;
  test_pairs.push_back(std::pair<size_t, size_t>( 0, 0));
  test_pairs.push_back(std::pair<size_t, size_t>( 1, 2));
  test_pairs.push_back(std::pair<size_t, size_t>( 2, 2));
  test_pairs.push_back(std::pair<size_t, size_t>( 3, 4));
  test_pairs.push_back(std::pair<size_t, size_t>( 4, 4));
  test_pairs.push_back(std::pair<size_t, size_t>( 5, 7));
  test_pairs.push_back(std::pair<size_t, size_t>( 6, 7));
  test_pairs.push_back(std::pair<size_t, size_t>( 7, 7));
  test_pairs.push_back(std::pair<size_t, size_t>( 8,11));
  test_pairs.push_back(std::pair<size_t, size_t>( 9,11));
  test_pairs.push_back(std::pair<size_t, size_t>(10,11));
  test_pairs.push_back(std::pair<size_t, size_t>(11,11));
  test_pairs.push_back(std::pair<size_t, size_t>(12,15));
  test_pairs.push_back(std::pair<size_t, size_t>(13,15));
  test_pairs.push_back(std::pair<size_t, size_t>(14,15));
  test_pairs.push_back(std::pair<size_t, size_t>(15,15));

  Msg* msg;
  for (size_t i=0; i < test_pairs.size(); ++i) {
    msg = pool_msgs.Get(test_pairs[i].first);
    ASSERT_TRUE(NULL!=msg);
    ASSERT_EQ(test_pairs[i].second, msg->size);
    pool_msgs.Free(msg);
  }

  msg = pool_msgs.Get(16);
  ASSERT_TRUE(NULL==msg);
}
