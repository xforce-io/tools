#include "gtest/gtest.h"
#include "../../src/jsontype/jsontype.h"

using namespace xlib;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestJsonType: public ::testing::Test {
 protected:
  TestJsonType() {}
  virtual ~TestJsonType() {}
  virtual void SetUp() {
    system("rm -rf data/jsontype/test_jsontype");
    system("mkdir -p data/jsontype/test_jsontype");
  }
  virtual void TearDown() {}
};

TEST_F(TestJsonType, all) {
  pub::JsonType json_val;
  ASSERT_EQ(pub::JsonValType::kNull, json_val.Type());
  json_val = true;
  ASSERT_EQ(pub::JsonValType::kBool, json_val.Type());
  json_val = 12;
  ASSERT_EQ(pub::JsonValType::kInt, json_val.Type());
  ASSERT_TRUE(12 == json_val.AsInt());
  json_val = 1.1;
  ASSERT_EQ(pub::JsonValType::kDouble, json_val.Type());
  json_val = "str";
  ASSERT_EQ(pub::JsonValType::kStr, json_val.Type());
  ASSERT_TRUE("str" == json_val.AsStr());

  json_val["table"]["key0"] = "val0";
  json_val["table"]["key1"][2] = "val1";
  ASSERT_EQ(2, json_val["table"].Size());
  ASSERT_EQ(3, json_val["table"]["key1"].Size());

  pub::JsonType json_val2 = json_val["table"];
  json_val2["key2"] = 12;
  ASSERT_EQ(3, json_val2.Size());

  ASSERT_EQ(2, json_val["table"].Size());

  pub::JsonType json_val3 = json_val;
  json_val3["table1"][2]["dog"] = 1.1;
  ASSERT_EQ(1, json_val.Size());
  ASSERT_EQ(2, json_val3.Size());

  std::stringstream ss;
  json_val.DumpJson(ss);
  ASSERT_TRUE(ss.str() == "{\"table\":{\"key1\":[null,null,\"val1\"], \"key0\":\"val0\"}}");
  ss.str("");
  json_val2.DumpJson(ss);
  ASSERT_TRUE(ss.str() == "{\"key2\":12, \"key1\":[null,null,\"val1\"], \"key0\":\"val0\"}");
  ss.str("");
  json_val3.DumpJson(ss);
  ASSERT_TRUE(ss.str() == 
      "{\"table1\":[null,null,{\"dog\":1.1}], \"table\":{\"key1\":[null,null,\"val1\"], \"key0\":\"val0\"}}");
}

TEST_F(TestJsonType, ReadinTrue) {
  const char* str = "";
  pub::JsonType* json_val = pub::SharedJsonVal::JsonParseUtil::ReadinTrue_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "2dsdc";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinTrue_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "true";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinTrue_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kBool, json_val->shared_json_val_->type);
  ASSERT_EQ(1, json_val->shared_json_val_->ref_cnt);
  ASSERT_TRUE(json_val->shared_json_val_->data.bool_val);
  XLIB_DELETE(json_val)
}

TEST_F(TestJsonType, ReadinFalse) {
  const char* str = "";
  pub::JsonType* json_val = pub::SharedJsonVal::JsonParseUtil::ReadinFalse_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "2dsdc";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinFalse_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "false";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinFalse_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kBool, json_val->shared_json_val_->type);
  ASSERT_EQ(1, json_val->shared_json_val_->ref_cnt);
  ASSERT_TRUE(!json_val->shared_json_val_->data.bool_val);
  XLIB_DELETE(json_val)
}

TEST_F(TestJsonType, ReadinList) {
  const char* str = "";
  pub::JsonType* json_val = pub::SharedJsonVal::JsonParseUtil::ReadinList_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "[3,2]";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinList_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kList, json_val->shared_json_val_->type); 
  ASSERT_TRUE(2 == json_val->shared_json_val_->data.list_val->size());
  XLIB_DELETE(json_val);
}

TEST_F(TestJsonType, ReadinDict) {
  const char* str = "";
  pub::JsonType* json_val = pub::SharedJsonVal::JsonParseUtil::ReadinDict_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "{\"key\":2\"}";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinDict_(str);
  ASSERT_TRUE(NULL==json_val);
  str = "{\"key\":\"val\"}";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadinDict_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kDict, json_val->shared_json_val_->type); 
  ASSERT_TRUE(1 == json_val->shared_json_val_->data.dict_val->size());
  XLIB_DELETE(json_val);
}

TEST_F(TestJsonType, ReadInDigits) {
  const char* str = "11";
  pub::JsonType* json_val = pub::SharedJsonVal::JsonParseUtil::ReadInDigits_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kInt, json_val->shared_json_val_->type); 
  ASSERT_TRUE(11 == json_val->shared_json_val_->data.int_val);
  XLIB_DELETE(json_val);
  str = "1.1";
  json_val = pub::SharedJsonVal::JsonParseUtil::ReadInDigits_(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_EQ(pub::JsonValType::kDouble, json_val->shared_json_val_->type); 
  ASSERT_TRUE( json_val->shared_json_val_->data.double_val > 1.0 
      && json_val->shared_json_val_->data.double_val < 1.2 );
  XLIB_DELETE(json_val);
}

TEST_F(TestJsonType, ReadinStrRaw) {
  const char* str = "";
  std::string* str_val = pub::SharedJsonVal::JsonParseUtil::ReadinStrRaw_(str);
  ASSERT_TRUE(NULL==str_val);
  str = "\"sdf";
  str_val = pub::SharedJsonVal::JsonParseUtil::ReadinStrRaw_(str);
  ASSERT_TRUE(NULL==str_val);
  str = "s\"df";
  str_val = pub::SharedJsonVal::JsonParseUtil::ReadinStrRaw_(str);
  ASSERT_TRUE(NULL==str_val);
  str = "\"dfs\"";
  str_val = pub::SharedJsonVal::JsonParseUtil::ReadinStrRaw_(str);
  ASSERT_TRUE(NULL!=str_val);
  ASSERT_TRUE(0 == strcmp("dfs", str_val->c_str()));
  XLIB_DELETE(str_val);
}

TEST_F(TestJsonType, ReadDictPair) {
  const char* str = "";
  std::pair<std::string, pub::JsonType>* res_pair = pub::SharedJsonVal::JsonParseUtil::ReadDictPair_(str);
  ASSERT_TRUE(NULL==res_pair);

  str = "\"\":123";
  res_pair = pub::SharedJsonVal::JsonParseUtil::ReadDictPair_(str);
  ASSERT_TRUE(NULL==res_pair);

  str = "\"key\":123";
  res_pair = pub::SharedJsonVal::JsonParseUtil::ReadDictPair_(str);
  ASSERT_TRUE(NULL!=res_pair);
  ASSERT_TRUE("key" == res_pair->first);
  ASSERT_TRUE(pub::JsonValType::kInt == res_pair->second.shared_json_val_->type);
  ASSERT_TRUE(123 == res_pair->second.shared_json_val_->data.int_val);
  XLIB_DELETE(res_pair);
}

TEST_F(TestJsonType, ParseJson) {
  const char* str = "{"
    "\"key2\": 12,"
    "\"key1\": [ null, null, \"val1\", 12.1 ], "
    "\"key0\": { \"subkey\" : \"val0\" , \"subkey2\" : 12 }, "
    "\"key3\": {  }"
  "}";

  pub::JsonType* json_val = pub::JsonType::ParseJson(str);
  ASSERT_TRUE(NULL!=json_val);
  ASSERT_TRUE((*json_val)["key2"] == 12);
  ASSERT_TRUE((*json_val)["key1"][2] == "val1");
  ASSERT_TRUE((*json_val)["key1"][3] == 12.1);
  ASSERT_TRUE((*json_val)["key0"]["subkey"] == "val0");
  ASSERT_TRUE((*json_val)["key0"]["subkey2"] == 12);
  ASSERT_TRUE((*json_val)["key3"].Size() == 0);
  XLIB_DELETE(json_val);
}
