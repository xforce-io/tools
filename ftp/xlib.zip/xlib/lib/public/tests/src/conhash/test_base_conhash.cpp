#include <gtest/gtest.h>

#include "../../src/base_conhash.h"

using namespace std;
using namespace xlib::pub;

int main(int argc, char **argv)
{
 	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

TEST(base_conhash, test_all)
{
  BaseConhash base_conhash;
  ASSERT_EQ(true, base_conhash.AddNode(0));
  ASSERT_EQ(0, base_conhash.head_.next->left);
  ASSERT_EQ(INT_MAX, base_conhash.head_.next->right);

  ASSERT_EQ(true, base_conhash.AddNode(1));
  ASSERT_EQ(0, base_conhash.head_.next->left);
  ASSERT_EQ(INT_MAX/2, base_conhash.head_.next->right);
  ASSERT_EQ(INT_MAX/2+1, base_conhash.head_.next->next->left);
  ASSERT_EQ(INT_MAX, base_conhash.head_.next->next->right);

  ASSERT_EQ(true, base_conhash.AddNode(2));
  ASSERT_EQ(0, base_conhash.head_.next->left);
  ASSERT_EQ(INT_MAX/6, base_conhash.head_.next->right);
  ASSERT_EQ(INT_MAX/6+1, base_conhash.head_.next->next->left);
  ASSERT_EQ(INT_MAX/2, base_conhash.head_.next->next->right);
  ASSERT_EQ(INT_MAX/2+1, base_conhash.head_.next->next->next->left);
  ASSERT_EQ(INT_MAX/3*2+1, base_conhash.head_.next->next->next->right);
  ASSERT_EQ(INT_MAX/3*2+2, base_conhash.head_.next->next->next->next->left);
  ASSERT_EQ(INT_MAX, base_conhash.head_.next->next->next->next->right);

  ASSERT_EQ(base_conhash.num_intervals_, 4);
  ASSERT_EQ(base_conhash.num_nodes_, 3);

  int answer[3] = {0, 0, 0};
  for (size_t i=0; i<30000; ++i) {
    int ret = base_conhash.GetRandSign()->sign;
    ++answer[ret];
  }
  ASSERT_TRUE(answer[0]>9000);
  ASSERT_TRUE(answer[1]>9000);
  ASSERT_TRUE(answer[2]>9000);
}
