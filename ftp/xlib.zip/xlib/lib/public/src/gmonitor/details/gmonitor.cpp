#include "../monitor.h"
#include "../../common.h"

namespace xlib { namespace pub {

monitor::Monitor* GMonitor::monitor_ = NULL; 

bool GMonitor::Init(const std::string& conf_path) {
  if (NULL!=monitor_) return true;

  XLIB_NEW(monitor_, monitor::Monitor)
  return monitor_->Init(conf_path);
}

void GMonitor::Tini() {
  XLIB_DELETE(monitor_)
}

}}
