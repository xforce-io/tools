#include <unistd.h>

#include "../db_reloader.h"
#include "../../time/time.h"

namespace xlib { namespace pub {

DBReloader::DBReloader(
    const std::string& name,
    size_t num_versions, 
    time_t check_interval_in_sec) : 
        name_(name),
        num_versions_(num_versions),
        check_interval_in_sec_(check_interval_in_sec),
        num_dbs_(0),
        current_latest_version_index_(0),
        pid_(0),
        end_(false) {
  memset(version_managers_, 0, sizeof(version_managers_)); 
  memset(latest_version_, 0, sizeof(latest_version_)); 
}

DBReloader::~DBReloader() {
  end_=true;
  if (0!=pid_) pthread_join(pid_, NULL);
  for (size_t i=0; i<kMaxNumVMs; ++i) {
    XLIB_DELETE(version_managers_[i]);
  }
}

bool DBReloader::CreateNewVersion_() {
  for(size_t i=0; i<num_dbs_; ++i) {
    int version = version_managers_[i]->CreateAndFreezeNewVersion();
    XLIB_FAIL_HANDLE(version < 0);

    latest_version_[1-current_latest_version_index_][i] = version;
  }
  current_latest_version_index_ = 1-current_latest_version_index_;
  return true;

  ERROR_HANDLE:
  return false;
}

void* DBReloader::ReloadThread_(void* arg) {
  DBReloader* db_reloader = RCAST<DBReloader*>(arg);
  while (!db_reloader->end_) {
    db_reloader->CreateNewVersion_();
    Time::UninteruptbleSleep(db_reloader->check_interval_in_sec_);
  }
  return NULL;
}

}}
