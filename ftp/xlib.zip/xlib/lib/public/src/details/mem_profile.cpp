#include "../mem_profile.h"

namespace xlib { namespace pub {

bool MemProfile::flag_ = false;

}}
