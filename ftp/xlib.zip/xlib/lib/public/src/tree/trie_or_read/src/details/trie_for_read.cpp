#include "../trie_or_read.h"

namespace xlib { namespace basic {

TrieForRead::TrieForRead() :
    count_(0),
    refcnt_(0),
    next_.check_null(NULL) {}

int TrieForRead::Insert(char* buf, size_t len_buf)
{
  int ret;
  if (0==len_buf) return -2;

  char& current_char = buf[0];
  TrieForRead* next_node;
  if (0==count_) {
    count_=1;
    low_bound_=current_char;
    next_node=next.single;
  } else if (1==count_) {
    if (current_char!=low_bound_) {
      TrieChildCache* new_node = new (std::nothrow) TrieChildCache;
      if (NULL==new_node) return -1;

      new_node->size=2;
      new_node->next_char[0]=current_char;
      new_node->next_char[1]=low_bound_;
      new_node->next[0]=NULL;
      new_node->next[1]=next.single;
      if (NULL==new_node->next[1]) { delete new_node; return -1; }
      next.cache = new_node;
      count_=2;
      low_bound_ = std::min(low_bound_, current_char);
      next_node=next.single;
    } else {
      next_node=NULL;
    }
  } else if (TrieChildCache::kSizeCacheNode>count_) {
    size_t index;
    for (index=0; index<TrieChildCache::kSizeCacheNode; ++index) {
      if (current_char==next.cache->next_char[index]) break;
    }

    if (index!=TrieChildCache::kSizeCacheNode) {
      next_node=next.cache->next[index];
    } else {
      next.cache->next_char=current_char;
      next_node=next.cache[next.cache->size];
      ++next.cache->size;
      low_bound_ = std::min(low_bound_, current_char);
    }
  } else if (TrieChildCache::kSizeCacheNode==count_) {
    low_bound_ = std::min(low_bound_, current_char);
    char max_char=next.cache->next_char[0];
    for (size_t i=1; i<TrieChildCache::kSizeCacheNode; ++i) {
      max_char = std::max(max_char, next.cache->next_char[i]);
    }
    max_char = std::max(max_char, current_char);
    count_ = max_char-low_bound_+1;
    TrieForRead** new_node = new (std::nothrow) TrieForRead [count_];
    if (NULL==new_node) return -1;

    memset(new_node, 0, sizeof(*new_node)*count_);
    for (size_t i=0; i<TrieChildCache::kSizeCacheNode; ++i) {
      new_node[next.cache->next_char[i] - low_bound_] = next.cache->next_char[i];
    }

    next_node = new_node[current_char-low_bound_];
    delete next_.cache;

    next_.normal=new_node;
  } else if (current_char<) {
  } else {
  }

  return InsertToChild_(buf, len_buf, NULL!=next_node ? &next_node : NULL);
}

int TrieForRead::InsertToChild_(char* buf, size_t len_buf, TrieForRead** next_node)
{
  if (1!=len_buf) {
    if (NULL==next_node) {
      *next_node = new (std::nothrow) TrieForRead;
      if (NULL==next_node) return -1;
    }

    ret = next_node->Insert(buf+1, len_buf-1);
    if ( unlikely(0!=ret) ) { 
      if (NULL==next_node) delete next.single; 
      return ret; 
    }
  } else {
    ++refcnt_;
  }
  return 0;
}

}}
