#include "../buffer.h"

namespace xlib { namespace pub {

Buffer::~Buffer() {
  if (NULL!=buf_) free(buf_);
}

}}
