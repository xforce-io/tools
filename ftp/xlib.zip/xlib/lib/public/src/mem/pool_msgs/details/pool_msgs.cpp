#include <iostream>
#include "../pool_msgs.h"

namespace xlib { namespace pub {

bool PoolMsgs::Init_()
{
  if (0 == conf_.size()) return false;

  len_to_pool_index_.reserve(1);
  len_to_pool_index_.push_back(0);
  pools_.reserve(1);
  pools_.push_back(Pool(0, 0, kDefaultPoolAllocSize));

  size_t last_upbound=0;
  for (size_t i=0; i<conf_.size(); ++i) {
    size_t current_upbound = conf_[i].first;
    size_t current_step = conf_[i].second;
    if (current_upbound<=last_upbound
        || 0==current_step
        || (current_upbound-last_upbound)%current_step != 0) 
      return false;

    len_to_pool_index_.reserve(current_upbound+1);
    for (
        size_t size=last_upbound; 
        size+current_step <= current_upbound; 
        size+=current_step) {
      for (size_t j=size+1; j<=size + current_step; ++j) {
        len_to_pool_index_.push_back(0);
      }
      ++num_pools_;
      len_to_pool_index_[size + current_step] = num_pools_;
      pools_.reserve(num_pools_+1);
      pools_.push_back(Pool(
          size+current_step,
          0,
          kDefaultPoolAllocSize));
    }
    last_upbound=current_upbound;
  }

  max_msg_size_=last_upbound;
  for (size_t size=last_upbound; size!=0; --size) {
    if (0 == len_to_pool_index_[size]) {
      len_to_pool_index_[size] = last_upbound;
    } else {
      last_upbound = len_to_pool_index_[size];
    }
  }
  
  init_=true;
  return true;
}

}}
