#include "../cache.h"

namespace xlib { namespace pub {

Cache::Cache() :
    buf_(NULL),
    len_(0),
    size_(0) {}

bool Cache::Append(const void* buf, size_t size) 
{
  if ( unlikely(len_+size > size_) ) {
    size_t new_size = (size_+kSizeAllocBlock >= len_+size ? 
        size_+kSizeAllocBlock : len_+size);
    void* new_buf = realloc(buf_, new_size);
    if (NULL==new_buf) {
      FATAL("fail_in_realloc");
      return false;
    }

    buf_=new_buf;
    size_=new_size;
  }

  memcpy(reinterpret_cast<char*>(buf_)+len_, buf, size);
  len_+=size;
  return true;
}

bool Cache::Append(char c) 
{
  if ( unlikely(len_+1 > size_) ) {
    size_t new_size = size_+kSizeAllocBlock;
    void* new_buf = realloc(buf_, new_size);
    if (NULL==new_buf) {
      FATAL("fail_in_realloc");
      return false;
    }

    buf_=new_buf;
    size_=new_size;
  }

  *(reinterpret_cast<char*>(buf_) + len_) = c;
  len_+=1;
  return true;
}

bool Cache::Append(size_t i) 
{
  char buf[kMaxLenInteger];
  if ( unlikely(snprintf(buf, sizeof(buf), "%lu", i) <= 0) ) {
    FATAL("fail_append_cache");
    return false;;
  }

  return Append(reinterpret_cast<void*>(buf), strlen(buf));
}

bool Cache::Append(int i) 
{
  char buf[kMaxLenInteger];
  if ( unlikely(snprintf(buf, sizeof(buf), "%d", i) <= 0) ) {
    FATAL("fail_append_cache");
    return false;;
  }

  return Append(reinterpret_cast<void*>(buf), strlen(buf));
}

Cache::~Cache() 
{
  if (NULL!=buf_) free(buf_);
}

}}
