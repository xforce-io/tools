#include "../conhash.h"

namespace xlib { namespace pub {

ConhashIterator ConhashIterator::operator++()
{
}

ConhashIterator ConhashIterator::operator++(int)
{
}

const char* ConhashIterator::operator*()
{
  if ( unlikely(NULL==conhash_interval_) ) return NULL;
}

Conhash::Conhash() :
    current_id_(0),
    current_virtual_id_(0) {}

int Conhash::AddNode(char* name, size_t weight)
{
  if ( unlikely(NULL==name || weight<=0) ) return -2;

  size_t new_id = ++current_id_;

  bool ret = (id_to_name_.insert(std::pair<size_t, std::string>(new_id, name))).second;
  if ( unlikely(false==ret) ) return -3;  

  size_t new_virtual_id_start = ++current_virtual_id_;
  current_virtual_id_ += weight;
  size_t new_virtual_id_end=current_virtual_id_;

/*
  ret = (virtual_id_to_id_.insert(
      std::pair< std::pair<size_t, size_t>, size_t >(
          std::pair<size_t, size_t>(
              new_virtual_id_start,
              new_virtual_id_end),
          new_id))).second;
          */

  for (size_t i=new_virtual_id_start; i<new_virtual_id_end; ++i) {
    ret = base_conhash_.AddNode(i);
    if (true!=ret) return -4;
  }
  return 0;
}

}}
