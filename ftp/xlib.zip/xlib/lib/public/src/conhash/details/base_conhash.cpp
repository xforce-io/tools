#include <iostream>
#include "../base_conhash.h"

namespace xlib { namespace pub {

bool ConhashInterval::Comp::operator() (
    ConhashInterval* intvl_1, 
    ConhashInterval* intvl_2) 
{
  return intvl_1->right < intvl_2->left ? true : false;
}

BaseConhash::BaseConhash() :
    num_intervals_(0),
    num_nodes_(0),
    init_(false) 
{
  head_.next = NULL;
}

bool BaseConhash::AddNode(int sign)
{
  XLIB_RAII_INIT(false)

  if ( unlikely(0==num_nodes_) ) {
    ++num_nodes_;
    return true;
  }

  ConhashInterval** iter;
  size_t current_num_intervals=0;
  for (iter=&(head_.next); *iter!=NULL; iter=&((*iter)->next)) {
    map_nodes_[(*iter)->sign] = false;
    tmp_intervals_[current_num_intervals++] = iter;
  }

  for (size_t i=0; i<current_num_intervals; ++i) {
    iter = tmp_intervals_[i];
    if (false == map_nodes_[(*iter)->sign]) {
      if ( unlikely(false == SplitInterval_(iter, sign))) return false;
      map_nodes_[(*iter)->sign] = true;
    }
  }
  ++num_nodes_;
  return true;
}

ConhashInterval* BaseConhash::GetRandInterval()
{
  XLIB_RAII_INIT(NULL)

  int rand_num = rand();
  ConhashInterval conhash_interval = {
      .left = rand_num, 
      .right = rand_num,
      .sign = -1,
      .next = NULL, };
  IndexIntervals::const_iterator iter = 
      index_intervals_.find(&conhash_interval);
  if (index_intervals_.end() != iter) return iter->first;
  return NULL;
}

bool BaseConhash::Init_()
{
  map_nodes_ = new (std::nothrow) bool [kMaxNumNodes];
  if (NULL==map_nodes_) return false;

  tmp_intervals_ = new (std::nothrow) ConhashInterval** [kMaxNumIntervals];
  if (NULL==tmp_intervals_) return false;

  ConhashInterval* new_interval = new (std::nothrow) ConhashInterval;
  if ( unlikely(NULL==new_interval) ) return false;

  new_interval->left = 0;
  new_interval->right = INT_MAX;
  new_interval->sign = 0;
  new_interval->next = NULL;
  head_.next = new_interval;
  ++num_intervals_;

  bool ret = (index_intervals_.insert(
      std::pair<ConhashInterval*, ConhashInterval*>(
          new_interval, new_interval))).second;
  if ( unlikely(false==ret) ) return false;

  init_=true;
  return true;
}

bool BaseConhash::SplitInterval_(
    ConhashInterval** interval, 
    int sign)
{ 
  size_t num_element_erased = index_intervals_.erase(*interval);
  if ( unlikely(1!=num_element_erased) ) return false;

  ConhashInterval* new_interval = new (std::nothrow) ConhashInterval;
  if ( unlikely(NULL==new_interval) ) return false;

  new_interval->left = (*interval)->left;
  new_interval->right = new_interval->left + INT_MAX/(num_nodes_ * (num_nodes_+1));
  new_interval->sign = sign;
  new_interval->next = *interval;  
  (*interval)->left = new_interval->right + 1;
  *interval = new_interval;
  ++num_intervals_;

  bool ret = (index_intervals_.insert(
      std::pair<ConhashInterval*, ConhashInterval*>(
          new_interval, new_interval))).second;
  if ( unlikely(true!=ret) ) return false;

  ret = (index_intervals_.insert(
      std::pair<ConhashInterval*, ConhashInterval*>(
          new_interval->next, new_interval->next))).second;
  if ( unlikely(true!=ret) ) return false;
  return true;
}

}}
