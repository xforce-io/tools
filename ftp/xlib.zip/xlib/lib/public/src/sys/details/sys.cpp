#include "../sys.h"

namespace xlib { namespace pub {

size_t Sys::GetVmRSS(pid_t pid) {
  std::stringstream proc_name;
  proc_name << "/proc/" << pid << "/status";
  FILE* fp = fopen(proc_name.str().c_str(), "r");
  if (NULL==fp) return 0;

  char buf[4096];
  char* line = fgets(buf, sizeof(buf), fp);
  int64_t ret=0;
  while (NULL!=line) {
    const std::string kPattern="VmRSS:";
    if (0 == strncmp(buf, kPattern.c_str(), kPattern.size())) {
      const char* ptr = buf + kPattern.size();
      while (' ' == *ptr) ++ptr;
      ret = atol(ptr);
      break;
    }

    line = fgets(buf, sizeof(buf), fp);
  }
  fclose(fp);
  return ret>0?ret:0;
}

}}
