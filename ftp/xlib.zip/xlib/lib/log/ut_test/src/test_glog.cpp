#include <stdarg.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <utility>
#include <time.h>

#include "gtest/gtest.h"
#include "lib/conf/src/conf.h"
#include "../../src/glog.h"
#include "../../src/public.h"

using xlib::log_t;
using namespace xlib;

static const int NumThreads = 1;
static const int TimesLog = 64000;
static const int SpeedLog = 6400;

static pid_t gettid() { return syscall(SYS_gettid); }

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_log : public ::testing::Test
{
    protected:
    virtual ~test_log(){};
    virtual void SetUp() 
    {
        system("rm -rf conf log; mkdir -p conf log");
    }

    virtual void TearDown() { }
};

void* log_thread(void*)
{
    printf("log_thread_%d_start\n", gettid());
    bool ret = glog_s::init_in_thread();
    if(false == ret) {
        printf("fail_init_in_thread");
        exit(1);
    }

    const int CheckTimesASec = 10;
    xlib::pub::timer_t timer;
    timer.start(true);
    for(int i = 1; i <= TimesLog/SpeedLog*CheckTimesASec; ++i) {
        for(int j=0; j<SpeedLog/CheckTimesASec; ++j) {
            //xlib::timer_t timer_inner;
            //timer_inner.start(true);
            FATAL("%d like %s 1234", 12, "dog");
            //timer_inner.stop(true);
//            printf("log consume[%lu]\n", timer_inner.time_us());
        }
        timer.stop(true);

        int64_t time_to_sleep = i*1000000/CheckTimesASec - timer.time_us();
        if(time_to_sleep > 0) {
            usleep(time_to_sleep);
        }
    }
    glog_s::close();
    printf("log_thread_%d_stop cost[%lu|%d]\n", 
        gettid(), timer.time_us(), TimesLog/SpeedLog);
    return NULL;
}

TEST_F(test_log, multi_thread_all)
{
    log_t log;
    int ret;
    char buf[100];
    FILE* fp;
    char* tmp;
    std::string path = "conf/test.conf";

    ASSERT_EQ(0, TimesLog%SpeedLog);

    xlib::pub::timer_t timer;
    timer.start();

    //log
    system("echo '[log]\ninit_mem_avail_per_thread:200000000\n"
        "level:3\nprefix:log/log\n' > conf/test.conf");
    ret = glog_s::init(path);
    ASSERT_EQ(true, ret);

    for(int i=0; i<NumThreads; ++i) {
        pthread_t thread;
        ret = pthread_create(&thread, NULL, log_thread, (void*)&log);
        ASSERT_EQ(ret, 0);
    }

    FATAL("%d like %s", 12, "dog");

    //wait for slave to complete init_in_thread
    sleep(3);
    glog_s::close();

    timer.stop();
    printf("all_consume[%lu]\n", timer.time_us());

    //test
    fp = fopen("log/log.wf", "r");
    ASSERT_TRUE(NULL != fp);
    
    for(int i=0; i<NumThreads*TimesLog+1; ++i) {
        tmp = fgets(buf, sizeof(buf), fp);
        ASSERT_TRUE(NULL != tmp);

        tmp = strstr(buf, "12 like dog");
        ASSERT_TRUE(NULL != tmp);

        tmp = strstr(buf, "12 like cat");
        ASSERT_TRUE(NULL == tmp);
    }
}
