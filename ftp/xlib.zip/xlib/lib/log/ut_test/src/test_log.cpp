#include <stdarg.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <utility>
#include <time.h>

#include "gtest/gtest.h"
#include "lib/conf/src/conf.h"
#include "../../src/log.h"
#include "../../src/public.h"

using xlib::log_t;
using namespace xlib;

static const int NumThreads = 1;
static const int TimesLog = 6400000;
static const int SpeedLog = 640000;

static pid_t gettid() { return syscall(SYS_gettid); }

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_log : public ::testing::Test
{
    protected:
    virtual ~test_log(){};
    virtual void SetUp() 
    {
        system("rm -rf conf log; mkdir -p conf log");
    }

    virtual void TearDown() { }
};

TEST_F(test_log, single_thread_all)
{
    log_t log;
    int ret;
    char buf[log_conf_s::MaxLogSize+100]; 
    char buf_1[log_conf_s::MaxLogSize+100], buf_2[log_conf_s::MaxLogSize+100];
    char buf_3[log_conf_s::MaxLogSize+100], buf_4[log_conf_s::MaxLogSize+100];
    FILE* fp;
    char* tmp;
    std::string path = "conf/test.conf";

    //log
    system("echo '[log]\ninit_mem_avail_per_thread:20000\n"
        "level:4\nprefix:log/log\n' > conf/test.conf");
    ret = log.init(path);
    ASSERT_EQ(true, ret);

    //wait for master to be up
    while(false == log._is_master_up)
        ;

    //short log
    log.log(4, "%d like %s %u %lu %ld %m", 12, "dog", 1, 2, 3);
    //long log type 1
    memset(buf_1, 'a', log_conf_s::MaxLogSize+50);
    memset(buf_2, 'a', log_conf_s::MaxLogSize+50);
    buf_2[log_conf_s::MaxLogSize-1] = '\0';
    log.log(4, buf_1);

    //long log type 2
    memset(buf_3, 'a', log_conf_s::MaxLogSize+50);
    buf_3[log_conf_s::MaxLogSize+50] = '%';
    buf_3[log_conf_s::MaxLogSize+50] = '\0';
    log.log(4, buf_3);
    
    //long log type 3
    memset(buf_4, 'a', log_conf_s::MaxLogSize+50);
    buf_4[log_conf_s::MaxLogSize-5] = '%';
    buf_4[log_conf_s::MaxLogSize-4] = 's';
    buf_4[log_conf_s::MaxLogSize+50] = '\0';
    log.log(4, buf_4, "123456789");

    log.log(4, "end");
    log.close();

    //test
    fp = fopen("log/log", "r");
    ASSERT_TRUE(NULL != fp);
    
    tmp = fgets(buf, sizeof(buf), fp);
    ASSERT_TRUE(NULL != tmp);

    tmp = strstr(buf, "12 like dog 1 2 3 %m");
    ASSERT_TRUE(NULL != tmp);

    tmp = fgets(buf, sizeof(buf), fp);
    ASSERT_TRUE(NULL != tmp);

    ret = strlen(buf);
    ASSERT_EQ(ret, log_conf_s::MaxLogSize-1);

    tmp = fgets(buf, sizeof(buf), fp);
    ASSERT_TRUE(NULL != tmp);

    ret = strlen(buf);
    ASSERT_EQ(ret, log_conf_s::MaxLogSize-1);

    tmp = fgets(buf, sizeof(buf), fp);
    ASSERT_TRUE(NULL != tmp);

    ret = strlen(buf);
    ASSERT_EQ(ret, log_conf_s::MaxLogSize-1);
}

void* log_thread(void* arg)
{
    printf("log_thread_%d_start\n", gettid());
    log_t* log = (log_t*)arg;
    bool ret = log->init_in_thread();
    if(false == ret) {
        printf("fail_init_in_thread");
        exit(1);
    }

    const int CheckTimesASec = 10;
    xlib::pub::timer_t timer;
    timer.start(true);
    for(int i = 1; i <= TimesLog/SpeedLog*CheckTimesASec; ++i) {
        for(int j=0; j<SpeedLog/CheckTimesASec; ++j) {
            log->log(1, "%d like %s %u %lu %ld", 12, "dog", 1, (uint64_t)2, (int64_t)3);
        }
        timer.stop(true);

        int64_t time_to_sleep = i*1000000/CheckTimesASec - timer.time_us();
        if(time_to_sleep > 0) {
            usleep(time_to_sleep);
        }
    }
    log->close();
    printf("log_thread_%d_stop cost[%lu|%d]\n", 
        gettid(), timer.time_us(), TimesLog/SpeedLog);
    return NULL;
}

TEST_F(test_log, multi_thread_all)
{
    log_t log;
    int ret;
    char buf[100];
    FILE* fp;
    char* tmp;
    std::string path = "conf/test.conf";

    ASSERT_EQ(0, TimesLog%SpeedLog);

    xlib::pub::timer_t timer;
    timer.start();

    //log
    system("echo '[log]\ninit_mem_avail_per_thread:200000000\n"
        "level:3\nprefix:log/log\n' > conf/test.conf");
    ret = log.init(path);
    ASSERT_EQ(true, ret);

    for(int i=0; i<NumThreads; ++i) {
        pthread_t thread;
        ret = pthread_create(&thread, NULL, log_thread, (void*)&log);
        ASSERT_EQ(ret, 0);
    }

    log.log(1, "%d like %s %u %lu %ld", 12, "dog", 1, (uint64_t)2, (int64_t)3);

    //wait for slave to complete init_in_thread
    sleep(3);
    log.close();

    timer.stop();
    printf("all_consume[%lu]\n", timer.time_us());

    //test
    fp = fopen("log/log.wf", "r");
    ASSERT_TRUE(NULL != fp);
    
    for(int i=0; i<NumThreads*TimesLog+1; ++i) {
        tmp = fgets(buf, sizeof(buf), fp);
        ASSERT_TRUE(NULL != tmp);

        tmp = strstr(buf, "12 like dog 1 2 3");
        ASSERT_TRUE(NULL != tmp);

        tmp = strstr(buf, "12 like cat 1 2 3");
        ASSERT_TRUE(NULL == tmp);
    }
}
