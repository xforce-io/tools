#include "gtest/gtest.h"
#include "lib/conf/src/conf.h"
#include "../../src/log_flows.h"

using xlib::log_flows_t;
using xlib::conf_t;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_log_flows : public ::testing::Test
{
    protected:
    virtual ~test_log_flows(){};
    virtual void SetUp() 
    {
        system("rm -rf conf log; mkdir -p conf log");
    }

    virtual void TearDown() { }
};

TEST_F(test_log_flows, fatal_and_warning_log_positive)
{
    conf_t conf;
    bool ret;
    log_flows_t log_flows;
    char buf[100];
    int size;
    const char* log_fatal = "fatal";
    const char* log_warn = "warn";

    //init
    system("echo '[log]\nprefix:log/test\nlevel:0' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(true, ret);

    //flow
    ASSERT_TRUE(NULL == log_flows.flow(0));
    ASSERT_TRUE(NULL != log_flows.flow(log_flows_t::Fatal));
    ASSERT_TRUE(NULL != log_flows.flow(log_flows_t::Warn));
    ASSERT_TRUE(NULL == log_flows.flow(log_flows_t::Warn+1));

    ASSERT_EQ(0, strcmp("fatal", log_flows.name(log_flows_t::Fatal)));
    ASSERT_EQ(0, strcmp("warn", log_flows.name(log_flows_t::Warn)));

    fprintf(log_flows.flow(log_flows_t::Fatal), log_fatal);
    fprintf(log_flows.flow(log_flows_t::Warn), log_warn);
    log_flows.flush(); 
    log_flows.close();

    //write
    FILE* fp = fopen("log/test.wf", "r");
    ASSERT_TRUE(NULL != fp);

    size = fread(buf, 100, 1, fp);
    char* result = strstr(buf, log_fatal);
    ASSERT_TRUE(NULL != result);
    result = strstr(buf, log_warn);
    ASSERT_TRUE(NULL != result);

    fp = fopen("log/test", "r");
    ASSERT_TRUE(NULL == fp);

    fp = fopen("log/test.debug", "r");
    ASSERT_TRUE(NULL == fp);
}

TEST_F(test_log_flows, fatal_and_warning_log_passive)
{
    conf_t conf;
    bool ret;
    log_flows_t log_flows;

    system("echo '[log]\nprefix:\n' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(false, ret);

    system("echo '[log]\nprefix:sample\nlevel:102' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(false, ret);
}

TEST_F(test_log_flows, notice_log_positive)
{
    conf_t conf;
    bool ret;
    log_flows_t log_flows;
    char buf[100];
    int size;
    const char* log_notice = "notice";

    system("echo '[log]\nprefix:log/test\nlevel:4' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(true, ret);

    fprintf(log_flows.flow(log_flows_t::Notice), log_notice);
    log_flows.flush(); log_flows.close();

    ASSERT_EQ(0, strcmp("notice", log_flows.name(log_flows_t::Notice)));

    FILE* fp = fopen("log/test", "r");
    ASSERT_TRUE(NULL != fp);

    size = fread(buf, 100, 1, fp);
    char* result = strstr(buf, log_notice);
    ASSERT_TRUE(NULL != result);

    fp = fopen("log/test.debug", "r");
    ASSERT_TRUE(NULL == fp);
}

TEST_F(test_log_flows, self_defined_positive)
{
    conf_t conf;
    bool ret;
    log_flows_t log_flows;
    char buf[100];
    int size;
    const char* log_selfdef = "selfdef";

    system("echo '[log]\nprefix:log/test\nlevel:4\n"
        "[log]\nfilename:log/test_self_def\nlevel:7\nname:selfdef\n' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(true, ret);

    fprintf(log_flows.flow(7), log_selfdef);
    log_flows.flush(); log_flows.close();

    ASSERT_EQ(0, strcmp("selfdef", log_flows.name(7)));

    FILE* fp = fopen("log/test_self_def", "r");
    ASSERT_TRUE(NULL != fp);

    size = fread(buf, 100, 1, fp);
    char* result = strstr(buf, log_selfdef);
    ASSERT_TRUE(NULL != result);

    fp = fopen("log/test.debug", "r");
    ASSERT_TRUE(NULL == fp);
}

TEST_F(test_log_flows, self_defined_passive)
{
    conf_t conf;
    bool ret;
    log_flows_t log_flows;

    system("echo '[log]\nprefix:log/test\nlevel:4\n[log]file:' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(false, ret);

    system("echo '[log]\nprefix:log/test\nlevel:4\n"
        "[log]\nfilename:log/test_self_def\nlevel:4' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(false, ret);

    system("echo '[log]\nprefix:log/test\nlevel:4\n"
        "[log]\nfilename:log/test_self_def\nlevel:7' > conf/test.conf");
    ret = conf.init("conf/test.conf");
    ASSERT_EQ(true, ret);

    ret = log_flows.init(conf);
    ASSERT_EQ(false, ret);
}
