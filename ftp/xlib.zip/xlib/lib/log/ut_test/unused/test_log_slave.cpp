#include "gtest/gtest.h"
#include "../src/log_slave.h"

using xlib::log_slave_t;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_log_slave : public ::testing::Test
{
    protected:
    virtual ~test_log_slave(){};
    virtual void SetUp() 
    {
        system("mkdir -p conf log");
    }

    virtual void TearDown() 
    {
        system("rm -rf conf log");
    };
};

TEST_F(test_log_slave, positive)
{
}
