#include <string.h>

#include "../public.h"
#include "../log_flows.h"

namespace xlib 
{

bool log_flows_t::init(const conf_t& conf)
{
    uint32_t log_level;
    string_t prefix;
    string_t filename;
    string_t selfdef_level_name;
    uint32_t level = 1;
    FILE* fp;
    uint32_t num_selfdef_level;

    bool ret = conf.get_subconf_uint32("log", 0, "level", log_level, 
        0, log_conf_s::MaxLogLevel);
    XLIB_FAIL_HANDLE(false == ret);

    ret = conf.get_subconf_str("log", 0, "prefix", prefix);
    XLIB_FAIL_HANDLE(false == ret);

    //init _flows
    memset(_flows, 0, sizeof(_flows));
    memset(_level_to_flow, 0, sizeof(_level_to_flow));

    _level_to_flow[Fatal] = level++;
    _level_to_flow[Warn] = level++;
    _level_to_flow[Notice] = level++;
    _level_to_flow[Trace] = level++;
    _level_to_flow[Debug] = level++;

    //init famous log levels
    fp = fopen((prefix+".wf").c_str(), "a");
    XLIB_FAIL_HANDLE_STDOUT(NULL == fp, 
        "[xlib:log] fail_open[%s]\n", (prefix+".wf").c_str());

    _flows[_level_to_flow[Fatal]] = fp;
    _flows[_level_to_flow[Warn]] = _flows[_level_to_flow[Fatal]];

    if(log_level >= Notice) {
        fp = fopen(prefix.c_str(), "a");
        XLIB_FAIL_HANDLE_STDOUT(NULL == fp, 
            "[xlib:log] fail_open[%s]\n", prefix.c_str());
        _flows[_level_to_flow[Notice]] = fp;

        if(log_level >= Trace) {
            fp = fopen((prefix+".debug").c_str(), "a");
            XLIB_FAIL_HANDLE_STDOUT(NULL == fp, "[xlib:log] fail_open[%s]\n", 
                (prefix+".debug").c_str());

            _flows[_level_to_flow[Trace]] = fp;
            if(log_level >= Debug) _flows[_level_to_flow[Debug]] = fp;
        }
    }

    strncpy(_names[_level_to_flow[Fatal]], "fatal", sizeof(_names[0]));
    strncpy(_names[_level_to_flow[Warn]], "warn", sizeof(_names[0]));
    strncpy(_names[_level_to_flow[Notice]], "notice", sizeof(_names[0]));
    strncpy(_names[_level_to_flow[Trace]], "trace", sizeof(_names[0]));
    strncpy(_names[_level_to_flow[Debug]], "debug", sizeof(_names[0]));

    _names[_level_to_flow[Fatal]][sizeof(_names[0]) - 1] = '\0';
    _names[_level_to_flow[Warn]][sizeof(_names[0]) - 1] = '\0';
    _names[_level_to_flow[Notice]][sizeof(_names[0]) - 1] = '\0';
    _names[_level_to_flow[Trace]][sizeof(_names[0]) - 1] = '\0';
    _names[_level_to_flow[Debug]][sizeof(_names[0]) - 1] = '\0';

    //init self defined levels
    num_selfdef_level = conf.get_subconf_len("log");
    --num_selfdef_level;

    uint32_t selfdef_level;
    if(num_selfdef_level > 0) {
        for(uint32_t i = 1; i <= num_selfdef_level; ++i) {
            ret = conf.get_subconf_str("log", i, "filename", filename);
            XLIB_FAIL_HANDLE(false == ret);

            ret = conf.get_subconf_uint32("log", i, "level", selfdef_level,
                0, log_conf_s::MaxLogLevel);
            XLIB_FAIL_HANDLE(false == ret);

            ret = conf.get_subconf_str("log", i, "name", selfdef_level_name);
            XLIB_FAIL_HANDLE(false == ret);

            XLIB_FAIL_HANDLE_STDOUT(
                selfdef_level == Fatal || 
                selfdef_level == Warn ||
                selfdef_level == Notice || 
                selfdef_level == Trace ||
                selfdef_level == Debug, 
                "[xlib:log] invalid_self_def_log_level[%d]\n",selfdef_level);

            fp = fopen(filename.c_str(), "a");
            XLIB_FAIL_HANDLE_STDOUT(NULL == fp,
                "[xlib:log] fail_open[%s]\n", filename.c_str());

            _level_to_flow[selfdef_level] = level++;
            _flows[_level_to_flow[selfdef_level]] = fp;
            strncpy(_names[_level_to_flow[selfdef_level]], selfdef_level_name.c_str(), 
                sizeof(_names[0]));
            _names[_level_to_flow[selfdef_level]][sizeof(_names[0]) - 1] = '\0';
        }
    }
    return true;

    ERROR_HANDLE:
    return false;
}

}
