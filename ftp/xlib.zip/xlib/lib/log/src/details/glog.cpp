#include "../glog.h"

namespace xlib
{

log_t glog_s::glog;
bool glog_s::init_=false;

bool glog_s::init(const glog_s::string_t& path) { 
  if (true==init_) return true;

  bool ret = glog.init(path); 
  if (true==ret) init_=true;
  return ret;
}

}
