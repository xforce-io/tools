#include "lib/public/public.h"
#include "lib/conf/src/conf.h"
#include "../log.h"

namespace xlib 
{

static pid_t gettid() { return syscall(SYS_gettid); }

bool log_t::init(const string_t& path)
{
    uint64_t time_start;
    _tid = gettid();

    //handle conf
    conf_t conf;
    int ret = conf.init(path);
    XLIB_FAIL_HANDLE(false == ret);

    ret = conf.get_subconf_uint64(string_t("log"), 0, 
        string_t("init_mem_avail_per_thread"), _init_mem_avail_per_thread);
    XLIB_FAIL_HANDLE(false == ret);

    //init log_flows
    ret = _log_flows.init(conf);
    XLIB_FAIL_HANDLE(false == ret);

    //init _lock_log_slaves
    ret = pthread_rwlock_init(&_lock_log_slaves, NULL);
    XLIB_FAIL_HANDLE(0 != ret);

    //init _log_slaves
    log_slave_t* log_slave;
    XLIB_NEW(log_slave, log_slave_t(info_to_slave_t(_log_flows, 
        _init_mem_avail_per_thread)));

    ret = log_slave->init();
    XLIB_FAIL_HANDLE(false == ret);

    _log_slaves.insert(std::pair<pid_t, log_slave_t*>(gettid(), log_slave));

    //init _log_master
    XLIB_NEW(_log_master, log_master_t(info_to_master_t(_log_flows, 
        _log_slaves, _is_master_up, _end, _lock_log_slaves)));
    ret = _log_master->init();
    XLIB_FAIL_HANDLE(false == ret);

    ret = pthread_create(&_master_id, NULL, run_log_master, _log_master);
    XLIB_FAIL_HANDLE(0 != ret);

    time_start = pub::Time::GetCurrentUsec(true);
    while(false == _is_master_up) {
        uint64_t time_stop = pub::Time::GetCurrentUsec(true);
        XLIB_FAIL_HANDLE_STDOUT(time_stop > time_start+3000000,
            "fatal | master_log_thread_fail_to_start");
    }
    return true;

    ERROR_HANDLE:
    hash_map<pid_t, log_slave_t*>::iterator iter;
    for(iter = _log_slaves.begin(); iter != _log_slaves.end(); ++iter) {
        delete iter->second;
    }
    if(NULL != _log_master) delete _log_master;
    return false;
}

bool log_t::init_in_thread()
{
    printf("notice|[log] init_in_thread %d\n", gettid());
    int ret;
    log_slave_t *log_slave;

    XLIB_NEW(log_slave, log_slave_t(info_to_slave_t(_log_flows, 
        _init_mem_avail_per_thread)))

    ret = log_slave->init();
    XLIB_FAIL_HANDLE_STDOUT(true != ret,
        "fatal | fail_init_log_slave\n");

    ret = pthread_rwlock_wrlock(&_lock_log_slaves);
    XLIB_FAIL_HANDLE_STDOUT(0 != ret, 
        "fatal | fail_init_rwlock_in_log_thread\n");

    if(false == _end) {
        _log_slaves.insert(
            std::pair<pid_t, log_slave_t*>(gettid(), log_slave));
    }

    pthread_rwlock_unlock(&_lock_log_slaves);
    return true;

    ERROR_HANDLE:
    return false;
}

void log_t::log(uint32_t level, const char* fmt, ...)
{ 
    if (NULL == _log_flows.flow(level)) return;

    char log[log_conf_s::MaxLogSize];
    va_list list;
    va_start(list, fmt);
    const char *p, *p_old = fmt;
    char *dst = log;
    int len_fmt = strlen(fmt), len_tmp;
    int tmp_int32; uint32_t tmp_uint32; int64_t tmp_int64; 
    uint64_t tmp_uint64; char* tmp_str;
    int free_size = log_conf_s::MaxLogSize-1; //for '\0'
    do {
        p = strchr(p_old, '%');
        if(NULL == p) {
            int len_p_old = strlen(p_old);
            int len_copied = (len_p_old <= free_size ? len_p_old : free_size);
            memcpy(dst, p_old, len_copied);
            dst += len_copied;
            *dst = '\0';
            break;
        } else {
            if(free_size-(p-p_old) < 0) { p = fmt+len_fmt-1; continue; }

            free_size -= (p-p_old);
            memcpy(dst, p_old, p-p_old);
            dst += p-p_old;
        }

        switch(*(p+1)) {
            case 'd' :
                tmp_int32 = va_arg(list, int);
                free_size -= sizeof(tmp_int32);
                if(free_size < 0) { p = fmt+len_fmt; free_size=0; break; }
                p+=2;
                sprintf(dst, "%d", tmp_int32);
                do{ ++dst; }while('\0' != *dst);
                break;
            case 'u' :
                tmp_uint32 = va_arg(list, uint32_t);
                free_size -= sizeof(tmp_uint32);
                if(free_size < 0) { p = fmt+len_fmt; free_size=0; break; }
                p+=2;
                sprintf(dst, "%u", tmp_uint32);
                do{ ++dst; }while('\0' != *dst);
                break;
            case 'l' :
                if('d' == *(p+2)) {
                    tmp_int64 = va_arg(list, int64_t);
                    free_size -= sizeof(tmp_int64);
                    if(free_size < 0) { p = fmt+len_fmt-1; break; }
                    p+=3;
                    sprintf(dst, "%ld", tmp_int64);    
                    do{ ++dst; }while('\0' != *dst);
                    break;
                } else if('u' == *(p+2)) {
                    tmp_uint64 = va_arg(list, uint64_t);
                    free_size -= sizeof(tmp_uint64);
                    if(free_size < 0) { p = fmt+len_fmt-1; break; }
                    p+=3;
                    sprintf(dst, "%lu", tmp_uint64);
                    do{ ++dst; }while('\0' != *dst);
                    break;    
                } else {
                    --free_size;
                    if(free_size < 0) { p = fmt+len_fmt-1; break; }
                    ++p;
                    *dst++ = '%';
                    break;
               }
            case 's' :
                tmp_str = va_arg(list, char*);
                len_tmp = strlen(tmp_str);
                free_size -= len_tmp;
                if(free_size < 0) { p = fmt+len_fmt; free_size=0; break; }
                p+=2;
                strcpy(dst, tmp_str);
                dst += len_tmp;
                break;
            default :
                --free_size;
                if(free_size < 0) { p = fmt+len_fmt; free_size=0; break; }
                ++p;
                *dst++ = '%';
                break;
        }
        p_old = p;
    }while(true);

    hash_map<pid_t, log_slave_t*>::iterator iter =  
        _log_slaves.find(gettid()); 
    if(_log_slaves.end() == iter) {
        std::string level_str;
        switch(level) {
            case log_flows_t::Fatal: level_str = "fatal"; break;
            case log_flows_t::Warn: level_str = "warn"; break;
            case log_flows_t::Notice: level_str = "notice"; break;
            case log_flows_t::Trace: level_str = "trace"; break;
            case log_flows_t::Debug: level_str = "debug"; break;
            default : level_str = "other"; break;
        }
        printf("%6s|%s\n", level_str.c_str(), log);
        return;
    }
    iter->second->log(level, log);
}

void log_t::close()
{
    if (true==_end) return;

    hash_map<pid_t, log_slave_t*>::iterator iter =  
        _log_slaves.find(gettid()); 
    if(_log_slaves.end() == iter) return;
    iter->second->close();

    if(_tid == gettid()) {
        _end = true;
        pthread_join(_master_id, NULL);
        hash_map<pid_t, log_slave_t*>::iterator iter;
        for (iter = _log_slaves.begin(); iter != _log_slaves.end(); ++iter) {
          XLIB_DELETE(iter->second)
        }
        _log_slaves.clear();
        printf("notice|[log] main_thread_exit\n");
    } else {
        printf("notice|[log] thread[%d] exit\n", _tid);
    }
}

}
