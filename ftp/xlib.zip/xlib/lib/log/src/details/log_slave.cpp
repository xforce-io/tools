#include <stdarg.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <utility>
#include <linux/unistd.h>
#include <time.h>

#include "lib/public/public.h"
#include "../log_slave.h"

namespace xlib 
{

static pid_t gettid() { return syscall(SYS_gettid); }
static pid_t getpid() { return syscall(SYS_getpid); }

bool log_slave_t::init()
{
    _pid = getpid();
    _tid = gettid();

    XLIB_MALLOC(_log_item, log_item_t*, _header_size_log_item+log_conf_s::MaxLogSize)
    return true;
}

bool log_slave_t::log(uint32_t level, const char* log)
{
    if(NULL == _log_flows.flow(level)) return false;

    _log_item->level = level;
    _log_item->size_buf = log_conf_s::MaxLogSize;
    _format_log(level, _log_item->buf, _log_item->size_buf, log);

    bool ret = _msg_pipe.SendMsg(NoneType(), (char*)_log_item, _header_size_log_item+_log_item->size_buf);
    XLIB_FAIL_HANDLE_STDOUT(false == ret, "fatal |[log] slave_fail_send_msg\n");
    return true;

    ERROR_HANDLE:
    return false;
}

void log_slave_t::_format_log(uint32_t level, char* buf, uint64_t& size_buf, 
    const char* log)
{
    char time_buf[255];
    time_t current_time = pub::Time::GetCurrentSec(true);
    strftime(time_buf, sizeof(time_buf), "%Y%m%d-%H:%M:%S", localtime(&current_time));
    snprintf(
        buf, 
        size_buf, 
        "%6s|%s:%6lu|%6u*%6u|%s\n", 
        _log_flows.name(level), 
        time_buf, 
        pub::Time::GetCurrentSec(false), 
        _pid, 
        _tid, 
        log);
    buf[size_buf-2] = '\n';
    buf[size_buf-1] = '\0';
    uint64_t len_log = strlen(buf);
    size_buf = (len_log+1 <= log_conf_s::MaxLogSize) ? len_log+1 : log_conf_s::MaxLogSize;
}

log_slave_t::~log_slave_t() {
  XLIB_FREE(_log_item)
}

}
