#include <string.h>
#include <unistd.h>

#include "lib/public/public.h"
#include "../log_master.h"

namespace xlib {

void* run_log_master(void* arg)
{
//    printf("notice|[log] log_master_start\n");
    log_master_t* log_master = (log_master_t*)arg;
    log_master->run();
//    printf("notice|[log] log_master_stop\n");
    return NULL;
}

void log_master_t::run()
{
    int i = 0;
    bool ret;
    pub::Timer timer;
    timer.Start(true);
//    printf("[notice] log_master_run\n");
    _is_master_up = true;
    for(;;) {
        ++i;
        ret = _log();
        if(false == ret) return;

        timer.Stop(true);
        int64_t sleep_time_in_ms = i*LogInterval - timer.TimeMs();
        if(sleep_time_in_ms > 0) usleep(sleep_time_in_ms<<10);
    }
}

bool log_master_t::_log()
{
    hash_map<pid_t, log_slave_t*>::const_iterator iter;

    int ret = pthread_rwlock_rdlock(&_lock_log_slaves);
    if(0 != ret) {
        printf("[log] fail_init_rwlock_in_thread\n");
        return false;
    }

    bool round=false;
    for(iter = _log_slaves.begin(); iter != _log_slaves.end(); ++iter) {
        log_slave_t* log_slave = iter->second;
        log_slave_t::Pipe::Msg* msg = log_slave->msg_pipe().RecieveMsg();
        while(NULL != msg) {
            round=true; 
            _print_logs(*(log_item_t*)(msg->msg));
            log_slave->msg_pipe().MsgConsumed();
            msg = log_slave->msg_pipe().RecieveMsg();
        }

        _log_flows.flush(); 
    }

    pthread_rwlock_unlock(&_lock_log_slaves);

    if (false==round) {
      usleep(1000);
    }

    if(true == _end) { 
//        printf("notice|[log] master_try_close\n");
        while(false == _try_close()) ; 
        return false;
    }
    return true;
}

bool log_master_t::_try_close()
{
    hash_map<pid_t, log_slave_t*>::const_iterator iter;

    int ret = pthread_rwlock_rdlock(&_lock_log_slaves);
    XLIB_FAIL_HANDLE_STDOUT(0 != ret, "fatal |[log] fail_init_rwlock_in_thread\n");

    for(iter = _log_slaves.begin(); iter != _log_slaves.end(); ++iter) {
        log_slave_t* log_slave = iter->second;
        log_slave_t::Pipe::Msg* msg = log_slave->msg_pipe().RecieveMsg();
        while(NULL != msg) {
            _print_logs(*(log_item_t*)(msg->msg));
            log_slave->msg_pipe().MsgConsumed();
            msg = log_slave->msg_pipe().RecieveMsg();
        }

        XLIB_FAIL_HANDLE(true != log_slave->is_closed());
    }

    pthread_rwlock_unlock(&_lock_log_slaves);
    _log_flows.close();
    return true;

    ERROR_HANDLE:
    pthread_rwlock_unlock(&_lock_log_slaves);
    return false;
}

}
