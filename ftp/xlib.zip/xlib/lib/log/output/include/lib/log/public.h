#ifndef PUBLIC_LOG_PUBLIC_H
#define PUBLIC_LOG_PUBLIC_H

#include "lib/public/public.h"

namespace xlib 
{

class log_conf_s
{
    public:
    static const uint32_t MaxLogSize = (1 << 12);
    static const uint32_t DefaultNumThread = 50;
    static const uint32_t MaxFlowSize = 10;
    static const uint32_t MaxLogLevel = 100;
};

struct log_item_t
{
    uint32_t level;
    uint64_t size_buf;
    char buf[1];
};

}

#endif
