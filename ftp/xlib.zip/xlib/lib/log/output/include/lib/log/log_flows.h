#ifndef PUBLIC_LOG_LOG_FLOWS_H
#define PUBLIC_LOG_LOG_FLOWS_H

#include <stdio.h>
#include "lib/conf/src/conf.h"
#include "public.h"

namespace xlib 
{

class log_flows_t
{
    public:
    typedef std::string string_t;

    public:
    static const int MaxLenLevelName = 10;

    public:
    enum log_level_t {
        Fatal = 1,
        Warn = 2,
        Notice = 4,
        Trace = 8,
        Debug = 16,
    };

    public:
    bool init(const conf_t& conf);

    FILE* flow(uint32_t level) const { return _flows[_level_to_flow[level]]; }

    const char* name(uint32_t level) const { return _names[_level_to_flow[level]]; }

    inline void flush() const;

    inline void close();

    private:
    uint32_t _level_to_flow[log_conf_s::MaxLogLevel];
    FILE* _flows[log_conf_s::MaxFlowSize];
    char _names[log_conf_s::MaxFlowSize][MaxLenLevelName];
};

void log_flows_t::flush() const
{
    for(uint32_t i = 0; i < sizeof(_flows)/sizeof(_flows[0]); ++i) {
        if(NULL != _flows[i]) fflush(_flows[i]);
    }
}

void log_flows_t::close()
{
    _flows[_level_to_flow[Warn]] = NULL;
    _flows[_level_to_flow[Debug]] = NULL;
    for(uint32_t i = 0; i < sizeof(_flows)/sizeof(_flows[0]); ++i) {
        if(NULL != _flows[i]) fclose(_flows[i]);
    }
}

}

#endif
