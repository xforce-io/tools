#ifndef PUBLIC_LOG_LOG_H
#define PUBLIC_LOG_LOG_H

#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <ext/hash_map>
#include <pthread.h>
#include <sys/syscall.h>
#include <linux/unistd.h>

#include "public.h"
#include "log_master.h"
#include "log_slave.h"

using namespace __gnu_cxx;

namespace xlib 
{

class log_t
{
    public:
    typedef std::string string_t;

    public:
    explicit log_t() : 
        _log_master(NULL), _is_master_up(false), _end(false) {}

    bool init(const string_t& path);

    bool init_in_thread();

    void log(uint32_t level, const char* fmt, ...); 

    void close();

    virtual ~log_t() { close(); }

    private:
    uint64_t _init_mem_avail_per_thread;

    log_flows_t _log_flows;

    hash_map<pid_t, log_slave_t*> _log_slaves;
    log_master_t* _log_master;

    pid_t _tid;
    pthread_t _master_id;

    bool _is_master_up;
    bool _end;

    pthread_rwlock_t _lock_log_slaves;
};

}

#endif
