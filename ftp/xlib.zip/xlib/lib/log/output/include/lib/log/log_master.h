#ifndef PUBLIC_LOG_LOG_MASTER_H
#define PUBLIC_LOG_LOG_MASTER_H

#include <ext/hash_map>
#include "lib/conf/src/conf.h"
#include "public.h"
#include "log_slave.h"
#include "log_flows.h"

using namespace __gnu_cxx;

namespace xlib 
{

struct info_to_master_t
{
    explicit info_to_master_t(
        log_flows_t& log_flows_arg,
        const hash_map<pid_t, log_slave_t*>& log_slaves_arg,
        bool& is_master_up_arg,
        const bool& end_arg,
        pthread_rwlock_t& lock_log_slaves_arg) : 
        log_flows(log_flows_arg),
        log_slaves(log_slaves_arg),
        is_master_up(is_master_up_arg),
        end(end_arg),
        lock_log_slaves(lock_log_slaves_arg) {}

    log_flows_t& log_flows;
    const hash_map<pid_t, log_slave_t*>& log_slaves;
    bool& is_master_up;
    const bool& end;
    pthread_rwlock_t& lock_log_slaves;
};

class log_master_t
{
    public:
    typedef std::string string_t;

    public:
    static const uint64_t LogInterval = 0; //ms

    public:
    explicit log_master_t(info_to_master_t info_to_master) : 
        _log_flows(info_to_master.log_flows), 
        _log_slaves(info_to_master.log_slaves), 
        _is_master_up(info_to_master.is_master_up),
        _end(info_to_master.end),
        _lock_log_slaves(info_to_master.lock_log_slaves) {}

    bool init() { return true; }

    void run();

    private:
    bool _log();

    inline void _print_logs(const log_item_t& log);

    bool _try_close();

    private:
    log_flows_t& _log_flows;
    const hash_map<pid_t, log_slave_t*>& _log_slaves;
    bool& _is_master_up;
    const bool& _end;
    pthread_rwlock_t& _lock_log_slaves;
};

void* run_log_master(void* arg);

void log_master_t::_print_logs(const log_item_t& log)
{
    fwrite(log.buf, strlen(log.buf), 1, _log_flows.flow(log.level));
}

}

#endif
