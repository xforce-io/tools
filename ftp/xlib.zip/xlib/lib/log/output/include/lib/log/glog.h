#ifndef PUBLIC_LOG_GLOG_H
#define PUBLIC_LOG_GLOG_H

#include "lib/public/public.h"
#include "log.h"
#include "log_flows.h"

#define FATAL(fmt, arg...) \
    xlib::glog_s::glog.log(xlib::log_flows_t::Fatal, "%s:%d | " fmt, __FILE__, __LINE__, ##arg);

#define WARN(fmt, arg...) \
    xlib::glog_s::glog.log(xlib::log_flows_t::Warn, "%s:%d | " fmt, __FILE__, __LINE__, ##arg);

#define NOTICE(fmt, arg...) \
    xlib::glog_s::glog.log(xlib::log_flows_t::Notice, "%s:%d | " fmt, __FILE__, __LINE__, ##arg);

#define TRACE(fmt, arg...) \
    xlib::glog_s::glog.log(xlib::log_flows_t::Trace, "%s:%d | " fmt, __FILE__, __LINE__, ##arg);

#define DEBUG(fmt, arg...) \
    xlib::glog_s::glog.log(xlib::log_flows_t::Debug, "%s:%d | " fmt, __FILE__, __LINE__, ##arg);

#define XLIB_FAIL_HANDLE_FATAL(op, fmt, arg...) \
  if(op) { \
      FATAL(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_WARN(op, fmt, arg...) \
  if(op) { \
      WARN(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_NOTICE(op, fmt, arg...) \
  if(op) { \
      NOTICE(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_TRACE(op, fmt, arg...) \
  if(op) { \
      TRACE(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_DEBUG(op, fmt, arg...) \
  if(op) { \
      DEBUG(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_FATAL_AND_SET(op, set, fmt, arg...) \
  if(op) { \
      set; \
      FATAL(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FAIL_HANDLE_WARN_AND_SET(op, set, fmt, arg...) \
  if(op) { \
      set; \
      WARN(fmt, ##arg); \
      goto ERROR_HANDLE; \
  } \

#define XLIB_FATAL_AND_CONTINUE(op, fmt, arg...) \
  if(op) { \
      FATAL(fmt, ##arg); \
      continue; \
  } \

#define XLIB_WARN_AND_CONTINUE(op, fmt, arg...) \
  if(op) { \
      WARN(fmt, ##arg); \
      continue; \
  } \

#define XLIB_NOTICE_AND_CONTINUE(op, fmt, arg...) \
  if(op) { \
      NOTICE(fmt, ##arg); \
      continue; \
  } \

#define XLIB_TRACE_AND_CONTINUE(op, fmt, arg...) \
  if(op) { \
      TRACE(fmt, ##arg); \
      continue; \
  } \

#define XLIB_DEBUG_AND_CONTINUE(op, fmt, arg...) \
  if(op) { \
      DEBUG(fmt, ##arg); \
      continue; \
  } \

#define XLIB_NEW_FATAL(member, type) \
  (member) = ::new (std::nothrow) (type); \
  XLIB_FAIL_HANDLE_FATAL(NULL==(member), "fail_to_new") \

#define XLIB_MALLOC_FATAL(member, type, size) \
  (member) = reinterpret_cast<type>(::malloc(size)); \
  XLIB_FAIL_HANDLE_FATAL(NULL==(member), "fail_to_malloc") \

#define XLIB_REALLOC_FATAL(new_member, old_member, type, size) \
  (new_member) = reinterpret_cast<typer>(::realloc((old_member), (size))); \
  XLIB_FAIL_HANDLE_FATAL(NULL==(new_member), "fail_to_realloc") \

namespace xlib
{

class glog_s
{
    public:
    typedef std::string string_t;

    public:
    static bool init(const glog_s::string_t& path);
    static bool init_in_thread() { return glog.init_in_thread(); }
    static void close() { glog.close(); }

    public:
    static log_t glog;

    private:
    static bool init_;
};

}

#endif
