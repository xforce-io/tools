#ifndef PUBLIC_LOG_LOG_SLAVE_H
#define PUBLIC_LOG_LOG_SLAVE_H

#include "public.h"
#include "log_flows.h"

namespace xlib 
{

struct info_to_slave_t
{
    explicit info_to_slave_t(
        const log_flows_t& log_flows_arg,
        uint64_t max_mem_avail_per_thread_arg) :
        log_flows(log_flows_arg),
        max_mem_avail_per_thread(max_mem_avail_per_thread_arg) {}
        
    const log_flows_t& log_flows;
    const uint64_t max_mem_avail_per_thread;
};

class log_slave_t
{
    public:
    typedef pub::FixedMsgPipe<NoneType> Pipe;

    public:
    explicit log_slave_t(info_to_slave_t info_to_slave) : 
        _log_flows(info_to_slave.log_flows),
        _msg_pipe(info_to_slave.max_mem_avail_per_thread),
        _max_mem_avail(info_to_slave.max_mem_avail_per_thread),
        _log_item(NULL),
        _header_size_log_item((char*)&(((log_item_t*)0)->buf) - 
            (char*)&(((log_item_t*)0)->level)),
        _closed(false) {}

    bool init();

    bool log(uint32_t level, const char* log);

    pub::FixedMsgPipe<NoneType>& msg_pipe() { return _msg_pipe; }

    void close() { _closed = true; }

    bool is_closed() const { return _closed; }

    virtual ~log_slave_t(); 

    private:
    void _format_log(uint32_t level, char* buf, 
        uint64_t& size_buf, const char* log);

    private:
    pid_t _pid;
    pid_t _tid;

    const log_flows_t& _log_flows;
    Pipe _msg_pipe;
    const uint64_t _max_mem_avail;

    log_item_t* _log_item;

    const uint64_t _header_size_log_item;

    bool _closed;
};

}

#endif
