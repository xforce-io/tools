#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "../conf.h"

namespace xlib
{

conf_t::string_t conf_t::DefaultStr = "0";
conf_t::string_t conf_t::DefaultTopic = "global";

bool conf_t::init(const string_t &path)
{
    FILE* fp = fopen(path.c_str(), "r");
    if(NULL == fp) {
        printf("fatal:conf| error_open[%s]\n", path.c_str());
        return false;
    }

    //init _confs
    string_t current_topic = DefaultTopic;
    uint32_t current_seq = 0;

    conf_items_vec_t* conf_items_vec = new (std::nothrow) conf_items_vec_t;
    if(false == conf_items_vec) {
        printf("fatal:conf| error_in_new\n");
        return false;
    }
    conf_items_vec->reserve(1);
    conf_items_vec->push_back(conf_items_t());
    _confs.insert(std::pair<string_t, conf_items_vec_t*>(current_topic, conf_items_vec));

    char char_note = '#';
    for(;;) {
        char* line = fgets(_buf, MaxLenConfLine, fp);
        if(NULL == line) {
            fclose(fp);
            _init = true;
            return true;
        }

        //remove note part
        char* note = strchr(_buf, char_note);
        if(NULL != note) *note = '\0';

        //if this line is a topic, modify item in _confs
        if('[' == _buf[0]) {
            char* rigth_bracket = strchr(_buf, ']');
            if(NULL != rigth_bracket && ']' != _buf[1]) {
                string_t old_topic = current_topic;
                current_topic = string_t(_buf+1, rigth_bracket-_buf-1);
                if(current_topic != old_topic) {
                    current_seq = 0;
                    conf_items_vec_t* conf_items_vec = 
                        new (std::nothrow) conf_items_vec_t;
                    if(false == conf_items_vec) {
                        printf("fatal:conf| error_in_new\n");
                        return false;
                    }
                    conf_items_vec->reserve(DefaultNumSubconf);
                    conf_items_vec->push_back(conf_items_t());
                    _confs.insert(std::pair<string_t, conf_items_vec_t*>
                        (current_topic, conf_items_vec));
                } else {
                    if(DefaultTopic == current_topic) continue;

                    conf_items_vec_t *conf_items_vec = _confs.find(current_topic)->second;
                    conf_items_vec->reserve(++current_seq);
                    conf_items_vec->push_back(conf_items_t());
                }
            }
            continue;
        }

        //extract key/value
        char* key = _buf;
        char* val = strchr(key, ':');
        uint32_t len_buf = strlen(_buf);
        if(NULL == val || '\0' == *(++val)) continue;

        key = _extract_item(_buf, 0, val-_buf-1);
        if(NULL == key) continue;

        val = _extract_item(_buf, val-_buf, len_buf-1);
        if(NULL == val) continue;

        //insert conf into _confs
        conf_items_vec_t* conf_items_vec = _confs.find(current_topic)->second;
        (*conf_items_vec)[current_seq].insert(conf_pair_t(key, val));
    }
}

bool conf_t::get_int64(
    string_t key, 
    int64_t& val, 
    int64_t min, 
    int64_t max,
    bool use_dflt, 
    int64_t dflt) const
{
    return get_subconf_int64(DefaultTopic, 0, key, val, min, max, use_dflt, dflt);
}

bool conf_t::get_uint64(
    string_t key, 
    uint64_t& val, 
    uint64_t min,
    uint64_t max,
    bool use_dflt, 
    uint64_t dflt) const
{
    return get_subconf_uint64(DefaultTopic, 0, key, val, min, max, use_dflt, dflt);
}

bool conf_t::get_int32(
    string_t key, 
    int32_t& val, 
    int32_t min, 
    int32_t max,
    bool use_dflt, 
    int32_t dflt) const
{
    return get_subconf_int32(DefaultTopic, 0, key, val, min, max, use_dflt, dflt);
}

bool conf_t::get_uint32(
    string_t key, 
    uint32_t& val, 
    uint32_t min,
    uint32_t max,
    bool use_dflt, 
    uint32_t dflt) const
{
    return get_subconf_uint32(DefaultTopic, 0, key, val, min, max, use_dflt, dflt);
}

bool conf_t::get_str(
    string_t key, 
    string_t& val, 
    bool use_dflt, 
    const string_t& dflt) const
{
    return get_subconf_str(DefaultTopic, 0, key, val, use_dflt, dflt);
}

uint32_t conf_t::get_subconf_len(const string_t& topic) const
{
    if(false == _init) return false;

    std::map<string_t, conf_items_vec_t*>::const_iterator iter = _confs.find(topic);
    return _confs.end() == iter ? 0 : iter->second->size();
}

bool conf_t::get_subconf_int64(
    string_t topic, 
    uint32_t seq, 
    string_t key, 
    int64_t& val, 
    int64_t min,
    int64_t max,
    bool use_dflt, 
    int64_t dflt) const
{
    if(false == _init) return false;

    std::map<string_t, conf_items_vec_t*>::const_iterator iter = _confs.find(topic);
    if(_confs.end() == iter || seq >= iter->second->size()) {
        printf("fatal:conf| no_topic[%s]\n", topic.c_str());
        return false;
    } else {
        conf_items_t conf_items = (*(iter->second))[seq];
        conf_items_t::iterator iter_conf_items = conf_items.find(key);
        if(conf_items.end() != iter_conf_items) {
            char* endptr;
            val = strtol(iter_conf_items->second.c_str(), &endptr, 10);
            if('\0' != *endptr || LONG_MAX == val || LONG_MIN == val ) {
                printf("fatal:conf| invalid_conf[%s:%s] val_should_be_int64\n",
                    key.c_str(), iter_conf_items->second.c_str());
                return false;
            }
        } else {
            if(true == use_dflt) {
                val = dflt;
            } else {
                printf("fatal:conf| no_conf[%s]\n", key.c_str());
                return false;
            }
        }
    }

    if(val > max || val < min) {
        printf("fatal:conf| invalid_conf[%s:%ld] val_should_be[%ld-%ld]\n",
            key.c_str(), val, min, max);
        return false;
    }
    return true;
}

bool conf_t::get_subconf_uint64(
    string_t topic, 
    uint32_t seq, 
    string_t key, 
    uint64_t& val, 
    uint64_t min,
    uint64_t max,
    bool use_dflt, 
    uint64_t dflt) const
{
    int64_t tmp;
    bool ret = get_subconf_int64(
        topic, 
        seq, 
        key, 
        tmp, 
        static_cast<int64_t>(min <= static_cast<uint64_t>(MaxInt64) ? min : MaxInt64), 
        static_cast<int64_t>(max),
        use_dflt, 
        static_cast<int64_t>(dflt <= static_cast<uint64_t>(MaxInt64) ? dflt : MaxInt64));
    val = static_cast<uint64_t>(tmp);
    return ret;
}

bool conf_t::get_subconf_int32(
    string_t topic, 
    uint32_t seq, 
    string_t key, 
    int32_t& val, 
    int32_t min,
    int32_t max,
    bool use_dflt, 
    int32_t dflt) const
{
    int64_t tmp;
    bool ret = get_subconf_int64(
        topic, 
        seq, 
        key, 
        tmp, 
        static_cast<int64_t>(min), 
        static_cast<int64_t>(max), 
        use_dflt, 
        static_cast<int64_t>(dflt));
    val = static_cast<int32_t>(tmp);
    return ret;
}

bool conf_t::get_subconf_uint32(
    string_t topic, 
    uint32_t seq, 
    string_t key, 
    uint32_t& val, 
    uint32_t min,
    uint32_t max,
    bool use_dflt, 
    uint32_t dflt) const
{
    int64_t tmp;
    bool ret = get_subconf_int64(
        topic, 
        seq, 
        key, 
        tmp, 
        static_cast<int64_t>(min), 
        static_cast<int64_t>(max), 
        use_dflt, 
        static_cast<int64_t>(dflt));
    val = static_cast<uint32_t>(tmp);
    return ret;
}

bool conf_t::get_subconf_str(
    string_t topic, 
    uint32_t seq, 
    string_t key, 
    string_t& val, 
    bool use_dflt, 
    const string_t& dflt) const
{
    if(false == _init) return false;

    std::map<string_t, conf_items_vec_t*>::const_iterator iter = 
        _confs.find(topic);
    if(_confs.end() == iter || seq >= iter->second->size()) {
        printf("fatal:conf| no_topic[%s]\n", topic.c_str());
        return false;
    }

    conf_items_t conf_items = (*(iter->second))[seq];
    conf_items_t::const_iterator iter_conf_items = conf_items.find(key);
    if(conf_items.end() != iter_conf_items) {
        val = iter_conf_items->second;
    } else {
        if(true == use_dflt) {
            val = dflt;
        } else {
            printf("fatal:conf| no_conf[%s:%d:%s]\n", 
                topic.c_str(), seq, key.c_str());
            return false;
        }
    }
    return true;
}

conf_t::~conf_t() {
  for (Confs::iterator iter = _confs.begin(); iter != _confs.end(); ++iter) {
    delete iter->second; 
  }
}

char* conf_t::_extract_item(char* buf, int start, int end)
{
    const char* char_tobe_ignored = "\r\n\t ";
    const int len_char_tobe_ignored = strlen(char_tobe_ignored);

    char* head = buf+start;
    while(*head != '\0') {
        int i;
        for(i = 0; i < len_char_tobe_ignored; ++i) {
            if(*(char_tobe_ignored+i) == *head) break;
        }

        if(i == len_char_tobe_ignored) break;
        ++head;
    }

    char* tail = buf+end;
    while(tail-1 > head) {
        int i;
        for(i = 0; i < len_char_tobe_ignored; ++i) {
            if(*(char_tobe_ignored+i) == *(tail-1)) break;
        }

        if(i == len_char_tobe_ignored) break;
        --tail;
    }

    if(tail <= head) return NULL;

    *tail = '\0';
    return head;
}

}
