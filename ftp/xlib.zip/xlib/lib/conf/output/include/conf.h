#ifndef PUBLIC_CONF_H
#define PUBLIC_CONF_H

#include <string>
#include <map>
#include <vector>

#include "lib/public/public.h"

namespace xlib
{

class conf_t
{
    public:
    typedef std::string string_t;
    typedef std::pair<string_t, string_t> conf_pair_t;
    typedef std::map<string_t, string_t> conf_items_t;
    typedef std::vector<conf_items_t> conf_items_vec_t;
    typedef std::map<string_t, conf_items_vec_t*> Confs;

    public:
    static const  int     MaxLenConfLine = 1024;
    static const  int64_t MinInt64 = ((int64_t)1<<63);
    static const  int64_t MaxInt64 = ((int64_t)1<<62)-1+((int64_t)1<<62);
    static const uint64_t MaxUint64 = ((int64_t)1<<62)-1+((int64_t)1<<62);
    static const  int32_t MinInt32 = ((int64_t)1<<31);
    static const  int32_t MaxInt32 = ((int64_t)1<<31)-1;
    static const uint32_t MaxUint32 = ((int64_t)1<<32)-1;
    static const  int DefaultNumSubconf = 10;
    static string_t DefaultStr;
    static string_t DefaultTopic;

    public:
    conf_t() : _init(false) {}

    bool init(const string_t& path);

    bool get_int64(
        IN string_t key, 
        OUT int64_t& val, 
        IN int64_t min=MinInt64, 
        IN int64_t max=MaxInt64,
        IN bool use_dflt=false, 
        IN int64_t dflt=0) const;

    bool get_uint64(
        IN string_t key, 
        OUT uint64_t& val, 
        IN uint64_t min=0,
        IN uint64_t max=MaxUint64,
        IN bool use_dflt=false, 
        IN uint64_t dflt=0) const;

    bool get_int32(
        IN string_t key, 
        OUT int32_t& val, 
        IN int32_t min=MinInt32, 
        IN int32_t max=MaxInt32,
        IN bool use_dflt=false, 
        IN int32_t dflt=0) const;

    bool get_uint32(
        IN string_t key, 
        OUT uint32_t& val, 
        IN uint32_t min=0,
        IN uint32_t max=MaxUint32,
        IN bool use_dflt=false, 
        IN uint32_t dflt=0) const;

    bool get_str(
        IN string_t key, 
        OUT string_t& val, 
        IN bool use_dflt=false, 
        IN const string_t& dflt=DefaultStr) const;

    uint32_t get_subconf_len(const string_t& topic) const;

    bool get_subconf_int64(
        IN string_t topic, 
        IN uint32_t seq, 
        IN string_t key, 
        OUT int64_t& val, 
        IN int64_t min=MinInt64,
        IN int64_t max=MaxInt64,
        IN bool use_dflt=false, 
        IN int64_t dflt=0) const;

    bool get_subconf_uint64(
        IN string_t topic, 
        IN uint32_t seq,
        IN string_t key,
        OUT uint64_t& val, 
        IN uint64_t min=0,
        IN uint64_t max=MaxUint64,
        IN bool use_dflt=false, 
        IN uint64_t dflt=0) const;

    bool get_subconf_int32(
        IN string_t topic, 
        IN uint32_t seq, 
        IN string_t key, 
        OUT int32_t& val, 
        IN int32_t min=MinInt32,
        IN int32_t max=MaxInt32,
        IN bool use_dflt=false, 
        IN int32_t dflt=0) const;

    bool get_subconf_uint32(
        IN string_t topic, 
        IN uint32_t seq, 
        IN string_t key, 
        OUT uint32_t& val, 
        IN uint32_t min=0,
        IN uint32_t max=MaxUint32,
        IN bool use_dflt=false, 
        IN uint32_t dflt=0) const;

    bool get_subconf_str(
        IN string_t topic, 
        IN uint32_t seq, 
        IN string_t key, 
        OUT string_t& val, 
        IN bool use_dflt=false, 
        IN const string_t& dflt=DefaultStr) const;

    virtual ~conf_t();

    private:
    /*
     * @brief : ignore the continuous negligible chars(\r\n\t' ')
     *          at the head and tail of buf, then return the pointer to 
     *          the head of remaining part and set '\0' to the tail
     * @return : if the rest part has length at least 1, 
     *           return the pointer, otherwise NULL
     */
    static char* _extract_item(char* buf, int start, int end);

    private:
    bool _init;
    Confs _confs;
    char _buf[MaxLenConfLine];
};

}

#endif
