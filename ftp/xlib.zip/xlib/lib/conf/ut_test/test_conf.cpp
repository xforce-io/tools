#include "gtest/gtest.h"
#include "../src/details/conf.cpp"

using xlib::conf_t;

int main(int argc, char** argv)
{
    system("mkdir -p data");

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_conf : public ::testing::Test
{
    protected:
    virtual ~test_conf(){};
    virtual void SetUp() {};
    virtual void TearDown() 
    {
        system("rm -rf data/*");
    };
};

TEST_F(test_conf, init_extract_item)
{
    char buf[100];
    char* p; 
    int ret;

    strcpy(buf, "\r\n as \n\n:");
    p = conf_t::_extract_item(buf, 0, strlen(buf)-1);
    ASSERT_TRUE(NULL != p);
    ret = strcmp(p, "as");
    ASSERT_EQ(0, ret);

    strcpy(buf, " \t\n bs \n\n");
    p = conf_t::_extract_item(buf, 0, strlen(buf)-1);
    ASSERT_TRUE(NULL != p);
    ret = strcmp(p, "bs");
    ASSERT_EQ(0, ret);
}

TEST_F(test_conf, init_positive)
{
    system("echo '[global]\n"
        "\r key\t : \tval \n\n"
        "[addr] \n"
        "\tip : \r127.0.0.1\n\n"
        "[addr]\n"
        " ip : \r127.0.0.2 \t\r\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    conf_t::conf_items_vec_t* conf_items_vec = conf._confs.find("global")->second;
    ASSERT_EQ(1, conf_items_vec->size());
    ASSERT_EQ("val", (*conf_items_vec)[0].find("key")->second);

    conf_items_vec = conf._confs.find("addr")->second;
    ASSERT_EQ(2, conf_items_vec->size());
    ASSERT_EQ("127.0.0.1", (*conf_items_vec)[0].find("ip")->second);
    ASSERT_EQ("127.0.0.2", (*conf_items_vec)[1].find("ip")->second);
}

TEST_F(test_conf, init_passive)
{
    system("rm -rf data/sample_conf");
    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(false, ret);
}

TEST_F(test_conf, get_int64_positive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        " ip : \r127.0.0.2 \t\r\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    int64_t val;
    ret = conf.get_int64("int", val);
    ASSERT_EQ(true, ret);
    ASSERT_EQ(123, val);

    ret = conf.get_int64("int_none", val, 1, 3, true, 2);
    ASSERT_EQ(true, ret);
    ASSERT_EQ(2, val);
}

TEST_F(test_conf, get_int64_passive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        " ip : \r127.0.0.2 \t\r\n"
        " sam:' > data/sample_conf");

    conf_t conf;
    bool ret;
    int64_t val;
    ret = conf.get_int64("int", val);
    ASSERT_EQ(false, ret);

    conf_t conf_2;
    ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);
    ret = conf_2.get_int64("int", val, 1, 3);
    ASSERT_EQ(false, ret);
    ret = conf_2.get_int64("int_none", val, 1, 3);
    ASSERT_EQ(false, ret);
    ret = conf_2.get_int64("int_none", val, 1, 3, true, 4);
    ASSERT_EQ(false, ret);
    ret = conf_2.get_int64("sam", val);
    ASSERT_EQ(false, ret);
}

TEST_F(test_conf, get_subconf_int64_positive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        "[addr] \n"
        "\tip : \r127.0.0.1\n \r port : \r 1000\n"
        "[addr]\n"
        " ip : \r127.0.0.2 \t\r\n port : \r 2000\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    int64_t val;
    ret = conf.get_subconf_int64("addr", 1, "port", val);
    ASSERT_EQ(true, ret);
    ASSERT_EQ(2000, val);

    ret = conf.get_subconf_int64("addr", 0, "port_none", val, 1000, 4000, true, 3000);
    ASSERT_EQ(true, ret);
    ASSERT_EQ(3000, val);
}

TEST_F(test_conf, get_subconf_int64_passive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        "[addr] \n"
        "\tip : \r127.0.0.1\n"
        " \r port : \r 1000\n"
        "sam : \n"
        "[addr]\n"
        " ip : \r127.0.0.2 \t\r\n"
        " port : \r 2000\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    int len = conf.get_subconf_len("addr");
    ASSERT_EQ(2, len);

    int64_t val;
    ret = conf.get_subconf_int64("addr_none", 0, "port", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_int64("addr", 2, "port", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_int64("addr", 1, "port", val, 2001, 2003);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_int64("addr", 1, "port_none", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_int64("addr", 1, "port_none", val, 1, 3, true, 0);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_int64("addr", 0, "sam", val);
    ASSERT_EQ(false, ret);
}

TEST_F(test_conf, get_str_positive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        " ip : \r127.0.0.2 \t\r\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    conf_t::string_t val;
    ret = conf.get_str("int", val);
    ASSERT_EQ(true, ret);
    ASSERT_EQ("123", val);

    ret = conf.get_str("int_none", val, true, "2");
    ASSERT_EQ(true, ret);
    ASSERT_EQ("2", val);
}

TEST_F(test_conf, get_str_passive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : \r\n\n"
        " ip : \r127.0.0.2 \t\r\n' > data/sample_conf");

    conf_t conf;
    bool ret;
    conf_t::string_t val;
    ret = conf.get_str("int", val);
    ASSERT_EQ(false, ret);

    conf_t conf_2;
    ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);
    ret = conf_2.get_str("int", val);
    ASSERT_EQ(false, ret);
    ret = conf_2.get_str("int_none", val);
    ASSERT_EQ(false, ret);
}

TEST_F(test_conf, get_subconf_str_positive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        "[addr] \n"
        "\tip : \r127.0.0.1\n \r port : \r 1000\n"
        "[addr]\n"
        " ip : \r127.0.0.2 \t\r\n port : \r 2000\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    conf_t::string_t val;
    ret = conf.get_subconf_str("addr", 1, "port", val);
    ASSERT_EQ(true, ret);
    ASSERT_EQ("2000", val);

    ret = conf.get_subconf_str("addr", 0, "port_none", val, true, "3000");
    ASSERT_EQ(true, ret);
    ASSERT_EQ("3000", val);
}

TEST_F(test_conf, get_subconf_str_passive)
{
    system("echo '\r key\t : \tval \n"
        " \tint : 123\r\n\n"
        "[addr] \n"
        "\tip : \r127.0.0.1\n \r port : \r 1000\n"
        "[addr]\n"
        "int :\n"
        " ip : \r127.0.0.2 \t\r\n port : \r 2000\n' > data/sample_conf");

    conf_t conf;
    bool ret = conf.init("data/sample_conf");
    ASSERT_EQ(true, ret);

    conf_t::string_t val;
    ret = conf.get_subconf_str("addr_none", 1, "port", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_str("addr", 2, "port", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_str("addr", 0, "port_none", val);
    ASSERT_EQ(false, ret);
    ret = conf.get_subconf_str("addr", 1, "int", val);
    ASSERT_EQ(false, ret);
}
