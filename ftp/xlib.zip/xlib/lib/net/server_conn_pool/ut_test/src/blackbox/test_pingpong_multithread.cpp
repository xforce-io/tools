#include <assert.h>
#include <gtest/gtest.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../../../../server_conn_pool/src/server_conn_pool.h"
#include "public/basic/time.h"

using namespace xlib;
using namespace net;

static const std::string kAddr="127.0.0.1";
static const uint16_t kPort=12321;
static const size_t kTimeTests=20000;
static const size_t kNumConn=20;
static const int kNumServers = 1;
static const int kNumClients = 50;

static bool end=false;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_multithread: public ::testing::Test
{
 protected:
  virtual ~test_multithread() {};
  virtual void SetUp() 
  {
    bool ret = glog_s::init("conf/log.conf");
    ASSERT_TRUE(ret==true);
  }

  virtual void TearDown() { }
};

void* client_thread(void*)
{
  glog_s::init_in_thread();
  std::list<int> conns;
  int sockfd;
  for (size_t i=0; i<kTimeTests; ++i) {
    if (0 == conns.size()) {
      WARN("connect");
      struct sockaddr_in servaddr;
      sockfd=socket(AF_INET,SOCK_STREAM,0);
      if(sockfd<0){
        printf("Socket created failed!\n");
        return NULL;
      }

      servaddr.sin_family=AF_INET;
      servaddr.sin_port=htons(kPort);
      servaddr.sin_addr.s_addr=inet_addr(kAddr.c_str());
      if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0){
        printf("Connect server failed! %s\n", strerror(errno));
        return NULL;
      }
      conns.push_back(sockfd);
    }

    sockfd = conns.front();
    conns.pop_front();

//    DEBUG("client_start_write %d", i);
    write(sockfd, &i, sizeof(i));

    xlib::timer_t timer;
    timer.start();

//    DEBUG("client_start_read");
    size_t buf;
    int bytes_read = read(sockfd, &buf, sizeof(buf));
    if (-1 == bytes_read) {
      WARN("sockfd[%d] bytes_read[%d]", sockfd, bytes_read)
      continue;
    } else {
      assert(bytes_read == sizeof(buf));
      assert(i==buf);
    }

    timer.stop();
    TRACE("client_cost[%ld] [%lu]", timer.time_us(), i);

    conns.push_back(sockfd);
  }
  printf("client_complete\n");
  glog_s::close();
  return NULL;
}

void* server(void* arg)
{
  glog_s::init_in_thread();
  ServerConnPool* server_conn_pool = (ServerConnPool*)arg;
  for (size_t i=0; i<kTimeTests*kNumClients; ++i) {
    int fd = server_conn_pool->FetchSocket(1);
    if (true==end) break;

    //assert(fd>0);
    if (fd<=0) {
      --i;
      continue;
    }

    xlib::timer_t timer;
    timer.start();

//    DEBUG("server_start_read");
    size_t buf;
    int bytes_read = read(fd, &buf, sizeof(buf));
    if (sizeof(buf) != bytes_read) {
      WARN("fd[%d] bytes_read[%d]", fd, bytes_read)
    }
    assert(sizeof(buf) == bytes_read);
//    DEBUG("server buf %d", buf);

//    DEBUG("server_start_write");
    write(fd, &buf, sizeof(buf));

    timer.stop();
    TRACE("server_conn[%lu] cost[%ld]", i, timer.time_us());
    server_conn_pool->FreeSocket(fd);
  }
  glog_s::close();
  return NULL;
}

TEST_F(test_multithread, test)
{
  glog_s::init_in_thread();
  ServerConnPool server_conn_pool;
  int ret = server_conn_pool.Init(kAddr, kPort, true);
  ASSERT_EQ(true, ret);

  //start clients
  pthread_t pid_clients[kNumClients];
  for (size_t i=0; i<kNumClients; ++i) {
    ret = pthread_create(&pid_clients[i], NULL, &client_thread, NULL);
    ASSERT_TRUE(ret>=0);
  }

  pthread_t pid_server[kNumServers];
  for (size_t i=0; i<kNumServers; ++i) {
    ret = pthread_create(&pid_server[i], NULL, &server, &server_conn_pool);
    ASSERT_TRUE(ret>=0);
  }

  for (size_t i=0; i<kNumClients; ++i) {
    pthread_join(pid_clients[i], NULL);
  }
  end=true;
  DEBUG("end_status");
  for (size_t i=0; i<kNumServers; ++i) { pthread_join(pid_server[i], NULL); }
  server_conn_pool.Close();
  glog_s::close();
}
