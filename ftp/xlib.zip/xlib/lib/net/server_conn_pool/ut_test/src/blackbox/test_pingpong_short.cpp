#include <assert.h>
#include <gtest/gtest.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <arpa/inet.h>

#include "../../../../server_conn_pool/src/server_conn_pool.h"
#include "public/basic/time.h"

using namespace xlib;
using namespace net;

static const std::string kAddr="127.0.0.1";
static const uint16_t kPort=12321;
static const size_t kTimeTests=20000;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_pingpong: public ::testing::Test
{
    protected:
    virtual ~test_pingpong() {};
    virtual void SetUp() 
    {
        bool ret = glog_s::init("conf/log.conf");
        ASSERT_TRUE(ret==true);
    }

    virtual void TearDown() { }
};

void* client_thread(void*)
{
  glog_s::init_in_thread();

  int sockfd;
  int buf;
  struct sockaddr_in servaddr;
  for (size_t i=0; i<kTimeTests; ++i) {
    DEBUG("client_start");
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0){
        printf("Socket created failed!\n");
        return NULL;
    }
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(kPort);
    servaddr.sin_addr.s_addr=inet_addr(kAddr.c_str());
    DEBUG("client_connect");
    if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0){
        printf("Connect server failed! %s\n", strerror(errno));
        return NULL;
    }

    DEBUG("client_stop_connect");
    buf=i;
    write(sockfd, &buf, sizeof(buf));

    xlib::timer_t timer;
    timer.start();

    DEBUG("client_stop_connect");
    int bytes_read = read(sockfd, &buf, sizeof(buf));
    assert(bytes_read == sizeof(buf));

    timer.stop();
    TRACE("client_cost[%ld]", timer.time_us());

    close(sockfd);
  }
  printf("client_complete\n");
  glog_s::close();
  return NULL;
}

TEST_F(test_pingpong, test)
{
  glog_s::init_in_thread();
  ServerConnPool server_conn_pool;
  int ret = server_conn_pool.Init(kAddr, kPort, false);
  ASSERT_EQ(true, ret);

  //start clients
  pthread_t pid;
  ret = pthread_create(&pid, NULL, &client_thread, NULL);
  ASSERT_TRUE(ret>=0);

  int buf;
  for (size_t i=0; i<kTimeTests; ++i) {
    int fd = server_conn_pool.FetchSocket();
    ASSERT_TRUE(fd>0);

    xlib::timer_t timer;
    timer.start();

    DEBUG("server_start_read");
    int bytes_read = read(fd, &buf, sizeof(buf));
    ASSERT_EQ(sizeof(buf), bytes_read);

    DEBUG("server_start_write");
    write(fd, &buf, sizeof(buf));
    ASSERT_EQ(buf, i);

    timer.stop();
    TRACE("server_get_conn[%lu] cost[%ld]", i, timer.time_us());
    server_conn_pool.FreeSocket(fd);
  }
  pthread_join(pid, NULL);
  server_conn_pool.Close();
  glog_s::close();
}
