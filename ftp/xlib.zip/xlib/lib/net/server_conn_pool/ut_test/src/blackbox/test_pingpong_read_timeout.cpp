#include <assert.h>
#include <gtest/gtest.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "../../../../server_conn_pool/src/server_conn_pool.h"
#include "public/basic/time.h"
#include "public/basic/fd_helper.hpp"

using namespace xlib;
using namespace net;

static const std::string kAddr="127.0.0.1";
static const uint16_t kPort=12321;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_pingpong: public ::testing::Test
{
    protected:
    virtual ~test_pingpong() {};
    virtual void SetUp() 
    {
        bool ret = glog_s::init("conf/log.conf");
        ASSERT_TRUE(ret==true);
    }

    virtual void TearDown() { }
};

void* client_thread_read_timeout(void*)
{
  glog_s::init_in_thread();

  int sockfd;
  int buf;
  struct sockaddr_in servaddr;
  DEBUG("client_start");
  sockfd=socket(AF_INET,SOCK_STREAM,0);
  if(sockfd<0){
      printf("Socket created failed!\n");
      return NULL;
  }
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(kPort);
  servaddr.sin_addr.s_addr=inet_addr(kAddr.c_str());
  DEBUG("client_connect");
  if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0){
      printf("Connect server failed! %s\n", strerror(errno));
      return NULL;
  }

  bool ret = fd_helper_i::setnonblock(sockfd);
  assert(true==ret);

  sleep(1);
  DEBUG("client_stop_connect");
  buf=0;
  write(sockfd, &buf, sizeof(buf));

  xlib::timer_t timer;
  timer.start();

  DEBUG("client_stop_connect");
  int bytes_read = read(sockfd, &buf, sizeof(buf));
  assert(bytes_read<=0);

  timer.stop();
  TRACE("client_cost[%ld]", timer.time_us());

  close(sockfd);
  printf("client_complete\n");
  glog_s::close();
  return NULL;
}

TEST_F(test_pingpong, test_read_timeout)
{
  glog_s::init_in_thread();
  ServerConnPool server_conn_pool;
  int ret = server_conn_pool.Init(kAddr, kPort, false, 200);
  ASSERT_EQ(true, ret);

  //start clients
  pthread_t pid;
  ret = pthread_create(&pid, NULL, &client_thread_read_timeout, NULL);
  ASSERT_TRUE(ret>=0);

  int fd;
  for (size_t i=0; i<10000; ++i) {
    fd = server_conn_pool.FetchSocket(0);
    ASSERT_EQ(fd, 0);
  }

  pthread_join(pid, NULL);
  server_conn_pool.Close();
  glog_s::close();
}
