#include "../server_conn_pool.h"

namespace xlib { namespace server_conn_pool {

bool ServerConnPool::Init(
    uint16_t listen_port, 
    size_t max_threads, 
    bool keepalive, 
    uint16_t timeo_wait_for_process, 
    uint16_t timeo_idle)
{
  int ret;
  pipe_ready_fds_=NULL;
  pipe_free_fds_=NULL;

  listen_port_=listen_port;
  XLIB_FAIL_HANDLE_FATAL(0==max_threads, "max_threads_can't_be_0")
  max_threads_=max_threads;
  keepalive_=keepalive;
  timeo_wait_for_process_=timeo_wait_for_process;
  timeo_idle_=timeo_idle;

  ret = event_driver_.Init();
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_init_event_driver")

  num_threads_=0;
  ret = pthread_mutex_init(&lock_num_thread_, NULL);
  XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_init_lock_num_thread")

  XLIB_NEW(pipe_ready_fds_, SimpleFixedMsgPipe<int> [max_threads])
  XLIB_NEW(pipe_free_fds_, SimpleFixedMsgPipe<int> [max_threads])

  ret = StartListen_();
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "error_start_listen reason[%s]", strerror(errno))
  return true;

  ERROR_HANDLE:
  XLIB_DELETE_ARRAY_IF_NOT_NULL(pipe_ready_fds_)
  XLIB_DELETE_ARRAY_IF_NOT_NULL(pipe_free_fds_)
  return false;
}

void ServerConnPool::WaitForEvents()
{
  bool ret;
  int num_ready_events;
  int result;
  void* context;
  EventContext* event_context;
  sockaddr client_addr;
  socklen_t len_socket;
  int coming_fd;

  while(true) {
    int num_ready_events = Wait(0);
    if (num_ready_events<=0) continue;

    for (size_t i=0; i<num_ready_events; ++i) {
      CheckReadyEvent(i, result, context);
      event_context = reinterpret_cast<EventContext*>(context);

      if (EventsDriver::kIn!=result) continue;

      if (listen_fd_ == event_context->fd()) {
        coming_fd = accept(listen_fd_, &client_addr, &len_socket);
        if (coming_fd<=0) continue;

        ret = pipe_ready_fds_->SendMsg((PipeItem){ coming_fd, time_s::get_current_time() });
        if (true!=ret) WARN("fail_send_msg_to_ready_pipe");

        ret = event_driver_.RegEvent(coming_fd, EventsDriver::kDelEvent, 0, NULL);
        if (true!=ret) WARN("fail_del_event");

        pool_event_contexts_.Free(event_context);
      } else {
        FATAL("unexpected_branch");
      }
    }
  }
}

int ServerConnPool::GetThreadIdx_()
{
  int* index = reinterpret_cast<int*>(thread_idxs_.Get(kNoThreadPrivacyThreadIdx));
  if (NULL!=index) return *index;

  int ret = pthread_mutex_lock(lock_num_thread_);
  XLIB_FAIL_HANDLE_FATAL(0!=ret, "error_lock_num_thread_mutex")

  *index = num_threads_++;
  ret = pipe_ready_fds_[*index].Init(kSizePipeFds); 
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "error_init_pipe_ready_fds")
  ret = pipe_free_fds_[*index].Init(kSizePipeFds); 
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "error_init_pipe_free_fds")

  pthread_mutex_unlock(lock_num_thread_);
  return *index;

  ERROR_HANDLE:
  return -1;
}

bool ServerConnPool::StartListen_()
{
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  struct sock_addr addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(listen_port_);
  addr.sin_addr.s_addr = htonl(INADDR_ANY);

  int ret = bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
  XLIB_FAIL_HANDLE_FATAL(ret<0, "error_bind ip[INADDR_ANY] port[%u]", listen_port_)

  ret = listen(listen_fd_, kBackLog);
  XLIB_FAIL_HANDLE_FATAL(ret<0, "error_listen_at[%d]", listen_fd_)

  EventContext* event_context = pool_event_contexts_.Get();
  XLIB_FAIL_HANDLE_FATAL(NULL==event_context, "fail_get_event_context_from_pool")

  event_context->fd = listen_fd_;
  ret = event_driver_.RegEvent(listen_fd_, EventsDriver::kAddEvent, EventsDriver::kIn, event_context);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "error_registe_listen_fd")
  return true;

  ERROR_HANDLE:
  return false;
}}
