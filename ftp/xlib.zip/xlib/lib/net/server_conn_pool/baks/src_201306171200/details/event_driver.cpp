#include "../event_driver.h"

#include "public/common.h"

namespace xlib { namespace server_conn_pool {

bool EventsDriver::Init()
{
  fd_epoll_ = epoll_create(HintMaxFds);
  XLIB_FAIL_HANDLE_FATAL(fd_epoll_<=0, "error_create_fd errno[%d]", errno)

  XLIB_NEW_FATAL(events_ready_, epoll_event [MaxNumEvents])
  return true;

  ERROR_HANDLE:
  return false;
}

}}
