#include "public/basic/pipe/simple_msg_pipe.hpp"
#include "public/basic/thread_privacy.h"
#include "events_driver.h"

namespace xlib { namespace server_conn_pool {

struct EventContext
{
  int fd;
};

struct PipeItem 
{
  int fd;
  int time_enter_pipe;
};

class ServerConnPool 
{
 public:
  static const size_t kNoThreadPrivacyThreadIdx=1;
  static const size_t kSizePipeFds=10000;
  static const int kBackLog=1000;
  
 public:
  /*
   * @parameters :
   *    max_threads : max num threads that use this pool
   *    keepalive : whether freed socket should be kept alive
   *    timeo_wait_for_process : timeout when fd waits to be processed
   *    timeo_idle : timeout for idle connection
   */
  bool Init(uint16_t listen_port, size_t max_threads, bool keepalive, uint16_t timeo_wait_for_process, uint16_t timeo_idle);

  int FetchScoket();

  void FreeScoket(int fd);

  void WaitForEvents();

 private:
  inline int GetThreadIdx_();
  bool StartListen_();

 private:
  //const
  uint16_t listen_port_;
  size_t max_threads_;
  bool keepalive_;
  int timeo_wait_for_process_;
  int timeo_idle_;
  ///

  int listen_fd_;
  SimpleAlloc<EventsDriver> pool_event_contexts_;
  EventsDriver event_driver_;

  int num_threads_;
  pthread_mutex_t lock_num_thread_;
  SimpleFixedMsgPipe<PipeItem>* pipe_ready_fds_;
  SimpleFixedMsgPipe<PipeItem>* pipe_free_fds_;
  ThreadPrivacy thread_idxs_;
};

int ServerConnPool::FetchScoket()
{
  int index = GetThreadIdx_();
  if (index<0) return -1;

  PipeItem* pipe_item = pipe_ready_fds_[index].RecieveMsg();
  if (NULL==pipe_item) return 0;

  pipe_ready_fds_[index].MsgConsumed();
  if (time_s::get_current_time() - pipe_item->time_enter_pipe > timeo_wait_for_process_) return 0;
  return pipe_item->fd;
}

void ServerConnPool::FreeScoket(int fd)
{
  int index = GetThreadIdx_();
  if (index<0) return;

  bool ret = pipe_free_fds_[index].SendMsg((PipeItem){ fd, time_s::get_current_time() });
  if (true!=ret) return;

  EventContext* event_context = pool_event_contexts_.Get(); 
  XLIB_FAIL_HANDLE_FATAL(NULL==event_context, "fail_get_event_context_from_pool")

  event_context->fd = fd;
  ret = event_driver_.RegEvent(fd, EventsDriver::kAddEvent, EventsDriver::kIn, event_context);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_reg_event")

  ERROR_HANDLE:
  return;
}

}}
