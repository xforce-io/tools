#include <sys/epoll.h>

namespace xlib { namespace server_conn_pool {
{

class EventsDriver
{
 public: 
  enum {
    kAddEvent,
    kModEvent,
    kDelEvent,
  };

  enum {
    kIn=0,
    kOut=1,
    kErr=2,
  };

 public:
  static const size_t MaxNumEvents=100000;
  static const size_t HintMaxFds=100000;

 public: 
  explicit EventsDriver() : events_ready_(NULL) {}

  bool Init();

  inline int Wait();
 
  inline bool RegEvent(int fd, int op, bool direction, void* context);

  void CheckReadyEvent(size_t index_events_ready, int& result, void*& context);

 private:
 int fd_epoll_;
 epoll_event* events_ready_;
};

int EventsDriver::Wait(size_t next_timeout) 
{
  int timeout = (next_timeout - time_s::get_current_time()) >> 10;
  return epoll_wait(
      fd_epoll_, 
      events_ready_, 
      MaxNumEvents, 
      timeout>0 ? timeout : 0);
}

bool EventsDriver::RegEvent(int fd, int op, bool direction, void* context)
{
  epoll_event ev;
  ev.events = (kIn==direction) ? EPOLLIN|EPOLLHUP|EPOLLERR : EPOLLOUT|EPOLLHUP|EPOLLERR;
  ev.data.ptr = context;

  int ret = epoll_ctl( fd_epoll_, kAddEvent==op ? EPOLL_CTL_ADD : 
      (kModEvent==op ? EPOLL_CTL_MOD : EPOLL_CTL_DEL), fd, &ev);
  return 0==ret ? true : false;
}

void EventsDriver::CheckReadyEvent(size_t index_events_ready, int& result, void*& context) 
{
  result = (EPOLLOUT == events_ready_[index_events_ready].events ? kOUT : 
      (EPOLLIN == events_ready_[index_events_ready].events ? kIn : kErr));
  context = events.ptr;
}

}}
