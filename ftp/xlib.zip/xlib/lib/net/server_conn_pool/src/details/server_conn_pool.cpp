#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "../server_conn_pool.h"

#include "lib/log/glog.h"

namespace xlib { namespace net {

bool ServerConnPool::Init(
    const std::string& addr,
    uint16_t listen_port, 
    bool keepalive, 
    int timeo_read,
    int timeo_idle,
    uint32_t timeo_wait_for_process, 
    uint32_t sleep_time_when_no_conn_us,
    uint32_t max_threads)
{
  int ret;

  pipe_ready_fds_=NULL;
  signs_heap_pipe_ready_fds_=NULL;
  pipe_free_fds_=NULL;

  listen_port_=listen_port;
  XLIB_FAIL_HANDLE_WARN(0==max_threads, "max_threads_can't_be_0")
  keepalive_=keepalive;
  timeo_read_=timeo_read;
  timeo_idle_=timeo_idle;
  timeo_wait_for_process_=timeo_wait_for_process;
  sleep_time_when_no_conn_us_=sleep_time_when_no_conn_us;
  XLIB_FAIL_HANDLE_WARN(0==sleep_time_when_no_conn_us_, "sleep_time_when_no_conn_ms_can't_be_0")

  num_threads_=0;
  ret = pthread_mutex_init(&lock_num_thread_, NULL);
  XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_init_lock_num_thread")

  XLIB_MALLOC(pipe_ready_fds_, Pipe*, max_threads*sizeof(*pipe_ready_fds_))
  for (size_t i=0; i<max_threads; ++i) pipe_ready_fds_[i] = Pipe(kDefaultPipeSize);
  XLIB_NEW(signs_heap_pipe_ready_fds_, size_t [max_threads])
  XLIB_MALLOC(pipe_free_fds_, Pipe*, max_threads*sizeof(*pipe_free_fds_))
  for (size_t i=0; i<max_threads; ++i) pipe_free_fds_[i] = Pipe(kDefaultPipeSize);

  ret = StartListen_(addr);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_start_listen reason[%s]", strerror(errno))

  ret = pthread_create(&slave_, NULL, &(ServerConnPool::EventLoop_), this);
  XLIB_FAIL_HANDLE_FATAL(ret<0, "fail_create_eventloop_thread reason[%s]", strerror(errno))
  return true;

  ERROR_HANDLE:
  XLIB_FREE(pipe_ready_fds_)
  XLIB_DELETE_ARRAY(signs_heap_pipe_ready_fds_)
  XLIB_FREE(pipe_free_fds_)
  return false;
}

void ServerConnPool::FreeSocket(int fd)
{
  bool ret;
  int index;
  EventContext* event_context=NULL;
  PipeItem pipe_item;
 
  index = GetThreadIdx_();
  XLIB_FAIL_HANDLE_FATAL(index<0, "fail_free_socket_for_fail_get_thread_index")

  pipe_item = (PipeItem){ 
      fd, 
      time_s::get_current_time(), 
      true==keepalive_ ? ConnState::IDLE : ConnState::LINGER_CLOSE };
  ret = pipe_free_fds_[index].SendMsg(pipe_item);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_free_socket_into_pipe")

  ERROR_HANDLE:
  if (NULL!=event_context) pool_event_contexts_.Free(event_context);
}

void ServerConnPool::Close()
{
  if (false==shutdown_) {
    shutdown_=true;
    pthread_join(slave_, NULL);
  }
}

ServerConnPool::~ServerConnPool()
{
  Close();
  XLIB_FREE(pipe_ready_fds_)
  XLIB_DELETE_ARRAY(signs_heap_pipe_ready_fds_)
  XLIB_FREE(pipe_free_fds_)
}

int ServerConnPool::GetThreadIdx_()
{
  int ret;
  bool new_index;
  int* index;
  
  index = reinterpret_cast<int*>(thread_idxs_.Get<int>(kNoThreadPrivacyThreadIdx, &new_index));
  XLIB_FAIL_HANDLE_FATAL(NULL==index, "fail_get_thread_index");

  if (false==new_index) return *index;

  ret = pthread_mutex_lock(&lock_num_thread_);
  XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_lock_num_thread_mutex")

  *index = num_threads_;
  ret = heap_len_pipe_ready_fds_.Insert(
      0,
      &(pipe_ready_fds_[*index]), 
      signs_heap_pipe_ready_fds_[*index]);
  XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_insert_into_heap_len_pipe_ready_fds")
  pthread_mutex_unlock(&lock_num_thread_);
  ++num_threads_;
  return *index;

  ERROR_HANDLE:
  return -1;
}

bool ServerConnPool::StartListen_(const std::string& address)
{
  int ret;
  struct sockaddr_in addr;
  EventContext* event_context;

  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(listen_port_);
  ret = inet_pton(addr.sin_family, address.c_str(), &(addr.sin_addr));
  XLIB_FAIL_HANDLE_FATAL(ret<=0, "fail_inet_pton reason[%s]", strerror(errno))

  listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
  XLIB_FAIL_HANDLE_FATAL(listen_fd_<0, "fail_create socket reason[%s]", strerror(errno))

  ret = bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
  XLIB_FAIL_HANDLE_FATAL(ret<0, "fail_bind ip[INADDR_ANY] port[%u]", listen_port_)

  ret = listen(listen_fd_, kBackLog);
  XLIB_FAIL_HANDLE_FATAL(ret<0, "fail_listen_at[%d]", listen_fd_)

  event_context = pool_event_contexts_.Get();
  XLIB_FAIL_HANDLE_FATAL(NULL==event_context, "fail_get_event_context_from_pool")

  event_context->fd = listen_fd_;
  ret = event_driver_.RegEvent(listen_fd_, EventsDriver::kAddEvent, EventsDriver::kIn, event_context, -1);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_registe_listen_fd")
  return true;

  ERROR_HANDLE:
  return false;
}

void ServerConnPool::InsertReadyFds_(EventContext* event_context)
{
  bool ret;
  std::pair<size_t, Pipe*>* selected_ready_pipe;

  selected_ready_pipe = heap_len_pipe_ready_fds_.Top();
  XLIB_FAIL_HANDLE_WARN(NULL==selected_ready_pipe, "fail_to_get_selected_ready_pipe")

  ret = (*selected_ready_pipe).second->SendMsg((PipeItem){ event_context->fd, time_s::get_current_time(), ConnState::READ });
  XLIB_FAIL_HANDLE_WARN(true!=ret, "fail_send_msg_to_ready_pipe")

  selected_ready_pipe->first = (*selected_ready_pipe).second->SizeMsgReady();
  heap_len_pipe_ready_fds_.RefreshTop();

  ret = event_driver_.RegEvent(event_context->fd, EventsDriver::kDelEvent, 0, NULL, -1);
  XLIB_FAIL_HANDLE_WARN(true!=ret, "fail_del_event reason[%s]", strerror(errno))

  pool_event_contexts_.Free(event_context);

  ERROR_HANDLE:
  void(0);
}

void ServerConnPool::ProcessPipeFreeFds_()
{
  EventContext* event_context;
  PipeItem* pipe_item;
  PipeItem tmp_pipe_item;
  bool ret;

  for (size_t i=0; i<num_threads_; ++i) {
    while (NULL != (pipe_item = pipe_free_fds_[i].RecieveMsg())) {
      tmp_pipe_item=*pipe_item;
      pipe_free_fds_[i].MsgConsumed();

      event_context = pool_event_contexts_.Get(); 
      XLIB_FATAL_AND_CONTINUE(NULL==event_context, "fail_get_event_context_from_pool")

      event_context->fd = tmp_pipe_item.fd;
      event_context->state = 
          (ConnState::IDLE == tmp_pipe_item.state ? ConnState::IDLE : ConnState::LINGER_CLOSE);
      ret = event_driver_.RegEvent(
          event_context->fd, 
          EventsDriver::kAddEvent, 
          EventsDriver::kIn, 
          event_context,
          (ConnState::IDLE == tmp_pipe_item.state ? timeo_idle_ : kTimeoutLingerClose));
      XLIB_FATAL_AND_CONTINUE(true!=ret, "fail_reg_event reason[%s]", strerror(errno))
    }
  }
}

void ServerConnPool::ProcessReadyFds_(size_t num_ready_events)
{
  bool ret;
  int event;
  EventContext* event_context;
  void* context;
  int coming_fd;
  int flag;
  sockaddr client_addr;
  socklen_t len_socket;

  for (size_t i=0; i<num_ready_events; ++i) {
    event_driver_.CheckReadyEvent(i, event, context);
    event_context = reinterpret_cast<EventContext*>(context);

    if (EventsDriver::kIn==event) {
      if (listen_fd_ == event_context->fd) {
        DEBUG("listen_event");

        len_socket=1;  //remove accept error [invalid argument]
        coming_fd = accept(listen_fd_, &client_addr, &len_socket);
        XLIB_WARN_AND_CONTINUE(coming_fd<=0, 
          "fail_to_accept coming_fd[%d] error[%s]", coming_fd, strerror(errno))

        flag=1;
        ret = setsockopt(coming_fd, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag));
        XLIB_FATAL_AND_CONTINUE(0!=ret, "fail_setsockopt_reuseaddr reason[%s]", strerror(errno))

        event_context = pool_event_contexts_.Get();
        XLIB_FATAL_AND_CONTINUE(NULL==event_context, "fail_get_event_context_from_pool")

        event_context->fd = coming_fd;
        event_context->state = ConnState::READ;
        ret = event_driver_.RegEvent(coming_fd, EventsDriver::kAddEvent, EventsDriver::kIn, event_context, timeo_read_);
        XLIB_FATAL_AND_CONTINUE(true!=ret, "fail_registe_listen_fd reason[%s]", strerror(errno))
      } else if (ConnState::READ == event_context->state 
          || ConnState::IDLE == event_context->state) {
        DEBUG("read_and_idle_event");

        InsertReadyFds_(event_context);
      } else if (ConnState::LINGER_CLOSE == event_context->state) {
        DEBUG("linger_event");

        ret = event_driver_.RegEvent(event_context->fd, EventsDriver::kDelEvent, 0, NULL, -1);
        XLIB_FATAL_AND_CONTINUE(true!=ret, "fail_del_event reason[%s]", strerror(errno))

        pool_event_contexts_.Free(event_context);
        close(event_context->fd);
      } else {
        XLIB_ASSERT(false);
      }
    } else {
      ret = event_driver_.RegEvent(event_context->fd, EventsDriver::kDelEvent, 0, NULL, -1);
      XLIB_FATAL_AND_CONTINUE(true!=ret, "fail_del_event reason[%s]", strerror(errno))

      pool_event_contexts_.Free(event_context);
      close(event_context->fd);
    } 
  }
}

void ServerConnPool::WaitForEvents_()
{
  while(false==shutdown_) {
    if (0==num_threads_) {
      usleep(1<<10); //1ms
      continue;
    }

    ProcessPipeFreeFds_();

    time_s::update_timer();
    int num_ready_events = event_driver_.Wait();
    XLIB_WARN_AND_CONTINUE(num_ready_events<0, "wait_ret_neg reason[%s]", strerror(errno))

    DEBUG("event_driver_ready[%d]", num_ready_events);

    time_s::update_timer();
    if (0==num_ready_events) event_driver_.RemoveTimeouts();
    ProcessReadyFds_(num_ready_events);
  }
}

int ServerConnPool::FetchSocketNonBlock_()
{
  int index = GetThreadIdx_();
  if (index<0) return -1;

  while (true) {
    PipeItem* pipe_item = pipe_ready_fds_[index].RecieveMsg();
    if (NULL==pipe_item) return 0;

    PipeItem tmp_pipe_item=*pipe_item;
    pipe_ready_fds_[index].MsgConsumed();

    if (time_s::get_current_time() - tmp_pipe_item.time_enter_pipe
        > static_cast<int64_t>(timeo_wait_for_process_)) {
      continue;
    } else {
      return tmp_pipe_item.fd;
    }
  }
}

void* ServerConnPool::EventLoop_(void* server_conn_pool)
{
  bool ret = glog_s::init_in_thread();
  if (true!=ret) { return NULL; }

  NOTICE("[server_conn_pool] start_loop")
  reinterpret_cast<ServerConnPool*>(server_conn_pool)->WaitForEvents_();
  NOTICE("[server_conn_pool] stop_loop")
  glog_s::close();
  return NULL;
}

}}
