#include "public/basic/simple_msg_pipe.hpp"
#include "public/basic/thread_privacy.h"
#include "public/basic/heap.hpp"
#include "../../public/event_driver/src/events_driver.h"

namespace xlib { namespace net {

struct ConnState {
  enum ConnStateE {
    IDLE,
    READ,
    LINGER_CLOSE,
  };
};

struct EventContext { 
  int fd;
  ConnState::ConnStateE state;
};

struct PipeItem
{
  int fd;
  int64_t time_enter_pipe;
  ConnState::ConnStateE state;
};

class ServerConnPool 
{
 public:
  typedef SimpleMsgPipe<PipeItem> Pipe; 

 public:
  static const size_t kNoThreadPrivacyThreadIdx=1;
  static const size_t kDefaultPipeSize=100000;
  static const uint32_t kTimeoutLingerClose=100; //100ms
  static const uint32_t kDefaultSleepTimeWhenNoConnMs=1;
  static const uint32_t kMaxThread=1000;
  static const int kBackLog=1000;
  
 public:

  explicit ServerConnPool() :
    pipe_ready_fds_(NULL),
    signs_heap_pipe_ready_fds_(NULL),
    pipe_free_fds_(NULL),
    shutdown_(false) {}

  /*
   * @parameters :
   *    max_threads : max num threads that use this pool
   *    keepalive : long connection or short connection
   *    timeo_wait_for_process : timeout when fd waits to be processed
   *    timeo_idle : timeout for idle connection
   */
  bool Init(
      const std::string& addr,
      uint16_t listen_port, 
      bool keepalive=true,
      int timeo_read=-1,
      int timeo_idle=-1,
      uint32_t timeo_wait_for_process=uint32_t(-1),
      uint32_t sleep_time_when_no_conn_us=kDefaultSleepTimeWhenNoConnMs*1000,
      uint32_t max_threads=kMaxThread);
  inline int FetchSocket(uint32_t timeout_ms = (uint32_t)-1);
  void FreeSocket(int fd);
  void Close();

  virtual ~ServerConnPool();

 private:
  inline int GetThreadIdx_();
  bool StartListen_(const std::string& addr);
  void InsertReadyFds_(EventContext* event_context);
  void ProcessPipeFreeFds_();
  void ProcessReadyFds_(size_t num_ready_events);
  void WaitForEvents_();
  int FetchSocketNonBlock_();

  static void* EventLoop_(void* server_conn_pool);

 private:
  //const
  uint16_t listen_port_;
  bool keepalive_;
  int timeo_read_;
  int timeo_idle_;
  uint32_t timeo_wait_for_process_;
  int64_t sleep_time_when_no_conn_us_;
  pthread_t slave_;
  ///

  int listen_fd_;
  pub::SimpleAlloc<EventContext> pool_event_contexts_;
  EventsDriver event_driver_;

  size_t num_threads_;
  pthread_mutex_t lock_num_thread_;

  //ready fds pipe
  Pipe* pipe_ready_fds_;
  size_t* signs_heap_pipe_ready_fds_;

  template <typename T>
  struct GetPipeLen 
  {
    size_t operator()(const T& t) const { return t->SizeMsgReady(); }
  };

  pub::SimpleKVHeap< 
    size_t,
    Pipe*, 
    pub::HeapKind::kMinHeap> heap_len_pipe_ready_fds_;

  //free fds pipe
  Pipe* pipe_free_fds_;

  pub::ThreadPrivacy thread_idxs_;

  bool shutdown_;
};

int ServerConnPool::FetchSocket(uint32_t timeout_ms)
{ 
  int64_t begin_time = time_s::get_current_time(true);
  while (true) {
    int ret = FetchSocketNonBlock_();
    if (0!=ret) {
      return ret;
    } else {
      if (0==timeout_ms) return 0;

      usleep(sleep_time_when_no_conn_us_);
      if ((time_s::get_current_time(true) - begin_time) >= (timeout_ms<<10)) return 0;
    }
  }
  return 0;
}

}}
