#include <assert.h>
#include <gtest/gtest.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../../src/events_driver.h"

static const std::string kAddr="127.0.0.1";
static const uint16_t kPort=12322;

using namespace xlib;
using namespace net;

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}

class test_events_driver: public ::testing::Test
{
 protected:
  virtual ~test_events_driver() {};
  virtual void SetUp() 
  {
    int ret;
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(kPort);
    ret = inet_pton(addr.sin_family, kAddr.c_str(), &(addr.sin_addr));
    assert(ret>0);

    listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    assert(listen_fd_>0);

    ret = bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
    if (0!=ret) {
      printf("bind error %s\n", strerror(errno));
    }
    assert(0==ret);

    ret = listen(listen_fd_, 100);
    assert(0==ret);
  }

  virtual void TearDown() 
  { 
    close(listen_fd_);
  }

 private:
  int listen_fd_;
};

void* just_connect(void* timeout)
{
  usleep(*reinterpret_cast<int*>(timeout) << 10);

  int sockfd;
  struct sockaddr_in servaddr;
  sockfd=socket(AF_INET,SOCK_STREAM,0);
  if(sockfd<0){
      printf("Socket created failed!\n");
      return NULL;
  }
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(kPort);
  servaddr.sin_addr.s_addr=inet_addr(kAddr.c_str());
  if(connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr))<0){
      printf("Connect server failed! %s\n", strerror(errno));
      return NULL;
  }
  sleep(100);
  return NULL;
}

TEST_F(test_events_driver, no_timeouts)
{
  EventsDriver events_driver;

  int context;

  pub::time_s::update_timer();

  int ret = events_driver.RegEvent(listen_fd_, EventsDriver::kAddEvent, EventsDriver::kIn, &context, -1);
  ASSERT_EQ(ret, true);

  pthread_t pthread;
  int timeout=100;
  ret = pthread_create(&pthread, NULL, &just_connect, &timeout);
  ASSERT_EQ(ret, 0);
  usleep(500000);
  ret = events_driver.Wait();
  ASSERT_EQ(ret, 1);
  
  pub::time_s::update_timer();

  int event;
  int *context_res;
  events_driver.CheckReadyEvent(0, event, (void*&)context_res);
  ASSERT_EQ(EventsDriver::kIn, event);
  ASSERT_TRUE(&context == context_res);

  struct sockaddr addr;
  socklen_t socklen;
  int conn_fd = accept(listen_fd_, &addr, &socklen);
  ASSERT_TRUE(conn_fd>0);

  ret = events_driver.RegEvent(conn_fd, EventsDriver::kAddEvent, EventsDriver::kOut, NULL, 30000);
  ASSERT_TRUE(ret);

  time_t time0 = pub::time_s::get_current_time(true);
  ret = events_driver.Wait();
  ASSERT_EQ(ret, 1);
  time_t time1 = pub::time_s::get_current_time(true);
  printf("timediff[%lu]", time1-time0);

  ret = events_driver.RegEvent(listen_fd_, EventsDriver::kDelEvent, EventsDriver::kIn, NULL, -1);
  ASSERT_TRUE(ret);
}
/*
TEST_F(test_events_driver, timeouts)
{
  EventsDriver events_driver;

  int context;
  int timeout=100;

  pub::time_s::update_timer();
  
  int ret = events_driver.RegEvent(listen_fd_, EventsDriver::kAddEvent, EventsDriver::kIn, &context, -1);
  ASSERT_EQ(ret, true);

  ret = events_driver.RegEvent(listen_fd_, EventsDriver::kModEvent, EventsDriver::kIn, &context, timeout);
  ASSERT_EQ(ret, true);

  pthread_t pthread;
  timeout*=2;
  ret = pthread_create(&pthread, NULL, &just_connect, &timeout);
  ASSERT_EQ(ret, 0);
  ret = events_driver.Wait();
  ASSERT_EQ(ret, 0);

  pub::time_s::update_timer();
  
  const std::vector<void*>* timeouts = events_driver.RemoveTimeouts();
  ASSERT_EQ(1, timeouts->size());
  ASSERT_EQ(&context, (*timeouts)[0]);

  ret = events_driver.RegEvent(listen_fd_, EventsDriver::kDelEvent, EventsDriver::kIn, NULL, -1);
  ASSERT_TRUE(!ret);
}
*/
