#ifndef XLIB_LIB_NET_PUBLIC_EVENT_DRIVER_H
#define XLIB_LIB_NET_PUBLIC_EVENT_DRIVER_H

#include <iostream>
#include <stdlib.h>
#include <vector>
#include <errno.h>
#include <sys/epoll.h>
#include "public/common.h"
#include "public/basic/time.h"
#include "public/basic/heap.hpp"
#include "lib/log/glog.h"

namespace xlib { namespace net {

/*
 * @notice : RAII
 */
class EventsDriver
{
 public: 
  enum {
    kAddEvent,
    kModEvent,
    kDelEvent,
  };

  enum {
    kIn=0,
    kOut=1,
    kErr=2,
  };

  struct EventCtx {
    void* context;
    size_t sign_timeo;
  };

  struct EventTimeo {
    int64_t expire_time;
    int fd;
  };

 public:
  static const size_t MaxNumEvents=100000;
  static const size_t DefaultInteruptTime=1; //ms

 public: 
  explicit EventsDriver() : events_ready_(NULL), init_(false) {}

  inline int Wait();
  bool RegEvent(int fd, int op, bool direction, void* context, int timeo);
  inline void CheckReadyEvent(size_t index_events_ready, int& event, void*& context);
  inline const std::vector<void*>* RemoveTimeouts();

  virtual ~EventsDriver() { XLIB_DELETE_ARRAY(events_ready_) }

 private: 
  bool Init_();

 private:
  int fd_epoll_;
  epoll_event* events_ready_;

  template <typename T>
  struct GetExpireTime {
    size_t operator()(const T& t) const { return t.expire_time; }
  };

  pub::SimpleHeap<
    EventTimeo,
    pub::HeapKind::kMinHeap,
    GetExpireTime<EventTimeo> > heap_timeo_;
  std::vector<EventCtx> fd_to_event_ctx_;  
  std::vector<void*> timeo_contexts_;

  bool init_;
};

int EventsDriver::Wait() 
{
  XLIB_RAII_INIT(-1)
  if (0!=heap_timeo_.Size()) {
    int64_t timeout = heap_timeo_.Top()->expire_time - pub::time_s::get_current_time();
    DEBUG("event_driver_wait[%ld] size_heap[%lu]", timeout, heap_timeo_.Size());
    return epoll_wait(fd_epoll_, events_ready_, MaxNumEvents, timeout>=0 ? timeout : 0);
  } else {
    DEBUG("event_driver_wait[%ld] size_heap[0]", DefaultInteruptTime);
    return epoll_wait(fd_epoll_, events_ready_, MaxNumEvents, DefaultInteruptTime);
  }
}

void EventsDriver::CheckReadyEvent(size_t index_events_ready, int& event, void*& context) 
{
  XLIB_RAII_INIT()
  event = (EPOLLOUT == events_ready_[index_events_ready].events ? kOut : 
      (EPOLLIN == events_ready_[index_events_ready].events ? kIn : kErr));
  context = fd_to_event_ctx_[events_ready_[index_events_ready].data.fd].context;
}

const std::vector<void*>* EventsDriver::RemoveTimeouts()
{
  XLIB_RAII_INIT(NULL)
  timeo_contexts_.clear();
  EventTimeo* event_timeo = heap_timeo_.Top();
  while (NULL!=event_timeo && event_timeo->expire_time < pub::time_s::get_current_time()) {
    timeo_contexts_.push_back(fd_to_event_ctx_[event_timeo->fd].context);
    heap_timeo_.Pop();
    
    RegEvent(event_timeo->fd, kDelEvent, 0, NULL, 0);
    TRACE("fd[%d] timeout", event_timeo->fd);

    event_timeo = heap_timeo_.Top();
  }
  return &timeo_contexts_;
}

}}

#endif
