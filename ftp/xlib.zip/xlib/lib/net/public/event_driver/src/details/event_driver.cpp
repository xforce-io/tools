#include "../events_driver.h"

#include "public/common.h"
#include "lib/log/glog.h"

namespace xlib { namespace net {

bool EventsDriver::Init_()
{
  fd_epoll_ = epoll_create(1);
  XLIB_FAIL_HANDLE_FATAL(fd_epoll_<=0, "error_create_fd errno[%d]", errno)

  XLIB_NEW_FATAL(events_ready_, epoll_event [MaxNumEvents])
  init_=true;
  return true;

  ERROR_HANDLE:
  return false;
}

bool EventsDriver::RegEvent(int fd, int op, bool direction, void* context, int timeo)
{
  XLIB_RAII_INIT(-1)

  int ret=-1;
  EventTimeo event_timeo;

  if (fd >= static_cast<int>(fd_to_event_ctx_.size())) fd_to_event_ctx_.resize(fd+1);

  epoll_event ev;
  ev.events = (kIn==direction) ? EPOLLIN|EPOLLHUP|EPOLLERR : EPOLLOUT|EPOLLHUP|EPOLLERR;
  ev.data.fd = fd;

  switch (op) {
    case kAddEvent :
      DEBUG("events_driver_add_event fd[%d] timeo[%d]", fd, timeo);
      fd_to_event_ctx_[fd].context = context;

      if (timeo>0) { 
        event_timeo = (struct EventTimeo){pub::time_s::get_current_time() + timeo, fd};
        ret = heap_timeo_.Insert(event_timeo, fd_to_event_ctx_[fd].sign_timeo);
        XLIB_FAIL_HANDLE_WARN(0!=ret, "fail_insert_into_heap_timeo")
      } else {
        fd_to_event_ctx_[fd].sign_timeo=0;
      }

      ret = epoll_ctl(fd_epoll_, EPOLL_CTL_ADD, fd, &ev);
      XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_epoll_ctl_add reason[%s]", strerror(errno))
      break;
    case kModEvent :
      DEBUG("events_driver_mod_event fd[%d]", fd);
      if (timeo>0) { 
        event_timeo = (struct EventTimeo){pub::time_s::get_current_time() + timeo, fd};
        if (0 != fd_to_event_ctx_[fd].sign_timeo) {
          heap_timeo_.Update(fd_to_event_ctx_[fd].sign_timeo, event_timeo);
        } else {
          ret = heap_timeo_.Insert(event_timeo, fd_to_event_ctx_[fd].sign_timeo);
          XLIB_FAIL_HANDLE_WARN(0!=ret, "fail_insert_into_heap_timeo")
        }
      }

      ret = epoll_ctl(fd_epoll_, EPOLL_CTL_MOD, fd, &ev);
      XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_epoll_ctl_mod reason[%s]", strerror(errno))
      break;
    default : // kDelEvent
      DEBUG("events_driver_del_event fd[%d]", fd);
      if (0 != fd_to_event_ctx_[fd].sign_timeo) {
        heap_timeo_.Free(fd_to_event_ctx_[fd].sign_timeo);
        fd_to_event_ctx_[fd].sign_timeo = 0;
      }

      ret = epoll_ctl(fd_epoll_, EPOLL_CTL_DEL, fd, &ev);
      XLIB_FAIL_HANDLE_FATAL(0!=ret, "fail_epoll_ctl_del reason[%s]", strerror(errno))
      break;
  }
  return true;

  ERROR_HANDLE:
  return false;
}

}}
