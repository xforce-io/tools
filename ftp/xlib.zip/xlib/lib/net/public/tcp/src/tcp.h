#ifndef XLIB_LIB_NET_PUBLIC_TCP_TCP_H
#define XLIB_LIB_NET_PUBLIC_TCP_TCP_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include "../../event_driver/src/events_driver.h"

namespace xlib { namespace net {

class Tcp
{
 public:
  static bool SetNoDelay(int fd);
  static int ConnectMs(const std::string& addr, int port, int timeout_ms); 
};

bool Tcp::SetNoDelay(int fd) 
{
  int on=1;
  return 0 == setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));
}

}}

#endif
