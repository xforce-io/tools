#include "../tcp.h"

namespace xlib { namespace net {

int Tcp::ConnectMs(const std::string& ip, int port, int timeout_ms)
{
  int ret;
  int fd;
  EventsDriver event_driver;
  in_addr_t ip_addr;
  sockaddr_in addr;

  ip_addr = inet_addr(ip.c_str());
  XLIB_FAIL_HANDLE_WARN(ip_addr<=0, "fail inet_addr ip[%s]", ip.c_str());

  bzero(&addr, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = ip_addr;
  addr.sin_port = port;

  fd = socket(AF_INET, SOCK_STREAM, 0);
  XLIB_FAIL_HANDLE_WARN(fd<0, "create_socket reason[%s]", strerror(errno))

  ret = tools_i::setnonblock(fd) && Tcp::SetNoDelay(fd);
  XLIB_FAIL_HANDLE_WARN(true!=ret, "set_socket_nonblock_and_nodelay reason[%s]", strerror(errno))

  ret = connect(fd, static_cast<struct sockaddr*>(&addr), sizeof(addr));
  if (0==ret) return fd;

  XLIB_FAIL_HANDLE_WARN(EINPROGRESS==errno, 
      "fail_connect [%s:%d] reason[%s]", ip.c_str(), port, strerror(errno))

  ret = event_driver.RegEvent(fd, EventsDriver::kAddEvent, EventsDriver::kIn, NULL, timeout_ms);
  XLIB_FAIL_HANDLE_WARN(true!=ret, "fail_reg_event reason[%s]", strerror(errno))

  ret = event_driver.Wait();
  XLIB_FAIL_HANDLE_WARN(1!=ret, "fail_connect reason[%s]", strerror(errno))
  return fd;

  ERROR_HANDLE:
  return 0;
}

}}
