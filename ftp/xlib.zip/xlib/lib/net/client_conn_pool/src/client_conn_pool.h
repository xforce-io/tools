#ifndef XLIB_LIB_NET_CLIENT_CONN_POOL_H
#define XLIB_LIB_NET_CLIENT_CONN_POOL_H

#include <vector>
#include <string>

#include "../../public/tcp/src/tcp.h"
#include "public/basic/fixed_size_shared_queue.hpp"
#include "addrs_selectors/addrs_selector.h"

namespace xlib { namespace net {

class ClientConnPool
{
 public:
  explicit ClientConnPool() : addrs_selector_(NULL) {} 

  bool Init(
      std::vector< std::pair<std::string, int> >& addrs, 
      bool keepalive,
      size_t max_conn_per_addr,
      size_t timeouts_ms); 

  inline int FetchSocket();
  inline void FreeSocket(int fd, bool is_ok);

  virtual ~ClientConnPool();

 private:
  size_t SelectAddr_();
  inline int ConnectAddr_(size_t index_addr);
  bool check_connection_(int fd);

 private:
  ///const
  std::vector< std::pair<std::string, int> > addrs_;
  bool keepalive_;
  size_t max_conn_per_addr_;
  size_t timeouts_ms_;
  //

  std::vector<int> fd_to_addr_index_;
  std::vector< FixedSizeSharedQueue<int> > free_fds_;
  AddrsSelector* addrs_selector_;
};

int ClientConnPool::FetchSocket()
{
  int index_addr = SelectAddr_();
  if (index_addr<0) return -1;

  if (true==keepalive_ && 0 != free_fds_[index_addr].length()) {
    int fd = free_fds_[index_addr].Get();
    if (true == check_connection_(fd)) {
      return fd;
    } else {
      addrs_selector_->Report(index_addr, false);
    }
  }

  int fd = ConnectAddr_(index_addr);
  if (fd>0) {
    free_fds_[index_addr].Put(fd);
    addrs_selector_->Report(index_addr, false);
  }
  return fd;
}

void ClientConnPool::FreeSocket(int fd, bool is_ok)
{
  if (false==keepalive_) {
    close(fd);
    return;
  }

  free_fds_[fd_to_addr_index_[fd]].Put(fd);
  addrs_selector_->Report(fd_to_addr_index_[fd], is_ok);
}

int ClientConnPool::ConnectAddr_(size_t index_addr)
{
  return Tcp::ConnectMs(addrs_[index_addr].first, addrs_[index_addr].second, timeouts_ms_);
}

bool ClientConnPool::check_connection_(int fd)
{
  char buf[1];
  ssize_t ret = recv(fd, buf, sizeof(buf), MSG_DONTWAIT);
  if (ret<0 && EWOULDBLOCK==errno) {
    return true;
  } else {
    close(fd);
    return false;
  }
}

}}

#endif
