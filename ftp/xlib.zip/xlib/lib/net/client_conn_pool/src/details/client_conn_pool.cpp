#include "../client_conn_pool.h"

#include <sys/types.h>
#include <sys/socket.h>

#include "public/basic/fixed_size_shared_queue.hpp"
#include "../../../public/tcp/src/tcp.h"
#include "../addrs_selectors/simple_addrs_selector.hpp"

namespace xlib { namespace net {

bool ClientConnPool::Init(
    std::vector< std::pair<std::string, int> >& addrs,
    bool keepalive,
    size_t max_conn_per_addr,
    size_t timeouts_ms)
{
  addrs_=addrs;
  keepalive_=keepalive;
  max_conn_per_addr_=max_conn_per_addr;
  timeouts_ms_=timeouts_ms;

  XLIB_FAIL_HANDLE_WARN(0 == addrs.size() || 0 == max_conn_per_addr,
    "invalid_parameters_for_init")

  free_fds_.resize(addrs.size(), FixedSizeSharedQueue<int>(max_conn_per_addr, 0));
  XLIB_NEW(addrs_selector_, SimpleAddrsSelector(addrs_.size()));
  return true;

  ERROR_HANDLE:
  return false;
}

ClientConnPool::~ClientConnPool() 
{ 
  XLIB_DELETE(addrs_selector_);
}

}}
