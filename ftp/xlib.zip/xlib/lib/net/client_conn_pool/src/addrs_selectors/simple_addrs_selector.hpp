#ifndef XLIB_LIB_NET_ADDRS_SELECTOR_SIMPLE_ADDRS_SELECTOR_HPP
#define XLIB_LIB_NET_ADDRS_SELECTOR_SIMPLE_ADDRS_SELECTOR_HPP

#include "public/common.h"
#include "addrs_selector.h"

namespace xlib { namespace net {

/*
 * RAII
 */
class SimpleAddrsSelector : public AddrsSelector
{
 public:
  static const size_t kBase=16;
  static const size_t kGatesContinuousFails=3;
  static const size_t kTryTimes=2;
  
 public:
  explicit SimpleAddrsSelector(size_t num_addrs) : 
      AddrsSelector(num_addrs),
      denominator_(num_addrs*kBase),
      continues_fails_(NULL),
      weights_(NULL),
      init_(false) {}

  void Report(size_t index_addr, bool is_ok);
  int SelectAddr();

 private:
  bool Init_();
  
 public:
  //
  size_t num_addrs_;
  size_t denominator_;
  ///

  size_t* continues_fails_;
  size_t* weights_;

  bool init_;
};

void SimpleAddrsSelector::Report(size_t index_addr, bool is_ok)
{
  if (true==is_ok) {
    continues_fails_[index_addr]=0;
    if (unlikely(kBase != weights_[index_addr])) weights_[index_addr] <<= 1; 
  } else {
    if (kGatesContinuousFails == continues_fails_[index_addr] 
        && 1 != weights_[index_addr]) {
      weights_[index_addr] /= 2; 
    } else {
      ++continues_fails_[index_addr];
    }
  }
}

int SimpleAddrsSelector::SelectAddr()
{
  XLIB_RAII_INIT(-1)

  int candidate;
  for (size_t i=0; i<kTryTimes; ++i) {
    candidate = rand() % num_addrs_;
    if (kBase == weights_[candidate] || rand()*kBase >= RAND_MAX*weights_[candidate]) {
      return candidate;
    }
  }
  return candidate;
}

bool SimpleAddrsSelector::Init_()
{
  XLIB_NEW(continues_fails_, size_t [num_addrs_])
  XLIB_NEW(weights_, size_t [num_addrs_])
  init_=true;
  return true;

  ERROR_HANDLE:
  return false;
}

}}

#endif
