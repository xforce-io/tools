#ifndef XLIB_LIB_NET_ADDRS_SELECTOR_ADDRS_SELECTOR_H
#define XLIB_LIB_NET_ADDRS_SELECTOR_ADDRS_SELECTOR_H

namespace xlib { namespace net {

class AddrsSelector
{
 public: 
  explicit AddrsSelector(size_t num_addrs);

  virtual void Report(size_t index_addr, bool is_ok)=0;
  virtual int SelectAddr()=0;
};

}}

#endif
