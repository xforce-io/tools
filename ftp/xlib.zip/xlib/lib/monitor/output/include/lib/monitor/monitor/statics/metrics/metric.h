#pragma once

#include "../../../public.h"

namespace xlib { namespace monitor {

class Metric {
 public:
  virtual bool Init() { Reset(); return true; }
  virtual void Reset()=0;
  virtual void Add(int64_t val)=0;
  virtual void Copy(const Metric& metric)=0;
  virtual void Freeze() {}

  virtual const std::string& GetName() const=0;
  virtual int64_t Query() const=0; 
  virtual void Output(std::stringstream& ss) const=0;

  virtual ~Metric() {}
};

}}
