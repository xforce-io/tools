#pragma once

#include "public.h"

#include "static_statics.h"
#include "dynamic_statics.h"

namespace xlib { namespace monitor {

class Statics : public pub::DataBase {
 private:
  typedef DataBase Super;

 public:
  bool Init(const std::string& name, void* init_params);

  /*
   * static monitor
   */
  inline void Inc(const std::string& item, int64_t val);
  inline void Set(const std::string& item, int64_t val);

  /*
   * dynamic monitor
   */
  inline void Add(const std::string& item, int64_t val);
  inline void Filter();

  inline void HandleFamousData(const std::string& item, int64_t val);

  void Reset();
  inline void Clear();

  inline bool Query(
      const std::string& item,
      OUT time_t& version,
      OUT int64_t& result) const;

  inline bool Query(
      const std::string& item,
      const std::string& metric,
      OUT time_t& version,
      OUT int64_t& result) const;

  void Output(std::stringstream& ss) const;
  void OutputJson(std::stringstream& ss) const;
 
 private:
  bool Load_(DataBase& prev_db); 

 private:
  bool is_dynamic_;
  time_t version_;
  StaticStatics static_statics_;
  DynamicStatics dynamic_statics_;
};

void Statics::Inc(const std::string& item, int64_t val) {
  static_statics_.Inc(item, val);
}

void Statics::Set(const std::string& item, int64_t val) {
  static_statics_.Set(item, val);
}

void Statics::Add(const std::string& item, int64_t val) {
  dynamic_statics_.Add(item, val);
}

void Statics::Filter() {
  if (is_dynamic_) {
    dynamic_statics_.Filter();
  }
}

void Statics::HandleFamousData(const std::string& item, int64_t val) {
  is_dynamic_ ? dynamic_statics_.Add(item, val) : static_statics_.Set(item, val);
}

void Statics::Clear() {
  is_dynamic_ ? dynamic_statics_.Clear() : static_statics_.Clear();
}

bool Statics::Query(
    const std::string& item,
    time_t& version,
    int64_t& result) const {
  if (unlikely(is_dynamic_)) return false;

  version=version_;
  return static_statics_.Query(item, result);
}

bool Statics::Query(
    const std::string& item,
    const std::string& metric,
    time_t& version,
    int64_t& result) const {
  if (unlikely(!is_dynamic_)) return false;

  version=version_;
  return dynamic_statics_.Query(item, metric, result);
}

}}
