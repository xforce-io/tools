#pragma once

#include "../../public.h"

namespace xlib { namespace monitor {

class StaticStatics {
 private:
  typedef std::unordered_map<std::string, int64_t> Statics;

 public:
  bool Init(const std::string& name);

  inline void Inc(const std::string& item, int64_t val);
  inline void Set(const std::string& item, int64_t val);

  void Reset();
  void Clear() { statics_.clear(); }

  inline bool Query(const std::string& item, int64_t& result) const;

  void Output(std::stringstream& ss) const;
  void OutputJson(std::stringstream& ss) const;

 private:
  inline int64_t* GetItem_(const std::string& item); 

 private:
  std::string name_;
  Statics statics_; 
};

void StaticStatics::Inc(const std::string& item_arg, int64_t val) {
  int64_t* item = GetItem_(item_arg);
  if (likely(NULL!=item)) *item+=val;
}

void StaticStatics::Set(const std::string& item_arg, int64_t val) {
  int64_t* item = GetItem_(item_arg);
  if (likely(NULL!=item)) *item=val;
}

bool StaticStatics::Query(const std::string& item, int64_t& result) const {
  Statics::const_iterator iter = statics_.find(item);
  if (unlikely(statics_.end() == iter)) return false;

  result = iter->second;
  return true;
}

int64_t* StaticStatics::GetItem_(const std::string& item_arg) {
  Statics::iterator iter = statics_.find(item_arg);
  if (unlikely(statics_.end() == iter)) {
    std::pair<Statics::iterator, bool> ret = 
      statics_.insert(std::pair<std::string, int64_t>(item_arg, 0));
    if (!ret.second) {
      WARN("fail_insert_static_monitor_item[%s]", item_arg.c_str());
      return NULL;
    }

    iter = ret.first;
  }
  return &(iter->second);
}

}}
