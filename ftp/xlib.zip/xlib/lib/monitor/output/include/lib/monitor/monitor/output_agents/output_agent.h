#pragma once

#include "public.h"

namespace xlib { namespace monitor {

class MonitorCore;
class ConfOutputAgent;

class OutputAgent {
 public: 
  explicit OutputAgent();

  virtual bool Init(
      const MonitorCore& monitor_core,
      const ConfOutputAgent& conf_output_agent);

  virtual void Output()=0;
  void OutputAll(std::stringstream& ss);
  void OutputAllJson(std::stringstream& ss);

  virtual ~OutputAgent() {}

 protected:
  //const
  const MonitorCore* monitor_core_;
  time_t output_interval_;
  ///

  time_t last_output_time_in_sec_;
  std::vector<std::string> statics_;
};

}}
