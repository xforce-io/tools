#pragma once

#include "public.h"
#include "msg.h"
#include "token_map.h"
#include "output_agents/output_agents.h"
#include "monitor_core.h"

namespace xlib { namespace monitor {

class MonitorImpl;
class MonitorConf;

/*
 * TPD stands for thread private data
 */
class MonitorTPD {
 private:  
  typedef MonitorCore::Pipe Pipe;

 private:
  static const size_t kNumBitsSeq=20;
  static const size_t kNumBitsRand=12;

 public:
  MonitorTPD();

  void SetPipe(Pipe* pipe) { pipe_=pipe; }
  Pipe* GetPipe() { return pipe_; }
  inline uint32_t GenerateLocalToken();

 private: 
  Pipe* pipe_;
  uint32_t cur_seq_;
};

class MonitorImpl {
 public:
  typedef MonitorCore::Pipe Pipe;

 private:
  static const time_t kTokensCleanThrehold=100000;
  static const time_t kTokensCleanTimeoutInSec=600;
  static const char kSep = ',';
  
 public:
  MonitorImpl();

  bool Init(const std::string& conf_path);

  /*
   * @brief : Modify interfaces
   */
  //for static type
  inline int Inc(const std::string& sub_monitor, const std::string& item, int64_t val);
  inline int Set(const std::string& sub_monitor, const std::string& item, int64_t val);

  //for distribution type
  inline int Add(const std::string& sub_monitor, const std::string& item, int64_t val);

  //for time distribution type 
  inline size_t Tik(const std::string& sub_monitor, const std::string& pre_item);
  inline int Tok(size_t token);
  inline int Tok(size_t token, const std::string& post_item);
  inline int Tok(size_t token, int64_t post_item);

  inline int Filter(const std::string& sub_monitor);

  /*
   * @brief : Read interfaces
   */
  //for static type
  inline bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      OUT time_t& version, 
      OUT int64_t& result);

  //for distribution and time_distribution type
  //metric includes: 
  //  max, min, qps, num, begins, ends, lat_avg, lat_50, lat_85, lat_99 
  inline bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      const std::string& metric,
      OUT time_t& version, 
      OUT int64_t& result);

  std::string GenerateReport() const { return output_agents_->GenerateReport(); }

  virtual ~MonitorImpl();

 private:
  bool InitConf_(
    IN const std::string& conf_path,
    OUT MonitorConf& monitor_conf);

  bool InitConfSubMonitors_(
    IN pub::JsonType& conf,
    OUT MonitorConf& monitor_conf);

  bool InitConfOutputAgents_(
    IN pub::JsonType& conf,
    OUT MonitorConf& monitor_conf);

  int SendMsg_(
      const std::string& sub_monitor, 
      size_t cmd, 
      int64_t val=0);

  int SendMsg_(
      const std::string& sub_monitor, 
      const std::string& item, 
      size_t cmd, 
      int64_t val=0);

  int SendMsg_(
      const std::string& sub_monitor, 
      const std::string& pre_item, 
      const std::string& post_item, 
      size_t cmd, 
      int64_t val=0);

  inline Pipe* GetPipe_();
  inline uint32_t GenerateLocalToken_();
  inline static char* ReserveSpaceFromPipe_(Pipe& pipe, size_t size);

 private: 
  MonitorCore* monitor_core_;
  OutputAgents* output_agents_;
  MonitorConf monitor_conf_;
  pub::ThreadPrivacy thread_privacy_;
  TokenMap tokens_;

  bool end_;
};

uint32_t MonitorTPD::GenerateLocalToken() {
  ++cur_seq_;
  if (unlikely(cur_seq_ == (1<<kNumBitsSeq))) cur_seq_=0;
  return (cur_seq_<<kNumBitsRand) + random() % (1<<kNumBitsRand);
}

int MonitorImpl::Inc(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return SendMsg_(sub_monitor, item, Cmd::kInc, val);
}

int MonitorImpl::Set(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return SendMsg_(sub_monitor, item, Cmd::kSet, val);
}

int MonitorImpl::Add(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return SendMsg_(sub_monitor, item, Cmd::kAdd, val);
}

size_t MonitorImpl::Tik(const std::string& sub_monitor, const std::string& pre_item) {
  return tokens_.Set(GenerateLocalToken_(), sub_monitor, pre_item);
}

int MonitorImpl::Tok(size_t token) {
  TokenItem token_item;
  int ret = tokens_.Get(token, token_item);
  if (unlikely(!ret)) return -10;

  time_t cur_time_in_usec = pub::Time::GetCurrentUsec(true);
  return SendMsg_(
      token_item.sub_monitor,
      token_item.pre_item,
      Cmd::kAdd,
      cur_time_in_usec - token_item.tik_time);
}

int MonitorImpl::Tok(size_t token, const std::string& post_item) {
  TokenItem token_item;
  int ret = tokens_.Get(token, token_item);
  if (unlikely(!ret)) return -10;

  time_t cur_time_in_usec = pub::Time::GetCurrentUsec(true);
  ret = SendMsg_(
      token_item.sub_monitor,
      token_item.pre_item,
      Cmd::kAdd,
      cur_time_in_usec - token_item.tik_time);
  if (unlikely(ret)) return ret;

  return SendMsg_(
      token_item.sub_monitor,
      token_item.pre_item,
      post_item,
      Cmd::kAdd,
      cur_time_in_usec - token_item.tik_time);
}

int MonitorImpl::Tok(size_t token, int64_t post_item) {
  char post_item_str[50];
  sprintf(post_item_str, "%ld", post_item);
  return Tok(token, post_item_str);
}

int MonitorImpl::Filter(const std::string& sub_monitor) {
  return SendMsg_(sub_monitor, Cmd::kFilter, 0);
}

bool MonitorImpl::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    time_t& version, 
    int64_t& result) {
  return monitor_core_->Query(sub_monitor, item, version, result);
}

bool MonitorImpl::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    const std::string& metric,
    time_t& version, 
    int64_t& result) {
  return monitor_core_->Query(sub_monitor, item, metric, version, result);
}

MonitorImpl::Pipe* MonitorImpl::GetPipe_() {
  MonitorTPD& monitor_tpd = *RCAST<MonitorTPD*>(thread_privacy_.Get<MonitorTPD>(0));
  Pipe* pipe = monitor_tpd.GetPipe();
  if (unlikely(NULL==pipe)) {
    pipe = monitor_core_->RegistePipe();
    if (NULL==pipe) {
      FATAL("fail_get_pipe");
      return NULL;
    }

    monitor_tpd.SetPipe(pipe);
  }
  return pipe;
}

uint32_t MonitorImpl::GenerateLocalToken_() {
  return RCAST<MonitorTPD*>(thread_privacy_.Get<MonitorTPD>(0))->GenerateLocalToken();
}

char* MonitorImpl::ReserveSpaceFromPipe_(Pipe& pipe, size_t size) {
  return pipe.ReserveSpaceForNewMsg(size);
}

}}
