#pragma once

#include "public.h"
#include "local_limits.h"

namespace xlib { namespace monitor {

struct Cmd {
  enum {
    kInc,
    kDec,
    kSet,
    kAdd,
    kFilter,
  };
};

struct Msg {
  inline Msg(uint32_t cmd_arg, uint32_t sub_monitor_id);
  inline Msg(uint32_t cmd_arg, uint32_t sub_monitor_id, int64_t val_arg);

  uint32_t cmd;
  uint32_t sub_monitor_id;
  int64_t val;
};

Msg::Msg(uint32_t cmd_arg, uint32_t sub_monitor_id_arg) :
  cmd(cmd_arg),
  sub_monitor_id(sub_monitor_id_arg) {}

Msg::Msg(uint32_t cmd_arg, uint32_t sub_monitor_id_arg, int64_t val_arg) :
  cmd(cmd_arg),
  sub_monitor_id(sub_monitor_id_arg),
  val(val_arg) {}

}}
