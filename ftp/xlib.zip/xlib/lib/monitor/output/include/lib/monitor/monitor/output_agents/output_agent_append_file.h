#pragma once

#include "output_agent.h"

namespace xlib { namespace monitor {

class OutputAgentAppendFile : public OutputAgent {
 private:
  typedef OutputAgent Super;
  
 private:
  static const size_t kMaxLenPath=256;

 public:
  OutputAgentAppendFile();

  bool Init(
      const MonitorCore& monitor_core,
      const ConfOutputAgent& conf_output_agent);

  void Output();

 private:
  std::string dir_;
  std::string prefix_;

  char buf_path_[kMaxLenPath];
};

}}
