#pragma once

#include "public.h"

namespace xlib { namespace monitor {

class OutputAgent;
class MonitorCore;
class ConfOutputAgent;

class OutputAgents {
 private:
  typedef OutputAgents Self;
  typedef std::tr1::unordered_map<std::string, OutputAgent*> Agents;

 public:
  explicit OutputAgents();

  bool Init(
      const MonitorCore& monitor_core,
      const std::vector<ConfOutputAgent>& conf_output_agents,
      bool& end);

  std::string GenerateReport() const;

  virtual ~OutputAgents();
 
 private:
  static void* Run_(void* args);
  void Output_();

 private:
  //const
  const MonitorCore* monitor_core_;
  bool* end_;
  pthread_t tid_;
  ///

  Agents output_agents_;
};


}}
