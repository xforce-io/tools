#pragma once

#include "public.h"
#include "msg.h"
#include "conf.h"
#include "statics/statics.h"

namespace xlib { namespace monitor {

class FamousDataCollector;

class MonitorCore {
 public:  
  typedef pub::FixedMsgPipe<Msg> Pipe;
  typedef std::vector<Pipe*> Pipes;

  typedef pub::VersionManager<Statics, pub::ReloadPerInterval> VMStatics;
  typedef std::vector<VMStatics*> SelfdefSubMonitors;

  typedef std::tr1::unordered_map<
      std::string, 
      std::pair<VMStatics*, FamousDataCollector*> > FamousSubMonitors;

 private:
  static const size_t kNumMonitorVersions=3;
  static const size_t kBatchProcess=100000;

 public:
  MonitorCore();

  bool Init(const MonitorConf& monitor_conf, bool& end);
  Pipe* RegistePipe();

  inline bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      OUT time_t& version, 
      OUT int64_t& result);

  inline bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      const std::string& metric,
      OUT time_t& version, 
      OUT int64_t& result);

  inline const Statics* GetStatics(const std::string& name) const;

  virtual ~MonitorCore();

 private:
  static void* Run_(void* args);
 
 private:
  inline void ProcessSubMonitors_();
  bool ProcessSelfdefSubMonitors_();
  void ProcessFamousSubMonitors_();
 
 private:
  //const
  MonitorConf monitor_conf_;
  bool* end_;
  pthread_t tid_;
  //

  pub::DelayDelPtr<Pipes> pipes_; 
  pub::ThreadMutex pipe_mutex_;
  SelfdefSubMonitors selfdef_sub_monitors_;
  FamousSubMonitors famous_sub_monitors_;
  time_t last_famous_sub_monitor_in_sec_;
  size_t famous_sub_monitors_accu_;
};

bool MonitorCore::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    time_t& version, 
    int64_t& result) {
  const Statics* statics = GetStatics(sub_monitor);
  if (unlikely(NULL==statics)) return false;

  return statics->Query(item, version, result);
}

bool MonitorCore::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    const std::string& metric,
    time_t& version, 
    int64_t& result) {
  const Statics* statics = GetStatics(sub_monitor);
  if (unlikely(NULL==statics)) return false;

  return statics->Query(item, metric, version, result);
}

const Statics* MonitorCore::GetStatics(const std::string& name) const {
  int64_t id = monitor_conf_.GetSubMonitorId(name);
  if (id>=0 && NULL != selfdef_sub_monitors_[id]) {
    return &(selfdef_sub_monitors_[id]->GetDB());
  }

  FamousSubMonitors::const_iterator iter_2 = famous_sub_monitors_.find(name);
  return famous_sub_monitors_.end() != iter_2 ?
    &(iter_2->second.first->GetDB()) :
    NULL;
}

void MonitorCore::ProcessSubMonitors_() {
  bool ret = ProcessSelfdefSubMonitors_();
  if (!ret) usleep(1000);

  if (!(++famous_sub_monitors_accu_%100)) {
    famous_sub_monitors_accu_=0;
    ProcessFamousSubMonitors_();
  }
}

}}
