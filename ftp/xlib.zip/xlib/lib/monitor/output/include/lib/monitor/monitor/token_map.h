#pragma once

#include "public.h"

namespace xlib { namespace monitor {

struct TokenItem {
  std::string sub_monitor;
  std::string pre_item;
  time_t tik_time;
};

class TokenMap {
 public:
  typedef std::tr1::unordered_map<size_t, TokenItem> Tokens;

 private:
  static const size_t kNumAreas=100000;
 
 public:
  TokenMap(time_t token_clean_timeout_in_sec);

  inline size_t Set(
      uint32_t local_token,
      const std::string& sub_monitor, 
      const std::string& pre_item);

  inline bool Get(size_t token, TokenItem& token_item);
 
  inline virtual ~TokenMap();

 private:
  static size_t GetArea_(size_t token) { return token%kNumAreas; }
  void CleanupTimeouts_(time_t current_time_in_usec);

 private: 
  //const
  time_t token_clean_timeout_in_usec_;
  ///

  time_t last_clean_timeouts_in_usec_;
  Tokens* tokens_;
  pub::SpinLock* locks_;
};

size_t TokenMap::Set(
    uint32_t local_token,
    const std::string& sub_monitor, 
    const std::string& pre_item) {
  time_t current_time_in_usec = pub::Time::GetCurrentUsec(true);
  if (current_time_in_usec - last_clean_timeouts_in_usec_ > token_clean_timeout_in_usec_) {
    last_clean_timeouts_in_usec_=current_time_in_usec;
    CleanupTimeouts_(current_time_in_usec);
  }

  size_t token = ( (SCAST<size_t>(pub::Sys::GetTid()) << 32) | ((current_time_in_usec/1000)<<48) ) + 
    local_token;
  size_t area = GetArea_(token);
  if (unlikely(!locks_[area].Lock())) return 0;

  bool ret = (tokens_[area].insert(std::pair<size_t, TokenItem>(
      token, 
      (struct TokenItem){sub_monitor, pre_item, current_time_in_usec}))).second;
  locks_[area].Unlock();
  return ret ? token : 0;
}

bool TokenMap::Get(size_t token, TokenItem& token_item) {
  size_t area = GetArea_(token);
  Tokens& tokens = tokens_[area];
  if (unlikely(!locks_[area].Lock())) return false;

  Tokens::iterator iter = tokens.find(token);
  if (unlikely(tokens.end() == iter)) {
    locks_[area].Unlock();
    WARN("can't_find_token[%lu]", token);
    return false;
  }

  token_item = iter->second;
  tokens.erase(iter);
  locks_[area].Unlock();
  return true;
}

TokenMap::~TokenMap() {
  XLIB_DELETE_ARRAY(tokens_)
  XLIB_DELETE_ARRAY(locks_)
}

}}
