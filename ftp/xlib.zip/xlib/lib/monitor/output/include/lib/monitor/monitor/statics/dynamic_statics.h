#pragma once

#include "public.h"
#include "metrics/metrics.h"

namespace xlib { namespace monitor {

class DynamicStatics {
 public:
  typedef DynamicStatics Self;
  typedef std::unordered_map<std::string, Metric*> Metrics;

  struct SingleStatics {
    int64_t tmp_val;
    Metrics* metrics;
  };

  typedef std::unordered_map<std::string, SingleStatics> Statics;
 
 public:
  static const int64_t kInvalidVal = LONG_MIN; 
  
 public:
  DynamicStatics();
  bool Init(const std::string& name, const std::vector<std::string>& metrics);

  void Add(const std::string& item, int64_t val);
  inline void Filter();

  void Freeze();
  void Reset();
  void Clear();

  inline bool Query(const std::string& item, const std::string& metric, int64_t& result) const;
  void Output(std::stringstream& ss) const;
  void OutputJson(std::stringstream& ss) const;

  Self& operator=(const Self& self); 

  virtual ~DynamicStatics();

 private:
  inline Metrics* CreateMetrics_(const Metrics* metrics);
  Metric* CreateMetric_(const std::string& conf, const Metric* metric);
  inline void AddValToMetrics_(Metrics& metrics, int64_t val);

 private: 
  //const
  std::string name_;
  std::vector<std::string> metrics_;
  ///

  bool is_filter_mode_;
  Statics statics_;
};

void DynamicStatics::Filter() {
  is_filter_mode_ = true;
  Statics::iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    SingleStatics& single_statics = iter->second;
    if (kInvalidVal != single_statics.tmp_val) {
      AddValToMetrics_(*(single_statics.metrics), single_statics.tmp_val);
      single_statics.tmp_val = kInvalidVal;
    }
  }
}

bool DynamicStatics::Query(
    const std::string& item, 
    const std::string& metric, 
    int64_t& result) const {
  Statics::const_iterator iter = statics_.find(item);
  if (unlikely(statics_.end() == iter)) return false;

  const Metrics& metrics = *(iter->second.metrics);
  Metrics::const_iterator iter_metric = metrics.find(metric);
  if (unlikely(metrics.end() == iter_metric)) return false;

  result = iter_metric->second->Query();
  return true;
}

DynamicStatics::Metrics* DynamicStatics::CreateMetrics_(const Metrics* metrics) {
  Metrics* new_metrics = new (std::nothrow) Metrics;
  Metric* metric=NULL;
  for (size_t i=0; i < metrics_.size(); ++i) {
    metric = CreateMetric_(
        metrics_[i], 
        NULL!=metrics ? metrics->find(metrics_[i])->second : NULL);
    if (NULL==metric) return NULL;

    new_metrics->insert(std::pair<std::string, Metric*>(metrics_[i], metric));
  }
  return new_metrics;
}

void DynamicStatics::AddValToMetrics_(Metrics& metrics, int64_t val) {
  Metrics::iterator iter;
  for (iter = metrics.begin(); iter != metrics.end(); ++iter) {
    iter->second->Add(val);
  }
}

}}
