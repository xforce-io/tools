#pragma once

#include "public.h"
#include "../statics/statics.h"

namespace xlib { namespace monitor {

class FamousDataMetric {
 public:
  virtual void SetData(Statics& statics) const=0;
  virtual ~FamousDataMetric() {}
};

class FamousDataMetricMemConsumed : public FamousDataMetric {
 public:
  static const std::string kItemName;
  
 public:
  void SetData(Statics& statics) const; 
};

}}
