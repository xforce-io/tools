#pragma once

namespace xlib { namespace monitor {

namespace Limits {

static const size_t kMaxLenMonitorName=15;

}

}}
