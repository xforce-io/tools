#pragma once

#include "public.h"
#include "famous_data_metrics.h"

namespace xlib { namespace monitor {

class ConfSubMonitor;
class Statics;

class FamousDataCollector {
 public:
  bool Init(const ConfSubMonitor& conf_sub_monitor);
  inline void SetData(Statics& statics);
  virtual ~FamousDataCollector();

 private:
  std::vector<FamousDataMetric*> data_metrics_;
};

void FamousDataCollector::SetData(Statics& statics) {
  for (size_t i=0; i < data_metrics_.size(); ++i) {
    data_metrics_[i]->SetData(statics);
  }
}

}}
