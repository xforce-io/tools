#pragma once

#include "metric.h"

namespace xlib { namespace monitor {

class MetricAccu : public Metric {
 private:
  typedef MetricAccu Self;
  
 public:
  static const std::string kName;
  
 public:
  void Reset() { accu_=0; }
  void Add(int64_t /*val*/) { ++accu_; }
  void Copy(const Metric& other) { accu_ = SCAST<const Self&>(other).accu_; }

  const std::string& GetName() const { return kName; }
  int64_t Query() const { return accu_; }
  void Output(std::stringstream& ss) const;
 
 private:
  size_t accu_; 
};

class MetricMax : public Metric {
 private:
  typedef MetricMax Self;
  
 public:
  static const std::string kName;
  
 public:
  void Reset() { max_ = LONG_MIN; }
  void Add(int64_t val) { if (val>max_) max_=val; }
  void Copy(const Metric& other) { max_ = SCAST<const Self&>(other).max_; }

  const std::string& GetName() const { return kName; }
  int64_t Query() const { return max_; }
  void Output(std::stringstream& ss) const;
 
 private:
  int64_t max_; 
};

class MetricMin : public Metric {
 private:
  typedef MetricMin Self;
  
 public:
  static const std::string kName;
  
 public:
  void Reset() { min_=LONG_MAX; }
  void Add(int64_t val) { if (val<min_) min_=val; }
  void Copy(const Metric& other) { min_ = SCAST<const Self&>(other).min_; }

  const std::string& GetName() const { return kName; }
  int64_t Query() const { return min_; }
  void Output(std::stringstream& ss) const;
 
 private:
  int64_t min_; 
};

class MetricAverage : public Metric {
 private:
  typedef MetricAverage Self;
   
 public:
  static const std::string kName;
  
 public:
  MetricAverage();
  void Reset();
  inline void Add(int64_t val);
  void Copy(const Metric& other);
  void Freeze() {}

  const std::string& GetName() const { return kName; }
  int64_t Query() const { return GetAverage_(); }
  void Output(std::stringstream& ss) const;

 private:
  double GetAverage_() const;

 private:
  int64_t vals_;
  size_t num_vals_;
};

class MetricQPS: public Metric {
 private:
  typedef MetricQPS Self;
   
 public:
  static const std::string kName;
  
 public:
  MetricQPS() : qps_(0) {}
  void Reset();
  void Add(int64_t /*val*/) { ++count_; }
  void Copy(const Metric& other);
  void Freeze();

  const std::string& GetName() const { return kName; }
  int64_t Query() const { return qps_; }
  void Output(std::stringstream& ss) const;

 private:
  double GetQPS_();

 private:
  time_t start_time_;
  size_t count_;
  double qps_;
};

class MetricDistr: public Metric {
 private:
  typedef MetricDistr Self;
   
 public:
  static const std::string kName;
 
 private:
  static const size_t kGranularity=1000000;
  
 public:
  MetricDistr(const std::string& conf);
  bool Init();
  void Reset();
  inline void Add(int64_t val);
  void Copy(const Metric& other);
  void Freeze() { result_ = GetResult_(); }

  inline const std::string& GetName() const { return name_; }
  int64_t Query() const { return result_; }
  void Output(std::stringstream& ss) const;

  virtual ~MetricDistr();

 private:
  int64_t GetResult_() const;
 
 private:
  //const
  std::string name_;
  std::string conf_;
  ///

  double threshold_;
  int64_t low_bound_;
  int64_t up_bound_;
  double* dist_;
  size_t count_;

  int64_t result_;
};

void MetricAverage::Add(int64_t val) { 
  vals_+=val; 
  ++num_vals_; 
}

void MetricDistr::Add(int64_t val) {
  if (unlikely(val<low_bound_ || val>=up_bound_)) return;
  ++dist_[SCAST<size_t>(SCAST<double>(kGranularity) * (val-low_bound_)/ (up_bound_-low_bound_))];
  ++count_;
}

}}
