#ifndef LIB_MONITOR_MONITOR_H
#define LIB_MONITOR_MONITOR_H

#include <stdint.h>
#include <string>

namespace xlib { namespace monitor {

class MonitorImpl;

class Monitor {
 public:
  Monitor();

  bool Init(const std::string& conf_path);

  /*
   * @brief : Modify interfaces
   */
  //for static type
  int Inc(const std::string& sub_monitor, const std::string& item, int64_t val);
  int Set(const std::string& sub_monitor, const std::string& item, int64_t val);

  //for distribution type
  int Add(const std::string& sub_monitor, const std::string& item, int64_t val);

  //for time distribution type 
  size_t Tik(const std::string& sub_monitor, const std::string& pre_item);
  int Tok(size_t token);
  int Tok(size_t token, const std::string& post_item);
  int Tok(size_t token, int64_t post_item);

  int Filter(const std::string& sub_monitor);

  /*
   * @brief : Read interfaces
   */
  //for static type
  bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      time_t& version, 
      int64_t& result);

  //for distribution and time_distribution type
  //metric includes: 
  //  max, min, qps, num, begins, ends, lat_avg, lat_50, lat_85, lat_99 
  bool Query(
      const std::string& sub_monitor, 
      const std::string& item,
      const std::string& metric,
      time_t& version, 
      int64_t& result);

  std::string GenerateReport() const;

  virtual ~Monitor();

 private: 
  MonitorImpl* monitor_impl_;
};

}}

#endif
