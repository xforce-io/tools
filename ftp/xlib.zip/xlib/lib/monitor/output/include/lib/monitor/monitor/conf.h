#pragma once

#include "public.h"

namespace xlib { namespace monitor {

struct ConfSubMonitor {
  std::string name;
  size_t id;
  time_t publish_interval;
  bool is_famous;
  std::vector<std::string> famous_metrics;
  bool is_dynamic;
  std::vector<std::string> statics_metrics;
  std::string output_agent;
};

struct ConfOutputAgent {
  std::string name;
  std::string type;
  std::string dir;
  std::string prefix;
  time_t output_interval;
  std::vector<std::string> sub_monitors;
};

struct MonitorConf {
  typedef std::unordered_map<std::string, uint32_t> NameToId;

  size_t size_pipe;
  std::vector<ConfSubMonitor> conf_sub_monitors;
  std::vector<ConfOutputAgent> conf_output_agents;
  NameToId name_to_id;

  inline int64_t GetSubMonitorId(const std::string& sub_monitor) const;
};

int64_t MonitorConf::GetSubMonitorId(const std::string& sub_monitor) const {
  NameToId::const_iterator iter = name_to_id.find(sub_monitor);
  return name_to_id.end() != iter ? SCAST<int64_t>(iter->second) : -1;
}

}}
