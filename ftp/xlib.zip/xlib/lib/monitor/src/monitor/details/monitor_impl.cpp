#include "../monitor_impl.h"
#include "../conf.h"
#include "../monitor_core.h"
#include "../local_limits.h"

namespace xlib { namespace monitor {

MonitorTPD::MonitorTPD() :
  pipe_(NULL),
  cur_seq_(0) {
  srandom(pub::Sys::GetTid());
}

MonitorImpl::MonitorImpl() :
  monitor_core_(NULL),
  output_agents_(NULL),
  tokens_(kTokensCleanTimeoutInSec),
  end_(false) {}

bool MonitorImpl::Init(const std::string& conf_path) {
  NOTICE("init");

  bool ret = InitConf_(conf_path, monitor_conf_);
  if (!ret) return false;

  XLIB_NEW(monitor_core_, MonitorCore)
  ret = monitor_core_->Init(monitor_conf_, end_);
  if (!ret) return false;

  XLIB_NEW(output_agents_, OutputAgents)
  ret = output_agents_->Init(*monitor_core_, monitor_conf_.conf_output_agents, end_);
  if (!ret) return false;
  return true;
}

MonitorImpl::~MonitorImpl() {
  end_=true;
  XLIB_DELETE(output_agents_)
  XLIB_DELETE(monitor_core_)
}

bool MonitorImpl::InitConf_(const std::string& conf_path, MonitorConf& monitor_conf) {
  bool ret;
  pub::JsonType* conf = pub::JsonType::CreateConf(conf_path);
  XLIB_FAIL_HANDLE_FATAL(NULL==conf || !conf->IsDict(), 
      "fail_init_service_conf conf_path[%s]", conf_path.c_str())

  XLIB_FAIL_HANDLE_FATAL(!(*conf)["size_pipe"].IsInt(), "fail_size_pipe")
  monitor_conf.size_pipe = (*conf)["size_pipe"].AsInt();

  ret = InitConfSubMonitors_(*conf, monitor_conf);
  XLIB_FAIL_HANDLE_FATAL(!ret, "fail_init_conf_sub_monitors")

  ret = InitConfOutputAgents_(*conf, monitor_conf);
  XLIB_FAIL_HANDLE_FATAL(!ret, "fail_init_conf_output_agents")

  XLIB_DELETE(conf)
  return true;

  ERROR_HANDLE:
  XLIB_DELETE(conf)
  return false;
}

bool MonitorImpl::InitConfSubMonitors_(
    pub::JsonType& conf,
    MonitorConf& monitor_conf) {
  const pub::JsonType& sub_monitors = conf["sub_monitors"];
  XLIB_FAIL_HANDLE_FATAL(!sub_monitors.IsList(), "fail_get_sub_monitors")
  monitor_conf.conf_sub_monitors.resize(sub_monitors.AsList().size());
  for (size_t i=0; i < sub_monitors.AsList().size(); ++i) {
    bool ret;
    size_t j;
    ConfSubMonitor& cur_sub_monitor = monitor_conf.conf_sub_monitors[i];

    const pub::JsonType& sub_monitor = sub_monitors.AsList()[i];
    XLIB_FAIL_HANDLE_FATAL(!sub_monitor.IsDict(), "fail_get_sub_monitor")

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["name"].IsStr(), "fail_get_sub_monitor_name")
    cur_sub_monitor.name = sub_monitor["name"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 
        cur_sub_monitor.name.size() > Limits::kMaxLenMonitorName
          || 0 == cur_sub_monitor.name.size(), 
        "invalid_sub_monitor_name[%s]", cur_sub_monitor.name.c_str() )

    for (j=0; j<i; ++j) {
      if (monitor_conf.conf_sub_monitors[j].name == monitor_conf.conf_sub_monitors[i].name) {
        break;
      }
    }

    XLIB_FAIL_HANDLE_FATAL(0!=i && j!=i, "dup_sub_monitor_name[%s]", cur_sub_monitor.name.c_str());

    cur_sub_monitor.id = i;
    ret = (monitor_conf.name_to_id.insert(std::pair<std::string, size_t>(
        cur_sub_monitor.name,
        cur_sub_monitor.id))).second;
    XLIB_FAIL_HANDLE_FATAL(!ret, "fail_insert_to_name_to_id")

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["publish_interval"].IsInt(), "fail_get_public_interval")
    cur_sub_monitor.publish_interval = sub_monitor["publish_interval"].AsInt();
    XLIB_FAIL_HANDLE_FATAL( cur_sub_monitor.publish_interval <= 0, 
        "invalid_sub_monitor_publish_interval[%lu]", cur_sub_monitor.publish_interval )

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["is_famous"].IsInt(), "fail_get_is_famous")
    cur_sub_monitor.is_famous = sub_monitor["is_famous"].AsInt();

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["famous_metrics"].IsStr(), "fail_get_famous_metrics")
    pub::String::SplitStr(
        sub_monitor["famous_metrics"].AsStr(), 
        kSep, 
        cur_sub_monitor.famous_metrics);

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["is_dynamic"].IsInt(), "fail_get_is_dynamic")
    cur_sub_monitor.is_dynamic = sub_monitor["is_dynamic"].AsInt();

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["statics_metrics"].IsStr(), "fail_get_statics_metrics")
    pub::String::SplitStr(
        sub_monitor["statics_metrics"].AsStr(), 
        kSep, 
        cur_sub_monitor.statics_metrics);

    XLIB_FAIL_HANDLE_FATAL(!sub_monitor["output_agent"].IsStr(), "fail_get_sub_monitor_output_agent")
    cur_sub_monitor.output_agent = sub_monitor["output_agent"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 0 == cur_sub_monitor.output_agent.size(), 
        "invalid_sub_monitor_output_agent[%s]", cur_sub_monitor.output_agent.c_str() )
  }
  return true;

  ERROR_HANDLE:
  return false;
}

bool MonitorImpl::InitConfOutputAgents_(
    pub::JsonType& conf,
    MonitorConf& monitor_conf) {
  const pub::JsonType& output_agents = conf["output_agents"];
  XLIB_FAIL_HANDLE_FATAL(!output_agents.IsList(), "fail_get_output_agents")
  monitor_conf.conf_output_agents.resize(output_agents.AsList().size());
  for (size_t i=0; i < output_agents.AsList().size(); ++i) {
    size_t j;
    ConfOutputAgent& cur_output_agent = monitor_conf.conf_output_agents[i];

    const pub::JsonType& output_agent = output_agents.AsList()[i];
    XLIB_FAIL_HANDLE_FATAL(!output_agent.IsDict(), "fail_get_output_agent")

    XLIB_FAIL_HANDLE_FATAL(!output_agent["name"].IsStr(), "fail_get_output_agent_name")
    cur_output_agent.name = output_agent["name"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 0 == cur_output_agent.name.size(), 
        "invalid_output_agent_name[%s]", cur_output_agent.name.c_str() )

    for (j=0; j<i; ++j) {
      if (monitor_conf.conf_output_agents[j].name == cur_output_agent.name) {
        break;
      }
    }

    XLIB_FAIL_HANDLE_FATAL(0!=i && j!=i, "dup_output_agent_name[%s]", cur_output_agent.name.c_str());

    XLIB_FAIL_HANDLE_FATAL(!output_agent["type"].IsStr(), "fail_get_output_agent_type")
    cur_output_agent.type = output_agent["type"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 0 == cur_output_agent.type.size(), 
        "invalid_output_agent_type[%s]", cur_output_agent.type.c_str() )

    XLIB_FAIL_HANDLE_FATAL(!output_agent["dir"].IsStr(), "fail_get_output_agent_dir")
    cur_output_agent.dir = output_agent["dir"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 0 == cur_output_agent.dir.size(), 
        "invalid_output_agent_dir[%s]", cur_output_agent.dir.c_str() )

    XLIB_FAIL_HANDLE_FATAL(!output_agent["prefix"].IsStr(), "fail_get_output_agent_prefix")
    cur_output_agent.prefix = output_agent["prefix"].AsStr();
    XLIB_FAIL_HANDLE_FATAL( 0 == cur_output_agent.prefix.size(), 
        "invalid_output_agent_prefix[%s]", cur_output_agent.prefix.c_str() )

    XLIB_FAIL_HANDLE_FATAL(!output_agent["output_interval"].IsInt(), "fail_get_output_agent_output_interval")
    cur_output_agent.output_interval = output_agent["output_interval"].AsInt();
    XLIB_FAIL_HANDLE_FATAL( cur_output_agent.output_interval <= 0, 
        "invalid_output_agent_output_interval[%lu]", cur_output_agent.output_interval )
  }

  for (size_t i=0; i < monitor_conf.conf_sub_monitors.size(); ++i) {
    size_t j=0;
    while (j < monitor_conf.conf_output_agents.size()) {
      if (monitor_conf.conf_output_agents[j].name == 
          monitor_conf.conf_sub_monitors[i].output_agent) {
        monitor_conf.conf_output_agents[j].sub_monitors.push_back(
            monitor_conf.conf_sub_monitors[i].name);
        break;
      }
      ++j;
    }

    XLIB_FAIL_HANDLE_FATAL(j == monitor_conf.conf_output_agents.size(),
        "unknown_output_agent[%s] in_sub_monitor_conf[%lu]", 
        monitor_conf.conf_sub_monitors[i].output_agent.c_str(), i)
  }
  return true;

  ERROR_HANDLE:
  return false;
}

int MonitorImpl::SendMsg_(
    const std::string& sub_monitor, 
    size_t cmd, 
    int64_t val) {
  int64_t id = monitor_conf_.GetSubMonitorId(sub_monitor);
  if (unlikely(id<0)) return -1;

  if (unlikely( ( Cmd::kAdd == cmd && !(monitor_conf_.conf_sub_monitors[id].is_dynamic) ) 
      || ( Cmd::kAdd != cmd && monitor_conf_.conf_sub_monitors[id].is_dynamic )
      || monitor_conf_.conf_sub_monitors[id].is_famous ) ) {
    return -2;
  }

  Pipe* pipe = GetPipe_();
  if (unlikely(NULL==pipe)) return -3;

  bool ret = pipe->SendMsg(Msg(cmd, id, val));
  if (unlikely(!ret)) return -4;

  return 0;
}

int MonitorImpl::SendMsg_(
    const std::string& sub_monitor, 
    const std::string& item, 
    size_t cmd, 
    int64_t val) {
  int64_t id = monitor_conf_.GetSubMonitorId(sub_monitor);
  if (unlikely(id<0)) return -1;

  if (unlikely( ( Cmd::kAdd == cmd && !(monitor_conf_.conf_sub_monitors[id].is_dynamic) ) 
      || ( Cmd::kAdd != cmd && monitor_conf_.conf_sub_monitors[id].is_dynamic )
      || monitor_conf_.conf_sub_monitors[id].is_famous ) ) {
    return -2;
  }

  Pipe* pipe = GetPipe_();
  if (unlikely(NULL==pipe)) return -3;

  size_t size_msg = item.length() + 1;
  char* buf = ReserveSpaceFromPipe_(*pipe, size_msg);
  if (unlikely(NULL==buf)) return -4;

  strcpy(buf, item.c_str());
  bool ret = pipe->SendMsg(Msg(cmd, id, val), size_msg);
  if (unlikely(!ret)) return -5;

  return 0;
}

int MonitorImpl::SendMsg_(
    const std::string& sub_monitor, 
    const std::string& pre_item, 
    const std::string& post_item, 
    size_t cmd, 
    int64_t val) {
  int64_t id = monitor_conf_.GetSubMonitorId(sub_monitor);
  if (unlikely(id<0)) return -1;

  if (unlikely( ( Cmd::kAdd == cmd && !(monitor_conf_.conf_sub_monitors[id].is_dynamic) ) 
      || ( Cmd::kAdd != cmd && monitor_conf_.conf_sub_monitors[id].is_dynamic )
      || monitor_conf_.conf_sub_monitors[id].is_famous ) ) {
    return -2;
  }

  Pipe* pipe = GetPipe_();
  if (unlikely(NULL==pipe)) return -3;

  size_t size_msg = pre_item.length() + post_item.length() + 2;
  char* buf = ReserveSpaceFromPipe_(*pipe, size_msg);
  if (unlikely(NULL==buf)) return -4;

  strcpy(buf, pre_item.c_str());
  buf[pre_item.length()] = '.';
  buf += pre_item.length() + 1;

  strcpy(buf, post_item.c_str());
  bool ret = pipe->SendMsg(Msg(cmd, id, val), size_msg);
  if (unlikely(!ret)) return -5;

  return 0;
}

}}
