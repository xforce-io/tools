#include "../token_map.h"

namespace xlib { namespace monitor {

TokenMap::TokenMap(time_t token_clean_timeout_in_sec) :
  token_clean_timeout_in_usec_(token_clean_timeout_in_sec*1000000),
  last_clean_timeouts_in_usec_(0) {
  XLIB_NEW(tokens_, Tokens [kNumAreas]);
  XLIB_NEW(locks_, pub::SpinLock [kNumAreas]);
}

void TokenMap::CleanupTimeouts_(time_t current_time_in_usec) {
  for (size_t i=0; i<kNumAreas; ++i) {
    if (!locks_[i].Lock()) continue;

    Tokens::iterator iter;
    for (iter = tokens_[i].begin(); iter != tokens_[i].end();) {
      if (current_time_in_usec - iter->second.tik_time > token_clean_timeout_in_usec_) {
        tokens_[i].erase(iter++);
      } else {
        ++iter;
      }
    }

    locks_[i].Unlock();
  }
}

}}
