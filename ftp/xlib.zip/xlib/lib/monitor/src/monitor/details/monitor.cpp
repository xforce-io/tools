#include "../monitor.h"
#include "../monitor_impl.h"

namespace xlib { namespace monitor {

Monitor::Monitor() :
  monitor_impl_(NULL) {}

bool Monitor::Init(const std::string& conf_path) {
  monitor_impl_ = new (std::nothrow) MonitorImpl;
  return monitor_impl_->Init(conf_path);
}

int Monitor::Inc(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return monitor_impl_->Inc(sub_monitor, item, val);
}

int Monitor::Set(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return monitor_impl_->Set(sub_monitor, item, val);
}

int Monitor::Add(const std::string& sub_monitor, const std::string& item, int64_t val) {
  return monitor_impl_->Add(sub_monitor, item, val);
}

size_t Monitor::Tik(const std::string& sub_monitor, const std::string& pre_item) {
  return monitor_impl_->Tik(sub_monitor, pre_item);
}

int Monitor::Tok(size_t token) {
  return monitor_impl_->Tok(token);
}

int Monitor::Tok(size_t token, const std::string& post_item) {
  return monitor_impl_->Tok(token, post_item);
}

int Monitor::Tok(size_t token, int64_t post_item) {
  return monitor_impl_->Tok(token, post_item);
}

int Monitor::Filter(const std::string& sub_monitor) {
  return monitor_impl_->Filter(sub_monitor);
}

bool Monitor::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    time_t& version, 
    int64_t& result) {
  return monitor_impl_->Query(sub_monitor, item, version, result);
}

bool Monitor::Query(
    const std::string& sub_monitor, 
    const std::string& item,
    const std::string& metric,
    time_t& version, 
    int64_t& result) {
  return monitor_impl_->Query(sub_monitor, item, metric, version, result);
}

std::string Monitor::GenerateReport() const { 
  return monitor_impl_->GenerateReport(); 
}

Monitor::~Monitor() {
  if (NULL!=monitor_impl_) delete monitor_impl_;
}

}}
