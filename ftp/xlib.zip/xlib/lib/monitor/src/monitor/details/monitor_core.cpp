#include "../monitor_core.h"

#include <sys/prctl.h>
#include "../famous_data_collector/famous_data_collector.h"
#include "../conf.h"

namespace xlib { namespace monitor {

MonitorCore::MonitorCore() :
  tid_(0),
  last_famous_sub_monitor_in_sec_(0),
  famous_sub_monitors_accu_(0) {}

bool MonitorCore::Init(const MonitorConf& monitor_conf, bool& end) {
  monitor_conf_=monitor_conf;
  end_ = &end;

  selfdef_sub_monitors_.resize(monitor_conf.conf_sub_monitors.size());
  for (size_t i=0; i < monitor_conf.conf_sub_monitors.size(); ++i) {
    selfdef_sub_monitors_[i] = NULL;
  }

  int ret;
  pub::ReloadPerInterval::InitParams reload_params;
  for (size_t i=0; i < monitor_conf_.conf_sub_monitors.size(); ++i) {
    const ConfSubMonitor& conf_sub_monitor = monitor_conf_.conf_sub_monitors[i];
    reload_params.load_interval_in_sec = conf_sub_monitor.publish_interval;

    VMStatics* statics = new (std::nothrow) VMStatics;
    FamousDataCollector* famous_data_collector=NULL;

    ret = statics->Init(
        conf_sub_monitor.name,
        &monitor_conf_.conf_sub_monitors[i],
        &reload_params,
        kNumMonitorVersions);
    XLIB_FAIL_HANDLE(!ret)

    if (!conf_sub_monitor.is_famous) {
      selfdef_sub_monitors_[i] = statics;
    } else {
      XLIB_NEW(famous_data_collector, FamousDataCollector);
      ret = famous_data_collector->Init(conf_sub_monitor);
      XLIB_FAIL_HANDLE(!ret)

      ret = (famous_sub_monitors_.insert(
          std::pair< std::string, std::pair<VMStatics*, FamousDataCollector*> >(
              conf_sub_monitor.name,
              std::pair<VMStatics*, FamousDataCollector*>(statics, famous_data_collector)
          ))).second;
      XLIB_FAIL_HANDLE(!ret)
    }
    continue;

    ERROR_HANDLE:
    XLIB_DELETE(famous_data_collector)
    XLIB_DELETE(statics)
    FATAL("fail_regist_sub_monitor[%s] type[%d] ret[%d]", 
        conf_sub_monitor.name.c_str(),
        conf_sub_monitor.is_dynamic,
        ret);
    return false;
  }

  ret = pthread_create(&tid_, NULL, Run_, this);
  if (0!=ret) {
    FATAL("fail_create_monitor_core_thread");
    return false;
  }
  return true;
}

MonitorCore::Pipe* MonitorCore::RegistePipe() {
  bool ret = pipe_mutex_.Lock();
  if (!ret) return NULL;

  Pipes* new_pipes = new Pipes;
  if (!pipes_.IsNull()) *new_pipes = *pipes_;

  Pipe* new_pipe = new Pipe(monitor_conf_.size_pipe);
  new_pipes->push_back(new_pipe);
  pipes_.Change(*new_pipes);
  pipe_mutex_.Unlock();
  return new_pipe;
}

MonitorCore::~MonitorCore() {
  if (0!=tid_) {
    pthread_join(tid_, NULL);
  }

  SelfdefSubMonitors::iterator iter;
  for (iter = selfdef_sub_monitors_.begin(); iter != selfdef_sub_monitors_.end(); ++iter) {
    XLIB_DELETE(*iter)
  }

  FamousSubMonitors::iterator iter_2;
  for (iter_2 = famous_sub_monitors_.begin(); iter_2 != famous_sub_monitors_.end(); ++iter_2) {
    XLIB_DELETE(iter_2->second.first)
    XLIB_DELETE(iter_2->second.second)
  }

  if (!pipes_.IsNull()) {
    Pipes& pipes = *pipes_;
    for (size_t i=0; i < pipes.size(); ++i) {
      delete pipes[i];
    }
  }
}

void* MonitorCore::Run_(void* args) {
  prctl(PR_SET_NAME, "monitor");
  MonitorCore& monitor_core = *(RCAST<MonitorCore*>(args));
  NOTICE("start_monitor_core_thread");
  while (!(*monitor_core.end_)) {
    monitor_core.ProcessSubMonitors_();
  }
  monitor_core.ProcessSubMonitors_();
  NOTICE("stop_monitor_core_thread");
  return NULL;
}

bool MonitorCore::ProcessSelfdefSubMonitors_() {
  if (unlikely(pipes_.IsNull())) return false;

  bool ret;
  VMStatics* vm_statics;
  Pipes pipes = *pipes_;
  Statics* statics;
  bool msg_recv=false;
  for (size_t i=0; i < pipes.size(); ++i) {
    size_t num_processed=0;
    Pipe& pipe = *(pipes[i]);
    ssize_t last_sub_monitor_id=-1;
    vm_statics=NULL;

    pub::FixedMsgPipe<Msg>::Msg* msg = pipe.RecieveMsg(); 
    while (NULL!=msg) {
      msg_recv=true;
      vm_statics = selfdef_sub_monitors_[msg->msg_header.sub_monitor_id];

      if (msg->msg_header.sub_monitor_id != last_sub_monitor_id) { 
        if (-1 != last_sub_monitor_id) {
          vm_statics->FreezeNewVersion();
        }

        ret = vm_statics->CreateNewVersion();
        XLIB_FAIL_HANDLE(!ret)
      }
      last_sub_monitor_id = msg->msg_header.sub_monitor_id;

      statics = &(vm_statics->GetWritableDB());
      switch (msg->msg_header.cmd) {
        case Cmd::kAdd : {
          statics->Add(msg->msg, msg->msg_header.val);
          break;
        }
        case Cmd::kFilter : {
          statics->Filter();
          break;
        }
        case Cmd::kInc : {
          statics->Inc(msg->msg, msg->msg_header.val); 
          break;
        }
        case Cmd::kSet : {
          statics->Set(msg->msg, msg->msg_header.val); 
          break;
        }
        default : {
          XLIB_FAIL_HANDLE_FATAL(true, "unknown_msg_cmd[%lu]", msg->msg_header.cmd);
          break;
        }
      }

      pipe.MsgConsumed();

      if (++num_processed<=kBatchProcess) break;

      msg = pipe.RecieveMsg(); 
      continue;

      ERROR_HANDLE:
      pipe.MsgConsumed();
      msg = pipe.RecieveMsg(); 
    }

    if (NULL!=vm_statics) {
      vm_statics->FreezeNewVersion();
    }
  }

  if (!msg_recv) {
    for (size_t i=0; i < selfdef_sub_monitors_.size(); ++i) {
      vm_statics = selfdef_sub_monitors_[i];
      if (NULL!=vm_statics) {
        ret = vm_statics->CreateNewVersion();
        if (ret) vm_statics->FreezeNewVersion();
      }
    }
  }
  return msg_recv;
}

void MonitorCore::ProcessFamousSubMonitors_() {
  time_t current_time_in_sec = pub::Time::GetCurrentSec(true);
  if (unlikely(current_time_in_sec == last_famous_sub_monitor_in_sec_)) return;

  last_famous_sub_monitor_in_sec_ = current_time_in_sec;

  FamousSubMonitors::iterator iter;
  for (iter = famous_sub_monitors_.begin(); iter != famous_sub_monitors_.end(); ++iter) {
    VMStatics& vm_statics = *(iter->second.first);
    FamousDataCollector& famous_data_collector = *(iter->second.second);
    bool ret = vm_statics.CreateNewVersion();
    if (!ret) continue;

    Statics& statics = vm_statics.GetWritableDB();
    famous_data_collector.SetData(statics);

    vm_statics.FreezeNewVersion();
  }
}

}}
