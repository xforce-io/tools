#include "../output_agents.h"
#include "../../conf.h"
#include "../output_agent_append_file.h"

namespace xlib { namespace monitor {

OutputAgents::OutputAgents() :
  tid_(0) {}

bool OutputAgents::Init(
    const MonitorCore& monitor_core, 
    const std::vector<ConfOutputAgent>& conf_output_agents,
    bool& end) {
  int ret;
  monitor_core_ = &monitor_core;
  end_ = &end;
  for (size_t i=0; i < conf_output_agents.size(); ++i) {
    if ("append_file" == conf_output_agents[i].type) {
      OutputAgentAppendFile* output_agent;
      XLIB_NEW(output_agent, OutputAgentAppendFile)
      ret = output_agent->Init(monitor_core, conf_output_agents[i]);
      if (true!=ret) {
        XLIB_DELETE(output_agent)
        return false;
      }

      ret = (output_agents_.insert(std::pair<std::string, OutputAgent*>(
          conf_output_agents[i].name, output_agent))).second;
      if (true!=ret) {
        XLIB_DELETE(output_agent)
        return false;
      }
    } else {
      FATAL("unknown_output_agent_type[%s]", conf_output_agents[i].type.c_str());
      return false;
    }
  }

  ret = pthread_create(&tid_, NULL, Run_, this);
  if (0!=ret) {
    FATAL("fail_start_output_agents_threads");
    return false;
  }
  return true;
}

std::string OutputAgents::GenerateReport() const {
  std::stringstream ss;
  for (Agents::const_iterator iter = output_agents_.begin(); 
      iter != output_agents_.end();
      ++iter) {
    iter->second->OutputAllJson(ss);
  }
  return ss.str();
}

OutputAgents::~OutputAgents() {
  if (0!=tid_) {
    pthread_join(tid_, NULL);
  }

  for (Agents::iterator iter = output_agents_.begin(); 
      iter != output_agents_.end();
      ++iter) {
    XLIB_DELETE(iter->second)
  }
}

void* OutputAgents::Run_(void* args) {
  NOTICE("output_agents_thread_start");
  Self& self = *(RCAST<Self*>(args));
  while (!(*self.end_)) {
    self.Output_();
    sleep(1);
  }
  self.Output_();
  NOTICE("output_agents_thread_stop");
  return NULL;
}

void OutputAgents::Output_() {
  for (Agents::iterator iter = output_agents_.begin(); 
      iter != output_agents_.end();
      ++iter) {
    iter->second->Output();
  }
}

}}
