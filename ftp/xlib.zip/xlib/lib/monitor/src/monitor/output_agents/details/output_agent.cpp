#include "../output_agent.h"
#include "../../monitor_core.h"
#include "../../statics/statics.h"

namespace xlib { namespace monitor {

OutputAgent::OutputAgent() :
  monitor_core_(NULL),
  last_output_time_in_sec_(0) {}

bool OutputAgent::Init(
    const MonitorCore& monitor_core,
    const ConfOutputAgent& conf_output_agent) {
  monitor_core_ = &monitor_core;
  output_interval_ = conf_output_agent.output_interval;
  statics_ = conf_output_agent.sub_monitors;
  return true;
}

void OutputAgent::OutputAll(std::stringstream& ss) {
  for (size_t i=0; i < statics_.size(); ++i) {
    monitor_core_->GetStatics(statics_[i])->Output(ss);
  }
}

void OutputAgent::OutputAllJson(std::stringstream& ss) {
  ss << "[";
  for (size_t i=0; i < statics_.size(); ++i) {
    if (0!=i) {
      ss << ",";
    }

    monitor_core_->GetStatics(statics_[i])->OutputJson(ss);
  }
  ss << "]";
}

}}
