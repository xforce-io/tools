#include "../output_agent_append_file.h"
#include "../../conf.h"

namespace xlib { namespace monitor {

OutputAgentAppendFile::OutputAgentAppendFile() :
  OutputAgent() {}

bool OutputAgentAppendFile::Init(
    const MonitorCore& monitor_core,
    const ConfOutputAgent& conf_output_agent) {
  if (!Super::Init(monitor_core, conf_output_agent)) return false;

  dir_ = conf_output_agent.dir;
  prefix_ = conf_output_agent.prefix;
  return true;
}

void OutputAgentAppendFile::Output() {
  time_t current_time_in_sec = pub::Time::GetCurrentSec(true);
  if (current_time_in_sec-last_output_time_in_sec_ < output_interval_) return;

  std::stringstream ss;
  OutputAll(ss);

  struct tm time;
  localtime_r(&current_time_in_sec, &time);
  snprintf(buf_path_, 
      sizeof(buf_path_)-1, 
      "%s/%s_%04d_%02d%02d",
      dir_.c_str(),
      prefix_.c_str(),
      (time.tm_year + 1900),
      (time.tm_mon + 1),
      time.tm_mday);

  FILE* fp = fopen(buf_path_, "a");
  if (NULL==fp) {
    WARN("fail_open_path[%s]", buf_path_);
    return;
  }

  fprintf(fp, "%s", ss.str().c_str());  
  fclose(fp);
  last_output_time_in_sec_ = pub::Time::GetCurrentSec(true);
}

}}
