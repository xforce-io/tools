#include "../famous_data_metrics.h"

namespace xlib { namespace monitor {

const std::string FamousDataMetricMemConsumed::kItemName = "mem";

void FamousDataMetricMemConsumed::SetData(Statics& statics) const {
  size_t vmrss = pub::Sys::GetVmRSS(getpid());
  if (0==vmrss) {
    FATAL("fail_get_current_vmrss");
    return;
  }
  statics.HandleFamousData(kItemName, vmrss);
}

}}
