#include "../famous_data_collector.h"
#include "../famous_data_metrics.h"
#include "../../conf.h"

namespace xlib { namespace monitor {

bool FamousDataCollector::Init(const ConfSubMonitor& conf_sub_monitor) {
  for (size_t i=0; i < conf_sub_monitor.famous_metrics.size(); ++i) {
    FamousDataMetric* famous_data_metric=NULL;
    if (conf_sub_monitor.famous_metrics[i] == FamousDataMetricMemConsumed::kItemName) {
      XLIB_NEW(famous_data_metric, FamousDataMetricMemConsumed)
      data_metrics_.push_back(famous_data_metric);
    } else {
      FATAL("unknown_famous_data_metrics[%s]",  conf_sub_monitor.famous_metrics[i].c_str());
      return false;
    }
  }
  return true;
}

FamousDataCollector::~FamousDataCollector() {
  for (size_t i=0; i < data_metrics_.size(); ++i) {
    XLIB_DELETE(data_metrics_[i])
  }
}

}}
