#include "../dynamic_statics.h"
#include "../../local_limits.h"

namespace xlib { namespace monitor {

DynamicStatics::DynamicStatics() :
  is_filter_mode_(false) {}

bool DynamicStatics::Init(const std::string& name, const std::vector<std::string>& metrics) {
  name_=name;

  Metric* metric=NULL;
  for (size_t i=0; i < metrics.size(); ++i) {
    metric = CreateMetric_(metrics[i], NULL);
    if (NULL==metric) return false;

    XLIB_DELETE(metric)
  }
  metrics_=metrics;
  return true;
}

void DynamicStatics::Add(const std::string& item, int64_t val) {
  Statics::iterator iter = statics_.find(item);
  if (unlikely(statics_.end() == iter)) {
    SingleStatics single_statics;
    single_statics.tmp_val = kInvalidVal;
    single_statics.metrics = CreateMetrics_(NULL);
    if (NULL == single_statics.metrics) return;

    std::pair<Statics::iterator, bool> ret_insert;
    ret_insert = statics_.insert(std::pair<std::string, SingleStatics>(item, single_statics));
    if (!ret_insert.second) {
      FATAL("fail_insert_into_statics");
      return;
    }
    iter = ret_insert.first;
  }

  SingleStatics& single_statics = iter->second;
  if (is_filter_mode_) {
    single_statics.tmp_val = val;
  } else {
    AddValToMetrics_(*(single_statics.metrics), val);
  }
}

void DynamicStatics::Freeze() {
  Statics::iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    Metrics& metrics = *(iter->second.metrics);
    Metrics::iterator iter;
    for (iter = metrics.begin(); iter != metrics.end(); ++iter) {
      iter->second->Freeze();
    }
  }
}

void DynamicStatics::Reset() {
  Statics::iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    Metrics& metrics = *(iter->second.metrics);
    Metrics::iterator iter_2;
    for (iter_2 = metrics.begin(); iter_2 != metrics.end(); ++iter_2) {
      iter_2->second->Reset();
    }
  }
}

void DynamicStatics::Clear() {
  Statics::iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    Metrics* metrics = iter->second.metrics;
    Metrics::iterator iter_2;
    for (iter_2 = metrics->begin(); iter_2 != metrics->end(); ++iter_2) {
      XLIB_DELETE(iter_2->second)
    }
    XLIB_DELETE(metrics)
  }
  statics_.clear();
}

void DynamicStatics::Output(std::stringstream& ss) const {
  if (statics_.empty()) return;

  char current_time[50];
  time_t current_time_in_sec = pub::Time::GetCurrentSec(true);
  struct tm time;
  localtime_r(&current_time_in_sec, &time);
  snprintf(current_time, 
      sizeof(current_time)-1, 
      "%02d%02d%02d",
      time.tm_hour,
      time.tm_min,
      time.tm_sec);

  ss << current_time << "-" << std::setw(Limits::kMaxLenMonitorName) << name_ << "-";

  Statics::const_iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    if (iter != statics_.begin()) {
      ss << std::setw(23) << " ";
    }
    ss << "[" << iter->first << "]{";
    const Metrics& metrics = *(iter->second.metrics);
    Metrics::const_iterator iter;
    for (iter = metrics.begin(); iter != metrics.end(); ++iter) {
      const Metric& metric = *(iter->second);
      metric.Output(ss);
      ss << ", ";
    }
    ss << "} " << std::endl;
  }
}

void DynamicStatics::OutputJson(std::stringstream& ss) const {
  ss << "{\"" << name_ << "\" : {";

  Statics::const_iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    if (iter != statics_.begin()) { ss << ", "; }
    ss << "\"" << iter->first << "\"" << " : {";
    const Metrics& metrics = *(iter->second.metrics);
    Metrics::const_iterator iter;
    for (iter = metrics.begin(); iter != metrics.end(); ++iter) {
      if (iter != metrics.begin()) { ss << ", "; }

      const Metric& metric = *(iter->second);
      metric.Output(ss);
    }
    ss << "}";
  }
  ss << "}}";
}

DynamicStatics& DynamicStatics::operator=(const Self& other) {
  Clear();
  
  metrics_ = other.metrics_;
  is_filter_mode_ = other.is_filter_mode_;

  Statics::const_iterator iter;
  for (iter = other.statics_.begin(); iter != other.statics_.end(); ++iter) {
    SingleStatics single_statics;
    single_statics.tmp_val = kInvalidVal;
    single_statics.metrics = CreateMetrics_(iter->second.metrics);
    bool ret = (statics_.insert(std::pair<std::string, SingleStatics>(
        iter->first,
        single_statics))).second;
    XLIB_STOP(NULL == single_statics.metrics || !ret)
  }
  return *this;
}

DynamicStatics::~DynamicStatics() {
  Clear();
}

Metric* DynamicStatics::CreateMetric_(const std::string& conf, const Metric* metric) {
  Metric* new_metric=NULL;
  if (MetricAccu::kName == conf) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricAccu);
  } else if (MetricMax::kName == conf) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricMax);
  } else if (MetricMin::kName == conf) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricMin);
  } else if (MetricAverage::kName == conf) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricAverage);
  } else if (MetricQPS::kName == conf) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricQPS);
  } else if (MetricDistr::kName == conf.substr(0, MetricDistr::kName.size())) {
    new_metric = SCAST<Metric*>(new (std::nothrow) MetricDistr(conf.substr(5)));
  } else {
    FATAL("unknown_metric[%s]", conf.c_str());
    return NULL;
  }

  if (NULL!=metric) {
    new_metric->Copy(*metric);
  } else {
    bool ret = new_metric->Init();
    if (!ret) {
      delete new_metric;
      return NULL;
    }
  }

  return new_metric;
}

}}
