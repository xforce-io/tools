#include "../statics.h"
#include "../../conf.h"

namespace xlib { namespace monitor {

bool Statics::Init(const std::string& name, void* init_params) {
  Super::Init_(name);

  ConfSubMonitor& conf_sub_monitor = *(RCAST<ConfSubMonitor*>(init_params));
  is_dynamic_ = conf_sub_monitor.is_dynamic;

  bool ret;
  if (is_dynamic_) {
    ret = dynamic_statics_.Init(name, conf_sub_monitor.statics_metrics); 
    dynamic_statics_.Reset();
  } else {
    ret = static_statics_.Init(name);
    static_statics_.Reset();
  }
  return ret;
}

void Statics::Reset() {
  is_dynamic_ ? dynamic_statics_.Reset() : static_statics_.Reset();
}

void Statics::Output(std::stringstream& ss) const {
  is_dynamic_ ? dynamic_statics_.Output(ss) : static_statics_.Output(ss);
}

void Statics::OutputJson(std::stringstream& ss) const {
  is_dynamic_ ? dynamic_statics_.OutputJson(ss) : static_statics_.OutputJson(ss);
}

bool Statics::Load_(DataBase& prev_db) {
  Statics& statics = RCAST<Statics&>(prev_db);
  if (is_dynamic_) {
    dynamic_statics_ = statics.dynamic_statics_;
    statics.dynamic_statics_.Freeze();
  } else {
    static_statics_ = statics.static_statics_;
  }
  Reset();
  version_ = pub::Time::GetCurrentUsec(true);
  return true;
}

}}
