#include "../static_statics.h"
#include "../../local_limits.h"

namespace xlib { namespace monitor {

bool StaticStatics::Init(const std::string& name) {
  name_=name;
  return true;
}

void StaticStatics::Reset() {
  Statics::iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    iter->second = 0;
  }
}

void StaticStatics::Output(std::stringstream& ss) const {
  if (statics_.empty()) return;

  char current_time[50];
  time_t current_time_in_sec = pub::Time::GetCurrentSec(true);
  struct tm time;
  localtime_r(&current_time_in_sec, &time);
  snprintf(current_time, 
      sizeof(current_time)-1, 
      "%02d%02d%02d",
      time.tm_hour,
      time.tm_min,
      time.tm_sec);

  ss << std::setw(Limits::kMaxLenMonitorName) << name_ << " -- {";
  Statics::const_iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    ss << "\"" << iter->first << "\":" << iter->second << "\n";
  }
  ss << "}" << std::endl;
}

void StaticStatics::OutputJson(std::stringstream& ss) const {
  ss << "{\"" << name_ << "\" : {";
  Statics::const_iterator iter;
  for (iter = statics_.begin(); iter != statics_.end(); ++iter) {
    if (iter != statics_.begin()) {
      ss << ", ";
    }
    ss << "\"" << iter->first << "\"" << " : " << iter->second;
  }
  ss << "}}";
}

}}
