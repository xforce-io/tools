#include "../metrics.h"

namespace xlib { namespace monitor {

const std::string MetricAccu::kName = "accu";
const std::string MetricMax::kName = "max";
const std::string MetricMin::kName = "min";
const std::string MetricAverage::kName = "avg";
const std::string MetricQPS::kName = "qps";
const std::string MetricDistr::kName = "dist_";

void MetricAccu::Output(std::stringstream& ss) const {
  ss << "\"" << kName << "\"" << " : " << accu_;
}

void MetricMax::Output(std::stringstream& ss) const {
  if (LONG_MIN==max_) {
    ss << "\"" << kName << "\"" << " : 0";
  } else {
    ss << "\"" << kName << "\"" << " : " << max_;
  }
}

void MetricMin::Output(std::stringstream& ss) const {
  if (LONG_MAX==min_) {
    ss << "\"" << kName << "\"" << " : 0";
  } else {
    ss << "\"" << kName << "\"" << " : " << min_;
  }
}

MetricAverage::MetricAverage() {
  Reset();
}

void MetricAverage::Reset() { 
  vals_=0;
  num_vals_=0;
}

void MetricAverage::Copy(const Metric& other) { 
  vals_ = SCAST<const Self&>(other).vals_; 
  num_vals_ = SCAST<const Self&>(other).num_vals_; 
}

void MetricAverage::Output(std::stringstream& ss) const {
  ss << "\"" << kName << "\"" << " : " << GetAverage_();
}

double MetricAverage::GetAverage_() const {
  return 0!=num_vals_ ? vals_*1.0/num_vals_ : 0;
}

void MetricQPS::Reset() {
  start_time_ = pub::Time::GetCurrentUsec(true);
  count_=0;
}

void MetricQPS::Copy(const Metric& other) {
  start_time_ = SCAST<const Self&>(other).start_time_;
  count_ = SCAST<const Self&>(other).count_;
}

void MetricQPS::Freeze() {
  qps_ = GetQPS_();
}

void MetricQPS::Output(std::stringstream& ss) const {
  ss << "\"" << kName << "\"" << " : " << qps_;
}

double MetricQPS::GetQPS_() {
  time_t diff = (pub::Time::GetCurrentUsec(true) - start_time_);
  if (unlikely(0==diff)) return 0;

  return count_*1000000/diff;
}

MetricDistr::MetricDistr(const std::string& conf) :
  conf_(conf),
  threshold_(0),
  dist_(NULL) {
  dist_ = new double [kGranularity];
}

bool MetricDistr::Init() {
  Reset();

  std::stringstream ss;
  const char* ptr = conf_.c_str();
  char* endptr;
  threshold_ = strtod(ptr, &endptr);
  XLIB_FAIL_HANDLE('(' != *endptr || threshold_<=0 || threshold_>=1)

  ptr = endptr + 1;
  low_bound_ = strtol(ptr, &endptr, 10);
  XLIB_FAIL_HANDLE('-' != *endptr)

  ptr = endptr + 1;
  up_bound_ = strtol(ptr, &endptr, 10);
  XLIB_FAIL_HANDLE(')' != *endptr || low_bound_>=up_bound_)

  ss << kName << threshold_;
  name_ = ss.str();
  return true; 

  ERROR_HANDLE:
  FATAL("invalid_metric_distr_conf[%s]", conf_.c_str());
  return false;
}

void MetricDistr::Reset() { 
  bzero(dist_, sizeof(dist_[0]) * kGranularity); 
  count_=0;
}

void MetricDistr::Copy(const Metric& other) {
  conf_ = SCAST<const Self&>(other).conf_;
  threshold_ = SCAST<const Self&>(other).threshold_;
  low_bound_ = SCAST<const Self&>(other).low_bound_;
  up_bound_ = SCAST<const Self&>(other).up_bound_;
  memcpy(dist_, SCAST<const Self&>(other).dist_, sizeof(dist_[0]) * kGranularity);
  count_ = SCAST<const Self&>(other).count_;

  std::stringstream ss;
  ss << kName << threshold_;
  name_ = ss.str();
}

void MetricDistr::Output(std::stringstream& ss) const {
  ss << "\"" << kName << threshold_ << "\"" << " : " << result_;
}

int64_t MetricDistr::GetResult_() const {
  size_t tmp_count=0;
  double threshold = threshold_*count_;
  for (size_t i=0; i<kGranularity; ++i) {
    tmp_count += dist_[i];
    if (tmp_count>=threshold) {
      return i*(up_bound_-low_bound_)/kGranularity + low_bound_;
    }
  }
  return up_bound_;
}

MetricDistr::~MetricDistr() {
  if (NULL!=dist_) {
    delete [] dist_;
  }
}

}}
