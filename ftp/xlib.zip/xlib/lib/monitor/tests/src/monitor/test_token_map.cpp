#include "gtest/gtest.h"
#include "monitor/token_map.h"

using namespace xlib;
using namespace xlib::Monitor;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_token_map, all) {
  TokenMap token_map(1);
  size_t token = token_map.Set(0, "sub_monitor", "pre_item");
  ASSERT_NE(token, 0);

  TokenItem token_item;
  bool ret = token_map.Get(token, token_item);
  ASSERT_TRUE(true==ret);
  ASSERT_TRUE(token_item.sub_monitor == "sub_monitor");
  ASSERT_TRUE(token_item.pre_item == "pre_item");

  ret = token_map.Get(token+1, token_item);
  ASSERT_TRUE(false==ret);

  for (size_t i=1; i<=10000; ++i) {
    size_t token = token_map.Set(i, "sub_monitor", "pre_item");
    ASSERT_NE(token, 0);
  }
  sleep(1);

  for (size_t i=10001; i<=25000; ++i) {
    size_t token = token_map.Set(i, "sub_monitor", "pre_item");
    ASSERT_NE(token, 0);
  }

  size_t count=0;
  for (size_t i=0; i < TokenMap::kNumAreas; ++i) {
    count += token_map.tokens_[i].size();
  }
  ASSERT_TRUE(count < 20000);
}
