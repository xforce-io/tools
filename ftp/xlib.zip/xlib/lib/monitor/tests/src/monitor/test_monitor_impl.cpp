#include "gtest/gtest.h"
#include "monitor/monitor_impl.h"

using namespace xlib;
using namespace xlib::Monitor;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_init_conf, positive) {
  MonitorConf monitor_conf;
  MonitorImpl monitor;
  bool ret = monitor.InitConf_("conf/monitor.conf", monitor_conf);
  ASSERT_TRUE(ret);

  ASSERT_EQ(2, monitor_conf.conf_sub_monitors.size());
  ASSERT_EQ(3, monitor_conf.conf_sub_monitors[0].statics_metrics.size());
  ASSERT_EQ(1, monitor_conf.conf_sub_monitors[0].is_famous);
  ASSERT_EQ(0, monitor_conf.conf_sub_monitors[1].is_famous);
  ASSERT_EQ(1, monitor_conf.conf_sub_monitors[1].famous_metrics.size());

  ASSERT_EQ(1, monitor_conf.conf_output_agents.size());
  ASSERT_EQ(2, monitor_conf.conf_output_agents[0].sub_monitors.size());
  ASSERT_TRUE("rtb_server_2" == monitor_conf.conf_output_agents[0].sub_monitors[1]);
}

TEST(test_init_conf, passive) {
  system("cp conf/monitor.conf conf/tmp.conf; "
      "sed -i 's/rtb_server_2/rtb_server/g' conf/tmp.conf");

  MonitorConf monitor_conf;
  MonitorImpl monitor;
  bool ret = monitor.InitConf_("conf/tmp.conf", monitor_conf);
  ASSERT_TRUE(!ret);

  system("cp conf/monitor.conf conf/tmp.conf; "
      "sed -i 's/output_agent = rtb_report/output_agent = rtb_report_2/g' conf/tmp.conf");

  ret = monitor.InitConf_("conf/tmp.conf", monitor_conf);
  ASSERT_TRUE(!ret);
}

//static unsigned int Seed=0;

void* BizThread(void* arg) {
  MonitorImpl& monitor = *(RCAST<MonitorImpl*>(arg));

  static const size_t kNumQueries = 300000000;
  static const std::string kQueries[] = {"0", "1", "2", "3", "4"};
  static const size_t kSpeedStep=200000;
  size_t speed = 1000000;
  time_t last_time = pub::Time::GetCurrentUsec(true);
  size_t last_acc = 0;
  ssize_t ret=0;
  size_t i=0;
  size_t accu=0;
  while (i < kNumQueries) {
    ++accu;
    if (!(i%1000)) {
      time_t current_time = pub::Time::GetCurrentUsec(true);
      if (last_time/1000000 == current_time/1000000) {
        if (current_time==last_time 
            || (i-last_acc)*1000000 / (current_time-last_time) > speed) {
          usleep(1);
          continue;
        }
      } else {
        std::cout << "accu " << accu << " in last sec" << std::endl;
        accu=0;
        if (0==ret) {
          speed+=kSpeedStep;
        } else {
          if (speed <= 10*kSpeedStep) {
            speed = kSpeedStep;
          } else {
            speed -= 10*kSpeedStep;
          }
        }
        std::cout << "speed change to " << speed << " i " << i << std::endl;

        last_time=current_time;
        last_acc=i;
        ret=0;
      }
    }

    ret = monitor.Tik("rtb_server_2", "he");
    assert(ret);

    ret = monitor.Tok(ret, kQueries[i%5]);
    if (ret) {
      std::cout << "ret " << ret << std::endl;
    }
/*
    ret = monitor.Add("rtb_server_2", kQueries[i%5], rand_r(&Seed)%1000);
   if (ret) {
      std::cout << "ret " << ret << std::endl;
    }
 */   

    assert(!ret);
    ++i;
  }
  return NULL;
}

TEST(test_static, all) {
  std::cout << "test_all_start" << std::endl;
  MonitorConf monitor_conf;
  MonitorImpl monitor;
  int ret = monitor.Init("conf/monitor.conf");
  ASSERT_TRUE(ret);

  static const size_t kNumThreads=1;
  pthread_t threads[kNumThreads];
  for (size_t i=0; i<kNumThreads; ++i) {
    ret = pthread_create(&threads[i], NULL, BizThread, &monitor);
    ASSERT_TRUE(0==ret);
  }

  for (size_t i=0; i<kNumThreads; ++i) {
    pthread_join(threads[i], NULL);
  }

  std::cout << "test_all_stop" << std::endl;
}
