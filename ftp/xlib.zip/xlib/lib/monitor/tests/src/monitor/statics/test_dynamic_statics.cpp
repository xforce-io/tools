#include "gtest/gtest.h"
#include "monitor/statics/dynamic_statics.h"

using namespace xlib;
using namespace xlib::Monitor;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_dynamic_statics, positive) {
  DynamicStatics dynamic_statics;
  std::vector<std::string> metrics;
  metrics.push_back("accu");
  metrics.push_back("max");
  metrics.push_back("min");
  metrics.push_back("avg");
  metrics.push_back("dist_0.6(0-1000)");

  bool ret = dynamic_statics.Init("dynamic_statics", metrics);
  ASSERT_TRUE(ret);

  for (int i=-1000; i<2000; ++i) {
    dynamic_statics.Add("sample", i);
  }
  for (int i=-1000; i<2000; ++i) {
    dynamic_statics.Add("sample_2", i);
  }

  DynamicStatics dynamic_statics_2;
  dynamic_statics_2=dynamic_statics;

  std::stringstream ss;
  dynamic_statics_2.Output(ss);
  std::cout << ss.str() << std::endl;
}

TEST(test_dynamic_statics, passive) {
  DynamicStatics dynamic_statics;
  std::vector<std::string> metrics;
  metrics.push_back("dist");
  bool ret = dynamic_statics.Init("dynamic_statics", metrics);
  ASSERT_TRUE(!ret);
}
