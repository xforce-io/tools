#include "gtest/gtest.h"
#include "monitor/statics/metrics/metrics.h"

using namespace xlib;
using namespace xlib::Monitor;

int main(int argc, char** argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_metric_agerage, positive) {
  MetricAverage metric;
  metric.Add(1);
  metric.Add(2);
  metric.Add(3);
  std::cout << metric.vals_ << std::endl;
  std::cout << metric.num_vals_ << std::endl;
  ASSERT_TRUE( metric.GetAverage_() > 1.9 && metric.GetAverage_() < 2.1 );
  ASSERT_EQ(3, metric.num_vals_);
  metric.Reset();
  ASSERT_TRUE( metric.GetAverage_() > -0.1 && metric.GetAverage_() < 0.1 );
}

TEST(test_metric_distr, positive) {
  MetricDistr metric("0.85(0-100)");
  bool ret = metric.Init();
  ASSERT_TRUE(ret);
  ASSERT_TRUE(metric.threshold_>0.84 && metric.threshold_<0.86);
  ASSERT_EQ(metric.low_bound_, 0);
  ASSERT_EQ(metric.up_bound_, 100);

  for (int i=-100; i<200; ++i) {
    metric.Add(i);
  }
  ASSERT_EQ(84, metric.GetResult_());
}

TEST(test_metric_distr, passive) {
  MetricDistr metric("85(0-100)");
  bool ret = metric.Init();
  ASSERT_TRUE(!ret);

  MetricDistr metric_2("0.85(100-100)");
  ret = metric_2.Init();
  ASSERT_TRUE(!ret);

  MetricDistr metric_3("0.98(0-100)");
  ret = metric_3.Init();
  ASSERT_TRUE(ret);

  metric_3.Add(-1);
  metric_3.Add(0);
  metric_3.Add(100);
  ASSERT_EQ(size_t(1), metric_3.count_);
}
