import os, subprocess, pdb

import tools

class conf_s(object) :
    TargetApp = 1
    TargetLib = 2

    rootdir = '../'
    cppflags = '-D_GNU_SOURCE -D__64BIT__ -D__STDC_LIMIT_MACROS -DVERSION=\\\'0.0.0.0\\\''
    cflags = '-g -pipe -W -Wall -fPIC'
    cxxflags = '-g -pipe -W -Wall -fPIC'
    ldflags = '-lpthread -lrt'
    is_cpp = False
    depmods = []
    incpath = ''
    libpath = ''
    targets = {}
    just_dep = False
    has_app = False
    output_headers = 'cp -r src/* output/include/'
    output_headers_prefix = ''

    @staticmethod
    def set_rootdir(path) : 
        if os.path.exists(path) == False :
            raise IOError('invalid_rootdir[%s]' % path)

        conf_s.rootdir = path
        conf_s.incpath += ' -I' + path

    @staticmethod
    def set_cppflags(str) : conf_s.cppflags = str

    @staticmethod
    def set_cflags(str) : conf_s.cflags = str

    @staticmethod
    def set_cxxflags(str) : conf_s.cxxflags = str        

    @staticmethod
    def set_incpaths(str, check=True) : 
        for path in str.split() :
            if check == True and os.path.exists(path) == False :
                raise IOError('invalid_inc_path[%s]' % path)
            conf_s.incpath += ' -I' + path

    @staticmethod
    def set_libpaths(str, check=True) : 
        for path in str.split() :
            if check == True and os.path.exists(path) == False :
                raise IOError('invalid_lib_path[%s]' % path)
            conf_s.libpath += ' -L' + path

    @staticmethod
    def set_ldflags(str) : conf_s.ldflags = str

    @staticmethod
    def set_dep(mod) : 
        path_mod = conf_s.rootdir + '/' + mod.rstrip(' ' ).rstrip('/')
        if os.path.exists(path_mod) == False :
            raise IOError('no_dep_lib[%s] path[%s]' % (mod, path_mod))
        
        conf_s.depmods += [path_mod]

        #set incpath
        conf_s.incpath += ' -I' + path_mod + '/output/include'

    @staticmethod
    def set_target(name, files, target_kind) :
        if target_kind != conf_s.TargetApp and \
            target_kind != conf_s.TargetLib :
            raise Exception("invalid_target_kind[%d]" % target_kind)

        if target_kind == conf_s.TargetLib :
            ret = name.find('/')
            if ret == -1 : name = 'lib'+name+'.a'
            else : name = name[:ret+1]+'lib'+name[ret+1:]+'.a'
        else :
            conf_s.has_app = True        

        if files.find('.cpp') != -1 :
            conf_s.is_cpp = True
            if files[-2:] == '.c' or files.find('.c ') != -1 or files.find('.c\t') != -1:
                raise Exception('can_not_contain_both_c_and_cpp_files')
        else :
            conf_s.is_cpp = False    

        conf_s.targets[name] = {}
        conf_s.targets[name]['dep'] = []
        conf_s.targets[name]['kind'] = target_kind

        objpaths = []
        for depfile in files.split() :
            objpaths += tools.parse_wildcard_files(depfile)

        #parse compile unit path
        for path in objpaths :
            obj = {}
            obj['srcpath'] = path
            obj['fullpath'] = (path[ : path.rfind('.c')] + '.o')

            conf_s.targets[name]['dep'] += [obj]

    @staticmethod
    def set_just_dep(val) :
        conf_s.just_dep = val

    @staticmethod
    def recursive_set_dep(mods_to_be_extended) :
        if len(mods_to_be_extended) == 0 : return

        tmp_mods = []
        mark = 'DEP('
        for mod in mods_to_be_extended:
            fp = open(mod + '/COMAKE', 'r')
            for line in fp:
                pos = line.find(mark)
                if -1 == pos : continue

                pos_end = line.find(')')
                if -1 == pos_end :
                    raise Exception("invalid DEP syntax in COMAKE of path[%s]"\
                        % mod)
                path = line[pos+len(mark)+1 : pos_end-1]    
                tmp_mods += [conf_s.rootdir+'/'+path.rstrip(' ' ).rstrip('/')]
        
        mods_to_be_extended[:] = []
        for path_mod in tmp_mods :
            #pdb.set_trace()
            if path_mod in conf_s.depmods : continue

            conf_s.depmods += [path_mod]
            conf_s.incpath += ' -I' + path_mod + '/output/include'
            mods_to_be_extended += [path_mod]

        #pdb.set_trace()
        conf_s.recursive_set_dep(mods_to_be_extended)

    @staticmethod
    def set_output_headers(str) :
      conf_s.output_headers = "cp -f " + str + " ./output/include/"

    @staticmethod
    def set_output_headers_prefix(str) :
      conf_s.output_headers_prefix = str
