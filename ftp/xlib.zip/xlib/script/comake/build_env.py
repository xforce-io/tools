import os, subprocess
from conf import conf_s

def build_env() :
    for mod in conf_s.depmods :
        print "Build : %s" % mod
        subprocess.check_output("cd %s; make clean; make -j4 -s" % mod, shell=True)
