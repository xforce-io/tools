import os, re
from conf import conf_s
import tools
import unittest, pdb

def ROOTDIR(str) : 
    if conf_s.just_dep == False : conf_s.set_rootdir(str)

def CPPFLAGS(str) : 
    if conf_s.just_dep == False : conf_s.set_cppflags(str)

def CFLAGS(str) :
    if conf_s.just_dep == False : conf_s.set_cflags(str)

def CXXFLAGS(str) : 
    if conf_s.just_dep == False : conf_s.set_cxxflags(str)

def INCPATHS(str, check=True) : 
    if conf_s.just_dep == False : conf_s.set_incpaths(str, check)

def LIBPATHS(str, check=True) : 
    if conf_s.just_dep == False : conf_s.set_libpaths(str, check)

def LDFLAGS(str) : 
    if conf_s.just_dep == False : conf_s.set_ldflags(str)

def DEP(mod) : 
    conf_s.set_dep(mod)

def APP(name, files) : 
    if conf_s.just_dep == False : conf_s.set_target(name, files, conf_s.TargetApp)

def LIB(name, files) : 
    if conf_s.just_dep == False : conf_s.set_target(name, files, conf_s.TargetLib)

def SRC(patterns) : 
    if conf_s.just_dep == False : return tools.parse_wildcard_files(patterns)

def IMPORT_DEPS(path) :
    conf_s.set_just_dep(True)
    execfile(path)

def OUTPUT_HEADERS(str) :
    conf_s.set_output_headers(str)

def OUTPUT_HEADERS_PREFIX(str) :
    conf_s.set_output_headers_prefix(str)

def FIND_PATTERN_RECURSIVE(dir, pattern) :
    results = []
    FIND_PATTERN_RECURSIVE_IMPL(dir, pattern, results)
    return results

def FIND_PATTERN_RECURSIVE_IMPL(dir, pattern, results) :
    for path in os.listdir(dir) :
        current_path = dir+'/'+path
        if os.path.isfile(current_path) :
            if re.match(pattern, current_path) :
                results += [current_path]
        else :
            FIND_PATTERN_RECURSIVE_IMPL(current_path, pattern, results)
          
class TestCases(unittest.TestCase) :
    def testAll(self) :
        os.system(" mkdir /tmp/test_interface/sample; "
          " touch /tmp/test_interface/asdcastest_ad.cpp; "
          " touch /tmp/test_interface/asdcastet_ad.cpp; "
          " touch /tmp/test_interface/sample/asdcastest_da.cpp; "
          " touch /tmp/test_interface/sample/asdcastest_da.cp; "
          )
        #pdb.set_trace()
        results = FIND_PATTERN_RECURSIVE("/tmp/test_interface", r".*test_\w+.cpp")
        self.assertEqual(2, len(results))

if __name__ == "__main__" :
    unittest.main()
