import subprocess, copy, pdb

from conf import conf_s

class mkfl_creator_s(object) :

    deplib = ''
    app_content = {}
    lib_content = {}
    objs_already_have = []

    @staticmethod
    def make_all() :
        mkfl_creator_s.__modify_depmods()

        mkfl_creator_s.__prepare_dep_lib()
        mkfl_creator_s.__prepare_target_content()

        if len(mkfl_creator_s.app_content) == 0 and \
            len(mkfl_creator_s.lib_content) == 0: 
            raise Exception("no_make_obj_designationed")

        return mkfl_creator_s.__make_head_part() + \
            mkfl_creator_s.__make_phony_part() + \
            mkfl_creator_s.__make_app_and_lib_part()

    ####################

    @staticmethod
    def __modify_depmods() :
        #pdb.set_trace()
        tmp = copy.deepcopy(conf_s.depmods)
        conf_s.recursive_set_dep(tmp)

    @staticmethod
    def __make_head_part() :
        return 'CC=gcc\nCXX=g++\nCXXFLAGS=%s\n' \
            'CFLAGS=%s\nCPPFLAGS=%s\nINCPATH=%s\n\n' % \
            (conf_s.cxxflags, conf_s.cflags, conf_s.cppflags, conf_s.incpath)

    @staticmethod
    def __make_app_and_lib_part() :
        content = ''
        for name in mkfl_creator_s.app_content :
            content += mkfl_creator_s.app_content[name]['ld']
        for name in mkfl_creator_s.lib_content :
            content += mkfl_creator_s.lib_content[name]['ld']
        for name in mkfl_creator_s.app_content :
            content += mkfl_creator_s.app_content[name]['compile']
        for name in mkfl_creator_s.lib_content :
            content += mkfl_creator_s.lib_content[name]['compile']
        return content

    @staticmethod
    def __make_md5check_part() :
        content = ''

    @staticmethod
    def __make_phony_part() :
        #make all
        content = ''
        for target in conf_s.targets : 
          if target[-2:] == '.a' : content = '%s '%target + content
          else : content += '%s ' % target
        
        content = '.PHONY:all\nall: check_md5 ' + content  
        content += \
            '\n\t@echo "[[1;32;40mCOMAKE:BUILD[0m]' \
            '[Target:\'[1;32;40mall[0m\']"\n' \
            '\t@echo "make all done"\n\n'

        #make check_md5
        content += 'COMAKE_MD5=%s\n' % \
            (subprocess.check_output('md5sum COMAKE', shell=True))
        content += '.PHONY:check_md5\ncheck_md5:\n' \
            '\t@echo "[[1;32;40mCOMAKE:BUILD[0m]' \
            '[Target:\'[1;32;40mcheck_md5[0m\']"\n' \
            '\t@echo "$(COMAKE_MD5)">.comake2.md5\n' \
            '\t@md5sum -c --status .comake2.md5\n' \
            '\t@rm -f .comake2.md5\n\n'

        #make clean
        content += \
            '.PHONY:clean\nclean:\n' \
            '\t@echo "[[1;32;40mCOMAKE:BUILD[0m]' \
            '[Target:\'[1;32;40clean[0m\']"\n'
        for target in mkfl_creator_s.app_content: 
            content += '%s' % mkfl_creator_s.app_content[target]['clean']
        for target in mkfl_creator_s.lib_content : 
            content += '%s' % mkfl_creator_s.lib_content[target]['clean']
        return content    

    ###################

    @staticmethod
    def __prepare_dep_lib() :
        if False == conf_s.has_app : return

        def modname(mod) : return mod.split('/')[-1]
            
        mkfl_creator_s.deplib = ''        
        for mod in conf_s.depmods :
            mkfl_creator_s.deplib += \
                '\t' + mod + '/output/lib/lib' + modname(mod) + '.a \\\n'

    @staticmethod
    def __prepare_target_content() :
        last_name = conf_s.targets.keys()[len(conf_s.targets) - 1]
        for name in conf_s.targets :
            compiler = ''
            if conf_s.is_cpp == True : compiler = '$(CXX)' 
            else : compiler = '$(CC)'

            output_dir = ''
            cmd = ''
            if conf_s.targets[name]['kind'] == conf_s.TargetApp :
                target_content = mkfl_creator_s.app_content
                output_dir = 'bin'
                cmd = '%s $(CPPFLAGS) $(CXXFLAGS) -o %s' % (compiler, name)
            else :
                target_content = mkfl_creator_s.lib_content
                output_dir = 'lib'
                cmd = 'ar crs %s' % name

            target_content[name] = {}

            #make ld content
            target_content[name]['ld'] = '%s: ' % name
            for obj in conf_s.targets[name]['dep'] : 
                target_content[name]['ld'] += '\\\n  %s ' % obj['fullpath']
            target_content[name]['ld'] += \
                '\n\t@echo "[[1;32;40mCOMAKE:BUILD[0m]' \
                '[Target:\'[1;32;40m%s[0m\']"\n' \
                '\t%s ' % (name, cmd)
            for obj in conf_s.targets[name]['dep'] : 
                target_content[name]['ld'] += '\\\n  %s ' % obj['fullpath']

            if conf_s.targets[name]['kind'] == conf_s.TargetApp :
                target_content[name]['ld'] += \
                    '\\\n\t-Xlinker "-(" %s %s %s -Xlinker "-)"' \
                    % (mkfl_creator_s.deplib, conf_s.libpath, conf_s.ldflags)

            #make compile content
            target_content[name]['compile'] = ''
            for obj in conf_s.targets[name]['dep'] :
                if obj['srcpath'] in mkfl_creator_s.objs_already_have : 
                    continue
                mkfl_creator_s.objs_already_have += [obj['srcpath']] 

                target_content[name]['compile'] += '%s : %s\n' \
                    '\t%s $(CPPFLAGS) $(CXXFLAGS) -c $(INCPATH) $(DEP_INCPATH) ' \
                    '-o %s %s\n\n' \
                    % (obj['fullpath'], obj['srcpath'], compiler, \
                        obj['fullpath'], obj['srcpath'])

            #make clean content
            target_content[name]['clean'] = '\trm -rf %s\n\trm -rf output\n' % name
            for obj in conf_s.targets[name]['dep'] :
                target_content[name]['clean'] += \
                    '\trm -rf %s\n' % obj['fullpath']
            target_content[name]['clean'] += '\n'

            if name == last_name :
              target_content[name]['ld'] += \
                  '\n\t\tmkdir -p ./output/%s output/include/%s\n' \
                  '\t\tcp -f %s ./output/%s\n' \
                  '\t\t%s &> /dev/null\n' \
                  '\t\tfind output/ -regex ".*\.c\|.*\.cpp\|.*\.cc\|.*\.o" | xargs -i rm -rf {}\n\n' \
                  % (output_dir, conf_s.output_headers_prefix, name, output_dir, conf_s.output_headers+conf_s.output_headers_prefix)
            else :
              target_content[name]['ld'] += '\n\n'
