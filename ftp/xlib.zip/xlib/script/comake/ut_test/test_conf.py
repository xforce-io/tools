import unittest, subprocess
execfile("../conf.py")

class conf_test_case_t(unittest.TestCase) :
    def test_simple_conf(self) :
        conf_s.set_rootdir("rootdir")
        conf_s.set_cppflags("cppflags")
        conf_s.set_cflags("cflags")
        conf_s.set_cxxflags("cxxflags")
        conf_s.set_ldflags("ldflags")

        self.assertEqual("rootdir", conf_s.rootdir)
        self.assertEqual("cppflags", conf_s.cppflags)
        self.assertEqual("cflags", conf_s.cflags)
        self.assertEqual("cxxflags", conf_s.cxxflags)
        self.assertEqual("ldflags", conf_s.ldflags)

    def test_set_incpaths(self) :
        ret = subprocess.check_output("touch /tmp/exist && rm -rf /tmp/nonexist",
            shell=True)

        conf_s.incpath = ""
        try:
            conf_s.set_incpaths("/tmp/nonexist")
        except IOError, e :    
            pass

        conf_s.set_incpaths("/tmp/exist")
        self.assertEqual(conf_s.incpath, " -I/tmp/exist")

    def test_set_dep(self) :
        ret = subprocess.check_output("touch /tmp/exist && rm -rf /tmp/nonexist",
            shell=True)

        conf_s.set_rootdir("/tmp")    
        conf_s.incpath = ""
        try:
            conf_s.set_dep("nonexist") 
        except IOError, e :    
            pass

        conf_s.set_dep("exist")    
        self.assertEqual(conf_s.incpath, " -I/tmp/exist/output/include")
        self.assertEqual(conf_s.depmods[0], "/tmp/exist")

    def test_set_app(self) :
        subprocess.check_output("rm -rf tmp "
            "&& mkdir tmp "
            "&& rm -rf tmp/*.cpp "
            "&& touch tmp/s1.cpp tmp/s2.cpp "
            "&& touch impossible.cpp",
            shell=True)
   
        conf_s.set_app("sample", "tmp/*.cpp impossible.cpp")
        self.assertEqual("s1.o", conf_s.apps["sample"][0]["name"]);
        self.assertEqual("tmp/s1.o", conf_s.apps["sample"][0]["fullpath"]);
        self.assertEqual("impossible.o", conf_s.apps["sample"][2]["name"]);
        self.assertEqual("./impossible.o", conf_s.apps["sample"][2]["fullpath"]);

        subprocess.check_output("rm impossible.cpp", shell=True)

if __name__ == "__main__" : 
    unittest.main()
