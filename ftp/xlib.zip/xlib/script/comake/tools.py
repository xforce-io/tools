import subprocess, pdb

def parse_wildcard_files(patterns) :
    files = []
    for pattern in patterns.split() :

        index_last_slash = pattern.rfind('/')
        if -1 == index_last_slash :
            cmd = 'find -path "./%s"' % pattern
        else :
            cmd = 'cd %s && find -path "./%s"' % \
                (pattern[:index_last_slash], pattern[index_last_slash+1:])

        depfiles = subprocess.check_output(cmd, shell=True)

        if -1 == index_last_slash :
            for file in depfiles.split('\n') :
                if file == '' : continue
                if file[:2] == './' : file = file[2:]    
                files += [file.replace('/./', '/')]
        else :            
            for file in depfiles.split('\n') :
                if file == '' : continue
                if file[:2] == './' : file = file[2:]    
                files += [(pattern[:index_last_slash] + '/' + file).replace('/./', '/')]
    return files
