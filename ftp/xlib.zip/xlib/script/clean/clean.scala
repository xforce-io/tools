import java.io._

object Clean // extends App 
{
  def walk(file: File) {
    if (!file.isFile()) {
      make_clean(file)
      file.listFiles().foreach(walk)
    }
  }

  def make_clean(dir: File) {
    for (
      file <- dir.listFiles
      if file.getName == "Makefile"
    ) println(dir.getName)
  }

  def main(args: Array[String]) {
    Runtime.getRuntime().exec("sleep 1; echo haha");
    walk(new File(args(0)))
  }
}
