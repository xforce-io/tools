TMP_DIR=/tmp/xp_bak/
BAK_FILE=/tmp/xp_bak/xlib_*.zip

mkdir -p $TMP_DIR 
rm $BAK_FILE
cd ~/dev/xlib/; sh script/make_clean
cp -r ~/dev/xlib/ /tmp/
cd /tmp/
zip -r xlib.zip xlib

DST=xlib_`date +%Y%m%d`.zip
scp xlib.zip 221.228.208.57:~/baks/$DST
