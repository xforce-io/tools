import subprocess, random, sys
from pyDes import *

code = "return666INT0000"

if __name__ == '__main__' :

    files_tobe_backup = ""
    fp = open("files_tobe_backup", "r")
    for line in fp:
        files_tobe_backup += line[:-1] + " "
    fp.close()    

    fout = open("destination", "r")
    destination = fout.readline()[:-1]    
    fout.close()

    subprocess.check_output("zip -r %s %s -P %s" % (destination, files_tobe_backup, code), shell=True)
