package log_collector
import scala.collection.mutable

class Action(val node: xml.Node)
{
  def log(log_data: log_collector.LogData, log_args :LogArgs) {
    loggers_.foreach { logger => logger.log(log_data, log_args) }
  }

  private val loggers_ = 
    (List[Logger]() /: (node \ "Logger")) {
      (loggers, logger_node) =>
        var new_loggers = (new Logger(logger_node)) :: loggers
        new_loggers
    }
}
