package log_collector

class LogArgs {}
