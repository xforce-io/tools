package log_collector

class Condition(node :xml.Node) 
{
  ///public
  def check(log_data :log_collector.LogData) :Int= { 
    val value = log_data.get(Key_)
    if (null==value) {
      if (Condition.Or_ == Connector_) return 1
      else return -1
    }

    val equal = (value == Val_)
    if ( ( (Condition.Equal_ == Operator_) && (true == equal) ) 
        || ( (Condition.NotEqual_ == Operator_) && (false == equal) ) ) {
      return if (Condition.And_ == Connector_) 1 else 0
    } else {
      return if (Condition.And_ == Connector_) -1 else 1
    }
    return 0 
  }

  ///private
  private val Key_ = (node \ "@key").toString
  private val Val_ = (node \ "@value").toString
  private val Operator_ = 
    if ( (node \ "@operator").toString == "eq" ) Condition.Equal_ else Condition.NotEqual_
  private val Connector_ =
    if ( (node \ "@connector").toString == "and" ) Condition.And_ else Condition.Or_

  ///constructor
}

object Condition
{
  private val Equal_ = 0
  private val NotEqual_ = 1
  private val And_ = 0
  private val Or_ = 1

  ///ut_test
  private val xml_content_and_ :xml.Node = 
    <content>
      <Condition key="key1" operator="eq" value="val1" connector="and" />
    </content>

  private val xml_content_or_ :xml.Node = 
    <content>
      <Condition key="key" operator="eq" value="val" connector="or" />
    </content>

  def test_init() {
    val condition_node = (xml_content_and_ \ "Condition")(0) 
    val condition = new Condition(condition_node)
    assert(Condition.Equal_ == condition.Operator_)
    assert("key1" == condition.Key_)
    assert("val1" == condition.Val_)
    assert(Condition.And_ == condition.Connector_)
  }

  def test_check_and() {
    val condition_node = (xml_content_and_ \ "Condition")(0) 
    val condition = new Condition(condition_node)
    val log_data = new log_collector.LogData
    log_data.reset("action=test&key=val1")
    assert(-1 == condition.check(log_data))
    log_data.reset("action=test&key1=val1")
    assert(1 == condition.check(log_data))
  }

  def test_check_or() {
    val condition_node = (xml_content_or_ \ "Condition")(0) 
    val condition = new Condition(condition_node)
    val log_data = new log_collector.LogData
    log_data.reset("action=test&key=val1")
    assert(1 == condition.check(log_data))
    log_data.reset("action=test&key=val")
    assert(0 == condition.check(log_data))
  }

  def main(args :Array[String]) {
    test_init
    test_check_and
    test_check_or
  }
}
