package log_collector.agents
import java.io._
import java.nio.channels._

abstract class Agent(private val name_ :String)
{
  protected var log_name_ = new String 
  protected var file_writer_ :FileWriter = null

  protected def openNewLog_() :Boolean = {
    if (null!=file_writer_) file_writer_.close
    file_writer_ = new FileWriter(log_name_)
    return true
  }

  def log(log_data :log_collector.LogData, log_args :log_collector.LogArgs) {}

  def flush() {
    if (null!=file_writer_) file_writer_.flush
  }
}

object Agent 
{
  private val MaxAgentName=256
}

// vim: set ts=4 sw=4 et:
