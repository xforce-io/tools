package log_collector.agents
import java.io._
import log_collector.LogData

class SimpleAgent(name :String, node :xml.Node) extends Agent(name)
{
  override def log(
      log_data :log_collector.LogData, 
      log_args :log_collector.LogArgs)
  {
    val current_time = System.currentTimeMillis / 
      ( if (SimpleAgent.kHour==cut_interval_) 3600*1000 else 60*1000 )

    if (current_time != current_time_) {
      current_time_ = current_time
      setCurrentLogName_
      if (false == openNewLog_()) return
    }

    file_writer_.write(log_data.log)
  }

  def setCurrentLogName_() {
    if (SimpleAgent.kHour==cut_interval_) {
      val format = new java.text.SimpleDateFormat("yyyyMMddHH")
      log_name_ = dir_name_.concat("/").concat(log_name_prefix_).
          concat("_").concat(format.format(System.currentTimeMillis))
    } else {
      val format = new java.text.SimpleDateFormat("yyyyMMddHHmm")
      log_name_ = dir_name_.concat("/").concat(log_name_prefix_).
          concat("_").concat(format.format(System.currentTimeMillis))
    }
  }

  ///private
  private val dir_name_ = (node \ "@dir_name").toString
  private val log_name_prefix_ = (node \ "@prefix").toString

  private var current_time_ :Long = 0
  private var cut_interval_ = 0

  ///constructor
  (node \ "@cut_interval").toString match {
    case "min" => cut_interval_ = SimpleAgent.kMin
    case _ => cut_interval_ = SimpleAgent.kHour
  }
}

object SimpleAgent
{
  private val kHour = 0
  private val kMin = 1  

  ///ut_test

  def test_all_positive() {
    val conf_name = "../ut_test/conf/tmp_conf"

    val file_writer = new FileWriter(conf_name)
    file_writer.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n")
    file_writer.write("<content>\n")
    file_writer.write("<Agent name=\"simple_agent\" dir_name=\"./log/\" prefix=\"log\" cut_interval=\"min\" split_size=\"1000000\" />\n")
    file_writer.write("</content>\n")
    file_writer.close

    val xml_content = xml.XML.loadFile(conf_name)
    val xml_node = (xml_content \ "Agent")(0)
    val agent = new SimpleAgent("simple_agent", xml_node)
    val log_data = new LogData
    log_data.reset("hahaha")
    val log_args = new log_collector.LogArgs
    agent.log(log_data, log_args)
    agent.flush

    val format = new java.text.SimpleDateFormat("yyyyMMddHHmm")
    val log_name = "./log/".concat("/log").concat("_").
      concat(format.format(System.currentTimeMillis))

    val file_reader = new FileReader(log_name)
    val br = new BufferedReader(file_reader)
    val line = br.readLine
    val index = line.indexOf("hahaha")
    assert(index>=0)
  }

  def main(args :Array[String]) {
    test_all_positive
  }
}
