package log_collector

class LogData 
{
  def reset(log :String) {
    log_org_ = log
    if ('\n'!=log(log.length-1)) log_org_ = log_org_.concat("\n")
  }

  def get(key :String) :String = {
    if (key=="action") {
      if (false == log_org_.startsWith("action=")) return null

      var pos = log_org_.indexOf('&')
      if (-1==pos) return null

      return log_org_.substring(LogData.FixedSizeAction, pos)
    } else {
      val pattern = "&".concat(key).concat("=")
      var pos = log_org_.indexOf(pattern)
      if (-1==pos) return null

      val start = pos+pattern.length
      val end = log_org_.indexOf('&', start)
      if (-1!=end) {
        return log_org_.substring(start, end)
      } else {
        return log_org_.substring(start, log_org_.indexOf('\n', start))
      }
    }
  }

  def log :String = log_org_

  ///private
  private var log_org_ = ""
}

object LogData 
{
  private val FixedSizeAction = "action=".length

  ///ut_test
  def main(args :Array[String]) {
    println("haha")
    val log_data = new LogData
    log_data.reset("action=test&a=b&c=&d=")

    var value = log_data.get("action")
    assert(value=="test")
    value = log_data.get("a")
    assert(value=="b")
    value = log_data.get("a")
    assert(value=="b")
    value = log_data.get("c")
    assert(value=="")
    value = log_data.get("d")
    assert(value=="")
    value = log_data.get("e")
    assert(value==null)
  }
}
