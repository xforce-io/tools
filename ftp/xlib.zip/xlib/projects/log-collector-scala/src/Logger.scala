package log_collector
import scala.collection.mutable
import scala.util.control.Breaks._


class Logger(val node: xml.Node) 
{
  ///public
  def log(
      log_data: log_collector.LogData, 
      log_arg: log_collector.LogArgs) :Boolean = {
    breakable {
      conditions_.foreach { condition =>
        val ret = condition.check(log_data)
        if (ret<0) return false
        else if (0==ret) break
      }
    }
    agent_.log(log_data, log_arg)
    return true
  }

  ///private
  private val conditions_ = 
    (List[Condition]() /: (node \ "Condition")) {
      (conditions_, condition_node) => 
        var new_conditions = (new Condition(condition_node)) :: conditions_
        new_conditions
    }
  private val agent_node_ = (node \ "Agent")(0)
  private var agent_ :agents.Agent = null

  ///constructor
  (agent_node_ \ "@name").toString match {
    case "simple_agent" => 
      agent_ = new agents.SimpleAgent("simple_agent", agent_node_)
  }
}

object Logger
{
  ///ut_test
  private val xml_content_init_positive_ :xml.Node = 
    <Logger>
      <Condition key="key1" operator="eq" value="val1" connector="and" />
      <Condition key="key2" operator="ne" value="val2" connector="or" />
      <Agent name="simple_agent" dir_name="./log/" prefix="log" cut_interval="min" />
    </Logger>

  private val xml_content_init_passive_no_agent_ :xml.Node = 
    <Logger>
      <Condition key="key1" operator="eq" value="val1" connector="and" />
      <Condition key="key2" operator="ne" value="val2" connector="or" />
    </Logger>

  def test_init_positive() {
    val logger = new Logger(xml_content_init_positive_)
  }

  def test_init_passive_no_agent() {
    var ret=true
    try {
      val logger = new Logger(xml_content_init_passive_no_agent_)
    } catch {
      case _ => ret=false
    }
    assert(false==ret)
  }

  def main(args :Array[String]) {
    test_init_positive
    test_init_passive_no_agent
  }
}
