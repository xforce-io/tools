package log_collector
import scala.collection.mutable

class ActionManager(val node: xml.Node)
{
  def log(logstr :String, log_args :LogArgs) {
    log_data_.reset(logstr)
    val action = log_data_.get("action")
    if (null==action) return
      
    actions_(action).log(log_data_, log_args)  
  }

  private val actions_ = 
   (mutable.HashMap[String, Action]() /: (node \ "Action")) {
      (map, action_node) =>
        map((action_node \ "@name").toString) = new Action(action_node)
        map  
    }

  private val log_data_ = new log_collector.LogData
  private val default_agent_ = new agents.SimpleAgent("default", node)
}

object ActionManager
{
  //ut_test
  private val xml_content_sample :xml.Node =
    <content>
      <Action name="data_group_auction_log">
        <Logger>
           <Agent name="simple_agent" dir_name="./log/" prefix="log" cut_interval="min" />
        </Logger>
      </Action>
      <Action name="rtbpv">
        <Logger>
           <Agent name="simple_agent" dir_name="./log/" prefix="rtbpv" cut_interval="min" />
        </Logger>
      </Action>
    </content>  

  def main(args :Array[String]) {
    val action_manager = new ActionManager(xml_content_sample)
    val log_args = new LogArgs
    while (true) {
      action_manager.log("action=rtbpv&qwd=qwd&cds=csd&action=rtbpv&qwd=qwd&cds=csd", log_args)
    }
  }
}
