scalac -d ./ ../src/*.scala ../src/agents/*.scala
