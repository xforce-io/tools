#include "gtest/gtest.h"
#include "../../../../src/core/disk/file_handler.h"
#include "../../../../src/limits.hpp"

using namespace xlib::xpipe;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_file_handler : public ::testing::Test
{
 protected:
  virtual ~test_file_handler(){}
  virtual void SetUp() 
  {
      system("rm -rf data/*");
  }

  virtual void TearDown() { }
};

TEST(test_file_handler, all)
{
  FileHandler file_handler(5);
  int ret = file_handler.Open("data/tmp", false);
  ASSERT_EQ(0, ret);

  char write_buf[] = "abcd ef gh";
  ssize_t bytes = file_handler.Write(write_buf, sizeof(write_buf));
  ASSERT_EQ(bytes, sizeof(write_buf));

  ret = file_handler.Flush();
  ASSERT_EQ(true, ret);

  file_handler.Close();

  ret = file_handler.Open("data/tmp", true);
  ASSERT_EQ(0, ret);

  char read_buf[Limits::kMaxMsgLen];
  bytes = file_handler.Read(read_buf, 2);
  ASSERT_EQ(2, bytes);
  ASSERT_EQ(0, memcmp(read_buf, "ab", 2));
  bytes = file_handler.ReadUntil(' ', sizeof(write_buf), read_buf);
  ASSERT_EQ(3, bytes);
  ASSERT_EQ(0, memcmp(read_buf, "cd ", 3));
  bytes = file_handler.ReadUntil(' ', sizeof(write_buf), read_buf);
  ASSERT_EQ(3, bytes);
  ASSERT_EQ(0, memcmp(read_buf, "ef ", 3));
  bytes = file_handler.Read(read_buf, 1);
  ASSERT_EQ(1, bytes);
  ASSERT_EQ(0, memcmp(read_buf, "g", 1));
  bytes = file_handler.Read(read_buf, 10);
  ASSERT_EQ(2, bytes);
  ASSERT_EQ(0, memcmp(read_buf, "h\0", 2));
  
  ret = file_handler.Flush();
  ASSERT_EQ(false, ret);

  file_handler.Close();
}
