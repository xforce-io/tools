#include "gtest/gtest.h"
#include "../../../src/core/mempool.h"

using namespace xlib::xpipe;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_mempool, len_to_idx)
{
  size_t index;
  ASSERT_EQ(Mempool::LenToIdxBasic_(1), 0);
  ASSERT_EQ(Mempool::LenToIdxBasic_(16), 0);
  ASSERT_EQ(Mempool::LenToIdxBasic_(17), 1);
  ASSERT_EQ(Mempool::LenToIdxBasic_(32), 1);
  ASSERT_EQ(Mempool::LenToIdxBasic_(33), 2);
  ASSERT_EQ(Mempool::LenToIdxBasic_(Limits::kMaxMsgLen), 17);
}

TEST(test_mempool, get_and_free)
{
  Mempool mempool;
  Msg* msg = mempool.Get(1);
  ASSERT_TRUE(NULL!=msg);

  mempool.Free(msg);
}
