#include "gtest/gtest.h"
#include "../../../../src/core/disk/partition.h"
#include "../../../../src/conf.h"

using namespace xlib::xpipe;

int main(int argc, char** argv)
{
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_partition : public ::testing::Test
{
    protected:
    virtual ~test_partition(){}
    virtual void SetUp() 
    {
        system("rm -rf data/*");
    }

    virtual void TearDown() { }
};

TEST_F(test_partition, all)
{
  Conf::MaxSegmentSize = 20;

  Partition partition(0, "data/tmp");
  Msg msg; 
  int ret = msg.Init(20);
  ASSERT_EQ(true, ret);
  msg.len=3; memcpy(msg.buf, "abc", msg.len);
  ret = partition.PutMsg(-1, &msg);
  ASSERT_EQ(true, ret);
  msg.len=2; memcpy(msg.buf, "de", msg.len);
  ret = partition.PutMsg(-1, &msg);
  ASSERT_EQ(true, ret);
  msg.len=2; memcpy(msg.buf, "fg", msg.len);
  ret = partition.PutMsg(-1, &msg);
  ASSERT_EQ(true, ret);
  msg.len=4; memcpy(msg.buf, "hijk", msg.len);
  ret = partition.PutMsg(25, &msg);
  ASSERT_EQ(true, ret);
  partition.Close();

  Msg msg_2;
  ret = msg_2.Init(100);
  ASSERT_EQ(true, ret);
  Partition partition_2(1, "data/tmp");
  ret = partition_2.GetMsg(0, &msg_2);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(0, strncmp("abc", msg_2.buf, 3));
  ASSERT_EQ(3, msg_2.len);
  ret = partition_2.GetMsg(-1, &msg_2);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(0, strncmp("de", msg_2.buf, 2));
  ASSERT_EQ(2, msg_2.len);
  ret = partition_2.GetMsg(-1, &msg_2);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(0, strncmp("fg", msg_2.buf, 2));
  ASSERT_EQ(2, msg_2.len);
  ret = partition_2.GetMsg(25, &msg_2);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(0, strncmp("hijk", msg_2.buf, 4));
  ASSERT_EQ(4, msg_2.len);
}

TEST_F(test_partition, passive)
{
  FILE* fp = fopen("data/tmp.0", "w");
  ASSERT_TRUE(NULL!=fp);

  char bytes_writen[] = "\t123\n4\t1234\n";
  int ret = fputs(bytes_writen, fp);
  ASSERT_TRUE(ret>0);

  fclose(fp);

  Msg msg;
  ret = msg.Init(100);
  ASSERT_EQ(true, ret);
  Partition partition(0, "data/tmp");
  ret = partition.GetMsg(0, &msg);
  ASSERT_EQ(-1, ret);
  ret = partition.GetMsg(-1, &msg);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(0, strncmp("1234", msg.buf, 4));
  ASSERT_EQ(4, msg.len);
}
