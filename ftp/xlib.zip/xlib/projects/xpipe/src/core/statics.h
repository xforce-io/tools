#ifndef XLIB_PROJECTS_XPIPE_SRC_CORE_STATICS_H
#define XLIB_PROJECTS_XPIPE_SRC_CORE_STATICS_H

namespace xlib {

class Statics
{
 public:
  explicit Statics() {}

 private:
  static SimpleMsgPipe<> ;

  //sign of msg -> result
  static std::tr1::unordered_map<size_t, int> statics_; 
};

}

#endif
