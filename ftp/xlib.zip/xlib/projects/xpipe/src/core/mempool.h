#ifndef XLIB_PROJECTS_XPIPE_SRC_CORE_MEMPOOL_H
#define XLIB_PROJECTS_XPIPE_SRC_CORE_MEMPOOL_H

#include "../public.h"
#include "public/basic/buffer_cache.h"
#include "public/basic/pool_objs.hpp"

namespace xlib { namespace xpipe {

/* RAII */
class Mempool
{
 public:
  typedef pub::PoolObjsInit<Msg, Msg::InitParam> Pool;

 public:
  static const size_t kMinMsgSize=16; 
  static const size_t kUpboundMostMsgSize=10000;

 public:
  explicit Mempool() : pools_(NULL), init_(false) {}
  inline Msg* Get(size_t size);
  inline void Free(Msg* msg);
  virtual ~Mempool() { XLIB_FREE(pools_); }

 private:
  bool Init_();
  inline size_t LenToIdx_(size_t len) const;
  inline static size_t LenToIdxBasic_(size_t len);

 private:
  size_t num_pools_; 
  Pool* pools_;
  size_t map_size_to_idx_[kUpboundMostMsgSize];

  bool init_;
};

Msg* Mempool::Get(size_t len)
{
  XLIB_RAII_INIT(NULL)
  return pools_[LenToIdx_(len)].Get();
}

void Mempool::Free(Msg* msg)
{
  XLIB_RAII_INIT()
  pools_[LenToIdx_(msg->len)].Free(msg);
}

size_t Mempool::LenToIdx_(size_t len) const
{
  if ( likely(len<kUpboundMostMsgSize) ) return map_size_to_idx_[len];
  return LenToIdxBasic_(len);
}

size_t Mempool::LenToIdxBasic_(size_t len)
{
  --len;

  int index=0;
  len>>=4;
  while (0!=len) {
    ++index;
    len>>=1;
  }
  return index;
}

}}

#endif
