#include "../partition.h"
#include "public/basic/string.hpp"

namespace xlib { namespace xpipe {

int Partition::GetMsg(off_t offset, Msg* msg)
{
  XLIB_RAII_INIT(-1)

  int ret = SeekRead_(offset);
  if ( unlikely(ret!=0) ) { return ret>0 ? 1 : -1; }

  ret = GetMsg_(msg);
  if (0==ret) {
    return 0;
  } else if (ret>0) {
    file_handler_.Close();
    ++current_seg_id_;
    ret = SeekRead_(0);
    if ( unlikely(ret!=0) ) { return ret>0 ? 1 : -1; }

    ret = GetMsg_(msg);
    return 0==ret ? 0 : -1;
  } else {
    return -1;
  }
}

bool Partition::PutMsg(off_t offset, const Msg* msg)
{
  XLIB_RAII_INIT(false)

  return SeekWrite_(offset, msg) && PutMsg_(msg);
}

bool Partition::Init_()
{
  init_=true;
  return true;
}

void Partition::SetCurrentFilepath_()
{
  snprintf(current_filepath_, Limits::kMaxLenFilePath+1, "%s.%lu", 
    path_prefix_.c_str(), current_seg_id_);
}

int Partition::SeekRead_(off_t offset)
{
  int ret;
  if ( likely(FileHandler::UNUSED != file_handler_.Stat()) ) {
    if (offset<0) {
      return 0;
    } else {
      size_t seg_id;
      off_t seg_offset;
      GetSegPos_(offset, seg_id, seg_offset);
      if ( seg_id!=current_seg_id_) {
        file_handler_.Close();
        if (seg_id!=current_seg_id_) current_seg_id_=seg_id;
      } else {
        int ret = file_handler_.Seek(seg_offset);
        if (0==ret) { 
          return 0;
        } else if (ret>0) {
          return 1;
        } else {
          WARN("fail_seek_file[%s]", current_filepath_);
          return -1;
        }
      }
    }
  }

  SetCurrentFilepath_();
  ret = file_handler_.Open(current_filepath_, true);
  if (0==ret) {
    return 0;
  } else if (ret>0) {
    return 1;
  } else {
    WARN("fail_open_file[%s]", current_filepath_);
    return -2;
  }
}

bool Partition::SeekWrite_(off_t offset, const Msg* msg)
{
  int ret;
  bool check_room=false;
  bool open_file=false;
  bool need_seek=false;
  bool handle_unused = (FileHandler::UNUSED == file_handler_.Stat());
  off_t seg_offset;
  if (offset<0) {
    check_room=true;
    seg_offset = (false==handle_unused ? file_handler_.Tell() : 0);
  } else {
    need_seek = true;

    size_t seg_id;
    GetSegPos_(offset, seg_id, seg_offset);
    if ( seg_id!=current_seg_id_) {
      if (seg_id!=current_seg_id_) current_seg_id_=seg_id;
      open_file=true;
    } else {
      check_room=true;
    }
  }

  if ( unlikely(true==handle_unused) ) {
    open_file=true;
  }

  if ( likely(true==check_room) ) {
    if ( seg_offset+msg->len+2+kMaxSizeMsgLen > Conf::MaxSegmentSize ) {
      ++current_seg_id_;
      open_file = true;
      need_seek=false;
    }
  }

  if ( unlikely(true==open_file) ) {
    file_handler_.Close();
    SetCurrentFilepath_();
    ret = file_handler_.Open(current_filepath_, false);
    XLIB_FAIL_HANDLE_WARN(0!=ret, "fail_open_file[%s]", 
      current_filepath_)
  }

  if ( unlikely(true==need_seek) ) {
    ret = file_handler_.Seek(seg_offset);
    XLIB_FAIL_HANDLE_WARN(0!=ret, "fail_seek_file[%s]",
      current_filepath_);
  }
  return true;

  ERROR_HANDLE:
  return false;
}

int Partition::GetMsg_(Msg* msg)
{
  ssize_t ret;
  ret = file_handler_.ReadUntil('\t', sizeof(buf_msg_len_), buf_msg_len_);
  if ( unlikely(ret<=1))  {
    if (0==ret) {
      return 1;
    } else {
      XLIB_FAIL_HANDLE_WARN(true, "fail_read_msg_len_info[%s]", current_filepath_)
    }
  }

  ret = ( pub::String::StrToInt(buf_msg_len_, (int&)(msg->len)) 
    && (msg->len > 0)
    && true == Limits::IsValidMsgLen(msg->len) );
  XLIB_FAIL_HANDLE_WARN(true!=ret && (ret=-1), 
    "invalid_msg_len_info[%s]", 
    current_filepath_, current_seg_id_)

  ret = file_handler_.Read(msg->buf, msg->len);
  XLIB_FAIL_HANDLE_WARN(msg->len!=ret, "fail_read_msg[%s]", 
    current_filepath_)

  char newline;
  ret = file_handler_.Read(&newline, 1) && ('\n'==newline);
  XLIB_FAIL_HANDLE_WARN(1!=ret, "fail_read_msg[%s]", 
    current_filepath_)
  return 0;

  ERROR_HANDLE:
  file_handler_.ReadUntil('\n', sizeof(buf_msg_len_), buf_msg_len_);
  return -1;
}

bool Partition::PutMsg_(const Msg* msg)
{
  ssize_t ret;
  const size_t kMaxLenNum = 10;
  char tmp_buf[kMaxLenNum];
  size_t len_size_msg;
  off_t org_pos = file_handler_.Tell();

  sprintf(tmp_buf, "%lu", msg->len);
  len_size_msg = strlen(tmp_buf);

  ret = file_handler_.Write(tmp_buf, len_size_msg);
  XLIB_FAIL_HANDLE_WARN(len_size_msg!=ret,
    "fail_write_file[%s]", current_filepath_)

  ret = file_handler_.Write("\t", 1);
  XLIB_FAIL_HANDLE_WARN(1!=ret,
    "fail_write_file[%s]", current_filepath_)

  ret = file_handler_.Write(msg->buf, msg->len);
  XLIB_FAIL_HANDLE_WARN(msg->len!=ret,
    "fail_write_file[%s]", current_filepath_)

  ret = file_handler_.Write("\n", 1);
  XLIB_FAIL_HANDLE_WARN(1!=ret,
    "fail_write_file[%s]", current_filepath_)
  return true;

  ERROR_HANDLE:
  file_handler_.Seek(org_pos);
  return false;
}

}}
