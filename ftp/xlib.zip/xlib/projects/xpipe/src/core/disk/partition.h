#ifndef XLIB_PROJECTS_XPIPE_CORE_PARTITION_H
#define XLIB_PROJECTS_XPIPE_CORE_PARTITION_H

#include "../../public.h"
#include "../../conf.h"
#include "file_handler.h"

namespace xlib { namespace xpipe {

/* RAII */
class Partition 
{
 public:
  static const size_t kMaxSizeMsgLen=10;

 public:
  explicit Partition(size_t id, std::string path_prefix) :
    id_(id),
    path_prefix_(path_prefix),
    current_seg_id_(0),
    file_handler_(Limits::kMaxMsgLen+1),
    init_(false) {}

  /*
   * reader interfaces
   */
  int GetMsg(IN off_t offset, OUT Msg* msg);

  /*
   * writer interfaces
   */
  bool PutMsg(off_t offset, const Msg* msg);
  bool Flush() { return file_handler_.Flush(); }

  void Close() { file_handler_.Close(); }

 private:
  bool Init_();
  inline void GetSegPos_(IN off_t offset, OUT size_t& seg_id, OUT off_t& seg_offset);
  void SetCurrentFilepath_();

  /*
   * seek from the current pos if offset<0
   */
  int SeekRead_(off_t offset);
  bool SeekWrite_(off_t offset, const Msg* msg);

  int GetMsg_(Msg* msg);
  bool PutMsg_(const Msg* msg);

 private:
  //const 
  size_t id_;
  std::string path_prefix_;
  ///

  char current_filepath_[Limits::kMaxLenFilePath+1];
  size_t current_seg_id_;
  FileHandler file_handler_;
  char buf_msg_len_[Limits::kMaxMsgLen];

  bool init_;
};

void Partition::GetSegPos_(IN off_t offset, OUT size_t& seg_id, OUT off_t& seg_offset)
{
  seg_id = offset/Conf::MaxSegmentSize;
  seg_offset = offset%Conf::MaxSegmentSize;
}

}}

#endif
