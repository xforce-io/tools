#include "../file_handler.h"
#include "public/basic/fd_helper.hpp"
#include "../../../public.h"

namespace xlib { namespace xpipe {

int FileHandler::Open(const std::string& filepath, bool read_mode)
{
  XLIB_RAII_INIT(-1)
  if (current_fd_>0) close(current_fd_);

  current_pos_buf_ = current_read_pos_ = 0;
  current_fd_ = open(
      filepath.c_str(), 
      true==read_mode ? O_RDONLY : (O_WRONLY|O_CREAT|O_TRUNC),
      0644);
  if (current_fd_<=0) { return errno==EACCES ? 1 : -2; }

  if ( true == FdHelper::SetNonBlock(current_fd_) ){
    status_ = (read_mode?READ:WRITE);
    return 0;
  } else {
    return -3;
  }
}

ssize_t FileHandler::Read(void* buf, size_t count)
{
  XLIB_RAII_INIT(false)
  if ( unlikely(READ!=status_) ) return -1;

  size_t copy_size=0;
  if (current_pos_buf_!=current_read_pos_) {
    size_t buf_space = current_pos_buf_-current_read_pos_;
    copy_size = (buf_space<=count ? buf_space : count);
    memcpy(buf, buf_+current_read_pos_, copy_size);
    current_read_pos_+=copy_size;
    if (copy_size==count) {
      return count; 
    } else {
      buf+=copy_size;
      count-=copy_size;
    }
  }

  ssize_t bytes_read = Read_(buf, count);
  return bytes_read>=0 ? copy_size+bytes_read : -2;
}

ssize_t FileHandler::ReadUntil(char sep, size_t max_size, void* buf)
{
  XLIB_RAII_INIT(-1)
  if ( unlikely(READ!=status_) ) return -2;

  memmove(buf_, buf_+current_read_pos_, current_pos_buf_-current_read_pos_);
  current_pos_buf_-=current_read_pos_;
  current_read_pos_=0;

  ssize_t bytes_read = Read_(buf_+current_pos_buf_, size_buf_-current_pos_buf_);
  if (bytes_read>0) {
  } else if (0==bytes_read) {
    if (0==current_pos_buf_) return 0;
  } else {
    return -3;
  }

  current_pos_buf_+=bytes_read;
  bytes_read += current_pos_buf_;
  size_t size_detected = (bytes_read<max_size?bytes_read:max_size);
  for (size_t i=0; i<size_detected; ++i) {
    if ( *(buf_+i) == sep ) {
      current_read_pos_=i+1;
      memcpy(buf, buf_, current_read_pos_);
      return current_read_pos_;
    }
  }
  return 0;
}

ssize_t FileHandler::Write(const void* buf, size_t count)
{
  XLIB_RAII_INIT(-1)
  if ( unlikely(WRITE!=status_) ) return -2;

  size_t org_count=count;
  while (count>0) {
    size_t size_free_buf = size_buf_-current_pos_buf_;
    size_t size_copied_to_buf = (count <= size_free_buf ? count : size_free_buf);
    memcpy(buf_+current_pos_buf_, buf, size_copied_to_buf);
    current_pos_buf_+=size_copied_to_buf;
    if (count<size_free_buf) {
      return org_count;
    } else {
      buf+=size_copied_to_buf;
      count-=size_copied_to_buf;
    }

    bool ret = Flush();
    if (false==ret) return -3;
  }
  return org_count-count;
}

bool FileHandler::Flush()
{
  XLIB_RAII_INIT(false)
  if ( unlikely(WRITE!=status_) ) return false;

  ssize_t bytes_written= write(current_fd_, buf_, current_pos_buf_);
  if (current_pos_buf_==bytes_written) {
    current_pos_buf_=0;
    return true;
  } else {
    if (bytes_written>0) {
      memmove(buf_, buf_+bytes_written, current_pos_buf_-bytes_written);
      current_pos_buf_-=bytes_written;
    }
    return false;
  }
}

void FileHandler::Close()
{
  if (current_fd_>0) {
    Flush();
    close(current_fd_);
    current_fd_=-1;
  }
  status_=UNUSED;
}

bool FileHandler::Lock_(size_t len, bool is_block)
{
  current_lock_pos_ = lseek(current_fd_, 0, SEEK_CUR);
  if ( unlikely(-1==current_lock_pos_) ) return false;

  flock lock;
  lock.l_type = ( (READ==status_) ? F_RDLCK : F_WRLCK);
  lock.l_start = current_lock_pos_;
  lock.l_whence = SEEK_SET;
  lock.l_len = current_lock_len_ = len;
  return -1 != fcntl(current_fd_, is_block?F_SETLKW:F_SETLK, &lock);
}

void FileHandler::Unlock_()
{
  flock lock;
  lock.l_type = F_UNLCK;
  lock.l_start = current_lock_pos_;
  lock.l_whence = SEEK_SET;
  lock.l_len = current_lock_len_;
  fcntl(current_fd_, F_SETLKW, &lock);
}

ssize_t FileHandler::Read_(void* buf, size_t count)
{
  size_t org_count=count;
  int ret = Lock_(count, true);
  if ( unlikely(true!=ret) ) return -2;

  ret = FdHelper::Read(current_fd_, buf, count);
  Unlock_();
  return 0==ret ? org_count : (FdHelper::INCOMPLETE==ret ? org_count-count : -3);
}

bool FileHandler::Init_()
{
  XLIB_FAIL_HANDLE(0==size_buf_ || size_buf_<=Limits::kMaxMsgLen)

  XLIB_MALLOC(buf_, char*, size_buf_)
  init_=true;
  return true;

  ERROR_HANDLE:
  XLIB_FREE(buf_)
  return false;
}

FileHandler::~FileHandler()
{
  XLIB_FREE(buf_)
}

}}
