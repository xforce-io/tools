#ifndef XLIB_PROJECTS_XPIPE_CORE_TOPIC_H
#define XLIB_PROJECTS_XPIPE_CORE_TOPIC_H

#include <tr1/unordered_map>
#include "../../public.h"
#include "partition.h"

namespace xlib { namespace xpipe {

/* RAII */
class Topic 
{
 public: 
  typedef std::tr1::unordered_map<size_t, Partition*> MapPartition;

 public:
  explicit Topic(size_t id, std::string name, std::string path_prefix) : 
    id_(id),
    name_(name),
    path_prefix_(path_prefix),
    init_(false) {}

  /*
   * writer interfaces
   */
  inline bool PutMsg(size_t partition_id, Msg* msg);

  /*
   * reader interfaces
   */
  inline bool GetMsg(IN size_t partition_id, IN size_t offset, OUT Msg* msg);

 private:
  bool Init_();

 private:
  //const 
  size_t id_;
  std::string name_;
  std::string path_prefix_;
  /// 
  
  MapPartition partitions_;

  bool init_;
};

bool Topic::PutMsg(size_t partition_id, Msg* msg)
{
  typename MapPartition::iterator iter = partitions_.find(partition_id);
  if ( unlikely(partitions_.end() == iter) ) {
    WARN("no_partition[%d] in_topic[%s]", partition_id, name_.c_str());
    return false;
  }
  return iter->second->PutMsg(0, msg);
}

bool Topic::GetMsg(IN size_t partition_id, IN size_t offset, OUT Msg* msg)
{
  typename MapPartition::iterator iter = partitions_.find(partition_id);
  if ( unlikely(partitions_.end() == iter) ) {
    WARN("no_partition[%d] in_topic[%s]", partition_id, name_.c_str());
    return false;
  }
  return iter->second->GetMsg(0, msg);
}

}}

#endif
