#include "../topic.h"

namespace xlib { namespace xpipe {

bool Topic::Init_() 
{ 
  init_=true;
  return true; 
}

}}
