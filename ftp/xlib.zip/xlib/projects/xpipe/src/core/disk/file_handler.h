#ifndef XLIB_PROJECTS_XPIPE_CORE_FILE_HANDLER_H
#define XLIB_PROJECTS_XPIPE_CORE_FILE_HANDLER_H

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "../../../public.h"

namespace xlib { namespace xpipe {

/* 
 * @brief : locked file handle, for one write thread && multi read threads
 *          RAII
 */
class FileHandler 
{
 public:
  enum Status {
    UNUSED,
    READ,
    WRITE,
  };

 public:
  explicit FileHandler(size_t size_write_buf) : 
    size_buf_(size_write_buf),
    status_(UNUSED),
    current_fd_(-1),
    buf_(NULL),
    init_(false) {}

  int Open(const std::string& filepath, bool read_mode);
  int Stat() const { return status_; }

  /*
   * reader interfaces
   */
  ssize_t Read(void* buf, size_t count);
  ssize_t ReadUntil(char sep, size_t max_size, void* buf);
  inline int Seek(off_t offset);

  /*
   * writer interfaces
   */
  ssize_t Write(const void* buf, size_t count);
  inline off_t Tell();
  bool Flush();

  void Close();
  virtual ~FileHandler();

 private:
  bool Lock_(size_t len, bool is_block);
  void Unlock_();
  ssize_t Read_(void* buf, size_t count);
//  ssize_t ReadNonBlock_(void* buf, size_t count);

  bool Init_(); 

 private: 
  //const 
  size_t size_buf_;
  ///

  Status status_;
  int current_fd_;
  char* buf_;
  size_t current_pos_buf_;
  size_t current_read_pos_;
  flock lock_;
  off_t current_lock_pos_;
  size_t current_lock_len_;

  bool init_;
};

int FileHandler::Seek(off_t offset)
{
  XLIB_RAII_INIT(-1)

  off_t off = lseek(current_fd_, offset, SEEK_SET);
  if ( unlikely(-1==off) ) {
    return EINVAL==errno ? 1 :  -3;
  }

  return 0;
}

off_t FileHandler::Tell()
{
  off_t current_pos = lseek(current_fd_, 0, SEEK_CUR);
  if ( unlikely(current_pos<0) ) return current_pos;

  return current_pos+current_pos_buf_;
}

}}

#endif
