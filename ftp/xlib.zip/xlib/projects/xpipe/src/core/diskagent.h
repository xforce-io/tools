#ifndef XLIB_PROJECTS_XPIPE_CORE_DISKMAN_H
#define XLIB_PROJECTS_XPIPE_CORE_DISKMAN_H

#include <tr1/unordered_map>
#include "../cmd.h"
#include "public/basic/item_pipe.hpp"
#include "disk/topic.h"

namespace xlib { namespace xpipe {

struct CmdMsg : public Cmd
{
  size_t id;
  Msg* msg;
};

class DiskAgent
{
 public:
  static const time_t kIdleSleepTimeUs = 1000;

 public:
  explicit DiskAgent() : current_id_(0) {}

  /*
   * called by Control
   */
  bool PutMsg(size_t id, Msg* msg);
  bool GetMsg(size_t id, Msg* msg);
  
  void CommitWriteReq(Msg* msg);
  int HandleOneWriteReq();
  void Report();

  void RunWriter();
  void RunReader();
 
 private:
  size_t current_id_;

  //communicate with Control
  pub::item_pipe_t<CmdMsg> pipe_put_msgs_;
  pub::item_pipe_t<CmdMsg> pipe_get_msgs_;

  //topic id --> topic
  std::tr1::unordered_map<size_t, Topic*> map_topics_;
};

bool DiskAgent::PutMsg(size_t id, Msg* msg)
{
  CmdMsg* cmd_msg = pipe_put_msgs_.get_msg();
  if ( unlikely(NULL==cmd_msg) ) return false;

  cmd_msg->id = id;
  cmd_msg->msg = msg;

  pipe_put_msgs_.send_msg(cmd_msg);
  return true;
}

bool DiskAgent::GetMsg(size_t id, Msg* msg)
{
  CmdMsg* cmd_msg = pipe_get_msgs_.get_msg();
  if ( unlikely(NULL==cmd_msg) ) return false;

  cmd_msg->id = id;
  cmd_msg->msg = msg;

  pipe_get_msgs_.send_msg(cmd_msg);
  return true;
}

}}

#endif
