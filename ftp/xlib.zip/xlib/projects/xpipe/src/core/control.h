#ifndef XLIB_PROJECTS_XPIPE_CORE_CONTROL_H
#define XLIB_PROJECTS_XPIPE_CORE_CONTROL_H

#include "public/basic/lru_queue.hpp"
#include "../public.h"
#include "mempool.h"

namespace xlib { namespace xpipe {

class Control
{
 public: 
//  explicit Control(Reporter& reporter) : reporter_(reporter) {}

  /*
   * @parameters :
   *    tag : user id to mark the msg which has not got a pipe id
   * @return : sign of the new msg, error if 0
   */
  bool Put(
      size_t tag,
      uint16_t topic, 
      uint16_t partition, 
      char* msg, 
      MsgSize len, 
      time_t validate_time);

  const Msg* Get(size_t id);

 private:
//  Reporter reporter_;

  Mempool mempool_; 
//  DiskAgent disk_agent_;
  //pipe id --> msg
  pub::LRUMapQueue<size_t, Msg*> lru_queue_;
};

}}

#endif
