#include "../mempool.h"
#include "../../public.h"

namespace xlib { namespace xpipe {

bool Mempool::Init_()
{
  int msg_size=kMinMsgSize;
  num_pools_=1;
  while (Limits::kMaxMsgLen != msg_size) {
    msg_size <<= 1;
    ++num_pools_;
  }

  XLIB_MALLOC(pools_, Pool*, sizeof(Pool)*num_pools_);
  for (size_t len=0; len<kUpboundMostMsgSize; ++len) 
    map_size_to_idx_[len] = LenToIdxBasic_(len);
  for (size_t len=kMinMsgSize; len<=Limits::kMaxMsgLen; len<<=1)
    new (pools_ + LenToIdx_(len)) Pool(1, len);

  init_=true;
  return true;

  ERROR_HANDLE:
  XLIB_FREE(pools_)
  return false;
}

}}
