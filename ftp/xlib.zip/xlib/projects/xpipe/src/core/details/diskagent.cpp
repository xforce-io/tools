#include "../diskagent.h"

namespace xlib { namespace xpipe {

void DiskAgent::RunWriter()
{
  std::list<CmdMsg*> msgs_tobe_put;
  for(;;) {
    pipe_put_msgs_.recieve_msgs(msgs_tobe_put);
    if (0==msgs_tobe_put.size()) {
      usleep(kIdleSleepTimeUs);
      continue;
    }
    


  }
}

void DiskAgent::RunReader()
{
  std::list<CmdMsg*> msgs_tobe_got;
  for(;;) {
    pipe_get_msgs_.recieve_msgs(msgs_tobe_got);
    if (0==msgs_tobe_got.size()) {
      usleep(kIdleSleepTimeUs);
      continue;
    }

  }
}


}}
