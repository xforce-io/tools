#include "../control.h"

namespace xlib { namespace xpipe {

bool Control::Put(
    size_t tag,
    uint16_t topic, 
    uint16_t partition, 
    char* msg, 
    MsgSize len, 
    time_t validate_time)
{
  bool ret;
  size_t id_msg;
  Msg* new_msg;

  XLIB_FAIL_HANDLE_FATAL(topic >= (1<<12) || partition >= (1<<12), "invalid_topic_or_partition");

  id_msg = (topic<<52) & (partition<<40);
  new_msg = mempool_.Get(len);
  XLIB_FAIL_HANDLE_FATAL(NULL==new_msg, "fail_get_msg_from_mempool")

  new_msg->buf = msg;
  new_msg->len = len;
//  ret = disk_agent_.PutMsg(id_msg, new_msg);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_put_new_msg")
  return true;

  ERROR_HANDLE:
  //reporter_.report(tag, false, 0);
  return false;
}

const Msg* Control::Get(size_t msg_id)
{
  bool ret;
  const std::pair<size_t, Msg*>* result;
  Msg* msg;

  result = lru_queue_.GetAndTouch(msg_id);
  if (NULL!=result) { return result->second; }

  msg = mempool_.Get(Limits::kMaxMsgLen);
  XLIB_FAIL_HANDLE_FATAL(NULL==msg, "fail_get_msg_from_mempool")

  msg->buf = msg->buf;
  msg->len = Limits::kMaxMsgLen;
 // ret = disk_agent_.GetMsg(id_msg, msg);
  XLIB_FAIL_HANDLE_FATAL(true!=ret, "fail_get_new_msg")
  return msg;

  ERROR_HANDLE:
//  reporter_.report();
  return NULL;
}

}}
