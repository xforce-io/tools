#ifndef XLIB_PROJECTS_XPIPE_CORE_CMD_H
#define XLIB_PROJECTS_XPIPE_CORE_CMD_H

#include "public.h"

namespace xlib { namespace xpipe {

struct Cmd
{
  uint16_t no;
};

}}

#endif
