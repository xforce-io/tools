#include "../conf.h"

namespace xlib { namespace xpipe {

time_t Conf::FlushTime;
size_t Conf::MaxSegmentSize=(2<<20);

}}
