#ifndef XLIB_PROJECTS_XPIPE_CONF_H
#define XLIB_PROJECTS_XPIPE_CONF_H

#include <time.h>

namespace xlib { namespace xpipe {

class Conf
{
 public:
  static time_t FlushTime; 
  static size_t MaxSegmentSize;
};

}}

#endif
