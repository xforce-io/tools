#ifndef XLIB_PROJECTS_XPIPE_LIMITS_H
#define XLIB_PROJECTS_XPIPE_LIMITS_H

#include <stdlib.h>

namespace xlib { namespace xpipe {

class Limits 
{
 public: 
  static const size_t kMaxMsgLen=(2<<20);
  static const size_t kMaxLenFilePath=1024;
 
 public:
  static bool IsValidMsgLen(size_t len) { return 0!=len && len<=kMaxMsgLen; } 
};

}}

#endif
