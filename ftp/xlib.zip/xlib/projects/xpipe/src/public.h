#ifndef XLIB_PROJECTS_PIPE_PUBLIC_H
#define XLIB_PROJECTS_PIPE_PUBLIC_H

#include <stdint.h>
#include "limits.hpp"

#include "public/public.h"
#include "lib/log/glog.h"

namespace xlib { namespace xpipe {

typedef uint32_t MsgSize ;

struct Msg
{
 public:
  typedef size_t InitParam;

 public:
  explicit Msg() { buf=NULL; }
  inline bool Init(InitParam init_param);
  virtual ~Msg() { XLIB_FREE(buf); }

 public:
  char* buf;
  size_t len;
};

bool Msg::Init(InitParam init_param) 
{
  len = init_param;
  return NULL != (buf = static_cast<char*>(malloc(init_param)));
}

}}

#endif
