#include "gtest/gtest.h"
#include "meta_server/table_index/table_index_simple_feature_list.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestTableSimpleFeatureList : public ::testing::Test {
 protected:
  virtual ~TestTableSimpleFeatureList() {} 
  virtual void SetUp() {
    system("mkdir -p data/test_table_simple_feature_list");
  }

  virtual void TearDown() {
    system("rm -rf data/test_table_simple_feature_list");
  }
};

TEST_F(TestTableSimpleFeatureList, all) {
}
