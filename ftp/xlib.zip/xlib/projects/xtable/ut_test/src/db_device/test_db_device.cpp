#include "gtest/gtest.h"
#include "db_device/db_device.h"
#include "public.h"
#include "db_mem.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestDBDevice : public ::testing::Test {
 protected:
  TestDBDevice() :
    end_(false) {}

  virtual ~TestDBDevice() {
    delete routine_file_dumper_;
    if (NULL!=db_device_) delete db_device_;
  } 

  virtual void SetUp() {
    system("rm -rf data/db* data/device_index*");
    db_device_ = new DBDevice;
    routine_file_dumper_ = new RoutineFileDumper(end_);

    bool ret = db_mem_.Init(
        *db_device_,
        (1<<20),
        1,
        1,
        *routine_file_dumper_, 
        end_);
    ASSERT_TRUE(true==ret);

    ret = db_device_->Init(
        100,
        0,
        0,
        *routine_file_dumper_,
        db_mem_,
        CallbackReplyLog_,
        end_);
    ASSERT_TRUE(true==ret);

    FlushMsg flush_msg;
    flush_msg.cmd = Cmd::kAddRecord;

    flush_msg.cmd_extra.add_rec.key=2;
    flush_msg.msg = Slice("abc", 3);
    ret = db_device_->ProcessFlushMsg(flush_msg);
    ASSERT_TRUE(ErrorNo::kSucc == ret);

    flush_msg.cmd_extra.add_rec.key=3;
    flush_msg.msg = Slice("de", 2);
    ret = db_device_->ProcessFlushMsg(flush_msg);
    ASSERT_TRUE(ErrorNo::kSucc == ret);

    flush_msg.cmd_extra.add_rec.key=4;
    flush_msg.msg = Slice("f", 1);
    ret = db_device_->ProcessFlushMsg(flush_msg);
    ASSERT_TRUE(ErrorNo::kSucc == ret);

    //flush
    db_device_->DumpDeviceIndex_();

    fp_device_index_ = fopen("data/device_index", "w");
    ASSERT_TRUE(NULL!=fp_device_index_);
    ret = DBDevice::IndexDumper_(RCAST<void*>(db_device_), fp_device_index_);
    ASSERT_TRUE(0==ret);
    fclose(fp_device_index_);
    ///

    flush_msg.cmd_extra.add_rec.key=5;
    flush_msg.msg = Slice("ghik", 4);
    ret = db_device_->ProcessFlushMsg(flush_msg);
    ASSERT_TRUE(ErrorNo::kSucc == ret);

    DevicePos device_pos;
    db_device_->GetDevicePos(device_pos);
    ASSERT_EQ(1, device_pos.index);
    ASSERT_EQ(32, device_pos.offset);

    ASSERT_EQ(0, db_device_->index_for_dump_.device_pos_.index);
    ASSERT_EQ(61, db_device_->index_for_dump_.device_pos_.offset);
  }

  virtual void TearDown() {}

 private:
  static bool CallbackReplyLog_(DBMem&, const DeviceLog&) {
    return true;
  }
 
 private:
  bool end_;
  DBMem db_mem_;
  DBDevice* db_device_;
  FILE* fp_device_index_;
  RoutineFileDumper* routine_file_dumper_;
};

TEST_F(TestDBDevice, all) {
  db_device_->~DBDevice();

  db_device_ = new (db_device_) DBDevice;
  int ret = db_device_->Init(
      100,
      0,
      0,
      *routine_file_dumper_,
      db_mem_,
      CallbackReplyLog_,
      end_);
  ASSERT_TRUE(true==ret);

  DevicePos device_pos;
  db_device_->GetDevicePos(device_pos);
  ASSERT_EQ(1, device_pos.index);
  ASSERT_EQ(32, device_pos.offset);

  DeviceLog* device_log;
  ret = db_device_->GetRecord(4, device_log);
  ASSERT_TRUE(ErrorNo::kSucc == ret);
  ASSERT_TRUE('f' == device_log->GetContent()[0]);
  ASSERT_TRUE(1 == device_log->GetContentLen());

  ret = db_device_->GetRecord(5, device_log);
  ASSERT_TRUE(ErrorNo::kSucc == ret);
  ASSERT_TRUE('g' == device_log->GetContent()[0]);
  ASSERT_TRUE(4 == device_log->GetContentLen());

  end_=true;
}
