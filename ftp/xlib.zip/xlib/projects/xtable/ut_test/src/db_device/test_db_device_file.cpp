#include "gtest/gtest.h"
#include "db_device/db_device_file.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
/*
class TestDBDeviceFile : public ::testing::Test {
 protected:
  virtual ~TestDBDeviceFile() {} 
  virtual void SetUp() {
    system("rm -rf data/db*");
  }
  virtual void TearDown() {}
};

TEST_F(TestDBDeviceFile, GetDBFilepath) {
  ASSERT_TRUE("data/db12" == DBDeviceFile::GetDBFilepath(12));
}

TEST_F(TestDBDeviceFile, GetLastDBFilePath) {
  int current_index;
  DBDeviceFile::GetLastDBFilePath(current_index);
  ASSERT_EQ(-1, current_index);
  system("touch data/db0 data/db12 data/db21");
  DBDeviceFile::GetLastDBFilePath(current_index);
  ASSERT_EQ(21, current_index);
}

class TestDBDeviceFileHandle : public ::testing::Test {
 protected:
  virtual ~TestDBDeviceFileHandle() {} 
  virtual void SetUp() {
    system("rm -rf data/db*");
  }
  virtual void TearDown() {}
};

TEST_F(TestDBDeviceFileHandle, writer_Reset) {
  DBDeviceFileWriteHandle write_handle(100);
  bool ret = write_handle.Reset(1, 123);
  ASSERT_TRUE(false==ret);

  ret = write_handle.Reset(1, 23);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(23, lseek(write_handle.fd_, 0, SEEK_CUR));

  ret = write_handle.Reset(1, 32);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(32, lseek(write_handle.fd_, 0, SEEK_CUR));

  ret = write_handle.Reset(2, 30);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(30, lseek(write_handle.fd_, 0, SEEK_CUR));

  ASSERT_EQ(write_handle.index_, 2);
  ASSERT_TRUE(write_handle.start_addr_ == 
      RCAST<char*>(write_handle.cur_log_));
  ASSERT_EQ(write_handle.room_left_, 100);
}

TEST_F(TestDBDeviceFileHandle, other) {
  //write handle

  typedef FixedMsgPipeMsg<FlushMsgHeader> PipeMsg;

  DBDeviceFileWriteHandle write_handle(100);
  int ret = write_handle.Reset(-1);
  ASSERT_TRUE(true==ret);
  ASSERT_TRUE(write_handle.HasValidLogHere() > 0);

  const char* str = "abc";
  PipeMsg* msg = RCAST<PipeMsg*>(
      operator new (sizeof(PipeMsg) + strlen(str)));

  msg->msg_header.logic_time = 12;
  msg->msg_header.cmd = Cmd::kAddRecord;
  msg->msg_header.cmd_extra.add_rec.key = 1;
  msg->len = strlen(str);
  memcpy(msg->msg, str, strlen(str));

  ASSERT_TRUE(true == write_handle.HasSpaceForNewLog(*msg));
  write_handle.WriteCurrentLog(*msg);

  msg->msg_header.logic_time = 13;
  msg->msg_header.cmd_extra.add_rec.key = 2;
  ASSERT_TRUE(true == write_handle.HasSpaceForNewLog(*msg));
  write_handle.WriteCurrentLog(*msg);

  msg->msg_header.logic_time = 14;
  msg->msg_header.cmd_extra.add_rec.key = 3;
  ASSERT_TRUE(true == write_handle.HasSpaceForNewLog(*msg));
  write_handle.WriteCurrentLog(*msg);

  ASSERT_TRUE(false == write_handle.HasSpaceForNewLog(*msg));

  DeviceLog* device_log = write_handle.GetLog(31);
  ASSERT_EQ(size_t(13), device_log->GetLogicTime());

  write_handle.Flush();

  ret = write_handle.Reset(1);
  ASSERT_TRUE(true==ret);
  ret = write_handle.Reset(0);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(12), write_handle.cur_log_->GetLogicTime());
  write_handle.PassLog();
  write_handle.PassLog();
  ASSERT_EQ(size_t(14), write_handle.cur_log_->GetLogicTime());
  write_handle.PassLog();
  ASSERT_TRUE(write_handle.HasValidLogHere() > 0);

  //read handle

  DBDeviceFileReadHandle read_handle;
  ret = read_handle.Reset(2, 0);
  ASSERT_TRUE(false==ret);
  ret = read_handle.Reset(0, 3);
  ASSERT_TRUE(true==ret);

  device_log = RCAST<DeviceLog*>(operator new (Limits::kMaxSizeRecord));
  ret = read_handle.ReadLog(*device_log);
  ASSERT_TRUE(ret<0);

  ret = read_handle.Reset(0, 31);
  ASSERT_TRUE(true==ret);

  ret = read_handle.ReadLog(*device_log);
  ASSERT_TRUE(0==ret);
  ASSERT_EQ(2, device_log->GetKey());

  ret = read_handle.Reset(0, 93);
  ASSERT_TRUE(true==ret);

  ret = read_handle.ReadLog(*device_log);
  ASSERT_TRUE(ret>0);

  delete device_log;
  delete msg;
}
*/
