#include "gtest/gtest.h"
#include "db_device/db_device_index.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestDBDeviceIndex : public ::testing::Test {
 protected:
  virtual ~TestDBDeviceIndex() {} 
  virtual void SetUp() {
    system("rm -rf data/test_db_device/; mkdir -p data/test_db_device/");
  }

  virtual void TearDown() {}
};

TEST_F(TestDBDeviceIndex, all) {
  /*
  bool ret;
  DBDeviceIndex db_device_index;
  ret = db_device_index.Init("db_device_index", NULL);
  ASSERT_TRUE(true==ret);

  ret = (db_device_index.Insert(1, (struct DiskRecordPos){2,3}, 1 )).first;
  ASSERT_TRUE(true==ret);
  ret = (db_device_index.Insert(2, (struct DiskRecordPos){3,4}, 2 )).first;
  ASSERT_TRUE(true==ret);
  ret = (db_device_index.Insert(3, (struct DiskRecordPos){4,5}, 3 )).first;
  ASSERT_TRUE(true==ret);
  ret = (db_device_index.Insert(4, (struct DiskRecordPos){9,1}, 4 )).first;
  ASSERT_TRUE(true==ret);
  ret = db_device_index.Erase(2, 5);
  ASSERT_TRUE(true==ret);

  DiskRecordPos disk_record_pos;
  ret = db_device_index.Find(1, disk_record_pos);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(3), disk_record_pos.offset);
  ret = db_device_index.Find(2, disk_record_pos);
  ASSERT_TRUE(false==ret);
  ret = db_device_index.Find(3, disk_record_pos);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(5), disk_record_pos.offset);
  ret = db_device_index.Find(4, disk_record_pos);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(1), disk_record_pos.offset);
 
  FILE* fp = fopen("data/tmp", "w");
  ASSERT_TRUE(NULL!=fp);
  ret = db_device_index.Serialize(fp);
  ASSERT_TRUE(true==ret);
  fclose(fp);

  db_device_index.Clear();

  fp = fopen("data/tmp", "r");
  ASSERT_TRUE(NULL!=fp);
  ret = db_device_index.Deserialize(fp);
  ASSERT_TRUE(true==ret);
  fclose(fp);

  ret = db_device_index.Find(1, disk_record_pos);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(3), disk_record_pos.offset);
  ret = db_device_index.Find(2, disk_record_pos);
  ASSERT_TRUE(false==ret);
  ret = db_device_index.Find(3, disk_record_pos);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(5), disk_record_pos.offset);
  ret = db_device_index.Find(4, disk_record_pos);
  ASSERT_TRUE(true==ret);
  */
}
