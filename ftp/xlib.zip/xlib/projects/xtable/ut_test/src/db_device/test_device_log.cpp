#include "gtest/gtest.h"
#include "db_device/db_device.h"
#include "public.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
/*
class TestDeviceLog : public ::testing::Test {
 protected:
  virtual ~TestDeviceLog() {} 
  virtual void SetUp() {
    system("rm -rf data/db* data/device_index*");
  }

  virtual void TearDown() {}
};

TEST_F(TestDeviceLog, all) {
  typedef FixedMsgPipeMsg<FlushMsgHeader> PipeMsg;
  const char* str = "abc";

  PipeMsg* msg = RCAST<PipeMsg*>(
      operator new (sizeof(PipeMsg) + strlen(str)));

  msg->msg_header.logic_time = 12;
  msg->msg_header.cmd = Cmd::kAddRecord;
  msg->msg_header.cmd_extra.add_rec.key = 1;
  msg->len = strlen(str);
  memcpy(msg->msg, str, strlen(str));

  DeviceLog* device_log = RCAST<DeviceLog*>(
      operator new (sizeof(DeviceLog) + strlen(str)));

  device_log->Assign(*msg);
  bool ret = device_log->CheckChecksum();
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(Cmd::kAddRecord, device_log->GetCmd());

  device_log->cmd_ = Cmd::kRemoveRecord;
  ret = device_log->CheckChecksum();
  ASSERT_TRUE(false==ret);

  ASSERT_EQ(size_t(31), device_log->GetSize());
  ASSERT_EQ(size_t(35), device_log->DeviceSpaceAquired());

  DeviceLog* device_log_dup = RCAST<DeviceLog*>(
      operator new (sizeof(DeviceLog) + strlen(str)));
  *device_log_dup = *device_log;
  ASSERT_EQ(Cmd::kRemoveRecord, device_log_dup->GetCmd());

  delete device_log_dup;
  delete device_log;
  delete msg;
}
*/
