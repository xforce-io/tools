#include "gtest/gtest.h"
#include "../../../src/db_mem_core/tables_mgr.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestTablesMgr : public ::testing::Test {
 protected:
  explicit TestTablesMgr() {}
  virtual void SetUp() {
    system("rm -rf data/test_tables_mgr; mkdir -p data/test_tables_mgr");
  }

  virtual void TearDown() {}
};

TEST_F(TestTablesMgr, parse) {
  /*
  bool end=false;
  TablesMgr tables_mgr;
  RoutineFileDumper routine_file_dumper(end);
  bool ret = tables_mgr.Init(
      2,
      routine_file_dumper);
  ASSERT_TRUE(true==ret);

  end=true;
  */
}
