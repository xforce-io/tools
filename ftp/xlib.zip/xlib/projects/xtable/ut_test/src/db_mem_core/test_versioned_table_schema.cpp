#include "gtest/gtest.h"
#include "../../../src/db_mem_core/versioned_table_schema.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestVersionedTableSchema : public ::testing::Test {
 protected:
  explicit TestVersionedTableSchema() {}

  virtual void SetUp() {
    system("rm -rf data/test_versioned_table_schema"); 
    system("mkdir -p data/test_versioned_table_schema");
  }

  virtual void TearDown() {}
};

TEST_F(TestVersionedTableSchema, init) {
  std::string table_syntax = "{"
        "\"name\":\"sample_table\","
        "\"schema\":["
          "{"
            "\"col\":\"col0\","
            "\"type\":\"int32\""
          "},{"
            "\"col\":\"col1\","
            "\"type\":\"str\""
          "},{"
            "\"col\":\"col2\","
            "\"type\":\"int64\""
          "}"
        "],"
        "\"indexs\":["
          "{"
            "\"name\":\"sample\","
            "\"category\":\"index\","
            "\"column\":2"
          "}"
        "]"
      "}";

  WeakType table_wt;
  int ret = table_wt.JsonDecode(table_syntax.c_str(), table_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  VersionedTableSchema versioned_table_schema;
  ret = versioned_table_schema.Init(table_wt);
  ASSERT_TRUE(true==ret);
}
