#include "gtest/gtest.h"
#include "db_mem_core/merger/settree/set_pool.h"
#include "db_mem_core/merger/settree/null_set.h"
#include "db_mem_core/merger/settree/set.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_settree, parse_positive) {
  NullSet* null_set = ThreadPrivateSetPool::Get<NullSet>();
  ASSERT_TRUE(NULL!=null_set);
  Set* set = ThreadPrivateSetPool::Get<Set>();
  ASSERT_TRUE(NULL!=set);
  ThreadPrivateSetPool::Free(set);
  ThreadPrivateSetPool::Free(null_set);
}
