#include "gtest/gtest.h"
#include "../../../src/db_mem_core/db_mem_core.h"
#include "../../../src/db_mem.h"
#include "../../../src/db_mem_core/table_index/table_index_feature_list.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestDBMemCore : public ::testing::Test {
 protected:
  explicit TestDBMemCore() : 
    end_(false),
    routine_file_dumper_(end_) {}

  virtual ~TestDBMemCore() {}

  virtual void SetUp() {
    system("rm -rf data/db* data/device_index*");

    bool ret = db_mem_.Init(
        db_device_,
        (1<<20),
        0,
        0,
        routine_file_dumper_, 
        end_);
    ASSERT_TRUE(true==ret);

    ret = db_device_.Init(
        100,                  //max_size_block
        0,                    //index_dump_interval
        0,                    //flush_interval
        routine_file_dumper_, //routine_file_dumper
        db_mem_,
        CallbackReplyLog_,
        end_);
    ASSERT_TRUE(true==ret);

    ret = db_device_.StartDumpThread();
    ASSERT_TRUE(true==ret);

    DBMemCore::InitParams init_params;
    init_params.db_device = &db_device_;
    init_params.size_lru_queue = 1000;
    init_params.tables_dump_interval = 1;
    init_params.routine_file_dumper = &routine_file_dumper_;

    ret = db_mem_core_.Init("db_mem_core", &init_params);
    ASSERT_TRUE(true==ret);

    table_syntax_ = 
      "{"
        "\"name\":\"sample_table\","
        "\"schema\":["
          "{"
            "\"col\":\"col0\","
            "\"type\":\"int32\""
          "},{"
            "\"col\":\"col1\","
            "\"type\":\"str\""
          "},{"
            "\"col\":\"col2\","
            "\"type\":\"int64\""
          "}"
        "],"
        "\"indexs\":["
          "{"
            "\"name\":\"sample\","
            "\"category\":\"index\","
            "\"column\":2"
          "}"
        "]"
      "}";
  }

  virtual void TearDown() {
    end_=true;
  }
 
 private:
  static bool CallbackReplyLog_(DBMem& /*db_mem*/, const DeviceLog& /*device_log*/) {
    return true;
  }
 
 private:
  bool end_;
  DBDevice db_device_; 
  DBMem db_mem_;
  DBMemCore db_mem_core_;
  RoutineFileDumper routine_file_dumper_;
  std::string table_syntax_;
};

TEST_F(TestDBMemCore, simple) {
  int ret = db_mem_core_.CreateTable(table_syntax_, 100);
  ASSERT_EQ(0, ret);

  WeakType record_wt;
  std::string record_syntax = "[12, \"abc\", 4]";

  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.AddRecord("unexist_table", record_wt, 101);
  ASSERT_TRUE(ErrorNo::kNoSuchTable == ret);

  ret = db_mem_core_.AddRecord("sample_table", record_wt, 99);
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  ResultsGetRecord* results_get_record;
  ret = db_mem_core_.GetRecord("sample_table", record_wt, results_get_record); 
  ASSERT_TRUE(ErrorNo::kInvalidSyntax == ret);

  ret = db_mem_core_.AddRecord("sample_table", record_wt, 101);
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  ret = db_mem_core_.AddRecord("sample_table", record_wt, 102);
  ASSERT_TRUE(ErrorNo::kDupKey == ret);

  record_wt = WeakType();
  record_syntax = "[12]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.GetRecord("sample_table", record_wt, results_get_record); 
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  ASSERT_EQ(size_t(1), results_get_record->size_records);
  ASSERT_TRUE(ErrorNo::kSucc == results_get_record->states[0]);
  ASSERT_EQ(12, results_get_record->records[0]->GetInt(0));
  ASSERT_EQ(4, results_get_record->records[0]->GetInt(2));

  record_syntax = "[13, \"c\", 5]";
  record_wt = WeakType();
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.AddRecord("sample_table", record_wt, 103);
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  record_syntax = "[14, \"ab\", 50]";
  record_wt = WeakType();
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.AddRecord("sample_table", record_wt, 104);
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  record_syntax = "[12, 13]";
  record_wt = WeakType();
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.RemoveRecord("sample_table", record_wt, 105);
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  record_wt = WeakType();
  record_syntax = "[11, 14]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = db_mem_core_.GetRecord("sample_table", record_wt, results_get_record); 
  ASSERT_TRUE(ErrorNo::kSucc == ret);

  ASSERT_EQ(size_t(2), results_get_record->size_records);
  ASSERT_TRUE(ErrorNo::kNoSuckKey == results_get_record->states[0]);
  ASSERT_TRUE(NULL == results_get_record->records[0]);
  ASSERT_TRUE(ErrorNo::kSucc == results_get_record->states[1]);
  ASSERT_EQ(14, results_get_record->records[1]->GetInt(0));
  ASSERT_EQ(50, results_get_record->records[1]->GetInt(2));
}
