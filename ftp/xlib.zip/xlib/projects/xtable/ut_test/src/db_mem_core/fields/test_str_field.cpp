#include "gtest/gtest.h"
#include "../../../../src/db_mem_core/fields/str_field.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestStrField : public ::testing::Test {
 protected:
  explicit TestStrField() {}
  virtual void SetUp() {}
  virtual void TearDown() {}
};

TEST_F(TestStrField, init) {
  std::string str = "asd";
  StrField str_field(str.c_str(), str.length());
  ASSERT_EQ(0, strcmp(str_field.GetStr(), str.c_str()));
  ASSERT_EQ(size_t(3), str_field.Len());

  str = "abcdefgh";
  str_field.Assign(str.c_str(), str.length());
  ASSERT_EQ(0, strcmp(str_field.GetStr(), str.c_str()));
  ASSERT_EQ(size_t(8), str_field.Len());

  str = "abcdef";
  str_field.Assign(str.c_str(), str.length());
  ASSERT_EQ(0, strcmp(str_field.GetStr(), str.c_str()));
  ASSERT_EQ(size_t(6), str_field.Len());

  str = "ab";
  str_field.Assign(str.c_str(), str.length());
  ASSERT_EQ(0, strcmp(str_field.GetStr(), str.c_str()));
  ASSERT_EQ(size_t(2), str_field.Len());
}

void MakeRandStr(std::string& str) {
  static const size_t kLenStr = 100;
  str.clear();
  size_t len_str = rand() % kLenStr;
  for (size_t j=0; j<len_str; ++j) {
    str.append(1, 'a'+rand()%26);
  }
}

TEST_F(TestStrField, pressure) {
  std::string str = "asd";
  StrField str_field(str.c_str(), str.length());

  static const size_t kNumTests = 1000;
  for (size_t i=0; i<kNumTests; ++i) {
    MakeRandStr(str);
    str_field.Assign(str.c_str(), str.length());
    ASSERT_EQ(0, strcmp(str_field.GetStr(), str.c_str()));
  }
}
