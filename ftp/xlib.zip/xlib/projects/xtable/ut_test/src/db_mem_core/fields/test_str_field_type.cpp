#include "gtest/gtest.h"
#include "../../../../src/db_mem_core/fields/str_field_type.hpp"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestStrFieldType : public ::testing::Test {
 protected:
  explicit TestStrFieldType() {}
  virtual void SetUp() {}
  virtual void TearDown() {}
};

TEST_F(TestStrFieldType, basic) {
  char mem[sizeof(void*)];
  bzero(mem, sizeof(mem));
  void* field = RCAST<void*>(mem);
  StrFieldType type;
  int ret = type.SetStr(field, "a");
  ASSERT_TRUE(true==ret);
  const char* str = type.GetStr(field);
  ASSERT_TRUE(0 == strcmp(str, "a"));

  char buf[2];
  ret = type.Serialize(field, buf, 1);
  ASSERT_TRUE(ret<=0);
  ret = type.Serialize(field, buf, sizeof(buf));
  ASSERT_EQ(2, ret);

  char mem_2[sizeof(void*)];
  bzero(mem_2, sizeof(mem_2));
  void* field_2 = RCAST<void*>(mem_2);

  ret = type.Deserialize(buf, sizeof(buf), field_2);
  ASSERT_EQ(2, ret);
  str = type.GetStr(field_2);
  ASSERT_TRUE(0 == strcmp(str, "a"));

  delete type.GetStrField(field);
  delete type.GetStrField(field_2);
}
