#include "gtest/gtest.h"
#include "../../../src/db_mem_core/table_schema.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  //srand(time(NULL));
  srand(2);
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestTableSchema : public ::testing::Test {
 protected:
  explicit TestTableSchema() {}
  virtual void SetUp() {
    system("rm -rf data/test_table_schema");
    system("mkdir -p data/test_table_schema");

    std::string table_schema_syntax = "["
        "{"
          "\"col\":\"col0\","
          "\"type\":\"int32\""
        "},{"
          "\"col\":\"col1\","
          "\"type\":\"set16\""
        "},{"
          "\"col\":\"col2\","
          "\"type\":\"int8\""
        "},{"
          "\"col\":\"col3\","
          "\"type\":\"bool\""
        "},{"
          "\"col\":\"col4\","
          "\"type\":\"str\""
        "},{"
          "\"col\":\"col5\","
          "\"type\":\"int64\""
        "},{"
          "\"col\":\"col6\","
          "\"type\":\"bool\""
        "}"
      "]";

    WeakType table_schema_wt;
    bool ret = table_schema_wt.JsonDecode(
        table_schema_syntax.c_str(), 
        table_schema_syntax.size(), 
        NULL);

    ret = table_schema_.Init(table_schema_wt);
    ASSERT_TRUE(true==ret);

    fields_ = malloc(100);
    bzero(fields_, 100);

    ret = table_schema_.SetInt(fields_, 0, 2);
    ASSERT_TRUE(true==ret);
    ret = table_schema_.InsertIntoIntSet(fields_, 1, "1,2,3,2e");
    ASSERT_TRUE(false==ret);
    ret = table_schema_.InsertIntoIntSet(fields_, 1, "1,2,3,2");
    ASSERT_TRUE(true==ret);
    ret = table_schema_.SetInt(fields_, 2, 12345);
    ASSERT_TRUE(false==ret);
    ret = table_schema_.SetInt(fields_, 3, 123);
    ASSERT_TRUE(true==ret);
    ret = table_schema_.SetStr(fields_, 4, "sd");
    ASSERT_TRUE(true==ret);
    ret = table_schema_.SetInt(fields_, 5, 12345612345612);
    ASSERT_TRUE(true==ret);
    const BaseIntSetField* intset = table_schema_.GetIntSet(fields_, "col1");
    ASSERT_EQ(size_t(4), intset->Size());
  }

  virtual void TearDown() {
    delete table_schema_.GetIntSet(fields_, "col1");
    delete table_schema_.GetStrField(fields_, "col4");
    free(fields_);
  }

  virtual ~TestTableSchema() {}
 
 private: 
  TableSchema table_schema_;
  void* fields_;
};

TEST_F(TestTableSchema, init) {
  ASSERT_EQ(size_t(7), table_schema_.Size());
  ASSERT_EQ(size_t(31), table_schema_.SizeRecord());
  ASSERT_EQ(size_t(0), table_schema_.schema_[0].offset);
  ASSERT_EQ(size_t(4), table_schema_.schema_[1].offset);
  ASSERT_EQ(size_t(30), table_schema_.schema_[6].offset);
  ASSERT_EQ(RealFieldType::kInt32, table_schema_.schema_[0].type.GetType());
  ASSERT_EQ(RealFieldType::kSet16, table_schema_.schema_[1].type.GetType());
}

TEST_F(TestTableSchema, get_and_set) {
  int64_t int64 = table_schema_.GetTableKey(fields_);
  ASSERT_EQ(2, int64);
  const char* str = table_schema_.GetStr(fields_, "col1");
  ASSERT_TRUE(NULL==str);
  int64 = table_schema_.GetInt(fields_, "col3");
  ASSERT_EQ(1, int64);
  str = table_schema_.GetStr(fields_, "col4");
  ASSERT_TRUE(NULL!=str);
  ASSERT_TRUE(0 == strcmp(str, "sd"));
  int64 = table_schema_.GetInt(fields_, "col5");
  ASSERT_EQ(12345612345612, int64);
}

TEST_F(TestTableSchema, change_syntax) {
  bool ret = table_schema_.ChangeType("col5", "int32");
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(7), table_schema_.Size());
  ASSERT_EQ(size_t(27), table_schema_.SizeRecord());

  ASSERT_TRUE("col5" == table_schema_.schema_[5].name);
  ASSERT_TRUE(RealFieldType::kInt32 == table_schema_.schema_[5].type.GetType());
  ASSERT_EQ(size_t(22), table_schema_.schema_[5].offset);

  ret = table_schema_.RemoveColumn("col5");
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(6), table_schema_.Size());
  ASSERT_EQ(size_t(23), table_schema_.SizeRecord());

  ASSERT_TRUE("col6" == table_schema_.schema_[5].name);
  ASSERT_TRUE(RealFieldType::kBool == table_schema_.schema_[5].type.GetType());
  ASSERT_EQ(size_t(22), table_schema_.schema_[5].offset);
}

TEST_F(TestTableSchema, update) {
  TableSchema table_schema_new = table_schema_;
  bool ret = table_schema_new.RemoveColumn("col3");
  ASSERT_TRUE(true==ret);
  ret = table_schema_new.RemoveColumn("col5");
  ASSERT_TRUE(true==ret);
  ret = table_schema_new.ChangeType("col2", "int16");
  ASSERT_TRUE(true==ret);

  std::string default_val = "abc";
  ret = table_schema_new.AddColumn("col3", "int16", &default_val, 1);
  ASSERT_TRUE(false==ret);
  ret = table_schema_new.AddColumn("col3", "str", &default_val, 1);
  ASSERT_TRUE(true==ret);

  void* new_fields = table_schema_new.Update(fields_, table_schema_);
  ASSERT_TRUE(NULL!=new_fields);

  ret = table_schema_new.SetInt(new_fields, 2, 12345);
  ASSERT_TRUE(true==ret);

  int64_t int64 = table_schema_new.GetInt(new_fields, "col0");
  ASSERT_EQ(2, int64);
  const char* str = table_schema_new.GetStr(new_fields, "col3");
  ASSERT_TRUE(0 == strcmp(str, "abc"));
  str = table_schema_new.GetStr(new_fields, "col4");
  ASSERT_TRUE(0 == strcmp(str, "sd"));
  int64 = table_schema_new.GetInt(new_fields, "col5");
  ASSERT_EQ(LLONG_MIN, int64);
  const BaseIntSetField* intset = table_schema_new.GetIntSet(new_fields, "col1");
  ASSERT_EQ(size_t(4), intset->Size());

  delete table_schema_new.GetIntSet(new_fields, "col1");
  delete table_schema_new.GetStrField(new_fields, "col3");
  delete table_schema_new.GetStrField(new_fields, "col4");
  free(new_fields);
}

TEST_F(TestTableSchema, copy) {
  void* new_fields = malloc(table_schema_.SizeRecord());
  bzero(new_fields, table_schema_.SizeRecord());
  bool ret = table_schema_.Copy(fields_, new_fields);
  ASSERT_TRUE(true==ret);
  const BaseIntSetField* intset = table_schema_.GetIntSet(new_fields, "col1");
  ASSERT_EQ(size_t(4), intset->Size());

  delete table_schema_.GetIntSet(new_fields, "col1");
  delete table_schema_.GetStrField(new_fields, "col4");
  free(new_fields);
}

TEST_F(TestTableSchema, serialize_schema) {
  FILE* fp = fopen("data/test_table_schema/schema", "w+");
  ASSERT_TRUE(NULL!=fp);

  int ret = table_schema_.Serialize(fp);
  ASSERT_EQ(0, ret);

  rewind(fp);

  TableSchema new_table_schema;
  ret = new_table_schema.Deserialize(fp);
  ASSERT_EQ(0, ret);

  ASSERT_TRUE(0 == strcmp(table_schema_.syntax_.c_str(), new_table_schema.syntax_.c_str()));
  ASSERT_EQ(table_schema_.name_to_index_.size(), new_table_schema.name_to_index_.size());
  ASSERT_EQ(table_schema_.schema_.size(), new_table_schema.schema_.size());
  ASSERT_EQ(new_table_schema.name_to_index_.size(), new_table_schema.schema_.size());
  ASSERT_EQ(table_schema_.schema_.begin()->offset, new_table_schema.schema_.begin()->offset);
  ASSERT_EQ(table_schema_.schema_.back().offset, new_table_schema.schema_.back().offset);
  ASSERT_EQ(table_schema_.schema_.back().version, new_table_schema.schema_.back().version);
}
