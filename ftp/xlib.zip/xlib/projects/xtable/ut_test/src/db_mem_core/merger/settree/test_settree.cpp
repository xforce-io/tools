#include "gtest/gtest.h"
#include "db_mem_core/merger/settree/settree.hpp"
#include "db_mem_core/merger/settree/null_set.h"
#include "db_mem_core/merger/set/set_op.h"

namespace zmt { namespace material_center {

LOGGER_IMPL(material_center, "material_center")

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_settree, parse_positive) {
  bool ret;
  std::string tree_conf = "{"
    "\"mark\":1,"
    "\"op\":\"and\""
  "}";

  WeakType tree_conf_wt;
  ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  ASSERT_TRUE(settree.root_->mark_ == 1);
  ASSERT_TRUE(settree.root_->op_ == IndexerOps::And);
  ASSERT_TRUE(settree.root_->is_mountable_ == false);
  ASSERT_TRUE(settree.root_->children_.size() == 0);

  std::string tree_conf_2 = "{"
      "\"name\":\"root\","
      "\"mark\":3,"
      "\"op\":\"and\","
      "\"children\":"
          "["
              "{"
                  "\"name\":\"left\","
                  "\"mark\":1,"
                  "\"op\":\"or\","
                  "\"mountable\":1"
              "},"
              "{"
                  "\"name\":\"right\","
                  "\"mark\":2,"
                  "\"op\":\"priority\","
                  "\"mountable\":0"
              "}"
          "]"
  "}";
  WeakType tree_conf_2_wt;
  ret = tree_conf_2_wt.JsonDecode(tree_conf_2.c_str(), tree_conf_2.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree_2;
  ret = settree_2.Parse(tree_conf_2_wt);
  ASSERT_TRUE(true==ret);

  ASSERT_TRUE(settree_2.root_->name_ == "root");
  ASSERT_TRUE(settree_2.root_->mark_ == 3);
  ASSERT_TRUE(settree_2.root_->op_ == IndexerOps::And);
  ASSERT_TRUE(settree_2.root_->is_mountable_ == false);
  ASSERT_EQ(settree_2.root_->children_.size(), size_t(2));

  ASSERT_TRUE(settree_2.root_->children_[0]->name_ == "left");
  ASSERT_TRUE(settree_2.root_->children_[0]->mark_ == 1);
  ASSERT_TRUE(settree_2.root_->children_[0]->op_ == IndexerOps::Or);
  ASSERT_TRUE(settree_2.root_->children_[0]->is_mountable_ == true);
  ASSERT_TRUE(settree_2.root_->children_[0]->is_extra_ == false);
  ASSERT_TRUE(settree_2.root_->children_[0]->idx_father_ == 0);
  ASSERT_TRUE(settree_2.root_->children_[0]->children_.size() == 0);

  ASSERT_TRUE(settree_2.root_->children_[1]->name_ == "right");
  ASSERT_TRUE(settree_2.root_->children_[1]->mark_ == 2);
  ASSERT_TRUE(settree_2.root_->children_[1]->op_ == IndexerOps::Priority);
  ASSERT_TRUE(settree_2.root_->children_[1]->is_mountable_ == false);
  ASSERT_TRUE(settree_2.root_->children_[1]->is_extra_ == false);
  ASSERT_TRUE(settree_2.root_->children_[1]->idx_father_ == 1);
  ASSERT_TRUE(settree_2.root_->children_[1]->children_.size() == 0);
}

TEST(test_settree, parse_passive) {
  //invalid mark
  std::string tree_conf = "{"
    "\"name\":\"root\","
    "\"mark\":\"1\","
    "\"op\":\"and\""
  "}";

  WeakType tree_conf_wt;
  bool ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(false==ret);

  //invalid json
  tree_conf = "{"
    "\"name\":\"root\","
    "\"mark\":1,"
    "\"op\":\"as\""
  "}";

  ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(false==ret);

  //same mark can't appear twice
  tree_conf = "{"
      "\"name\":\"root\","
      "\"mark\":3,"
      "\"op\":\"and\","
      "\"children\":"
          "["
              "{"
                  "\"name\":\"left\","
                  "\"mark\":1,"
                  "\"op\":\"or\","
                  "\"mountable\":1"
              "},"
              "{"
                  "\"name\":\"right\","
                  "\"mark\":3,"
                  "\"op\":\"priority\","
                  "\"mountable\":0"
              "}"
          "]"
  "}";

  ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(false==ret);
}

TEST(test_settree, add_extra_node_and_reset) {
  bool ret;
  std::string tree_conf = "{"
      "\"name\":\"root\","
      "\"mark\":3,"
      "\"op\":\"and\","
      "\"children\":"
          "["
              "{"
                  "\"name\":\"left\","
                  "\"mark\":1,"
                  "\"op\":\"or\","
                  "\"mountable\":1"
              "},"
              "{"
                  "\"name\":\"right\","
                  "\"mark\":2,"
                  "\"op\":\"priority\","
                  "\"mountable\":0"
              "}"
          "]"
  "}";

  WeakType tree_conf_wt;
  ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_.size());
  ret = settree.AddDynamicNode(2, NULL);
  ASSERT_TRUE(false==ret);
  ret = settree.AddDynamicNode(1, NULL);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(1), settree.root_->children_[0]->children_.size());
  settree.Reset();
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_.size());
}

TEST(test_settree, add_del_node) {
  bool ret;
  std::string tree_conf = "{"
    "\"name\":\"root\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int>* settree_node;
  settree_node = settree.AddNode_("a", 2, IndexerOps::Or, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  ASSERT_EQ(size_t(1), settree.root_->children_.size());

  settree_node = settree.AddNode_("b", 0, IndexerOps::And, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  ASSERT_EQ(size_t(2), settree.root_->children_.size());

  settree_node = settree.AddNode_("c", 4, IndexerOps::Priority, false, settree.root_, 0);
  ASSERT_TRUE(NULL!=settree_node);
  ASSERT_EQ(size_t(2), settree.root_->children_.size());

  ASSERT_TRUE(settree.root_->name_ == "root");
  ASSERT_TRUE(settree.root_->children_[0]->name_ == "c");
  ASSERT_TRUE(settree.root_->children_[1]->name_ == "b");
  ASSERT_TRUE(settree.root_->children_[0]->children_[0]->name_ == "a");
  ASSERT_TRUE(settree.root_->children_[1]->name_ == "b");

  settree.DelNode_(*(settree.root_->children_[0]));
  ASSERT_TRUE(settree.root_->children_[0]->name_ == "a");

  settree.DelNode_(*(settree.root_->children_[0]));
  ASSERT_EQ(size_t(1), settree.root_->children_.size());
  ASSERT_TRUE(settree.root_->children_[0]->name_ == "b");
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_.size());
}

TEST(test_settree, planished) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2, *settree_node_3;
  settree_node = settree.AddNode_("b", 0, IndexerOps::And, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::And, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node_3 = settree.AddNode_("d", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  settree_node_3 = settree.AddNode_("e", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  settree_node_2 = settree.AddNode_("f", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  settree_node = settree.AddNode_("g", 0, IndexerOps::Or, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("h", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node_2 = settree.AddNode_("i", 0, IndexerOps::Or, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node_3 = settree.AddNode_("j", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  settree_node_3 = settree.AddNode_("k", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);

  settree_node = settree.AddNode_("l", 0, IndexerOps::And, true, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("m", 0, IndexerOps::And, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node_3 = settree.AddNode_("o", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  settree_node_3 = settree.AddNode_("p", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  settree_node_2 = settree.AddNode_("n", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  ret = settree.Planish_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_TRUE(settree.root_->name_ == "a");
  ASSERT_EQ(settree.root_->children_.size(), size_t(5));
  ASSERT_TRUE(settree.root_->children_[0]->name_ == "d");
  ASSERT_TRUE(settree.root_->children_[1]->name_ == "g");
  ASSERT_TRUE(settree.root_->children_[2]->name_ == "l");
  ASSERT_TRUE(settree.root_->children_[3]->name_ == "e");
  ASSERT_TRUE(settree.root_->children_[4]->name_ == "f");
  ASSERT_EQ(settree.root_->children_[1]->children_.size(), size_t(3));
  ASSERT_TRUE(settree.root_->children_[1]->children_[0]->name_ == "h");
  ASSERT_TRUE(settree.root_->children_[1]->children_[1]->name_ == "k");
  ASSERT_TRUE(settree.root_->children_[1]->children_[2]->name_ == "j");
  ASSERT_EQ(settree.root_->children_[2]->children_.size(), size_t(3));

  ret = settree.Planish_(*(settree.root_));
  ASSERT_TRUE(0==ret);
}

TEST(test_settree, adjust_and_child_has_not) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2;
  settree_node = settree.AddNode_("b", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node = settree.AddNode_("d", 0, IndexerOps::None, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("e", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("f", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_TRUE(IndexerOps::Not != settree.root_->children_[0]->op_);
  ASSERT_TRUE(IndexerOps::Not == settree.root_->children_[1]->op_);
  ASSERT_TRUE(IndexerOps::Not == settree.root_->children_[2]->op_);
}

TEST(test_settree, adjust_and_child_all_not) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2;
  settree_node = settree.AddNode_("b", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node = settree.AddNode_("d", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("e", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_EQ(size_t(1), settree.root_->children_.size());
  ASSERT_TRUE(IndexerOps::Not == settree.root_->op_);
  ASSERT_EQ(size_t(2), settree.root_->children_[0]->children_.size());
  ASSERT_EQ(IndexerOps::Or, settree.root_->children_[0]->op_);
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_[0]->idx_father_);
  ASSERT_EQ(size_t(1), settree.root_->children_[0]->children_[1]->idx_father_);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(0==ret);
}

TEST(test_settree, adjust_or_child_has_not) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"or\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2;
  settree_node = settree.AddNode_("b", 0, IndexerOps::None, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("c", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("d", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_TRUE(IndexerOps::Not == settree.root_->op_);
  ASSERT_EQ(size_t(1), settree.root_->children_.size());
  ASSERT_TRUE("a" == settree.root_->children_[0]->name_);
  ASSERT_TRUE(settree.root_ == settree.root_->children_[0]->father_);
  ASSERT_EQ(IndexerOps::And, settree.root_->children_[0]->op_);
  ASSERT_EQ(size_t(2), settree.root_->children_[0]->children_.size());
  ASSERT_EQ("b", settree.root_->children_[0]->children_[0]->children_[0]->name_);
  ASSERT_EQ(IndexerOps::Not, settree.root_->children_[0]->children_[0]->op_);
  ASSERT_EQ(size_t(1), settree.root_->children_[0]->children_[0]->children_.size());
  ASSERT_EQ("d", settree.root_->children_[0]->children_[1]->name_);
  ASSERT_EQ(IndexerOps::None, settree.root_->children_[0]->children_[1]->op_);
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_[1]->children_.size());

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_NE(IndexerOps::Not, settree.root_->children_[0]->children_[0]->op_);
  ASSERT_EQ(IndexerOps::Not, settree.root_->children_[0]->children_[1]->op_);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(0==ret);
}

TEST(test_settree, adjust_not_child) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"not\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2;
  settree_node = settree.AddNode_("b", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_TRUE(IndexerOps::None == settree.root_->op_);
  ASSERT_EQ(size_t(0), settree.root_->children_.size());
  ASSERT_TRUE("c" == settree.root_->name_);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(0==ret);
}

TEST(test_settree, adjust_not_child_not_root) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node, *settree_node_2, *settree_node_3;
  settree_node = settree.AddNode_("b", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::Not, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  settree_node_3 = settree.AddNode_("d", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(ret>0);

  ASSERT_TRUE(IndexerOps::And == settree.root_->op_);
  ASSERT_EQ(size_t(1), settree.root_->children_.size());
  ASSERT_TRUE("a" == settree.root_->name_);

  ASSERT_TRUE(IndexerOps::None == settree.root_->children_[0]->op_);
  ASSERT_EQ(size_t(0), settree.root_->children_[0]->children_.size());
  ASSERT_TRUE("d" == settree.root_->children_[0]->name_);

  ret = settree.AdjustChildren_(*(settree.root_));
  ASSERT_TRUE(0==ret);
}

TEST(test_settree, all_case_1) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"or\""
    "}";

  WeakType tree_conf_wt;
  int ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<int> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<int> *settree_node;
  settree_node = settree.AddNode_("b", 0, IndexerOps::None, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("c", 0, IndexerOps::Not, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("d", 0, IndexerOps::And, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("e", 0, IndexerOps::Not, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("f", 0, IndexerOps::Or, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node);
  settree_node = settree.AddNode_("g", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node);

  ret = settree.Optimize_();
  ASSERT_TRUE(true==ret);

  ASSERT_TRUE(IndexerOps::Or == settree.root_->op_);
  ASSERT_EQ(size_t(2), settree.root_->children_.size());
  ASSERT_TRUE("a" == settree.root_->name_);
  ASSERT_TRUE("b" == settree.root_->children_[0]->name_);
  ASSERT_TRUE("g" == settree.root_->children_[1]->name_);
}

class TestResolveSet : public Set {
 public:
  static const size_t kCategory=100;

 public:
  uint8_t GetCategory() const { return kCategory; } 
  void Resolve() { content_ += name_; }
  Set* GetResult() { return this; }
  void SetName(const std::string& name) { name_=name; }
  static std::string GetContent() { return content_; }
 
 public:
  std::string name_;
  
 private:
  static std::string content_;  
};

std::string TestResolveSet::content_;  

TEST(test_settree, test_resolve) {
  std::string tree_conf = "{"
    "\"name\":\"a\","
    "\"mark\":1,"
    "\"op\":\"and\""
    "}";

  WeakType tree_conf_wt;
  bool ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  Settree<SetOpInterface> settree;
  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  SettreeNode<SetOpInterface> *settree_node, *settree_node_2, *settree_node_3;
  TestResolveSet* new_set;

  settree_node = settree.AddNode_("b", 0, IndexerOps::And, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);

  settree_node_2 = settree.AddNode_("c", 0, IndexerOps::And, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  settree_node_3 = settree.AddNode_("d", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_3->SetPrivateSet(new_set); new_set->SetName("d");

  settree_node_3 = settree.AddNode_("e", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_3->SetPrivateSet(new_set); new_set->SetName("e");

  settree_node_2 = settree.AddNode_("f", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_2->SetPrivateSet(new_set); new_set->SetName("f");

  settree_node = settree.AddNode_("g", 0, IndexerOps::Or, false, settree.root_);
  ASSERT_TRUE(NULL!=settree_node);

  settree_node_2 = settree.AddNode_("h", 0, IndexerOps::None, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_2->SetPrivateSet(new_set); new_set->SetName("h");

  settree_node_2 = settree.AddNode_("i", 0, IndexerOps::Or, false, settree_node);
  ASSERT_TRUE(NULL!=settree_node_2);

  settree_node_3 = settree.AddNode_("j", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_3->SetPrivateSet(new_set); new_set->SetName("j");

  settree_node_3 = settree.AddNode_("k", 0, IndexerOps::None, false, settree_node_2);
  ASSERT_TRUE(NULL!=settree_node_3);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node_3->SetPrivateSet(new_set); new_set->SetName("k");

  ret = settree.Resolve();
  ASSERT_TRUE(0 == strcmp(TestResolveSet::GetContent().c_str(), "defhjk"));

  settree.Reset();
}

TEST(test_settree, null_set) {
  std::string tree_conf, tree_conf_2, tree_conf_3;
  Settree<SetOpInterface> settree, settree_2, settree_3;
  size_t mark;
  TestResolveSet* new_set;
  SettreeNode<SetOpInterface> *settree_node;

  tree_conf = "{"
      "\"name\":\"root\","
      "\"mark\":3,"
      "\"op\":\"and\","
      "\"children\":"
          "["
              "{"
                  "\"name\":\"left\","
                  "\"mark\":1,"
                  "\"op\":\"or\","
                  "\"mountable\":1"
              "},"
              "{"
                  "\"name\":\"right\","
                  "\"mark\":2,"
                  "\"op\":\"priority\","
                  "\"mountable\":0"
              "}"
          "]"
  "}";

  WeakType tree_conf_wt;
  bool ret = tree_conf_wt.JsonDecode(tree_conf.c_str(), tree_conf.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = settree.Parse(tree_conf_wt);
  ASSERT_TRUE(true==ret);

  mark = settree.Resolve();
  ASSERT_EQ(mark, size_t(1));

  settree.Reset();

  tree_conf_2 = "{"
      "\"name\":\"root\","
      "\"mark\":3,"
      "\"op\":\"or\","
      "\"children\":"
      "["
          "{"
              "\"name\":\"left\","
              "\"mark\":1,"
              "\"op\":\"none\","
              "\"mountable\":0"
          "},"
          "{"
              "\"name\":\"right\","
              "\"mark\":2,"
              "\"op\":\"not\","
              "\"mountable\":0,"
              "\"children\":"
              "["
                  "{"
                      "\"name\":\"left\","
                      "\"mark\":4,"
                      "\"op\":\"none\","
                      "\"mountable\":0"
                  "}"
              "]"
          "}"
      "]"
  "}";

  WeakType tree_conf_2_wt;
  ret = tree_conf_2_wt.JsonDecode(tree_conf_2.c_str(), tree_conf_2.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = settree_2.Parse(tree_conf_2_wt);
  ASSERT_TRUE(true==ret);

  mark = settree_2.Resolve();
  ASSERT_EQ(mark, size_t(0));
  ASSERT_TRUE(NULL != settree_2.root_->GetSet());
  ASSERT_EQ(1, settree_2.root_->GetSet()->GetCategory());
  ASSERT_TRUE(true == settree_2.root_->GetSet()->GetNot());

  settree_2.Reset();

  tree_conf_3 = "{"
      "\"name\":\"root\","
      "\"mark\":1,"
      "\"op\":\"and\","
      "\"children\":"
        "["
          "{"
            "\"name\":\"right\","
            "\"mark\":2,"
            "\"op\":\"not\","
            "\"children\":"
              "["
                "{"
                  "\"name\":\"left\","
                  "\"mark\":3"
                "}"
              "]"
          "},"
          "{"
            "\"name\":\"left\","
            "\"mark\":4"
          "}"
        "]"
      "}";

  WeakType tree_conf_3_wt;
  ret = tree_conf_3_wt.JsonDecode(tree_conf_3.c_str(), tree_conf_3.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = settree_3.Parse(tree_conf_3_wt);
  ASSERT_TRUE(true==ret);
  settree_node = settree_3.GetNode(4);
  ASSERT_TRUE(NULL!=settree_node);
  new_set = ThreadPrivateSetPool::Get<TestResolveSet>();
  ASSERT_TRUE(NULL!=new_set);
  settree_node->SetPrivateSet(new_set); new_set->SetName("k");

  mark = settree_3.Resolve();
  ASSERT_EQ(mark, size_t(0));
  ASSERT_TRUE(NULL != settree_3.root_->GetSet());
  ASSERT_EQ(100, settree_3.root_->GetSet()->GetCategory());
  ASSERT_TRUE(false == settree_3.root_->GetSet()->GetNot());

  settree_3.Reset();
}

}}
