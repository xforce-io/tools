#include "gtest/gtest.h"
#include "../../../../src/db_mem_core/fields/int_set_field_type.hpp"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestSetFieldType : public ::testing::Test {
 protected:
  explicit TestSetFieldType() {}
  virtual void SetUp() {
    system("rm -rf data/test_int_set_field_type");
    system("mkdir -p data/test_int_set_field_type");
  }
  virtual void TearDown() {}
};

TEST_F(TestSetFieldType, all) {
  char mem[sizeof(void*)];
  bzero(mem, sizeof(mem));
  void* field = RCAST<void*>(mem);
  IntSetFieldType<int8_t> type;
  
  //insert and erase
  int ret = type.InsertIntoIntSet(field, "2,3,2,1,2,3,");
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(6), type.GetIntSet(field)->Size());
  ret = type.EraseFromIntSet(field, "3");
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(4), type.GetIntSet(field)->Size());

  //Serialize and Deserialize with buffer
  char buf[100];
  int ret_ser = type.Serialize(field, buf, sizeof(buf));
  ASSERT_TRUE(ret_ser>0);

  char mem_2[sizeof(void*)];
  bzero(mem_2, sizeof(mem_2));
  void* field_2 = RCAST<void*>(mem_2);
  int ret_des = type.Deserialize(buf, sizeof(buf), field_2);
  ASSERT_EQ(ret_des, ret_ser);
  ASSERT_EQ(size_t(4), type.GetIntSet(field_2)->Size());

  //Serialize and Deserialize with fp
  type.GetIntSet(field_2)->Clear();
  ASSERT_EQ(size_t(0), type.GetIntSet(field_2)->Size());

  const static std::string kFile = "data/test_int_set_field_type/file";
  FILE* fp = fopen(kFile.c_str(), "w");
  ASSERT_TRUE(NULL!=fp);

  ret = type.Serialize(field, fp);
  ASSERT_TRUE(0==ret);

  fclose(fp);

  fp = fopen(kFile.c_str(), "r");
  ASSERT_TRUE(NULL!=fp);

  ret = type.Deserialize(fp, field_2);
  ASSERT_TRUE(0==ret);
  ASSERT_EQ(size_t(4), type.GetIntSet(field_2)->Size());

  fclose(fp);

  delete type.GetIntSet(field);
  delete type.GetIntSet(field_2);
}
