#include "gtest/gtest.h"
#include "db_mem_core/table_index/table_index_feature_list.h"

using namespace zmt;
using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
/*
class TestTableIndexFeatureList : public ::testing::Test {
 protected:
  TestTableIndexFeatureList() {}

  virtual void SetUp() {
    system("mkdir -p data/test_table_index_feature_list");

    std::string table_schema_syntax = "["
        "{"
          "\"name\":\"col0\","
          "\"type\":\"int32\""
        "},{"
          "\"name\":\"col1\","
          "\"type\":\"str\""
        "},{"
          "\"name\":\"col2\","
          "\"type\":\"int64\""
        "}"
      "]";

    WeakType table_schema_wt;
    bool ret = table_schema_wt.JsonDecode(
        table_schema_syntax.c_str(), 
        table_schema_syntax.size(), 
        NULL);
    ASSERT_TRUE(true==ret);

    ret = table_.table_schema_.Init(table_schema_wt);
    ASSERT_TRUE(true==ret);
  }

  virtual void TearDown() {
    system("rm -rf data/quickload_index*;"
        "rm -rf data/test_table_index_feature_list");
  }

  virtual ~TestTableIndexFeatureList() {}

 private:
  Table table_; 
};

TEST_F(TestTableIndexFeatureList, init) {
  std::string index_syntax = "{"
        "\"name\":\"sample\","
        "\"category\":\"\","
        "\"column\":1"
      "}";

  WeakType index_wt;
  bool ret = index_wt.JsonDecode(
      index_syntax.c_str(), 
      index_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  TableIndexFeatureList table_index_feature_list;
  ret = table_index_feature_list.Init(table_, index_wt);
  ASSERT_TRUE(false==ret);

  index_syntax = "{"
        "\"name\":\"sample\","
        "\"category\":\"index\","
        "\"column\":1"
      "}";

  ret = index_wt.JsonDecode(
      index_syntax.c_str(), 
      index_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  ret = table_index_feature_list.Init(table_, index_wt);
  ASSERT_TRUE(false==ret);

  index_syntax = "{"
        "\"name\":\"sample\","
        "\"category\":\"index\","
        "\"column\":2"
      "}";

  ret = index_wt.JsonDecode(
      index_syntax.c_str(), 
      index_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  ret = table_index_feature_list.Init(table_, index_wt);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(table_index_feature_list.col_, size_t(2));
}

TEST_F(TestTableIndexFeatureList, add_remove_record) {
  std::string index_syntax = "{"
        "\"name\":\"sample\","
        "\"category\":\"index\","
        "\"column\":2"
      "}";

  WeakType index_wt;
  int ret = index_wt.JsonDecode(
      index_syntax.c_str(), 
      index_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  TableIndexFeatureList table_index_feature_list;
  ret = table_index_feature_list.Init(table_, index_wt);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(table_index_feature_list.col_, size_t(2));

  std::string record_syntax;
  WeakType record_wt;

  record_syntax = "[12, \"abc\", 4]";

  ret = record_wt.JsonDecode(
      record_syntax.c_str(), 
      record_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  Record* record = new Record(table_);
  ret = record->Parse(record_wt);
  ASSERT_TRUE(true==ret);
  //add [12, abc, 4]
  ret = table_index_feature_list.AddRecord(*record);
  ASSERT_TRUE(true==ret);

  ret = record->SetInt(0, 1); ASSERT_TRUE(true==ret);
  //add [1, abc, 4]
  ret = table_index_feature_list.AddRecord(*record);
  ASSERT_TRUE(true==ret);

  ret = record->SetInt(0, 4); ASSERT_TRUE(true==ret);
  ret = record->SetInt(2, 3); ASSERT_TRUE(true==ret);
  //add [4, abc, 3]
  ret = table_index_feature_list.AddRecord(*record);
  ASSERT_TRUE(true==ret);

  ret = record->SetInt(0, 5); ASSERT_TRUE(true==ret);
  ret = record->SetInt(2, 3); ASSERT_TRUE(true==ret);
  //add [5, abc, 3]
  ret = table_index_feature_list.AddRecord(*record);
  ASSERT_TRUE(true==ret);

  ret = table_index_feature_list.RemoveRecord(*record);
  ASSERT_TRUE(true==ret);
  ret = record->SetInt(0, 10); ASSERT_TRUE(true==ret);
  ret = table_index_feature_list.RemoveRecord(*record);
  ASSERT_TRUE(false==ret);

  // [12, abc, 4] [1, abc, 4] [4, abc, 3] is left

  delete record;

  FILE* fp = fopen("data/test_table_index_feature_list/sample", "w");
  ASSERT_TRUE(NULL!=fp);
  ret = table_index_feature_list.Serialize(fp);
  ASSERT_EQ(0, ret);
  fclose(fp);

  fp = fopen("data/test_table_index_feature_list/sample", "r");
  ASSERT_TRUE(NULL!=fp);
  ret = table_index_feature_list.Deserialize(fp);
  ASSERT_EQ(0, ret);
  fclose(fp);
}
*/
