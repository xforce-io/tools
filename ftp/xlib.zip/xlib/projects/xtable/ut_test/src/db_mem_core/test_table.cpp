#include "gtest/gtest.h"
#include "../../../src/db_mem_core/table.h"
#include "../../../src/db_mem_core/record.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestTable : public ::testing::Test {
 protected:
  explicit TestTable() {}

  virtual void SetUp() {
    system("rm -rf data/test_table; mkdir -p data/test_table");
  }

  virtual void TearDown() {}
};

TEST_F(TestTable, init) {
  std::string table_syntax = "{"
        "\"name\":\"sample_table\","
        "\"schema\":["
          "{"
            "\"col\":\"col0\","
            "\"type\":\"int32\""
          "},{"
            "\"col\":\"col1\","
            "\"type\":\"str\""
          "},{"
            "\"col\":\"col2\","
            "\"type\":\"int64\""
          "}"
        "],"
        "\"indexs\":["
          "{"
            "\"name\":\"sample\","
            "\"category\":\"index\","
            "\"column\":2"
          "}"
        "]"
      "}";

  WeakType table_wt;
  int ret = table_wt.JsonDecode(table_syntax.c_str(), table_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  Table table;
  ret = table.CreateTable(table_wt, 1);
  ASSERT_EQ(0, ret);
  ASSERT_EQ(size_t(1), table.table_indexs_.Size());

  Record* record;
  std::string record_syntax;
  WeakType record_wt;
  record_syntax = "[12, \"abc\", 4]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = table.ParseRecord(record_wt, record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);
  ret = table.AddRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);

  record_wt = zmt::WeakType();
  record_syntax = "[1, \"abc\", 4]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = table.ParseRecord(record_wt, record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);
  ret = table.AddRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);

  record_wt = zmt::WeakType();
  record_syntax = "[4, \"abc\", 3]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = table.ParseRecord(record_wt, record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);
  ret = table.AddRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);

  record_wt = zmt::WeakType();
  record_syntax = "[5, \"abc\", 3]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);

  ret = table.ParseRecord(record_wt, record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);
  ret = table.AddRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);

  record = new Record(table);

  record_wt = zmt::WeakType();
  record_syntax = "[5, \"abc\", 3]";
  ret = record_wt.JsonDecode(record_syntax.c_str(), record_syntax.size(), NULL);
  ASSERT_TRUE(true==ret);
  ret = record->Parse(record_wt);
  ASSERT_TRUE(true==ret);
  ret = table.RemoveRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc==ret);
  ret = table.RemoveRecord(*record);
  ASSERT_TRUE(ErrorNo::kSucc!=ret);

  delete record;

  FILE* fp = fopen("data/test_table/sample", "w");
  ASSERT_TRUE(NULL!=fp);
  ret = table.Serialize(fp);
  ASSERT_EQ(0, ret);
  fclose(fp);

  fp = fopen("data/test_table/sample", "r");
  ASSERT_TRUE(NULL!=fp);
  ret = table.Deserialize(fp);
  ASSERT_EQ(0, ret);
  fclose(fp);

  //TODO: test index
}
