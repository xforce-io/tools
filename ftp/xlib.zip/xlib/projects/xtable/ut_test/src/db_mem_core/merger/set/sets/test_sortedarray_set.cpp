#include "gtest/gtest.h"
#include "db_mem_core/merger/set/sets/sortedarray_set.hpp"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_sorted_array_int64_set, test_and) {
}
