#include "gtest/gtest.h"
#include "../../../src/db_mem_core/record.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestRecord : public ::testing::Test {
 protected:
  explicit TestRecord() :
    table_() {}

  virtual void SetUp() {
    system("mkdir -p data/test_record/");

    std::string table_schema_syntax = "["
        "{"
          "\"col\":\"col0\","
          "\"type\":\"int32\""
        "},{"
          "\"col\":\"col1\","
          "\"type\":\"str\""
        "},{"
          "\"col\":\"col2\","
          "\"type\":\"bool\""
        "}"
      "]";

    WeakType table_schema_wt;
    bool ret = table_schema_wt.JsonDecode(
        table_schema_syntax.c_str(), 
        table_schema_syntax.size(), 
        NULL);
    ASSERT_TRUE(true==ret);

    table_.table_no_ = 0;
    ret = table_.table_schemas_.Init(table_schema_wt);
    ASSERT_TRUE(true==ret);
  }

  virtual void TearDown() {}
 
 private:
  Table table_; 
};

TEST_F(TestRecord, parse) {
  Record record(table_);

  std::string record_syntax;
  WeakType record_wt;

  record_syntax = "[1, 2]";

  int ret = record_wt.JsonDecode(
      record_syntax.c_str(), 
      record_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  ret = record.Parse(record_wt);
  ASSERT_TRUE(false==ret);

  //TODO: check whether this is a bug of allspark
  record_wt = zmt::WeakType();
  record_syntax = "[123, \"abc\", 2]";
  ret = record_wt.JsonDecode(
      record_syntax.c_str(), 
      record_syntax.size(), 
      NULL);
  ASSERT_TRUE(true==ret);

  ret = record.Parse(record_wt);
  ASSERT_TRUE(true==ret);

  ret = record.GetInt(0);
  ASSERT_EQ(123, ret);
  ret = strcmp("abc", record.GetStr(1));
  ASSERT_EQ(0, ret);
  ret = record.GetInt(2);
  ASSERT_EQ(1, ret);

  Record record_dup(record);

  ret = record_dup.GetInt(0);
  ASSERT_EQ(123, ret);
  ret = strcmp("abc", record_dup.GetStr(1));
  ASSERT_EQ(0, ret);
  ret = record_dup.GetInt(2);
  ASSERT_EQ(1, ret);

  char buf[1000];
  ret = record.Serialize(buf, sizeof(buf));
  ASSERT_TRUE(ret>0);
  ret = record.Deserialize(buf, sizeof(buf));
  ASSERT_TRUE(ret>0);
  ASSERT_EQ(123, record.GetInt(0));
  ASSERT_TRUE(0 == strcmp(record.GetStr(1), "abc"));
  ASSERT_EQ(1, record.GetInt(2));
  ret = record.Serialize(buf, 6);
  ASSERT_TRUE(ret<=0);
  ASSERT_TRUE(0 == strcmp(record.GetStr(1), "abc"));

  FILE* fp = fopen("data/test_record/record", "w+");
  ASSERT_TRUE(NULL!=fp);
  ret = record.Serialize(fp);
  ASSERT_EQ(0, ret);

  Record record_sample(table_);
  rewind(fp);
  ret = record_sample.Deserialize(fp);
  ASSERT_EQ(0, ret);

  ret = record_sample.GetInt(0);
  ASSERT_EQ(123, ret);
  const char* str = record_sample.GetStr(1);
  ret = strcmp("abc", str);
  ASSERT_EQ(0, ret);
  ret = record_sample.GetInt(2);
  ASSERT_EQ(1, ret);
}
