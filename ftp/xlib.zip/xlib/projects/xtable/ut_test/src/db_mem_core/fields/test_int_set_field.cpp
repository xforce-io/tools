#include "gtest/gtest.h"
#include "db_mem_core/fields/int_set_field.hpp"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(str_to_vec, all) {
  std::vector<int8_t> vals;
  bool ret = IntSetField<int8_t>::StrToVec_("1,2,", vals);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(2), vals.size());
  ASSERT_EQ(1, vals[0]);
  ASSERT_EQ(2, vals[1]);

  ret = IntSetField<int8_t>::StrToVec_("3", vals);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(1), vals.size());
  ASSERT_EQ(3, vals[0]);

  ret = IntSetField<int8_t>::StrToVec_("3a", vals);
  ASSERT_TRUE(false==ret);
  ret = IntSetField<int8_t>::StrToVec_("3a,", vals);
  ASSERT_TRUE(false==ret);

  ret = IntSetField<int8_t>::StrToVec_("3, ", vals);
  ASSERT_TRUE(false==ret);
  ret = IntSetField<int8_t>::StrToVec_("1,2,3,2e", vals);
  ASSERT_TRUE(false==ret);
}

class TestIntSetField : public ::testing::Test {
 protected:
  explicit TestIntSetField() {}
  virtual void SetUp() {}
  virtual void TearDown() {}
};

TEST_F(TestIntSetField, simple) {
  IntSetField<int8_t> set(0);
  bool ret = set.Insert("1000");
  ASSERT_TRUE(false==ret);

  ret = set.Insert("1,");
  ASSERT_TRUE(true==ret);
  ret = set.Insert("2");
  ASSERT_TRUE(true==ret);
  ret = set.Insert("2,3,3");
  ASSERT_TRUE(true==ret);
  ret = set.Erase("4, ");
  ASSERT_TRUE(false==ret);
  ret = set.Erase("3");
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(3), set.Size());
}

TEST_F(TestIntSetField, pressure) {
  IntSetField<int32_t> set(0);
  std::vector<int32_t> vals;
  for (size_t i=0; i<100000; ++i) {
    int32_t elm = rand()%1000;
    vals.clear();
    vals.push_back(elm);
    if (rand()%2) {
      bool ret = set.Insert(vals);
      ASSERT_TRUE(true==ret);
    } else {
      set.Erase(vals);
    }
  }

  static const size_t kTimesTest = 100;
  static const size_t kMaxVecLen = 1000;
  std::vector<int32_t> arrays[kTimesTest];
  for (size_t i=0; i<kTimesTest; ++i) {
    size_t len = rand() % kMaxVecLen;
    for (size_t j=0; j<len; ++j) {
      arrays[i].push_back(rand() % kMaxVecLen);
    }
  }

  for (size_t i=0; i<kTimesTest; ++i) {
    if (rand()%2) {
      bool ret = set.Insert(arrays[i]);
      ASSERT_TRUE(true==ret);
    } else {
      set.Erase(arrays[i]);
    }
  }

  //TODO: verify results
}
