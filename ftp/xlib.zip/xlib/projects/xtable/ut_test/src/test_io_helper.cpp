
#include "gtest/gtest.h"
#include "../../src/io_helper.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestIOHelper : public ::testing::Test {
 protected:
  explicit TestIOHelper() {}

  virtual void SetUp() {
    system("mkdir -p data/test_io_helper");
  }

  virtual void TearDown() {
    system("rm -rf data/test_io_helper");
  }
};

TEST_F(TestIOHelper, read_write_fp) {
  FILE* fp = fopen("data/test_io_helper/sample", "w");
  ASSERT_TRUE(NULL!=fp);

  bool ret;
  for (size_t i=0; i<1000; ++i) {
    ret = IOHelper::WriteInt(i, fp);
    ASSERT_TRUE(true==ret);
  }

  ret = IOHelper::WriteStr("asd", fp);
  ASSERT_TRUE(true==ret);

  for (size_t i=1000; i<100000; ++i) {
    ret = IOHelper::WriteInt(i, fp);
    ASSERT_TRUE(true==ret);
  }
  fclose(fp);

  fp = fopen("data/test_io_helper/sample", "r");

  int64_t int64;
  std::string str;

  for (size_t i=0; i<1000; ++i) {
    ret = IOHelper::ReadInt(fp, int64);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(size_t(int64), i);
  }

  ret = IOHelper::ReadStr(fp, str);
  ASSERT_TRUE(true==ret);
  ASSERT_TRUE(0 == strcmp(str.c_str(), "asd"));

  for (int64_t i=1000; i<100000; ++i) {
    ret = IOHelper::ReadInt(fp, int64);
    ASSERT_TRUE(true==ret);
    ASSERT_EQ(int64, i);
  }
  fclose(fp);
}

TEST_F(TestIOHelper, read_write_buf) {
  char buf[1000];
  size_t pos=0;
  int ret = IOHelper::WriteInt(1, buf+pos, sizeof(buf));
  ASSERT_TRUE(0!=ret);
  pos+=ret;

  ret = IOHelper::WriteInt(281474976710657, buf+pos, sizeof(buf) - pos);
  ASSERT_TRUE(0!=ret);
  pos+=ret;

  ret = IOHelper::WriteStr("asd", buf+pos, sizeof(buf) - pos);
  ASSERT_TRUE(0!=ret);
  pos+=ret;

  ret = IOHelper::WriteInt(2, buf+pos, sizeof(buf) - pos);
  ASSERT_TRUE(0!=ret);
  pos+=ret;

  int64_t int_obj;
  pos=0;
  ret = IOHelper::ReadInt(buf+pos, sizeof(buf), int_obj);
  ASSERT_TRUE(ret>0);
  ASSERT_EQ(1, ret);
  pos+=ret;

  ret = IOHelper::ReadInt(buf+pos, sizeof(buf), int_obj);
  ASSERT_TRUE(ret>0);
  ASSERT_EQ(281474976710657, int_obj);
  pos+=ret;

  std::string str;
  ret = IOHelper::ReadStr(buf+pos, str);
  ASSERT_TRUE(ret>0);
  ASSERT_TRUE(str == "asd");
  pos+=ret;

  ret = IOHelper::ReadInt(buf+pos, sizeof(buf), int_obj);
  ASSERT_TRUE(ret>0);
  ASSERT_EQ(2, int_obj);
  pos+=ret;

  ret = IOHelper::ReadInt(buf+pos, ret-1, int_obj);
  ASSERT_TRUE(0==ret);
}

TEST_F(TestIOHelper, bug_case0) {
  FILE* fp = fopen("data/test_io_helper/sample", "w");
  ASSERT_TRUE(NULL!=fp);

  bool ret = IOHelper::WriteInt(281474976710657, fp);
  ASSERT_TRUE(true==ret);

  fclose(fp);

  fp = fopen("data/test_io_helper/sample", "r");

  int64_t int64;
  std::string str;

  ret = IOHelper::ReadInt(fp, int64);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(int64, 281474976710657);

  fclose(fp);
}

