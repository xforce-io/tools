#include "gtest/gtest.h"
#include "../../src/db.h"

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

using namespace zmt;
using namespace zmt::material_center;

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestDB : public ::testing::Test {
 protected:
  explicit TestDB() {}

  virtual void SetUp() {
    system("mkdir -p data/test_io_helper");
  }

  virtual void TearDown() {
    system("rm -rf data/test_io_helper");
  }
};

TEST_F(TestDB, all) {
  DB db;
  bool end=false;
  //RoutineFileDumper routine_file_dumper(end);
  //end=true;

//  bool ret = db.Init(1000, 1, 1, 100000, 1, 1, 100000);
}
