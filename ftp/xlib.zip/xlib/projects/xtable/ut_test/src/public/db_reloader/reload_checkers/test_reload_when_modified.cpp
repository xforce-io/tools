#include "gtest/gtest.h"
#include "../../../../../src/public/public.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class TestDBReloader : public ::testing::Test {
 protected:
  virtual ~TestDBReloader() {}

  virtual void SetUp() { 
    system("mkdir -p data/; touch data/tmp");
  }

  virtual void TearDown() { }
};

TEST_F(TestDBReloader, all_positive) {
  std::string filepath = "data/tmp";
  ReloadWhenModified::InitParams init_params = (ReloadWhenModified::InitParams) {filepath};
  ReloadWhenModified reload_when_modified(&init_params);

  int ret = reload_when_modified.ToLoad();
  ASSERT_EQ(ret, 0);
  ret = reload_when_modified.ToLoad();
  ASSERT_EQ(ret, 1);
  ret = reload_when_modified.ToLoad();
  ASSERT_EQ(ret, 1);
  sleep(2);
  system("touch data/tmp");
  ret = reload_when_modified.ToLoad();
  ASSERT_EQ(ret, 0);
}

TEST_F(TestDBReloader, all_passive) {
  system("rm -rf data/tmp");
  ReloadWhenModified::InitParams init_params = (ReloadWhenModified::InitParams) {"data/tmp"};
  ReloadWhenModified reload_when_modified(&init_params);

  int ret = reload_when_modified.ToLoad();
  ASSERT_TRUE(ret<0);
}
