#include "gtest/gtest.h"

#include <functional>
#include "../../../../src/public/cow_btree/cow_btree_map.hpp"
#include "../../../../src/public/functors.hpp"
#include "../../../../src/public/time/time.h"
#include "../../../../src/3rd/cpp-btree-1.0.1/btree_set.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {

LOGGER_IMPL(material_center, "material_center")

template<typename X, typename Y>
std::ostream& operator<<(std::ostream& os, const std::pair<X,Y>& pair) {
  os << "(" << pair.first << "," << pair.second << ")";
  return os;
}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_base_cow_btree : public ::testing::Test {
 protected:
  explicit test_base_cow_btree() {}
  virtual void SetUp() {}
  virtual void TearDown() {}
};

typedef CowBtreeMap< int, int, std::less<int> > BtreeInt;
typedef MultiCowBtreeMap< int, int, std::less<int> > MultiBtreeInt;

TEST_F(test_base_cow_btree, insert_erase) {
  //insert
  BtreeInt base_cow_btree(5);
  std::pair<bool, BtreeInt::Iterator> ret = base_cow_btree.Insert(3,1);
  ASSERT_TRUE(true==ret.first);

  BtreeInt::Iterator iter = base_cow_btree.Begin();
  ASSERT_EQ(3, (*iter++).first);
  ASSERT_TRUE(iter == base_cow_btree.End());

  ret = base_cow_btree.Insert(1,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(4,3);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(5,2);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(8,4);
  ASSERT_TRUE(true==ret.first);

  BtreeInt::Iterator riter = base_cow_btree.RBegin();
  ASSERT_EQ(8, (*riter++).first);
  ASSERT_EQ(5, (*riter++).first);
  ASSERT_EQ(4, (*riter++).first);
  ASSERT_EQ(3, (*riter++).first);
  ASSERT_EQ(1, (*riter++).first);
  ASSERT_TRUE(riter == base_cow_btree.REnd());

  ret = base_cow_btree.Insert(7,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(9,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(2,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(6,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(6,1);
  ASSERT_TRUE(false==ret.first);
  ret = base_cow_btree.Insert(10,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(0,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(5,1);
  ASSERT_TRUE(false==ret.first);
  ret = base_cow_btree.Insert(11,1);
  ASSERT_TRUE(true==ret.first);

  ASSERT_EQ(size_t(12), base_cow_btree.Size());

  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[1].first, 8);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs).Size(), size_t(2));

  ret = base_cow_btree.Insert(32,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(15,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(17,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(12,1);
  ASSERT_TRUE(true==ret.first);

  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 4);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[2].first, 12);

  BtreeInt::Node* node = static_cast<BtreeInt::NonLeaveNode*>(
      base_cow_btree.root_)->children_[3];
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[0].first, 12);
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[3].first, 32);

  ret = base_cow_btree.Insert(14,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(13,2);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(20,3);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(18,2);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(21,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(16,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(19,2);
  ASSERT_TRUE(true==ret.first);

  ASSERT_EQ(size_t(23), base_cow_btree.Size());

  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 12);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs).Size(), size_t(1));

  node = static_cast<BtreeInt::NonLeaveNode*>(
        base_cow_btree.root_)->children_[0];
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[0].first, 4);
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[1].first, 8);
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs).Size(), size_t(2));

  node = static_cast<BtreeInt::NonLeaveNode*>(
      base_cow_btree.root_)->children_[1];
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[0].first, 16);
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs)[1].first, 20);
  ASSERT_EQ((node->shared_sorted_objs_->sorted_objs).Size(), size_t(2));

  //copy 
  BtreeInt base_cow_btree_copy(5);
  ASSERT_TRUE(true == base_cow_btree_copy.Copy(base_cow_btree));

  //erase
  bool ret_bool;
  ret_bool = base_cow_btree.Erase(130);
  ASSERT_TRUE(false==ret_bool);
  ret_bool = base_cow_btree.Erase(13);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(16);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(17);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(18);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(15);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(19);
  ASSERT_TRUE(true==ret_bool);

  for (int i=0; i<=9; ++i) {
    ret_bool = base_cow_btree.Erase(i);
    ASSERT_TRUE(true==ret_bool);
  }

  ret_bool = base_cow_btree.Erase(10);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(11);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(12);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(32);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(14);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(21);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(20);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree.Erase(20);
  ASSERT_TRUE(false==ret_bool);
  ASSERT_EQ(size_t(0), base_cow_btree.Size());

  riter = base_cow_btree_copy.RBegin();
  ASSERT_EQ(32, (*riter++).first);
  ASSERT_EQ(21, (*riter++).first);
  ASSERT_EQ(20, (*riter++).first);
  ASSERT_EQ(19, (*riter++).first);
}

TEST_F(test_base_cow_btree, iterator_erase) {
  MultiBtreeInt base_cow_btree(5);
  std::pair<bool, MultiBtreeInt::Iterator> ret;

  ret = base_cow_btree.Insert(7,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(7,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(9,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(2,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(6,2);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(10,1);
  ASSERT_TRUE(true==ret.first);

  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 7);

  MultiBtreeInt::Iterator iter = base_cow_btree.Find(7);
  ASSERT_TRUE(iter != base_cow_btree.End());
  bool ret_bool = base_cow_btree.Erase(iter);
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 7);

  iter = base_cow_btree.Find(7);
  ASSERT_TRUE(iter != base_cow_btree.End());
  ret_bool = base_cow_btree.Erase(iter);
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 9);

  iter = base_cow_btree.Find(9);
  ASSERT_TRUE(iter != base_cow_btree.End());
  ret_bool = base_cow_btree.Erase(iter);
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ((base_cow_btree.root_->shared_sorted_objs_->sorted_objs)[0].first, 2);

  std::cout << base_cow_btree << std::endl;
}

TEST_F(test_base_cow_btree, same_vals) {
  MultiBtreeInt base_cow_btree(5);
  std::pair<bool, MultiBtreeInt::Iterator> ret;
  for (size_t i=0; i<100; ++i) {
    ret = base_cow_btree.Insert(3,1);
  }
  ASSERT_TRUE(true==ret.first);

  bool ret_bool = base_cow_btree.Erase(3);
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ(size_t(0), base_cow_btree.Size());
}

TEST_F(test_base_cow_btree, iterator) {
  srand(0);

  const size_t kNumToInsert = 100000;

  MultiBtreeInt base_cow_btree(100);
  SortedObjs<int> sorted_objs(kNumToInsert);
  std::pair<bool, MultiBtreeInt::Iterator> ret_btree_insert;
  std::pair<int, int*> ret_sorted_objs_insert;

  for (size_t i=0; i<kNumToInsert; ++i) {
    int rand_op = rand() % 2;
    int rand_int = rand();

    if (0==rand_op) {
      ret_btree_insert = base_cow_btree.Insert(rand_int,1);
      ASSERT_TRUE(true==ret_btree_insert.first);

      sorted_objs.Insert(rand_int);
    } else {
      base_cow_btree.Erase(rand_int);
      sorted_objs.RemoveObj(rand_int);
    }
  }

  size_t size = base_cow_btree.Size() > sorted_objs.Size() ? 
    base_cow_btree.Size() :
    sorted_objs.Size();

  MultiBtreeInt::Iterator iter = base_cow_btree.Begin();
  for (size_t i=0; i<size; ++i) {
    int tmp = iter.GetKey();
    ASSERT_TRUE(sorted_objs[i] == tmp);
    ++iter;
  }
  ASSERT_TRUE(iter == base_cow_btree.End());
}

TEST_F(test_base_cow_btree, clear) {
  BtreeInt base_cow_btree(5);
  std::pair<bool, BtreeInt::Iterator> ret = base_cow_btree.Insert(3,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(1,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(4,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(5,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree.Insert(8,1);
  ASSERT_TRUE(true==ret.first);

  base_cow_btree.Clear();
  ASSERT_EQ(base_cow_btree.Size(), size_t(0));
}

TEST_F(test_base_cow_btree, copy) {
  std::pair<bool, BtreeInt::Iterator> ret;
  BtreeInt base_cow_btree(5);
  ASSERT_TRUE(true == base_cow_btree.Copy(base_cow_btree));

  BtreeInt base_cow_btree_tmp(5);
  ASSERT_TRUE(true == base_cow_btree.Copy(base_cow_btree_tmp));

  BtreeInt base_cow_btree_6(6);
  ASSERT_TRUE(false == base_cow_btree.Copy(base_cow_btree_6));

  ret = base_cow_btree_tmp.Insert(0,1);
  ASSERT_TRUE(true==ret.first);
  ASSERT_TRUE(true == base_cow_btree.Copy(base_cow_btree_tmp));
  ASSERT_EQ(size_t(1), base_cow_btree.Size());

  BtreeInt::Iterator iter = base_cow_btree.Begin();
  ASSERT_EQ(0, (*iter++).first);
  ASSERT_TRUE(iter == base_cow_btree.End());
  ret = base_cow_btree.Insert(2,0);
  ASSERT_TRUE(true==ret.first);

  ret = base_cow_btree_tmp.Insert(3,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree_tmp.Insert(1,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree_tmp.Insert(4,1);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree_tmp.Insert(5,0);
  ASSERT_TRUE(true==ret.first);
  ret = base_cow_btree_tmp.Insert(8,0);
  ASSERT_TRUE(true==ret.first);

  ASSERT_TRUE(true == base_cow_btree.Copy(base_cow_btree_tmp));
  ASSERT_EQ(size_t(6), base_cow_btree.Size());

  bool ret_bool;
  ret_bool = base_cow_btree_tmp.Erase(3);
  ASSERT_TRUE(true==ret_bool);
  ret_bool = base_cow_btree_tmp.Erase(4);
  ASSERT_TRUE(true==ret_bool);

  BtreeInt::Iterator riter = base_cow_btree.RBegin();
  ASSERT_EQ(8, (*riter++).first);
  ASSERT_EQ(5, (*riter++).first);
  ASSERT_EQ(4, (*riter++).first);
  ASSERT_EQ(3, (*riter++).first);
  ASSERT_EQ(1, (*riter++).first);
  ASSERT_EQ(0, (*riter++).first);
  ASSERT_TRUE(riter == base_cow_btree.REnd());
}

TEST_F(test_base_cow_btree, benchmark) {
  const size_t kNumToInsert = 1000000;
  const size_t kTimesCopy = 100;
  const size_t kFanout = 2000;
  Timer timer;
  srand(0);
  int *seqs = new int [2*kNumToInsert];
  for (size_t i=0; i < 2*kNumToInsert; ++i) {
    seqs[i] = rand();
  }

  MultiBtreeInt base_cow_btree(kFanout);
  std::pair<bool, MultiBtreeInt::Iterator> ret_btree_insert;
  timer.Start();
  for (size_t i=0; i<kNumToInsert; ++i) {
    int rand_op = seqs[2*i] % 2;
    int rand_int = seqs[2*i+1] % (kNumToInsert * 2);
    if (0==rand_op) {
      base_cow_btree.Insert(rand_int,1);
    } else {
      base_cow_btree.Erase(rand_int);
    }
  }
  timer.Stop();
  std::cout << "insert_erase_cow_btree_cost: " 
            << timer.TimeUs() 
            << " size: " 
            << base_cow_btree.Size()
            << std::endl;

  timer.Start();
  size_t dummy=0;
  for (size_t i=0; i<kTimesCopy; ++i) {
    MultiBtreeInt base_cow_btree_copy(kFanout);
    base_cow_btree_copy.Copy(base_cow_btree);
    dummy += base_cow_btree_copy.Size();
  }
  timer.Stop();
  std::cout << "copy_cow_btree_cost: " << timer.TimeUs() << '\t' << dummy << std::endl;

  btree::btree_multiset<int, std::less<int>, std::allocator<int>, kFanout> google_btree;
  timer.Start();
  for (size_t i=0; i<kNumToInsert; ++i) {
    int rand_op = seqs[2*i] % 2;
    int rand_int = seqs[2*i+1] % (kNumToInsert * 2);
    if (0==rand_op) {
      google_btree.insert(rand_int);
    } else {
      google_btree.erase(rand_int);
    }
  }
  timer.Stop();
  std::cout << "insert_erase_google_btree_cost: " 
            << timer.TimeUs() 
            << " size: "
            << google_btree.size()
            << std::endl;

  timer.Start();
  dummy=0;
  for (size_t i=0; i<kTimesCopy; ++i) {
    btree::btree_multiset<int, std::less<int>, std::allocator<int>, kFanout> google_btree_copy;
    google_btree_copy = google_btree;
    dummy += google_btree_copy.size();
  }
  timer.Stop();
  std::cout << "copy_google_btree_cost: " << timer.TimeUs() << '\t' << dummy << std::endl;
}

TEST_F(test_base_cow_btree, bugcase0) {
  BtreeInt base_cow_btree(5);
  base_cow_btree.Insert(1,1);
  base_cow_btree.Erase(1);
  ASSERT_TRUE(base_cow_btree.Begin() == base_cow_btree.End());
}

}}
