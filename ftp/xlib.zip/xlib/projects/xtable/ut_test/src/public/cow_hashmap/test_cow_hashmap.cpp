#include <time.h>
#include <sys/time.h>
#include <tr1/unordered_map>

#include "gtest/gtest.h"
#include "../../../../src/public/cow_hashmap/cow_hashmap.hpp"

using namespace zmt::material_center;

namespace zmt { namespace material_center {

LOGGER_IMPL(material_center, "material_center")

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(cow_hashmap, singletable) {
  CowHashmap<int> cow_hashmap(CowHashmap<int>::kDefaultToResize, true);
  std::pair<bool, CowHashmap<int>::Iterator> ret_insert = 
    cow_hashmap.Insert(1, 2);
  ASSERT_TRUE(true == ret_insert.first);
  ASSERT_EQ(ret_insert.second.GetKey(), 1);
  ASSERT_EQ(ret_insert.second.GetVal(), 2);

  int ret = (cow_hashmap.Insert(1, 3)).first;
  ASSERT_TRUE(false==ret);
  ret = (cow_hashmap.Insert(2, 3)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(3, 4)).first;
  ASSERT_TRUE(true==ret);

  std::cout << cow_hashmap << std::endl;

  CowHashmap<int>::Iterator result;
  result = cow_hashmap.Find(1);
  ASSERT_TRUE(cow_hashmap.End() != result);
  ASSERT_EQ(result.GetVal(), 2);

  result = cow_hashmap.Find(4);
  ASSERT_TRUE(cow_hashmap.End() == result);

  ret = cow_hashmap.Erase(1);
  ASSERT_TRUE(true==ret);

  result = cow_hashmap.Find(1);
  ASSERT_TRUE(cow_hashmap.End() == result);
  ASSERT_EQ(size_t(2), cow_hashmap.Size());
}

TEST(multit_cow_hashmap, singletable) {
  MultiCowHashmap<int> cow_hashmap(CowHashmap<int>::kDefaultToResize, true);
  int ret = (cow_hashmap.Insert(1, 2)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(1, 3)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(2, 3)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(2, 4)).first;
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(4), cow_hashmap.Size());

  MultiCowHashmap<int>::Iterator result;
  result = cow_hashmap.Find(1);
  ASSERT_TRUE(cow_hashmap.End() != result);
  ASSERT_EQ(result.GetVal(), 3);
  ++result;
  ASSERT_TRUE(cow_hashmap.End() != result);
  ASSERT_EQ(result.GetVal(), 2);

  ret = cow_hashmap.Erase(2);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(size_t(2), cow_hashmap.Size());

  ret = cow_hashmap.Erase(result);
  ASSERT_TRUE(true==ret);

  std::cout << cow_hashmap << std::endl;

  result = cow_hashmap.Find(1);
  ASSERT_TRUE(cow_hashmap.End() != result);
  ASSERT_EQ(result.GetVal(), 3);
  ASSERT_EQ(size_t(1), cow_hashmap.Size());
}

TEST(cow_hashmap, singletable_resize) {
  CowHashmap<int> cow_hashmap(2, true);
  int ret;
  for (size_t i=0; i<9; ++i) {
    ret = (cow_hashmap.Insert(i, i+1)).first;
    ASSERT_EQ(true, ret);
  }

  ASSERT_EQ(size_t(9), cow_hashmap.num_items_);
  ASSERT_EQ(size_t(5), cow_hashmap.size_buckets_);

  ret = (cow_hashmap.Insert(10, 11)).first;
  ASSERT_EQ(true, ret);
  ret = (cow_hashmap.Insert(11, 12)).first;
  ASSERT_EQ(true, ret);

  std::cout << cow_hashmap << std::endl;

  ASSERT_EQ(size_t(11), cow_hashmap.num_items_);
  ASSERT_EQ(size_t(53), cow_hashmap.size_buckets_);

  CowHashmap<int>::Iterator result;
  result = cow_hashmap.Find(11);
  ASSERT_TRUE(cow_hashmap.End() != result);
  ASSERT_EQ(result.GetVal(), 12);
}

TEST(cow_hashmap, multitable) {
  CowHashmap<int, int> cow_hashmap, cow_hashmap_2;
  bool ret = (cow_hashmap.Insert(1, 2)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(2, 3)).first;
  ASSERT_TRUE(true==ret);
  ret = (cow_hashmap.Insert(3, 4)).first;
  ASSERT_TRUE(true==ret);

  ret = cow_hashmap_2.Copy(cow_hashmap);
  ASSERT_TRUE(true==ret);
  CowHashmap<int, int> cow_hashmap_3 = cow_hashmap_2;

  ret = cow_hashmap_3.Erase(3);
  ASSERT_TRUE(true==ret);
  ret = cow_hashmap_3.Erase(3);
  ASSERT_TRUE(false==ret);

  ret = (cow_hashmap_3.Insert(cow_hashmap_2.size_buckets_*2+2, 3)).first;
  ASSERT_TRUE(true==ret);

  CowHashmap<int, int>::Iterator result;
  result = cow_hashmap_3.Find(1);
  ASSERT_TRUE(cow_hashmap_3.End() != result);
  ASSERT_EQ(result.GetVal(), 2);
  *result.GetValToWrite() = 3;
  result = cow_hashmap_3.Find(1);
  ASSERT_TRUE(cow_hashmap_3.End() != result);
  ASSERT_EQ(result.GetVal(), 3);

  result = cow_hashmap_3.Find(2);
  ASSERT_TRUE(cow_hashmap_3.End() != result);
  ASSERT_EQ(result.GetVal(), 3);

  result = cow_hashmap_3.Find(3);
  ASSERT_TRUE(cow_hashmap_3.End() == result);

  result= cow_hashmap_2.Find(3);
  ASSERT_TRUE(cow_hashmap_3.End() != result);
  ASSERT_EQ(result.GetVal(), 4);
  
  result = cow_hashmap_2.Find(cow_hashmap_2.size_buckets_*2+2);
  ASSERT_TRUE(cow_hashmap_3.End() == result);
  
  result = cow_hashmap_3.Find(cow_hashmap_2.size_buckets_*2+2);
  ASSERT_TRUE(cow_hashmap_3.End() != result);
  cow_hashmap.Clear();
  ASSERT_EQ(cow_hashmap.Size(), size_t(0));
  ASSERT_NE(cow_hashmap_2.Size(), size_t(0));
  ASSERT_NE(cow_hashmap_3.Size(), size_t(0));

  CowHashmap<int, int> cow_hashmap_4;
  ret = cow_hashmap_2.Copy(cow_hashmap_4);
  ASSERT_TRUE(true==ret);
  ASSERT_EQ(cow_hashmap_2.Size(), size_t(0));
}

TEST(cow_hashmap, pressure_insert_erase) {
  const size_t kTimesTest=10;
  const size_t kRange=1000;
  const size_t kNumToOp=1000000;
  timeval t1, t2;
  gettimeofday(&t1, NULL);
  for (size_t i=0; i<kTimesTest; ++i) {
    CowHashmap<int, int> cow_hashmap;
    bool map[kRange];
    memset(map, 0, sizeof(map));
    for (size_t j=0; j<kNumToOp; ++j) {
      bool to_insert = (0 != rand()%4);
      int key_to_op = (rand() % kRange);

      if (true==to_insert) {
        cow_hashmap.Insert(key_to_op, key_to_op+1);
        map[key_to_op]=true;
      } else {
        cow_hashmap.Erase(key_to_op);
        map[key_to_op]=false;
      }
    }

    size_t num_in_map=0;
    for (size_t j=0; j<kRange; ++j) {
      if (true==map[j]) ++num_in_map;
    }

    ASSERT_EQ(num_in_map, cow_hashmap.num_items_);
  }
  gettimeofday(&t2, NULL);
  std::cout << "insert_erase cow_hashmap cost "
      << 1000000*(t2.tv_sec-t1.tv_sec) + (t2.tv_usec-t1.tv_usec) 
      << std::endl;

  gettimeofday(&t1, NULL);
  for (size_t i=0; i<kTimesTest; ++i) {
    std::tr1::unordered_map<int, int> unordered_map;
    bool map[kRange];
    memset(map, 0, sizeof(map));
    for (size_t j=0; j<kNumToOp; ++j) {
      bool to_insert = (0 != rand()%4);
      int key_to_op = (rand() % kRange);

      if (true==to_insert) {
        unordered_map.insert(std::pair<int, int>(key_to_op, key_to_op+1));
        map[key_to_op]=true;
      } else {
        unordered_map.erase(key_to_op);
        map[key_to_op]=false;
      }
    }

    size_t num_in_map=0;
    for (size_t j=0; j<kRange; ++j) {
      if (true==map[j]) ++num_in_map;
    }
  }
  gettimeofday(&t2, NULL);
  std::cout << "insert_erase unordered_map cost "
      << 1000000*(t2.tv_sec-t1.tv_sec) + (t2.tv_usec-t1.tv_usec) 
      << std::endl;
}

TEST(cow_hashmap, pressure_insert_erase_copy) {
  const size_t kTimesTest=1;
  const size_t kRange=1000;
  const size_t kNumToOp=1000;
  timeval t1, t2;
  gettimeofday(&t1, NULL);
  for (size_t i=0; i<kTimesTest; ++i) {
    CowHashmap<int, int> cow_hashmap[2];
    bool map[kRange];
    memset(map, 0, sizeof(map));
    for (size_t j=0; j<kNumToOp; ++j) {
      bool to_insert = (0 != rand()%4);
      int key_to_op = (rand() % kRange);

      if (true==to_insert) {
        cow_hashmap[j%2].Insert(key_to_op, key_to_op+1);
        map[key_to_op]=true;
      } else {
        cow_hashmap[j%2].Erase(key_to_op);
        map[key_to_op]=false;
      }
      bool ret = cow_hashmap[1-j%2].Copy(cow_hashmap[j%2]);
      ASSERT_EQ(true, ret);
    }

    size_t num_in_map=0;
    for (size_t j=0; j<kRange; ++j) {
      if (true==map[j]) ++num_in_map;
    }

    ASSERT_EQ(num_in_map, cow_hashmap[0].num_items_);
    ASSERT_EQ(num_in_map, cow_hashmap[1].num_items_);
  }
  gettimeofday(&t2, NULL);
  std::cout << "all cow_hashmap cost "
      << 1000000*(t2.tv_sec-t1.tv_sec) + (t2.tv_usec-t1.tv_usec) 
      << std::endl;

  gettimeofday(&t1, NULL);
  for (size_t i=0; i<kTimesTest; ++i) {
    std::tr1::unordered_map<int, int> unordered_map[2];
    bool map[kRange];
    memset(map, 0, sizeof(map));
    for (size_t j=0; j<kNumToOp; ++j) {
      bool to_insert = (0 != rand()%4);
      int key_to_op = (rand() % kRange);

      if (true==to_insert) {
        unordered_map[j%2].insert(std::pair<int, int>(key_to_op, key_to_op+1));
        map[key_to_op]=true;
      } else {
        unordered_map[j%2].erase(key_to_op);
        map[key_to_op]=false;
      }
      unordered_map[1-j%2] = unordered_map[j%2];
    }

    size_t num_in_map=0;
    for (size_t j=0; j<kRange; ++j) {
      if (true==map[j]) ++num_in_map;
    }
  }
  gettimeofday(&t2, NULL);
  std::cout << "all unordered_map cost "
      << 1000000*(t2.tv_sec-t1.tv_sec) + (t2.tv_usec-t1.tv_usec) 
      << std::endl;
}

TEST(cow_hashmap, bug_case0) {
  CowHashmap<int> cow_hashmap(CowHashmap<int>::kDefaultToResize, true);
  cow_hashmap.Clear();
}

}}
