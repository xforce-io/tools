#include "gtest/gtest.h"

#include <functional>
#include "../../../../src/public/cow_btree/sorted_objs.hpp"
#include "../../../../src/public/functors.hpp"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_sorted_objs : public ::testing::Test {
 protected:
  explicit test_sorted_objs() :
    sorted_objs_(5) {}

  virtual void SetUp() {
    std::pair<int, int*> result = sorted_objs_.Insert(3);
    ASSERT_TRUE(result.first>=0);
    ASSERT_EQ(*(result.second), 3);

    result = sorted_objs_.Insert(4);
    ASSERT_TRUE(result.first>=0);
    ASSERT_EQ(*(result.second), 4);

    result = sorted_objs_.Insert(2);
    ASSERT_TRUE(result.first>=0);
    ASSERT_EQ(*(result.second), 2);

    result = sorted_objs_.Insert(1);
    ASSERT_TRUE(result.first>=0);
    ASSERT_EQ(*(result.second), 1);

    sorted_objs_.ReserveSpaceAtHead(1);

    ASSERT_EQ(size_t(1), sorted_objs_.begin_);
    ASSERT_EQ(size_t(5), sorted_objs_.end_);

    result = sorted_objs_.Insert(5);
    ASSERT_TRUE(result.first>=0);
    ASSERT_EQ(*(result.second), 5);
  }

  virtual void TearDown() {}
 
 private:
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs_;
};

TEST_F(test_sorted_objs, insert_and_clear) {
  ASSERT_EQ(size_t(5), sorted_objs_.Size());
  ASSERT_EQ(size_t(0), sorted_objs_.begin_);
  ASSERT_EQ(size_t(5), sorted_objs_.end_);
  ASSERT_EQ(1, sorted_objs_[0]);
  ASSERT_EQ(2, sorted_objs_[1]);
  ASSERT_EQ(3, sorted_objs_[2]);
  ASSERT_EQ(4, sorted_objs_[3]);
  ASSERT_EQ(5, sorted_objs_[4]);

  sorted_objs_.Clear();
  ASSERT_EQ(size_t(0), sorted_objs_.Size());
}

TEST_F(test_sorted_objs, find) {
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs(10);
  ASSERT_TRUE(sorted_objs.Insert(1).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(2).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(2).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(2).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(2).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(3).first >= 0);
  ASSERT_TRUE(sorted_objs.Insert(4).first >= 0);
  sorted_objs.ReserveSpaceAtHead(1);

  ASSERT_EQ(-1, sorted_objs.Find(0));
  ASSERT_EQ(0, sorted_objs.Find(1));
  ASSERT_EQ(5, sorted_objs.Find(3));
  ASSERT_EQ(6, sorted_objs.Find(4));
  ASSERT_EQ(-1, sorted_objs.Find(5));
  ASSERT_EQ(0, sorted_objs.FindFirstOf(1));
  ASSERT_EQ(1, sorted_objs.FindFirstOf(2));
  ASSERT_EQ(-1, sorted_objs.FindFirstOf(5));
}

TEST_F(test_sorted_objs, low_bound) {
  ASSERT_EQ(size_t(1), sorted_objs_.RemoveObj(1));
  ASSERT_EQ(size_t(0), sorted_objs_.LowBound(0));
  ASSERT_EQ(size_t(0), sorted_objs_.LowBound(1));
  ASSERT_EQ(size_t(1), sorted_objs_.LowBound(2));
  ASSERT_EQ(size_t(2), sorted_objs_.LowBound(3));
  ASSERT_EQ(size_t(3), sorted_objs_.LowBound(4));
  ASSERT_EQ(size_t(4), sorted_objs_.LowBound(5));
  ASSERT_EQ(size_t(4), sorted_objs_.LowBound(6));
}

TEST_F(test_sorted_objs, copy_and_remove) {
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs(12);
  ASSERT_TRUE( true == sorted_objs.Copy(sorted_objs_) );
  
  std::pair<int, int*> result = sorted_objs.Insert(1);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(3);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(5);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(5);
  ASSERT_TRUE(result.first>=0);

  ASSERT_EQ(size_t(2), sorted_objs.RemoveObj(3));
  ASSERT_EQ(size_t(2), sorted_objs.RemoveObj(1));
  ASSERT_EQ(size_t(3), sorted_objs.RemoveObj(5));

  ASSERT_EQ(size_t(2), sorted_objs.Size());
  ASSERT_EQ(2, sorted_objs[0]);
  ASSERT_EQ(4, sorted_objs[1]);

  sorted_objs.Remove(1);
  ASSERT_EQ(size_t(1), sorted_objs.Size());
  ASSERT_EQ(2, sorted_objs[0]);

  sorted_objs.Remove(0);
  ASSERT_EQ(size_t(0), sorted_objs.Size());
}

TEST_F(test_sorted_objs, push_pop) {
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs(10);
  ASSERT_TRUE( true == sorted_objs.Copy(sorted_objs_) );

  sorted_objs.PushFront(-1);
  ASSERT_EQ(-1, sorted_objs[0]);
  sorted_objs.ReserveSpaceAtHead(4);
  sorted_objs.PushBack(10);
  sorted_objs.PushBack(11);

  ASSERT_EQ(-1, sorted_objs[0]);
  ASSERT_EQ(1, sorted_objs[1]);
  ASSERT_EQ(2, sorted_objs[2]);
  ASSERT_EQ(11, sorted_objs[7]);
  ASSERT_EQ(size_t(8), sorted_objs.Size());
}

TEST_F(test_sorted_objs, insert) {
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs(10);
  sorted_objs.ReserveSpaceAtHead(1);
  
  std::pair<int, int*> result = sorted_objs.Insert(1);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(3);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(4);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs.Insert(1, 2);
  ASSERT_TRUE(result.first>=0);

  ASSERT_EQ(1, sorted_objs[0]);
  ASSERT_EQ(2, sorted_objs[1]);
  ASSERT_EQ(3, sorted_objs[2]);
  ASSERT_EQ(4, sorted_objs[3]);
  ASSERT_EQ(size_t(4), sorted_objs.Size());

  size_t ret = sorted_objs.RemoveObj(4);
  ASSERT_EQ(size_t(1), ret);
  ASSERT_EQ(1, sorted_objs[0]);
  ASSERT_EQ(2, sorted_objs[1]);
  ASSERT_EQ(3, sorted_objs[2]);
}

TEST_F(test_sorted_objs, move) {
  std::pair<int, int*> result;
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs_1(10);
  SortedObjs< int, int, ReflectorF<int>, std::less<int> > sorted_objs_2(10);

  result = sorted_objs_1.Insert(1);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs_1.Insert(3);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs_1.Insert(5);
  ASSERT_TRUE(result.first>=0);
  sorted_objs_1.ReserveSpaceAtHead(2);

  result = sorted_objs_2.Insert(2);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs_2.Insert(4);
  ASSERT_TRUE(result.first>=0);
  result = sorted_objs_2.Insert(6);
  ASSERT_TRUE(result.first>=0);
  sorted_objs_2.ReserveSpaceAtHead(2);

  sorted_objs_1.MoveBackToFront(1, sorted_objs_2);
  ASSERT_EQ(size_t(2), sorted_objs_1.Size());
  ASSERT_EQ(size_t(4), sorted_objs_2.Size());
  ASSERT_EQ(1, sorted_objs_1[0]);
  ASSERT_EQ(3, sorted_objs_1[1]);
  ASSERT_EQ(5, sorted_objs_2[0]);
  ASSERT_EQ(2, sorted_objs_2[1]);

  sorted_objs_2.MoveFrontToBack(2, sorted_objs_1);
  ASSERT_EQ(size_t(4), sorted_objs_1.Size());
  ASSERT_EQ(size_t(2), sorted_objs_2.Size());
  ASSERT_EQ(1, sorted_objs_1[0]);
  ASSERT_EQ(2, sorted_objs_1[3]);
  ASSERT_EQ(4, sorted_objs_2[0]);
  ASSERT_EQ(6, sorted_objs_2[1]);
}

TEST_F(test_sorted_objs, pressure) {
  const size_t kNumToInsert=3000;
  SortedObjs<int> sorted_objs(kNumToInsert+1);
  std::pair<int, int*> result;
  std::multiset<int> set_objs;

  for (size_t i=0; i<kNumToInsert; ++i) {
    int rand_int = rand();
    result = sorted_objs.Insert(rand_int);
    ASSERT_TRUE(result.first>=0);

    set_objs.insert(rand_int);
  }

  std::set<int>::iterator iter = set_objs.begin();
  for (size_t i=0; i<kNumToInsert; ++i) {
    ASSERT_EQ(sorted_objs[i], *iter++);
  }
  ASSERT_TRUE(set_objs.end() == iter);
}

TEST_F(test_sorted_objs, bug_case0) {
  std::pair<int, int*> result;
  SortedObjs<int> sorted_objs(6);
  for (size_t i=0; i<2; ++i) {
    result = sorted_objs.Insert(2);
    ASSERT_TRUE(result.first>=0);
  }
  sorted_objs.ReserveSpaceAtHead(2);
  size_t ret = sorted_objs.RemoveObj(2);
  ASSERT_EQ(size_t(2), ret);
}
