#include "gtest/gtest.h"
#include "../../../../src/public/routine_file_dumper/routine_file_dumper.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class test_routine_file_dumper : public ::testing::Test {
 protected:
  explicit test_routine_file_dumper() {}
  virtual void SetUp() {
    system("mkdir -p data/test_routine_file_dumper");
  }

  virtual void TearDown() {
    system("rm -rf data/test_routine_file_dumper");
  }
};

int CallOnce(void* args, FILE* fp) {
  size_t bytes_written = fwrite(args, sizeof(size_t), 1, fp);
  return 1 == bytes_written ? 0 : -1;
}

static size_t num=0;

int CallRoutine(void*, FILE* fp) {
  static size_t times=0;
  ++times;
  if (0 == times%2) return 1;

  size_t bytes_written = fwrite(
      RCAST<void*>(&num),
      sizeof(size_t), 
      1, 
      fp);
  ++num;
  return 1 == bytes_written ? 0 : -1;
}

TEST_F(test_routine_file_dumper, insert_erase) {
  bool end=false;
  size_t content = 123;
  RoutineFileDumper routine_file_dumper(end);
  int ret = routine_file_dumper.RegisteDumpTask(
      "call_once",
      CallOnce,
      RCAST<void*>(&content),
      "data/test_routine_file_dumper",
      "sample_once",
      0);
  ASSERT_TRUE(true==ret);

  ret = routine_file_dumper.RegisteDumpTask(
      "call_routine",
      CallRoutine,
      NULL,
      "data/test_routine_file_dumper",
      "sample_routine",
      0);
  ASSERT_TRUE(true==ret);

  sleep(4);

  char buf[4096];
  FILE* fp = fopen("data/test_routine_file_dumper/sample_once", "r");
  ASSERT_TRUE(NULL!=fp);
  fgets(buf, sizeof(buf), fp);  
  ASSERT_EQ(123, (int)buf[0]);
  fclose(fp);

  fp = fopen("data/test_routine_file_dumper/sample_routine", "r");
  ASSERT_TRUE(NULL!=fp);
  fgets(buf, sizeof(buf), fp);  
  ASSERT_TRUE(atoll(buf)<3);
  fclose(fp);

  end=true;
}
