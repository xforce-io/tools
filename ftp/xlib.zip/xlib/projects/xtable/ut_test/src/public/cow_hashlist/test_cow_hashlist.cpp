#include <time.h>
#include <sys/time.h>
#include <tr1/unordered_map>

#include "gtest/gtest.h"
#include "../../../../src/public/cow_hashlist/cow_hashlist.hpp"

using namespace zmt::material_center;

namespace zmt { namespace material_center {

LOGGER_IMPL(material_center, "material_center")

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

struct PairHasher {
  size_t operator() (const std::pair<int, int>& p) const {
    return __gnu_cxx::hash<int>()(p.first);
  }
};

struct PairEqualer {
  bool operator() (
      const std::pair<int, int>& p1,
      const std::pair<int, int>& p2) const {
    return p1.first == p2.first;
  }
};

std::ostream& operator<<(std::ostream& os, const std::pair<int, int>& p) { 
  os << "(" << p.first << "," << p.second << ")";
  return os; 
}

std::ostream& operator<<(std::ostream& os, const std::pair<size_t, int>& p) { 
  os << "(" << p.first << "," << p.second << ")";
  return os; 
}

TEST(cow_hashlist, insert) {
  typedef CowHashlist< 
      std::pair<int, int>,
      size_t, 
      std::pair<size_t, int>,
      PairHasher,
      PairEqualer,
      std::_Select1st< std::pair<size_t, int> >, 
      std::less<size_t> > Hashlist;

  Hashlist hashlist(10);
  std::pair<bool, Hashlist::List::Iterator> ret;

  //insert
  ret = hashlist.Insert(
      std::pair<int, int>(1, 3), 
      std::pair<size_t, int>(2, 3));
  ASSERT_TRUE(true == ret.first);

  ret = hashlist.Insert(
      std::pair<int, int>(1, 2), 
      std::pair<size_t, int>(2, 4));
  ASSERT_TRUE(false == ret.first);

  ret = hashlist.Insert(
      std::pair<int, int>(1, 2), 
      std::pair<size_t, int>(4, 4));
  ASSERT_TRUE(true == ret.first);

  ret = hashlist.Insert(
      std::pair<int, int>(2, 3), 
      std::pair<size_t, int>(4, 3));
  ASSERT_TRUE(true == ret.first);

  ret = hashlist.Insert(
      std::pair<int, int>(2, 3), 
      std::pair<size_t, int>(5, 3));
  ASSERT_TRUE(true == ret.first);

  //copy
  Hashlist hashlist_2(10);
  bool ret_bool = hashlist_2.Copy(hashlist);
  ASSERT_TRUE(true==ret_bool);

  //find
  Hashlist::List::ConstIterator ret_const_find = 
    hashlist.Find(std::pair<int, int>(2, 0), 4);
  ASSERT_EQ(3, ret_const_find.GetVal().second);

  Hashlist::List::Iterator ret_find = 
    hashlist.FindToWrite(std::pair<int, int>(2, 0), 4);
  ASSERT_EQ(3, ret_find.GetVal().second);

  //erase
  ret_bool = hashlist.Erase(std::pair<int, int>(1, 0));
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ(size_t(1), hashlist.Size());

  ret_bool = hashlist.Erase(std::pair<int, int>(2, 0), 5);
  ASSERT_TRUE(true==ret_bool);
  ASSERT_EQ(size_t(1), hashlist.Size());

  //check
  ASSERT_EQ(size_t(2), hashlist_2.Size());

  ret_find = hashlist_2.FindToWrite(std::pair<int, int>(2, 0), 4);
  ASSERT_EQ(3, ret_find.GetVal().second);
}

TEST(cow_hashlist, pressure) {
  typedef MultiCowHashlist<size_t, size_t> Hashlist;

  Hashlist hashlist(10, 10, true);
  std::pair<bool, Hashlist::List::Iterator> ret;

  const static size_t kNumSample=1000;
  const static size_t kRange=1000;
  std::vector< std::pair<size_t, size_t> > container;
  for (size_t i=0; i<kNumSample; ++i) {
    size_t key = rand() % kRange;
    size_t val = rand() % kRange;
    ret = hashlist.Insert(key, val);
    ASSERT_TRUE(true == ret.first);

    container.push_back(std::pair<size_t, size_t>(key, val));
  }

  const static size_t kTimesTest=100;
  for (size_t i=0; i<kTimesTest; ++i) {
    std::cout << "test " << i << std::endl;
    size_t key0 = rand() % kRange;
    size_t key1 = rand() % kRange;
    size_t hign_key = key0 > key1 ? key0 : key1;
    size_t low_key = (hign_key==key0 ? key1 : key0);

    size_t num_hashlist=0;
    for (size_t key=low_key; key<hign_key; ++key) {
      const Hashlist::List* list = hashlist.FindList(key);
      if (NULL!=list) num_hashlist += list->Size();
    }

    size_t num_container=0;
    for (size_t i=0; i < container.size(); ++i) {
      if (container[i].first <= hign_key && container[i].first >= low_key) {
        ++num_container;
      }
    }
    ASSERT_EQ(num_hashlist, num_container);
  }
}

}}
