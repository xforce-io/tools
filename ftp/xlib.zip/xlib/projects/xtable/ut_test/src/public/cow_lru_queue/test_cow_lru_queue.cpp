#include <stdlib.h>
#include <time.h>

#include "gtest/gtest.h"
#include "../../../../src/public/cow_lru_queue/cow_lru_queue.hpp"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_lru_queue, simple_copy_test) {
  CowLRUQueue<int, bool> queue(2);
  queue = CowLRUQueue<int, bool>(3);
  ASSERT_TRUE(queue.size_queue_==3);

  CowLRUQueue<int, bool> queue_2(3);
  queue.Copy(queue_2);
  queue = CowLRUQueue<int, bool>(3);
}

TEST(test_lru_queue, normal) {
  CowLRUQueue<int, bool> queue(3);
  int ret, val_in;
  std::pair< int, std::pair<int*, bool*> > result;
  result = queue.Insert(val_in=1, 0);
  ASSERT_EQ(result.first, 0);

  result = queue.Insert(val_in=1, 1);
  ASSERT_EQ(result.first, 1);
  result = queue.Insert(val_in=2, 0);
  ASSERT_EQ(result.first, 0);
  ASSERT_EQ(*(result.second.first), 2);
  ASSERT_EQ(*(result.second.second), 0);
  result = queue.Insert(val_in=4, 0);
  ASSERT_EQ(result.first, 0);

  CowLRUQueue<int, bool>::Iterator iter = queue.Begin();
  ASSERT_EQ(*((*iter).first), 4);
  ASSERT_EQ(*((*iter).second), 0);
  ++iter;
  ASSERT_EQ(*((*iter).first), 2);
  ASSERT_EQ(*((*iter).second), 0);
  ++iter;
  ASSERT_EQ(*((*iter).first), 1);
  ASSERT_EQ(*((*iter).second), 0);
  ++iter;
  ASSERT_TRUE(queue.End() == iter);

  ASSERT_EQ(*(queue.head_->key), 4);  
  ASSERT_EQ(*(queue.head_->next->key), 2);  
  ASSERT_EQ(*(queue.head_->next->next->key), 1);  
  ASSERT_EQ(size_t(3), queue.map_.Size());

  result = queue.Insert(val_in=0, 0);
  ASSERT_EQ(result.first, 0);

  ASSERT_EQ(*(queue.head_->key), 0);  
  ASSERT_EQ(*(queue.head_->next->key), 4);  
  ASSERT_EQ(*(queue.head_->next->next->key), 2);  
  ASSERT_EQ(size_t(3), queue.map_.Size());

  ASSERT_EQ(size_t(3), queue.Size());

  ret = queue.Touch(val_in=3);
  ASSERT_TRUE(false == ret);

  ASSERT_EQ(*(queue.head_->key), 0);
  ASSERT_EQ(*(queue.head_->next->key), 4);
  ASSERT_EQ(*(queue.head_->next->next->key), 2);
  ASSERT_EQ(size_t(3), queue.map_.Size());

  CowLRUQueue<int, bool> queue_2(4);
  ret = queue_2.Copy(queue);
  ASSERT_TRUE(false == ret);

  CowLRUQueue<int, bool> queue_3(3);
  ret = queue_3.Copy(queue);
  ASSERT_TRUE(true == ret);

  CowLRUQueue<int, bool> queue_4(3);
  ret = queue_4.Copy(queue);
  ASSERT_TRUE(true == ret);

  std::pair<const int*, const bool*> result_2 = queue_3.GetAndTouch(val_in=2);
  ASSERT_EQ(0, *(result_2.second));

  ASSERT_EQ(*(queue_3.head_->key), 2);
  ASSERT_EQ(*(queue_3.head_->next->key), 0);
  ASSERT_EQ(*(queue_3.head_->next->next->key), 4);
  ASSERT_EQ(size_t(3), queue_3.map_.Size());

  queue_3.Erase(0);
  ASSERT_EQ(*(queue_3.head_->key), 2);  
  ASSERT_EQ(*(queue_3.head_->next->key), 4);  
  ASSERT_EQ(size_t(2), queue_3.map_.Size());

  queue_3.Erase(4);
  ASSERT_EQ(*(queue_3.head_->key), 2);  
  ASSERT_EQ(size_t(1), queue_3.map_.Size());
  ASSERT_EQ(0, *(queue_3.Get(2).second));

  queue_3.Erase(4);
  ASSERT_EQ(*(queue_3.head_->key), 2);  
  ASSERT_EQ(size_t(1), queue_3.map_.Size());
  ASSERT_TRUE(queue_3.head_==queue_3.tail_);

  queue_3.Erase(2);
  ASSERT_EQ(size_t(0), queue_3.map_.Size());

  ASSERT_EQ(size_t(3), queue.map_.Size());
  ASSERT_EQ(size_t(3), queue_4.map_.Size());
  queue_4.Clear();

  ASSERT_EQ(size_t(0), queue_4.map_.Size());
  ASSERT_TRUE(NULL == queue_4.head_);
  ASSERT_TRUE(NULL == queue_4.tail_);

  ASSERT_EQ(size_t(3), queue.map_.Size());
  ASSERT_TRUE(NULL != queue.head_);
  ASSERT_TRUE(NULL != queue.tail_);

  result_2 = queue.Get(val_in=0);
  ASSERT_EQ(0, *(result_2.second));

  CowLRUQueue<int, bool> queue_5(1);
  ret = (queue_5.Insert(0, 0)).first;
  ASSERT_EQ(ret, -1);
}

TEST(test_lru_queue, iterator) {
  static const size_t kCount=2458;
  CowLRUQueue<size_t, bool> queue(kCount);
  ASSERT_TRUE(queue.Begin() == queue.End());  

  for (size_t i=0; i<kCount-1; ++i) {
    queue.Insert(rand(), 0);
  }

  queue.Insert(rand(), 0);

  std::cout << queue.Size() << std::endl;
  CowLRUQueue<size_t, bool>::Iterator iter;
  size_t count=0;
  for (iter = queue.Begin();
      iter != queue.End();
      ++iter) {
    ++count;
  }
}

TEST(test_lru_queue, bugcase0) {
  CowLRUQueue<int, int>* queue = new CowLRUQueue<int, int>(30);
  queue->map_.size_buckets_=1;
  int ret = queue->map_.Init_();
  ASSERT_TRUE(true==ret);

  ret = (queue->Insert(1, 1)).first;
  ASSERT_EQ(0, ret);

  CowLRUQueue<int, int>* queue_2 = new CowLRUQueue<int, int>(30);
  queue_2->map_.size_buckets_=1;
  ret = queue_2->Copy(*queue);
  ASSERT_TRUE(true==ret);

  ret = (queue_2->Insert(2, 9)).first;
  ASSERT_EQ(0, ret);

  delete queue;
  queue_2->Erase(2);

  delete queue_2;
}
