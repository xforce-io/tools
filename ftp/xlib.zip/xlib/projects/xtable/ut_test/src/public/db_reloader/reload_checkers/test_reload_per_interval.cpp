#include "gtest/gtest.h"
#include "../../../../../src/public/public.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(test_reload_per_interval, init) {
  ReloadPerInterval::InitParams init_params = (struct ReloadPerInterval::InitParams){ 1 };
  ReloadPerInterval reload_per_interval(&init_params);
  int ret = reload_per_interval.ToLoad();
  ASSERT_EQ(0, ret);
  usleep(1);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
  sleep(1);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(0, ret);
  ret = reload_per_interval.ToLoad();
  ASSERT_EQ(1, ret);
}
