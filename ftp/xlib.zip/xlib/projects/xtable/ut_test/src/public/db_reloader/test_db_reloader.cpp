#include "gtest/gtest.h"

#include "../../../../src/public/public.h"

using namespace zmt::material_center;

namespace zmt { namespace material_center {
LOGGER_IMPL(material_center, "material_center")
}}

class TestDBReloader : public ::testing::Test {
 protected:
  virtual ~TestDBReloader() {};
  virtual void SetUp() { 
    system("mkdir -p data");
  }
  virtual void TearDown() { }
};

int main(int argc, char** argv) {
  srand(time(NULL));
  LOGGER_SYS_INIT("conf/log.conf")
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

class DBTestedInterval : public DataBase {
 public:
  typedef DataBase Super;

 public:
  bool Init(const std::string& db_name, void* /*params*/) {
    Super::Init_(db_name);
    count_=0;
    return true;
  }

 private:
  bool Load_(const Super&) { 
    static time_t start_time = time(NULL);
    if (time(NULL) - start_time >= 2) count_=10;
    std::cout << "reload:" << count_ << " start_time:" << start_time 
        << " now:" << time(NULL) << std::endl;
    return true; 
  }

 private:
  size_t count_; 
};

class DbTestedUpdate: public DataBase {
 public:
  typedef DataBase Super;

 public:
  bool Init(const std::string& db_name, void* /*params*/) {
    Super::Init_(db_name);
    return true;
  }

 private:
  bool Load_(const Super&) { return true; }
};

class DbTestedInvalid : public DataBase {
 public:
  typedef DataBase Super;

 public:
  bool Init(const std::string& db_name, void* /*params*/) {
    Super::Init_(db_name);
    return true;
  }

 private:
  bool Load_(const Super&) { return false; }
};

TEST_F(TestDBReloader, init) {
  system("touch data/tmp");
  ReloadPerInterval::InitParams reload_checker_interval_params;
  reload_checker_interval_params.load_interval_in_sec=1;
  ReloadWhenModified::InitParams reload_checker_update_params;
  reload_checker_update_params.monitored_filepath="data/tmp";

  DBReloader db_reloader("test_db_reloader", 3);
  int id_db_tested_interval = db_reloader.RegistDB<DBTestedInterval, ReloadPerInterval>(
      "db_tested_interval",
      NULL,
      &reload_checker_interval_params);
  ASSERT_TRUE(id_db_tested_interval>=0);

  int id_db_tested_update = db_reloader.RegistDB<DbTestedUpdate, ReloadWhenModified>(
      "db_tested_update",
      NULL,
      &reload_checker_update_params);
  ASSERT_TRUE(id_db_tested_update>0);

  bool ret = db_reloader.StartReloadThread();
  ASSERT_EQ(ret, true);

  sleep(1);

  size_t count;
  for (size_t i=0; i<1000; ++i) {
    count = RCAST<DBTestedInterval*>(
        db_reloader.GetDB(id_db_tested_interval))->count_;
    ASSERT_EQ(size_t(0), count);    
  }

  sleep(4);
  for (size_t i=0; i<1000; ++i) {
    count = RCAST<DBTestedInterval*>(
        db_reloader.GetDB(id_db_tested_interval))->count_;
    ASSERT_EQ(size_t(10), count);    
  }

  for (size_t i=0; i<1000000; ++i) {
    ASSERT_TRUE(NULL!=db_reloader.GetDB(id_db_tested_interval));
    ASSERT_TRUE(NULL!=db_reloader.GetDB(id_db_tested_update));
  }
}
