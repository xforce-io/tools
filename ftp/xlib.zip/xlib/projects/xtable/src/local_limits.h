#pragma once

#include <stddef.h>
#include <stdint.h>
#include <limits.h>

namespace zmt { namespace material_center {

namespace Limits {
  static const size_t kMaxNumIndexsPerTable=100;
  static const size_t kMaxSizePath=256;
  static const size_t kMaxSizeRecord = (1<<20);
  static const size_t kMaxSizeRecordFile= (1<<30);

  static const size_t kMaxNoTable = (1<<15);
  static const int64_t kMaxTableKey = (((int64_t)1)<<48) - 1;
  static const int64_t kMinTableKey = -(((int64_t)1)<<48);
};

}}
