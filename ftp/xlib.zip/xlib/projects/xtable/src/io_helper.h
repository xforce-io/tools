#pragma once

#include "public.h"

namespace zmt { namespace material_center {

class IOHelper {
 private:
  static const size_t kSizeBuf = sizeof(int64_t)+1;
  static const char kMaskMeta = 248;
  static const char kMaskExcMeta = 7;
  static const char kMaskInvade = (1<<7);
  static const char kMaskPos = (1<<6);
  static const char kMaskNumBytes = (7<<3);
 
 public:
  inline static size_t WriteInt(int64_t int_obj, char* buf, size_t size_buf);
  inline static size_t WriteStr(const std::string& str, char* buf, size_t size_buf);
  inline static size_t WriteStr(const char* str, char* buf, size_t size_buf);
  inline static bool WriteInt(int64_t int_obj, FILE* fp);
  inline static bool WriteStr(const std::string& str, FILE* fp);
  inline static bool WriteStr(const char* str, FILE* fp);

  static size_t ReadInt(IN const char* buf, IN size_t size_buf, OUT int64_t& int_obj); 

  /*
   * @note: user should assure that '\0' should be at valid memory
   */
  inline static size_t ReadStr(IN const char* buf, OUT std::string& str);
  static bool ReadInt(IN FILE* fp, OUT int64_t& int_obj); 
  inline static bool ReadStr(IN FILE* fp, OUT std::string& str);

 private: 
  /* 
   * @return: output buffer
   * @note: 
   *    (1) '\0' is contained in buf
   *    (2) buf should have size which is ge sizeof(int64_t)+2
   */
  static size_t EncodeInt64_(int64_t int64, char* buf);
  inline static uint16_t MetaInfo_(bool invade, bool is_pos, size_t num_bytes);
};

size_t IOHelper::WriteInt(int64_t int_obj, char* buf, size_t size_buf) {
  if (unlikely(size_buf<kSizeBuf)) return 0;
  return EncodeInt64_(int_obj, buf);
}

size_t IOHelper::WriteStr(const std::string& str, char* buf, size_t size_buf) {
  if (unlikely(size_buf <= str.length())) return 0;
  memcpy(buf, str.c_str(), str.length() + 1);
  return str.length() + 1;
}

size_t IOHelper::WriteStr(const char* str, char* buf, size_t size_buf) {
  size_t len_str = strlen(str);
  if (unlikely(size_buf<=len_str)) return 0;
  memcpy(buf, str, len_str+1);
  return len_str+1;
}

bool IOHelper::WriteInt(int64_t int_obj, FILE* fp) {
  char buf[kSizeBuf];
  size_t size = EncodeInt64_(int_obj, buf);
  return 1 == fwrite(buf, size, 1, fp);
}

bool IOHelper::WriteStr(const std::string& str, FILE* fp) {
  return 1 == fwrite(str.c_str(), str.length() + 1, 1, fp);
}

bool IOHelper::WriteStr(const char* str, FILE* fp) {
  return 1 == fwrite(str, strlen(str) + 1, 1, fp);
}

size_t IOHelper::ReadStr(const char* buf, std::string& str) {
  str.assign(buf);
  return str.length() + 1;
}

bool IOHelper::ReadStr(FILE* fp, std::string& str) {
  str.clear();
  char tmp_char = fgetc(fp);
  while (0!=tmp_char) {
    if (unlikely(EOF==tmp_char)) return false;
    str.push_back(tmp_char);
    tmp_char = fgetc(fp);
  }
  str.push_back(0);
  return true;
}

uint16_t IOHelper::MetaInfo_(bool invade, bool is_pos, size_t num_bytes) {
  return (invade<<4) | (is_pos<<3) | (num_bytes-1);
}

}}
