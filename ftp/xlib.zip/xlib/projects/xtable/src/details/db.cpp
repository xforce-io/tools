#include "../db.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <fcntl.h>

#include "../public.h"
#include "db_talk.h"

namespace zmt { namespace material_center {

bool DBTPD::ResetPipe() {
  int ret;
  int fd[2];
  ret = socketpair(AF_UNIX, SOCK_STREAM, 0, fd);
  MEGA_FAIL_HANDLE_FATAL(ret<0, "fail_create_pipe_in_db")

  for (size_t i=0; i < sizeof(fd)/sizeof(fd[0]); ++i) {
    ret = fcntl(fd[i], F_GETFL, 0);
    if(ret<0) {
      ret = fcntl(fd[i], F_SETFL, ret | O_NONBLOCK);
      MEGA_FAIL_HANDLE_FATAL(ret<0, "fail_fcntl")
    }
  }

  memcpy(fd_, fd, sizeof(fd_));
  return true;;

  ERROR_HANDLE:
  return false;
}

DB::DB() : 
//  pipe_flush_(NULL),
  db_device_(NULL),
  db_mem_(NULL),
  start_(false) {}  

bool DB::Init(
    size_t max_size_device_block,
    time_t device_index_dump_interval,
    time_t device_flush_interval,
    size_t size_lru_queue,
    time_t tables_dump_interval,
    time_t tables_reload_interval,
    //size_t size_flush_pipe,
    RoutineFileDumper& routine_file_dumper,
    size_t num_writer,
    bool& end) {
  MEGA_NEW(db_device_, DBDevice)
  MEGA_NEW(db_mem_, DBMem)
  bool ret = db_mem_->Init(
      *db_device_,
     // *pipe_flush_,
      size_lru_queue,
      tables_dump_interval,
      tables_reload_interval,
      routine_file_dumper,
      end);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_init_db_mem")

  ret = db_device_->Init(
      max_size_device_block,
      device_index_dump_interval,
      device_flush_interval,
      //*pipe_flush_,
      routine_file_dumper,
      *db_mem_,
      DBMem::CallbackReplayDeviceLog,
      end);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_init_db_device")

  ret = pthread_barrier_init(&thread_barrier_, NULL, num_writer);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_register_pipe");  

  return true;

  ERROR_HANDLE:
  MEGA_DELETE(db_mem_)
  MEGA_DELETE(db_device_)
  return false;
}

int DB::CreateTable(const std::string& command) {
  if (unlikely(true != WaitForStart_())) return ErrorNo::kOther;

  WeakType command_wt;
  int ret = command_wt.JsonDecode(command.c_str(), command.size(), NULL);
  if (true!=ret || true != command_wt.IsString()) {
    return ErrorNo::kInvalidSyntax;
  }

  DBMsgCreateTable db_msg_create_table;
  db_msg_create_table.cmd = DBMsgCreateTable::kCmd;
  db_msg_create_table.syntax = &(command_wt.GetString());

  int talk_fd = GetFdPipeDBMem_();
  if (unlikely(talk_fd<=0)) return ErrorNo::kOther;

  ret = DBTalk::WriteDBMsgRequest(
      talk_fd, 
      static_cast<DBMsgHeader&>(db_msg_create_table));
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = DBTalk::ReadDBMsgResponse(talk_fd);
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = db_msg_create_table.ret_code;
  MEGA_FAIL_HANDLE(0!=ret)
  return 0;

  ERROR_HANDLE:
  ResetPipe_();
  return ret;
}

int DB::AddRecord(const std::string& command) {
  if (unlikely(true != WaitForStart_())) return ErrorNo::kOther;

  WeakType command_wt;
  int ret = command_wt.JsonDecode(command.c_str(), command.size(), NULL);
  if (unlikely(true!=ret 
      || true != command_wt.IsDict()
      || true != command_wt["table"].IsString())) {
    return ErrorNo::kInvalidSyntax;
  }

  DBMsgAddRecord db_msg_add_record;
  db_msg_add_record.cmd = DBMsgAddRecord::kCmd;
  db_msg_add_record.table_name = &(command_wt["table"].GetString());
  db_msg_add_record.record = &(command_wt["record"]);

  int talk_fd = GetFdPipeDBMem_();
  if (unlikely(talk_fd<=0)) return ErrorNo::kOther;

  ret = DBTalk::WriteDBMsgRequest(
      talk_fd, 
      static_cast<DBMsgHeader&>(db_msg_add_record));
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = DBTalk::ReadDBMsgResponse(talk_fd);
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = db_msg_add_record.ret_code;
  MEGA_FAIL_HANDLE(0!=ret)
  return 0;

  ERROR_HANDLE:
  ResetPipe_();
  return ret;
}

int DB::RemoveRecord(const std::string& command) {
  if (unlikely(true != WaitForStart_())) return ErrorNo::kOther;

  WeakType command_wt;
  int ret = command_wt.JsonDecode(command.c_str(), command.size(), NULL);
  if (unlikely(true!=ret 
      || true != command_wt.IsDict()
      || true != command_wt["table"].IsString())) {
    return ErrorNo::kInvalidSyntax;
  }

  DBMsgRemoveRecord db_msg_remove_record;
  db_msg_remove_record.cmd = DBMsgRemoveRecord::kCmd;
  db_msg_remove_record.table_name = &(command_wt["table"].GetString());
  db_msg_remove_record.keys_to_remove = &(command_wt["keys_to_remove"]);

  int talk_fd = GetFdPipeDBMem_();
  if (unlikely(talk_fd<=0)) return ErrorNo::kOther;

  ret = DBTalk::WriteDBMsgRequest(
      talk_fd,
      static_cast<DBMsgHeader&>(db_msg_remove_record));
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = DBTalk::ReadDBMsgResponse(talk_fd);
  MEGA_FAIL_HANDLE(0!=ret && (ret=ErrorNo::kOther))

  ret = db_msg_remove_record.ret_code;
  MEGA_FAIL_HANDLE(0!=ret)
  return 0;

  ERROR_HANDLE:
  ResetPipe_();
  return ret;
}

int DB::UpdateRecord(const std::string& command) {
  if (unlikely(true != WaitForStart_())) return ErrorNo::kOther;

  WeakType command_wt;
  int ret = command_wt.JsonDecode(command.c_str(), command.size(), NULL);
  if (unlikely(true!=ret 
      || true != command_wt.IsDict()
      || true != command_wt["table"].IsString())) {
    return ErrorNo::kInvalidSyntax;
  }

  DBMsgUpdateRecord db_msg_update_record;
  db_msg_update_record.cmd = DBMsgUpdateRecord::kCmd;
  db_msg_update_record.table_name = &(command_wt["table"].GetString());
  db_msg_update_record.keys_to_remove = &(command_wt["keys_to_remove"]);
  db_msg_update_record.record = &(command_wt["record"]);

  int talk_fd = GetFdPipeDBMem_();
  if (unlikely(talk_fd<=0)) return ErrorNo::kOther;

  ret = DBTalk::WriteDBMsgRequest(
      talk_fd, 
      static_cast<DBMsgHeader&>(db_msg_update_record));
  MEGA_FAIL_HANDLE(0!=ret && (ret = ErrorNo::kOther))

  ret = DBTalk::ReadDBMsgResponse(talk_fd);
  MEGA_FAIL_HANDLE(0!=ret && (ret = ErrorNo::kOther))

  ret = db_msg_update_record.ret_code;
  MEGA_FAIL_HANDLE(0!=ret)
  return 0;

  ERROR_HANDLE:
  ResetPipe_();
  return ret;
}

bool DB::ResetPipe_() {
  void* thread_privacy = thread_privacy_.Get<DBTPD>(kNoThreadPrivacy);
  if (unlikely(NULL==thread_privacy)) return false;

  return RCAST<DBTPD*>(thread_privacy)->ResetPipe();
}

bool DB::RegisterPipe_() {
  void* thread_privacy = thread_privacy_.Get<DBTPD>(kNoThreadPrivacy);
  if (unlikely(NULL==thread_privacy)) return false;

  return RCAST<DBTPD*>(thread_privacy)->RegisterPipe(*db_mem_);
}

DB::~DB() {
  pthread_barrier_destroy(&thread_barrier_);
  MEGA_DELETE(db_mem_)
  MEGA_DELETE(db_device_)
  //MEGA_DELETE(pipe_flush_)
}

}}
