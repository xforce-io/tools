#include "../public.h"

namespace zmt { namespace material_center {

const int ErrorNo::kSucc=0;
const int ErrorNo::kInvalidSyntax=-1;
const int ErrorNo::kExceedLimit=-2;
const int ErrorNo::kNoSuchTable=-3;
const int ErrorNo::kDupTable=-4;
const int ErrorNo::kNoSuckKey=-5;
const int ErrorNo::kDupKey=-6;
const int ErrorNo::kIO=-7;
const int ErrorNo::kOther=-100;

}}
