#include "../db_mem.h"
#include "../public.h"
#include "../db_talk.h"

namespace zmt { namespace material_center {

const std::string DBMem::kQuickloadDir = "data";
const std::string DBMem::kQuickloadFilename = "quickload_db_mem";

DBMem::DBMem() :
  end_(NULL),
  tid_writes_handler_(0) {}

bool DBMem::Init(
    DBDevice& db_device,
    size_t size_lru_queue,
    time_t tables_dump_interval,
    time_t tables_reload_interval,
    RoutineFileDumper& routine_file_dumper,
    bool& end) {
  DBMemCore::InitParams db_mem_core_init_params;
  db_mem_core_init_params.db_device = &db_device;
  db_mem_core_init_params.size_lru_queue = size_lru_queue;
  db_mem_core_init_params.tables_dump_interval = tables_dump_interval;
  db_mem_core_init_params.routine_file_dumper = &routine_file_dumper;

  ReloadPerInterval::InitParams reloader_init_params;
  reloader_init_params.load_interval_in_sec = tables_reload_interval;
  int ret = db_mem_cores_.Init(
      "db_mem_core",
      RCAST<void*>(&db_mem_core_init_params),
      RCAST<void*>(&reloader_init_params),
      kNumVersionsDBMemCores);
  if (true!=ret) {
    FATAL("fail_init_db_mem_cores");
    return false;
  }

  FILE* fp = fopen((kQuickloadDir + "/" + kQuickloadFilename).c_str(), "r");
  if (NULL==fp) {
    NOTICE("start_db_mem_without_quickload");
  } else {
    ret  = db_mem_cores_.CreateNewVersion();
    if (true!=ret) return false;
    
    DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
    ret = db_mem_core.Deserialize(fp);
    if (0!=ret) {
      FATAL("fail_deserialize_db_mem ret[" << ret << "]");
      return false;
    }

    db_mem_cores_.FreezeNewVersion();
    fclose(fp);
  }

  end_ = &end;

  ret = pthread_create(
      &tid_writes_handler_, 
      NULL, 
      WritesHandler_, 
      RCAST<void*>(this));
  if (0!=ret) {
    FATAL("fail_create_writes_handle_thread");
    return false;
  }
  return true;
}

bool DBMem::RegisterPipe(int fd) {
  bool ret = thread_mutex_.Lock();
  if (true!=ret) {
    FATAL("fail_registe_pipe");
    return false;
  }

  fds_.resize(fds_.size()+1);
  fds_.push_back(fd);
  thread_mutex_.Unlock();
  return true;
}

bool DBMem::ReplayDeviceLog(const DeviceLog& device_log) {
  int ret  = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return ErrorNo::kOther;

  DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
  ret = db_mem_core.ReplayDeviceLog(device_log);
  db_mem_cores_.FreezeNewVersion();
  return ret;
}

DBMem::~DBMem() {
  if (0!=tid_writes_handler_) {
    pthread_join(tid_writes_handler_, NULL);
  }
}

void* DBMem::WritesHandler_(void* self_arg) {
  Self& self = *(RCAST<Self*>(self_arg));
  while (false == *self.end_) {
    self.HandleWrites_();
  }
  self.HandleWrites_();
  return NULL;
}

void DBMem::HandleWrites_() {
  DBMsgHeader* db_msg_header;
  bool ret = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return;

  for (size_t i=0; i < fds_.size(); ++i) {
    for (;;) {
      int ret = DBTalk::ReadDBMsgRequest(fds_[i], db_msg_header);
      if (ret>0) {
        break;
      } else if(ret<0) {
        WARN("fail_read_db_msg_request ret_code[" << ret << "]");
        break;
      }

      switch (db_msg_header->cmd) {
        case DBMsgCreateTable::kCmd : {
          DBMsgCreateTable* db_msg = static_cast<DBMsgCreateTable*>(db_msg_header);
          db_msg->ret_code = CreateTable_(*(db_msg->syntax), db_msg->logic_time);
          break;
        }
        case DBMsgAddRecord::kCmd : {
          DBMsgAddRecord* db_msg = static_cast<DBMsgAddRecord*>(db_msg_header);
          db_msg->ret_code = AddRecord_(
              *(db_msg->table_name),
              *(db_msg->record),
              db_msg->logic_time);
          break;
        }
        case DBMsgRemoveRecord::kCmd : {
          DBMsgRemoveRecord* db_msg = static_cast<DBMsgRemoveRecord*>(db_msg_header);
          db_msg->ret_code = RemoveRecord_(
              *(db_msg->table_name),
              *(db_msg->keys_to_remove),
              db_msg->logic_time);
          break;
        }
        case DBMsgUpdateRecord::kCmd : {
          DBMsgUpdateRecord* db_msg = static_cast<DBMsgUpdateRecord*>(db_msg_header);
          db_msg->ret_code = UpdateRecord_(
              *(db_msg->table_name),
              *(db_msg->keys_to_remove),
              *(db_msg->record),
              db_msg->logic_time);
          break;
        }
        default :
          FATAL("unknow_cmd_got_in_db_talk cmd[" 
              << db_msg_header->cmd
              << "]");
          break;
      }
    }
  }
  db_mem_cores_.FreezeNewVersion();
}

int DBMem::CreateTable_(const std::string& syntax, LogicTime logic_time) {
  int ret  = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return ErrorNo::kOther;

  DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
  ret = db_mem_core.CreateTable(syntax, logic_time);
  db_mem_cores_.FreezeNewVersion();
  return ret;
}

int DBMem::AddRecord_(
    const std::string& table_name, 
    const WeakType& record,
    LogicTime logic_time) {
  int ret  = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return ErrorNo::kOther;

  DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
  ret = db_mem_core.AddRecord(table_name, record, logic_time);
  db_mem_cores_.FreezeNewVersion();
  return ret;
}

int DBMem::RemoveRecord_(
    const std::string& table_name, 
    const WeakType& keys_to_remove,
    LogicTime logic_time) {
  int ret  = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return ErrorNo::kOther;

  DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
  ret = db_mem_core.RemoveRecord(table_name, keys_to_remove, logic_time);
  db_mem_cores_.FreezeNewVersion();
  return ret;
}

int DBMem::UpdateRecord_(
    const std::string& table_name,
    const WeakType& keys_to_remove,
    const WeakType& record, 
    LogicTime logic_time) {
  int ret  = db_mem_cores_.CreateNewVersion();
  if (true!=ret) return ErrorNo::kOther;

  DBMemCore& db_mem_core = db_mem_cores_.GetWritableDB();
  db_mem_core.RemoveRecord(table_name, keys_to_remove, logic_time);
  ret = db_mem_core.AddRecord(table_name, record, logic_time);
  db_mem_cores_.FreezeNewVersion();
  return ret;
}

}}
