#include "../io_helper.h"

namespace zmt { namespace material_center {

size_t IOHelper::ReadInt(const char* buf, size_t size_buf, int64_t& int_obj) {
  int_obj=0;
  char* int_buf = RCAST<char*>(&int_obj);
  size_t pos=0;
  size_t pos_buf=0;
  if (unlikely(pos_buf+1 >= size_buf)) return 0;
  int_buf[pos] = buf[pos_buf++];
  if (unlikely(!int_buf[pos])) return 1;

  uint32_t meta_info = (int_buf[pos] & kMaskMeta);
  bool is_pos = (meta_info & kMaskPos);
  size_t num_bytes = ((meta_info & kMaskNumBytes) >> 3);
  int_buf[pos] &= kMaskExcMeta; 
  for (size_t i=0; i<num_bytes; ++i) {
    if (unlikely(pos_buf+1 == size_buf)) return -1;
    int_buf[++pos] = buf[pos_buf++];
  }
  if (!(meta_info & kMaskInvade)) int_obj>>=8;
  if (unlikely(!is_pos)) int_obj=-int_obj;
  return pos_buf;
}

bool IOHelper::ReadInt(FILE* fp, int64_t& int_obj) {
  int_obj=0;
  char* buf = RCAST<char*>(&int_obj);
  size_t pos=0;
  if (unlikely(feof(fp))) return false;
  buf[pos] = fgetc(fp);
  if (unlikely(!buf[pos])) return true;

  uint32_t meta_info = (buf[pos] & kMaskMeta);
  bool is_pos = (meta_info & kMaskPos);
  size_t num_bytes = ((meta_info & kMaskNumBytes) >> 3);
  buf[pos] &= kMaskExcMeta; 
  for (size_t i=0; i<num_bytes; ++i) {
    if (unlikely(feof(fp))) return false;
    buf[++pos] = fgetc(fp);
  }
  if (!(meta_info & kMaskInvade)) int_obj>>=8;
  if (unlikely(!is_pos)) int_obj=-int_obj;
  return true;
}

size_t IOHelper::EncodeInt64_(int64_t int64, char* buf) {
  buf[0]=0;
  if (unlikely(!int64)) return 1;

  bzero(buf, kSizeBuf);
  int pos = kSizeBuf-1;
  bool invade = !(int64&kMaskMeta);
  bool is_pos = (int64>0);
  *(RCAST<int64_t*>(buf+!invade)) = is_pos ? int64 : -int64;
  while (!buf[pos]) --pos;
  buf[0] |= (MetaInfo_(invade, is_pos, pos+1) << 3);
  return pos+1;
}

}}
