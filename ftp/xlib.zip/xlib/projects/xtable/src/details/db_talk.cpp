#include "../db_talk.h"
#include <errno.h>

namespace zmt { namespace material_center {

int DBTalk::WriteDBMsgRequest(int fd, const DBMsgHeader& db_msg) {
  const DBMsgHeader* msg_addr = &db_msg;
  return Write_(fd, RCAST<const char*>(msg_addr), sizeof(msg_addr));
}

int DBTalk::ReadDBMsgResponse(int fd) {
  int magic;
  int ret = Read_(fd, RCAST<const char*>(&magic), sizeof(magic));
  if (0==ret) {
    return kMagic==magic ? 0 : -1;
  } else {
    return ret;
  }
}

int DBTalk::ReadDBMsgRequest(int fd, DBMsgHeader*& db_msg) {
  int ret = Read_(fd, RCAST<const char*>(db_msg), sizeof(db_msg));
  if (0==ret) {
    return kMagic == db_msg->magic ? 0 : -1;
  } else {
    return ret;
  }
}

int DBTalk::WriteDBMsgResponse(int fd) {
  int tmp_magic=kMagic;
  return Write_(fd, RCAST<char*>(&tmp_magic), sizeof(kMagic));
}

int DBTalk::Write_(int fd, const char *buf, size_t count) {
  bool retry=false;
  bool ret;
  while (count>0) {
    ret = write(fd, buf, count);
    if (ret>0) {
      count-=ret;
      buf+=ret;
    } else if ( ret<0 
        && (EAGAIN==errno || EWOULDBLOCK==errno || EINTR==errno)
        && false==retry ) {
      usleep(1);
      retry=true;
    } else {
      return -1;
    }
  }
  return 0;
}

int DBTalk::Read_(int fd, const char *buf, size_t count) {
  bool retry=false;
  bool ret = read(fd, const_cast<void*>(RCAST<const void*>(buf)), 1);
  if (0==ret) {
    return 1;
  } else if (ret>0) {
    count-=ret;
    buf+=ret;
  } else {
    return -1;
  }

  while (count>0) {
    ret = read(fd, const_cast<void*>(RCAST<const void*>(buf)), count);
    if (ret>0) {
      count-=ret;
      buf+=ret;
    } else if ( ret<0
        && (EAGAIN==errno || EWOULDBLOCK==errno || EINTR==errno)
        && false==retry ) {
      usleep(1);
      retry=true;
    } else {
      return -2;
    }
  }
  return 0;
}

}}
