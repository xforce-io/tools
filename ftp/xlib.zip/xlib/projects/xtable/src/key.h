#pragma once

#include <cstddef>
#include <stdint.h>
#include "public.h"

namespace zmt { namespace material_center {

/*
 * @notice:
 *    table_no should be less than 2^15
 *    table_key should be in [-2^48 , 2^48)
 */
class UnionKey {
 public:
  static const size_t kMask = (((size_t)((1<<16)-1))<<48);
  static const size_t kNegBitMask = ~(((size_t)1)<<63);

 public:
  inline UnionKey(Key key);
  inline UnionKey(size_t table_no, int64_t table_key);
  inline void Set(size_t table_no, int64_t table_key);
  Key Encode() const { return key_; }
  inline void Decode(OUT size_t& table_no, OUT int64_t& table_key) const;

  inline static Key Encode(size_t table_no, int64_t table_key);
  inline static void Decode(IN Key key, OUT size_t& table_no, OUT int64_t& table_key);

 private:
  Key key_;
};

UnionKey::UnionKey(Key key) : 
  key_(key) {}

UnionKey::UnionKey(size_t table_no, int64_t table_key) {
  Set(table_no, table_key);
}

void UnionKey::Set(size_t table_no, int64_t table_key) {
  key_ = Encode(table_no, table_key);
}

void UnionKey::Decode(size_t& table_no, int64_t& table_key) const {
  Decode(key_, table_no, table_key);
}

Key UnionKey::Encode(size_t table_no, int64_t table_key) {
  return (table_no<<48) + (table_key & ~kMask);
}

void UnionKey::Decode(Key key, size_t& table_no, int64_t& table_key) {
  table_no = ((key & kNegBitMask) >> 48);
  table_key = ((key - (table_no<<48)) | kMask);
}

}}
