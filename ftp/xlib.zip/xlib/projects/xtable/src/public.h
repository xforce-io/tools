#pragma once

#include "public/public.h"
#include "local_limits.h"
#include "../src/3rd/crc32/crc.h"

namespace zmt { namespace material_center {

class Record;

typedef size_t LogicTime;
typedef int64_t TableKey;
typedef int64_t Key;

struct ErrorNo {
  static const int kSucc;
  static const int kInvalidSyntax;
  static const int kExceedLimit;
  static const int kNoSuchTable;
  static const int kDupTable;
  static const int kNoSuckKey;
  static const int kDupKey;
  static const int kIO;
  static const int kOther;
};

struct DevicePos {
  inline DevicePos(int index_arg=-1, off_t offset_arg=0);

  bool operator<(const DevicePos& other) {
    return (index < other.index) 
      || (index == other.index && offset < other.offset);
  }

  int index;
  off_t offset;
};

inline std::ostream& operator<<(std::ostream& os, DevicePos device_pos);

struct ResultsGetRecord {
  static const size_t kMaxBatchSize = 10000;

  int states[kMaxBatchSize];
  const Record* records[kMaxBatchSize];
  size_t size_records;
};

struct Cmd {
  enum EnumCmd {
    kUninit,
    kCreateTable,
    kDropTable,
    kAddRecord,
    kRemoveRecord,
    kNumCheckCode,
  };
};

struct FlushMsg {
  Cmd::EnumCmd cmd;
  size_t logic_time;

  union {
    struct {
      /* body */
      // char* syntax
    } create_table;

    struct {
      Key key;

      /* body */
      // char* serialize_record
    } add_rec;

    struct {
      /* body */
      // char* keys_tobe_removed
    } remove_rec;
  } cmd_extra;

  Slice msg;
};

DevicePos::DevicePos(int index_arg, off_t offset_arg) :
  index(index_arg), offset(offset_arg) {}

std::ostream& operator<<(std::ostream& os, DevicePos device_pos) {
  os << "{index:" 
     << device_pos.index 
     << ", offset:" 
     << device_pos.offset 
     << "}";
  return os;
}

}}
