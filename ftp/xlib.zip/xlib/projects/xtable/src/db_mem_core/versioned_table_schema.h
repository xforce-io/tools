#pragma once

#include "table_schema.h"

namespace zmt { namespace material_center {

class VersionedTableSchema {
 private:
  typedef VersionedTableSchema Self;
  typedef std::tr1::unordered_map<size_t, TableSchema*> Schemas;
  
 public:
  bool Init(const WeakType& syntax);
  bool ChangeSchema(const WeakType& syntax);
  inline const TableSchema* GetSchema(size_t version) const;
  inline const TableSchema& GetCurrentSchema() const;
  size_t GetCurrentVersion() const { return current_pos_schema_; }
  inline bool IsValidVersion(size_t version) const;

  int Serialize(FILE* fp) const;
  int Deserialize(FILE* fp);

  Self& operator=(const Self& other);
  void Clear();

  virtual ~VersionedTableSchema();
 
 private:
  inline size_t GetNextVersion_();
  
 private:
  Schemas schemas_;
  size_t current_pos_schema_;
};

const TableSchema* VersionedTableSchema::GetSchema(
    size_t version) const {
  Schemas::const_iterator iter = schemas_.find(version);
  if (unlikely(schemas_.end() == iter)) {
    return NULL;
  }
  return iter->second;
}

const TableSchema& VersionedTableSchema::GetCurrentSchema() const {
  return *(schemas_.find(current_pos_schema_)->second);
}

size_t VersionedTableSchema::GetNextVersion_() {
  return current_pos_schema_+1;
}

bool VersionedTableSchema::IsValidVersion(size_t version) const {
  return schemas_.end() != schemas_.find(version);
}

}}
