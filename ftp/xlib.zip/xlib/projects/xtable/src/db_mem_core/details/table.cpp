#include "../table.h"
#include "../table_index/table_index_feature_list.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

MapIndexs::Node* MapIndexs::GetNode_(
    const Key& key, 
    const Val& val) {
  bool ret;
  Node* node = node_alloc_.Get();
  MEGA_FAIL_HANDLE(NULL==node)

  node->key=key;
  if (TableIndexFeatureList::kCategory == val->GetCategory()) {
    MEGA_NEW(node->val, TableIndexFeatureList)
  } else {
    MEGA_FAIL_HANDLE(true)
  }

  ret = node->val->Copy(*val);
  MEGA_FAIL_HANDLE(true!=ret)
  return node;

  ERROR_HANDLE:
  if (NULL!=node) FreeNode_(*node);
  return NULL;
}

void MapIndexs::FreeNode_(Node& node) {
  MEGA_DELETE(node.val)
  node_alloc_.Free(&node);
}

Table::Table() :
  tmp_record_(NULL),
  init_(false) {}

Table::Table(const Self& other) :
  tmp_record_(NULL),
  init_(false) { 
  operator=(other); 
}

int Table::CreateTable(
    const WeakType& syntax, 
    size_t table_no) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  table_no_=table_no;

  int ret=0;
  TableIndexFeatureList table_index_feature_list;
  /*
   * parse from syntax
   */
  MEGA_FAIL_HANDLE_WARN(
      (true != syntax.IsDict() 
        || true != syntax["name"].IsString()),
      "invalid_table_string_syntax[" << syntax.DumpJson() << "]")
  name_ = syntax["name"].GetString();

  MEGA_FAIL_HANDLE_WARN( 
      (true != syntax["schema"].IsList() 
        || true != table_schemas_.Init(syntax["schema"]))
      && (ret = ErrorNo::kInvalidSyntax), 
      "invalid_table_schema_syntax syntax[" << syntax.DumpJson() << "]")

  MEGA_NEW(tmp_record_, Record(*this))

  if ( true == syntax["indexs"].IsList() ) {
    for (size_t i=0; i < syntax["indexs"].GetList().size(); ++i) {
      const WeakType& table_index_conf = syntax["indexs"][i];
      MEGA_FAIL_HANDLE_WARN( 
          (true != table_index_conf.IsDict()
            || true != table_index_conf["category"].IsString())
          && (ret = ErrorNo::kInvalidSyntax), 
          "invalid_table_index_syntax[" << syntax.DumpJson() << "]")

      if ( "index" == table_index_conf["category"].GetString() ) {
        ret = table_index_feature_list.Init(*this, table_index_conf);
        MEGA_FAIL_HANDLE(true!=ret && (ret = ErrorNo::kOther))

        ret = (table_indexs_.Insert(
            table_index_feature_list.GetName(), 
            &table_index_feature_list)).first;
        MEGA_FAIL_HANDLE_FATAL(true!=ret && (ret = ErrorNo::kOther), 
            "fail_insert_into_table_index")
      } else {
        MEGA_FAIL_HANDLE_FATAL(true && (ret = ErrorNo::kOther), 
            "unknow_table_index[" << table_index_conf["category"].GetString() )
      }
    }
  }
  return ErrorNo::kSucc;

  ERROR_HANDLE:
  return ret;
}

int Table::ChangeSchema(const WeakType& syntax) {
  bool ret = table_schemas_.ChangeSchema(syntax); 
  if (true!=ret) return ErrorNo::kOther;

  MEGA_DELETE(tmp_record_)
  MEGA_NEW(tmp_record_, Record(*this))
  return true;
}

int Table::AddRecord(const Record& record) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  for (MapIndexs::Iterator iter = table_indexs_.Begin();
      iter != table_indexs_.End();
      ++iter) {
    bool ret = iter.GetVal()->AddRecord(record);
    if (true!=ret) return ErrorNo::kDupKey;
  }
  return ErrorNo::kSucc;
}

int Table::ParseRecord(
    const WeakType& record_syntax,
    Record*& record) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  bool ret = tmp_record_->Parse(record_syntax);
  if (true!=ret) {
    WARN("invalid_record_syntax[" << record_syntax.DumpJson() << "]");
    return ErrorNo::kInvalidSyntax;
  }
  record=tmp_record_;
  return ErrorNo::kSucc;
}

int Table::RemoveRecord(const Record& record) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  for (MapIndexs::Iterator iter = table_indexs_.Begin();
      iter != table_indexs_.End();
      ++iter) {
    bool ret = iter.GetVal()->RemoveRecord(record);
    if (true!=ret) {
      FATAL("fail_update_index[" << iter.GetKey() << "]");
      return ErrorNo::kNoSuchTable;
    }
  }
  return ErrorNo::kSucc;
}

bool Table::SearchRecords(const WeakType& node_wt,
    SortedArrayInt64Set*& result) {
  if (unlikely(true != node_wt["index"].IsString())) {
    return false;
  }

  const std::string& index_name = node_wt["index"].GetString();
  TableIndex* index = GetIndex(index_name);
  return NULL!=index ? 
    index->SearchRecords(node_wt, result) : 
    false;
}

int Table::Serialize(FILE* fp) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  int ret = IOHelper::WriteInt(table_no_, fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteStr(name_, fp);
  if (true!=ret) return -2;

  ret = table_schemas_.Serialize(fp);
  if (0!=ret) {
    FATAL("fail_serialize_table_schema ret[" << ret << "]");
    return -3;
  }

  ret = IOHelper::WriteInt(table_indexs_.Size(), fp);
  if (true!=ret) return -4;

  for (MapIndexs::Iterator iter = table_indexs_.Begin();
      iter != table_indexs_.End();
      ++iter) {
    ret = IOHelper::WriteInt(iter.GetVal()->GetCategory(), fp);
    if (true!=ret) return -5;

    ret = iter.GetVal()->Serialize(fp);
    if (0!=ret) {
      FATAL("fail_serialize_table_index table_no[" 
          << table_no_ << "] ret[" << ret << "]");
      return -6;
    }
  }
  return 0;
}

int Table::Deserialize(FILE* fp) {
  MEGA_RAII_INIT(ErrorNo::kOther)

  Clear();

  int64_t tmp_int;
  std::string tmp_str;

  int ret = IOHelper::ReadInt(fp, tmp_int);
  if (true!=ret || tmp_int<0) return -1;
  table_no_=tmp_int;

  ret = IOHelper::ReadStr(fp, tmp_str);
  if (true!=ret) return -2;
  name_=tmp_str;

  ret = table_schemas_.Deserialize(fp);
  if (0!=ret) {
    FATAL("fail_deserialize_table_schema ret[" << ret << "]");
    return -3;
  }

  int64_t num_indexs;
  ret = IOHelper::ReadInt(fp, num_indexs);
  if (true!=ret || num_indexs<0) return -4;

  for (int64_t i=0; i<num_indexs; ++i) {
    size_t category_index;
    ret = IOHelper::ReadInt(fp, RCAST<int64_t&>(category_index));
    if (true!=ret) return -5;

    switch (category_index) {
      case TableIndexFeatureList::kCategory : {
        TableIndexFeatureList table_index;

        ret = table_index.Deserialize(fp);
        if (0!=ret) {
          FATAL("fail_deserialize_table_index table_no[" 
              << table_no_ << "] ret[" << ret << "]");
          return -6;
        }

        ret = (table_indexs_.Insert(table_index.GetName(), &table_index)).first;
        if (true!=ret) {
          FATAL("fail_insert_hashmap");
          return -7;
        }

        break;
      }
      default :
        FATAL("invalid_table_index_category[" << category_index << "]");
        break;
    }
  }
  MEGA_NEW(tmp_record_, Record(*this))
  return 0;
}

Table& Table::operator=(const Self& other) {
  if (unlikely(this == &other)) return *this;

  MEGA_ASSERT(true==init_ || true==Init_());

  table_no_ = other.table_no_;
  name_ = other.name_;
  table_schemas_ = other.table_schemas_;
  table_indexs_ = other.table_indexs_;
  return *this;
}

void Table::Clear() {
  MEGA_DELETE(tmp_record_)
  table_indexs_.Clear();
  table_schemas_.Clear();
}

Table::~Table() {
  Clear();
}

bool Table::Init_() {
  init_=true;
  return true;
}

}}
