#include <limits.h>
#include "../table_schema.h"
#include "../fields/type_cast_ops.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

bool TableSchema::Init(const WeakType& syntax) {
  syntax_ = syntax.DumpJson();

  if (true != syntax.IsList() || syntax.GetList().size() < 2) {
    WARN("invalid_table_schema[" << syntax.DumpJson() << "]");
    return false;
  }

  bool ret;
  for (size_t i=0; i < syntax.GetList().size(); ++i) {
    const WeakType& conf_item = syntax[i];
    if ( true != conf_item.IsDict()
        || true != conf_item["col"].IsString()
        || 0 == conf_item["col"].GetString().size()
        || true != conf_item["type"].IsString() ) {
      WARN("invalid_table_item[" << conf_item.DumpJson() << "]");
      return false;
    }

    const std::string& col = conf_item["col"].GetString();
    const std::string& type = conf_item["type"].GetString();
    ret = AddColumn(col, type, NULL, 0);
    if (true!=ret) return false;
  }
  return true;
}

bool TableSchema::AddColumn(
    const std::string& col, 
    const std::string& type, 
    const std::string* default_val,
    size_t version) {
  NameToIndex::iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() != iter)) return false;

  Property property;
  property.name = col;

  bool ret = property.type.Parse(type);
  if (unlikely(true!=ret)) return false;

  property.offset = SizeRecord();
  property.version = version;
  if (NULL==default_val) {
    property.default_field_val.has_val=false;
  } else {
    property.default_field_val.has_val=true;
    ret = property.type.ParseDefaultVal(
        *default_val, 
        property.default_field_val.val);
    if (unlikely(true!=ret)) return false;
  }

  ret = (name_to_index_.insert(
      std::pair<std::string, size_t>(col, schema_.size()))).second;
  if (true!=ret) return false;

  schema_.push_back(property);
  return true;
}

bool TableSchema::RemoveColumn(const std::string& col) {
  if (name_to_index_.size() <= 2) return false;

  NameToIndex::iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return false;

  size_t index_to_remove = iter->second;
  name_to_index_.erase(iter);

  size_t old_size = schema_[index_to_remove].type.GetSize();
  size_t old_offset = schema_[index_to_remove].offset;

  if (index_to_remove != schema_.size() - 1) {
    schema_[index_to_remove] = schema_[schema_.size() - 1];

    iter = name_to_index_.find(schema_[index_to_remove].name);
    MEGA_BUG(name_to_index_.end() == iter)

    iter->second = index_to_remove;

    schema_[index_to_remove].offset = old_offset;
    int64_t diff_offset = schema_[index_to_remove].type.GetSize() - old_size;
    for (size_t i=index_to_remove+1; i < schema_.size(); ++i) {
      schema_[i].offset += diff_offset;
    }
  }
  schema_.resize(schema_.size() - 1);
  return true;
}

bool TableSchema::ChangeType(
    const std::string& col, 
    const std::string& type) {
  NameToIndex::iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return false;

  size_t index_to_change = iter->second;
  size_t old_size = schema_[index_to_change].type.GetSize();

  bool ret = schema_[index_to_change].type.Parse(type);
  if (unlikely(true!=ret)) return false;

  int64_t diff_offset = schema_[index_to_change].type.GetSize() - old_size;
  for (size_t i=index_to_change+1; i < schema_.size(); ++i) {
    schema_[i].offset += diff_offset;
  }
  return true;
}

void* TableSchema::Update(const void* fields, const Self& table_schema) const {
  void* new_fields;
  MEGA_MALLOC(new_fields, void*, SizeRecord())
  bzero(new_fields, SizeRecord());

  bool ret;
  NameToIndex::const_iterator iter, iter_old;
  for (iter = name_to_index_.begin(); iter != name_to_index_.end(); ++iter) {
    iter_old = table_schema.name_to_index_.find(iter->first);
    if (table_schema.name_to_index_.end() != iter_old) {
      if (schema_[iter->second].version != 
          table_schema.schema_[iter_old->second].version) {
        ret = SetDefaultVal(
            new_fields, 
            iter->second, 
            schema_[iter->second].default_field_val);
        MEGA_FAIL_HANDLE(true!=ret)
      } else if (schema_[iter->second].type.GetType() != 
          table_schema.schema_[iter_old->second].type.GetType()) {
        TypeCastOps::TypeCaster type_caster = TypeCastOps::GetTypeCaster(
            table_schema.schema_[iter_old->second].type,
            schema_[iter->second].type);
        MEGA_FAIL_HANDLE(NULL==type_caster)

        ret = type_caster(
            RCAST<const void*>(RCAST<const char*>(fields) + 
              schema_[iter->second].offset),
            schema_[iter->second].type,
            RCAST<void*>(RCAST<char*>(new_fields) + 
              table_schema.schema_[iter->second].offset),
            table_schema.schema_[iter_old->second].type);
        MEGA_FAIL_HANDLE(true!=ret)
      } else {
        RealFieldType::Type type = schema_[iter->second].type.GetType();
        if (RealFieldType::kBool <= type && RealFieldType::kInt64 >= type) {
          ret = SetInt(new_fields, iter->second, 
              table_schema.GetInt(fields, iter_old->second));
        } else if (RealFieldType::kStr == type) {
          ret = SetStr(new_fields, iter->second, 
              table_schema.GetStr(fields, iter_old->second));
        } else if (RealFieldType::kSet8 <= type && RealFieldType::kSet64 >= type){
          ret = SetIntSet(new_fields, iter->second, 
              table_schema.GetIntSet(fields, iter_old->second));
        } else {
          ret = false;
        }
        MEGA_FAIL_HANDLE(true!=ret)
      }
    } else {
      ret = SetDefaultVal(
          new_fields, 
          iter->second, 
          schema_[iter->second].default_field_val);
      MEGA_FAIL_HANDLE(true!=ret)
    }
  }
  return new_fields;

  ERROR_HANDLE:
  MEGA_FREE(new_fields)
  return NULL;
}

bool TableSchema::Copy(const void* fields_from, void* fields_to) const {
  for (size_t i=0; i < schema_.size(); ++i) {
    RealFieldType::Type type = schema_[i].type.GetType();
    bool ret;
    if (RealFieldType::kBool <= type && RealFieldType::kInt64 >= type) {
      ret = SetInt(fields_to, i, GetInt(fields_from, i));
    } else if (RealFieldType::kStr == type) {
      ret = SetStr(fields_to, i, GetStr(fields_from, i));
    } else if (RealFieldType::kSet8 <= type && RealFieldType::kSet64 >= type){
      ret = SetIntSet(fields_to, i, GetIntSet(fields_from, i));
    } else {
      MEGA_BUG(true)
    }
    if (true!=ret) return false;
  }
  return true;
}

int TableSchema::Serialize(const void* fields, char* buf, size_t size_buf) const {
  size_t pos=0;
  for (size_t i=0; i < schema_.size(); ++i) {
    int ret = schema_[i].type.Serialize(GetField(fields, i), buf+pos, size_buf-pos);
    if (ret<=0) return ret;

    pos+=ret;
  }
  return pos;
}

int TableSchema::Deserialize(const char* buf, size_t size_buf, void* fields) const {
  size_t pos=0;
  for (size_t i=0; i < schema_.size(); ++i) {
    int ret = schema_[i].type.Deserialize(buf+pos, size_buf-pos, GetField(fields, i));
    if (ret<=0) return ret;

    pos+=ret;
  }
  return pos;
}

int TableSchema::Serialize(const void* fields, FILE* fp) const {
  for (size_t i=0; i < schema_.size(); ++i) {
    int ret = schema_[i].type.Serialize(GetField(fields, i), fp);
    if (ret<0) return ret;
  }
  return 0;
}

int TableSchema::Deserialize(FILE* fp, void* fields) const {
  for (size_t i=0; i < schema_.size(); ++i) {
    int ret = schema_[i].type.Deserialize(fp, GetField(fields, i));
    if (ret<0) return ret;
  }
  return 0;
}

int TableSchema::Serialize(FILE* fp) const {
  bool ret = IOHelper::WriteStr(syntax_, fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteInt(name_to_index_.size(), fp);
  if (true!=ret) return -2;

  NameToIndex::const_iterator iter;
  for (iter = name_to_index_.begin(); iter != name_to_index_.end(); ++iter) {
    ret = IOHelper::WriteStr(iter->first, fp);
    if (true!=ret) return -3;

    ret = IOHelper::WriteInt(iter->second, fp);
    if (true!=ret) return -4;
  }

  for (size_t i=0; i < schema_.size(); ++i) {
    ret = IOHelper::WriteStr(schema_[i].name, fp);
    if (true!=ret) return -5;

    RealFieldType::Type type = schema_[i].type.GetType();
    ret = IOHelper::WriteInt(type, fp);
    if (true!=ret) return -6;

    ret = IOHelper::WriteInt(schema_[i].offset, fp);
    if (true!=ret) return -7;

    ret = IOHelper::WriteInt(schema_[i].version, fp);
    if (true!=ret) return -8;

    ret = IOHelper::WriteInt(schema_[i].default_field_val.has_val, fp);
    if (true!=ret) return -9;

    if (type >= RealFieldType::kBool && type <= RealFieldType::kInt64) {
      ret = IOHelper::WriteInt(schema_[i].default_field_val.val.int_val, fp);
      if (true!=ret) return -10;
    } else if (RealFieldType::kStr == type) {
      ret = IOHelper::WriteStr(schema_[i].default_field_val.val.str_val, fp);
      if (true!=ret) return -11;
    } else if (type >= RealFieldType::kSet8 && type <= RealFieldType::kSet64) {
      ret = IOHelper::WriteStr(schema_[i].default_field_val.val.set_val, fp);
      if (true!=ret) return -12;
    } else {
      MEGA_BUG(true)
    }
  }
  return 0;
}

int TableSchema::Deserialize(FILE* fp) {
  Clear();

  std::string tmp_str;
  int64_t tmp_int;

  bool ret = IOHelper::ReadStr(fp, tmp_str);
  if (true!=ret) return -1;
  syntax_=tmp_str;

  ret = IOHelper::ReadInt(fp, tmp_int);
  if (true!=ret || tmp_int<0) return -2;

  size_t size_schemas = tmp_int;
  for (size_t i=0; i<size_schemas; ++i) {
    ret = IOHelper::ReadStr(fp, tmp_str);
    if (true!=ret) return -3;

    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -4;

    ret = (name_to_index_.insert(std::pair<std::string, size_t>(tmp_str, tmp_int))).second;
    if (true!=ret) return -5;
  }

  Property property;
  for (size_t i=0; i<size_schemas; ++i) {
    ret = IOHelper::ReadStr(fp, tmp_str);
    if (true!=ret) return -6;
    property.name = tmp_str;

    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -7;

    ret = property.type.Parse(RealFieldType::Type(tmp_int));
    if (true!=ret) return -8;

    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -9;
    property.offset = tmp_int;

    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -10;
    property.version = tmp_int;

    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -11;
    property.default_field_val.has_val = tmp_int;

    RealFieldType::Type type = property.type.GetType();
    if (type >= RealFieldType::kBool && type <= RealFieldType::kInt64) {
      ret = IOHelper::ReadInt(fp, property.default_field_val.val.int_val);
      if (true!=ret) return -12;
    } else if (RealFieldType::kStr == type) {
      ret = IOHelper::ReadStr(fp, property.default_field_val.val.str_val);
      if (true!=ret) return -13;
    } else if (type >= RealFieldType::kSet8 && type <= RealFieldType::kSet64) {
      ret = IOHelper::ReadStr(fp, property.default_field_val.val.set_val);
      if (true!=ret) return -14;
    } else {
      MEGA_BUG(true)
    }
    schema_.push_back(property);
  }
  return 0;
}

TableSchema& TableSchema::operator=(const Self& other) {
  if (this == &other) return *this;

  name_to_index_ = other.name_to_index_;
  schema_ = other.schema_;
  return *this;
}

}}
