#include "../record.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

Record::Record() : 
  table_(NULL),
  fields_(NULL) {}

Record::Record(const Table& table) :
  table_(&table),
  fields_(NULL) {
  version_schema_ = table_->GetCurrentVersion();
  Init_();
}

Record::Record(const Self& other) :
  table_(NULL),
  fields_(NULL) {
  operator=(other);
}

bool Record::Parse(const WeakType& syntax) {
  MEGA_FAIL_HANDLE_WARN(true != syntax.IsList() 
      || syntax.GetList().size() != GetTableSchema_().Size(),
      "fail_parse_record[" << syntax.DumpJson() << "]")

  for (size_t i=0; i < GetTableSchema_().Size(); ++i) {
    RealFieldType::Type type = GetTableSchema_().GetType(i);
    bool ret;
    if (RealFieldType::kBool <= type && RealFieldType::kInt64 >= type) {
      MEGA_FAIL_HANDLE_WARN(true != syntax[i].IsInt(),
        "invalid_rec_item[" << syntax.DumpJson() << "] col[" << i << "]")

      ret = SetInt(i, syntax[i].GetInt());
      MEGA_FAIL_HANDLE(true!=ret)
    } else if (RealFieldType::kStr == type) {
      MEGA_FAIL_HANDLE_WARN(true != syntax[i].IsString(),
        "invalid_rec_item[" << syntax.DumpJson() << "] col[" << i << "]")

      ret = SetStr(i, syntax[i].GetString());
      MEGA_FAIL_HANDLE(true!=ret)
    } else if (RealFieldType::kSet8 <= type && RealFieldType::kSet64 >= type){
      MEGA_FAIL_HANDLE_WARN(true != syntax[i].IsString(),
        "invalid_rec_item[" << syntax.DumpJson() << "] col[" << i << "]")

      ret = InsertIntoIntSet(i, syntax[i].GetString());
      MEGA_FAIL_HANDLE(true!=ret)
    } else {
      MEGA_BUG(true)
    }
  }
  return true;
  
  ERROR_HANDLE:
  WARN("fail_set_record[" << syntax.DumpJson() << "]");
  return false;
}

Record& Record::operator=(const Self& other) {
  if (unlikely(this == &other || NULL == other.table_)) {
    return *this;
  }

  version_schema_ = other.version_schema_;
  if (unlikely(NULL==table_)) {
    table_ = other.table_;
    Init_();
  }

  if (unlikely(table_->GetTableNo() != other.table_->GetTableNo())) {
    Clear_();
    table_ = other.table_;
    Init_();
  }

  if (likely(NULL != other.fields_)) {
    GetTableSchema_().Copy(other.fields_, fields_);
  }
  return *this;
}

Record::~Record() {
  Clear_();
}

void Record::Init_() {
  if (unlikely(NULL==fields_)) {
    size_t size_record = GetTableSchema_().SizeRecord();
    MEGA_MALLOC(fields_, void*, size_record)
    bzero(fields_, size_record);
  }
}

}}
