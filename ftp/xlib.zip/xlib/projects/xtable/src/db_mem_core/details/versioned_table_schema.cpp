#include "../versioned_table_schema.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

bool VersionedTableSchema::Init(const WeakType& syntax) {
  current_pos_schema_=0;

  TableSchema* schema;
  MEGA_NEW(schema, TableSchema)
  std::pair<Schemas::iterator, bool> result = 
    schemas_.insert(std::pair<size_t, TableSchema*>(0, schema));
  return result.second && result.first->second->Init(syntax);
}

bool VersionedTableSchema::ChangeSchema(const WeakType& syntax) {
  if ( 0== schemas_.size()
    || true != syntax.IsDict() 
    || true != syntax["subcmd"].IsString()
    || true != syntax["col"].IsString() ) {
    return false;
  }

  TableSchema* new_schema=NULL;
  MEGA_NEW(new_schema, TableSchema)

  *new_schema = GetCurrentSchema();

  size_t new_version = GetNextVersion_();
  FieldType field_type;
  bool ret;
  if (syntax["subcmd"].GetString() == "add_col") {
    MEGA_FAIL_HANDLE( true != syntax["type"].IsString() 
        || true != syntax["default"].IsString() )

    ret = new_schema->AddColumn(
        syntax["col"].GetString(),
        syntax["type"].GetString(), 
        &(syntax["default"].GetString()), 
        new_version);
    MEGA_FAIL_HANDLE(true!=ret)
  } else if (syntax["subcmd"].GetString() == "remove_col") {
    ret = new_schema->RemoveColumn(syntax["col"].GetString());
    MEGA_FAIL_HANDLE(true!=ret)
  } else if (syntax["subcmd"].GetString() == "change_type") {
    MEGA_FAIL_HANDLE( true != syntax["type"].IsString() )

    ret = new_schema->ChangeType(
        syntax["col"].GetString(), 
        syntax["type"].GetString());
    MEGA_FAIL_HANDLE(true!=ret)
  } else {
    MEGA_FAIL_HANDLE(true)
  }

  ret = (schemas_.insert(std::pair<size_t, TableSchema*>(new_version, new_schema))).second;
  MEGA_FAIL_HANDLE(true!=ret)

  ++current_pos_schema_;
  return true;

  ERROR_HANDLE:
  MEGA_DELETE(new_schema)
  WARN("invalid_change_schema_syntax[" << syntax.DumpJson() << "]");
  return false;
}

int VersionedTableSchema::Serialize(FILE* fp) const {
  int ret = IOHelper::WriteInt(schemas_.size(), fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteInt(current_pos_schema_, fp);
  if (true!=ret) return -2;

  Schemas::const_iterator iter;
  for (iter = schemas_.begin(); iter != schemas_.end(); ++iter) {
    ret = IOHelper::WriteInt(iter->first, fp);
    if (true!=ret) return -3;

    ret = iter->second->Serialize(fp);
    if (0!=ret) {
      FATAL("fail_serialize_schema ret[" << ret << "]");
      return -4;
    }
  }
  return 0;
}

int VersionedTableSchema::Deserialize(FILE* fp) {
  Clear();

  std::string tmp_str;
  int64_t tmp_int;

  int64_t size_schemas;
  int ret = IOHelper::ReadInt(fp, size_schemas);
  if (true!=ret || size_schemas<0) return -1;

  ret = IOHelper::ReadInt(fp, tmp_int);
  if (true!=ret || tmp_int<0) return -2;
  current_pos_schema_=tmp_int;

  for (int64_t i=0; i<size_schemas; ++i) {
    ret = IOHelper::ReadInt(fp, tmp_int);
    if (true!=ret || tmp_int<0) return -3;

    TableSchema* table_schema;
    MEGA_NEW(table_schema, TableSchema)
    ret = table_schema->Deserialize(fp);
    if (0!=ret) {
      FATAL("fail_deserialize_schema ret[" << ret << "]");
      return -4;
    }

    ret = (schemas_.insert(std::pair<size_t, TableSchema*>(tmp_int, table_schema))).second;
    if (true!=ret) return -5;
  }
  return 0;
}

VersionedTableSchema& VersionedTableSchema::operator=(const Self& other) {
  if (this == &other) return *this;

  Clear();

  Schemas::const_iterator iter;
  for (iter = other.schemas_.begin(); iter != other.schemas_.end(); ++iter) {
    TableSchema* new_table_schema;
    MEGA_NEW(new_table_schema, TableSchema) 
    *new_table_schema = *(iter->second);
    schemas_.insert(std::pair<size_t, TableSchema*>(iter->first, new_table_schema));
  }
  current_pos_schema_ = other.current_pos_schema_;
  return *this;
}

void VersionedTableSchema::Clear() {
  current_pos_schema_=0;

  Schemas::iterator iter;
  for (iter = schemas_.begin(); iter != schemas_.end(); ++iter) {
    MEGA_DELETE(iter->second)
  }
  schemas_.clear();
}

VersionedTableSchema::~VersionedTableSchema() {
  Clear();
}

}}
