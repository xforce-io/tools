#include "../tables_mgr.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

TablesMgr::TablesMgr() : 
  current_table_no_(1),
  search_tree_(NodeParser_, this, false) {}

int TablesMgr::CreateTable(const WeakType& syntax) {
  tables_.resize(current_table_no_+1);

  int ret = tables_[current_table_no_].CreateTable(
      syntax, current_table_no_);
  if (ErrorNo::kSucc != ret) {
    WARN("fail_create_table syntax[" << syntax << "]");
    return ret;
  }

  ret = (tables_no_.insert(
      std::pair<std::string, size_t>(
          tables_[current_table_no_].GetName(), 
          current_table_no_))).second;
  if (true!=ret) {
    FATAL("fail_insert_table syntax[" << syntax << "]");
    return ErrorNo::kOther;
  }
  ++current_table_no_;
  return ErrorNo::kSucc;
}

bool TablesMgr::SearchRecords(const WeakType& syntax,
    SortedArrayInt64Set*& result) {
  size_t ret = search_tree_.Parse(syntax);
  if (unlikely(true!=ret)) return false;

  search_tree_.Resolve();
  result = search_tree_.GetRoot() ? 
      SCAST<SortedArrayInt64Set*>(search_tree_.GetRoot()->GetSet()) : 
      NULL;
  return true;
}

void TablesMgr::Clear() {
  tables_no_.clear();
  tables_.clear();
  current_table_no_=1;
}

int TablesMgr::Serialize(FILE* fp) {
  int ret = IOHelper::WriteInt(tables_no_.size(), fp);
  if (true!=ret) return -1;

  TablesNo::const_iterator iter;
  for (iter = tables_no_.begin(); 
      iter !=tables_no_.end(); 
      ++iter) {
    ret = IOHelper::WriteStr(iter->first, fp);
    if (true!=ret) return -2;

    ret = IOHelper::WriteInt(iter->second, fp);
    if (true!=ret) return -3;

    ret = tables_[iter->second].Serialize(fp);
    if (0!=ret) {
      FATAL("fail_serialize_table[" << iter->second 
          << "] ret[" << ret << "]");
      return -4;
    }
  }
  ret = IOHelper::WriteInt(current_table_no_, fp);
  if (true!=ret) return -5;
  return 0;
}

int TablesMgr::Deserialize(FILE* fp) {
  Clear();

  int64_t size_tables_no;
  int ret = IOHelper::ReadInt(fp, size_tables_no);
  if (true!=ret || size_tables_no<0) return -1;

  tables_.resize(size_tables_no+1);
  for (int64_t i=0; i<size_tables_no; ++i) {
    std::string table_name;
    ret = IOHelper::ReadStr(fp, table_name);
    if (true!=ret) return -2;

    int64_t table_no;
    ret = IOHelper::ReadInt(fp, table_no);
    if (true!=ret || table_no<0) return -3;

    ret = (tables_no_.insert(std::pair<std::string, size_t>(
        table_name, table_no))).second;
    if (true!=ret) return -4;

    tables_.resize(table_no+1);
    ret = tables_[table_no].Deserialize(fp);
    if (0!=ret) {
      FATAL("fail_deserialize_table[" << table_name 
          << "] ret[" << ret << "]");
      return -5;
    }
  }

  int64_t tmp_int;
  ret = IOHelper::ReadInt(fp, tmp_int);
  if (true!=ret) return -6;
  current_table_no_=tmp_int;
  return 0;
}

void TablesMgr::CopyForRead(const Self& other) {
  tables_no_ = other.tables_no_;
  tables_ = other.tables_;
  current_table_no_ = other.current_table_no_;
}

bool TablesMgr::NodeParse_(const WeakType& node_wt, 
      SettreeNode<SetOpInterface>& node) {
  if (unlikely(true != node_wt.IsDict() 
      || true != node_wt["table"].IsString())) {
    return false;
  }

  const std::string& table_name = node_wt["table"].GetString();
  size_t table_no = GetTableNo(table_name);
  if (unlikely(0==table_no)) return false;

  SortedArrayInt64Set* result;
  bool ret = GetTable(table_no).SearchRecords(node_wt, result);
  if (unlikely(true!=ret)) return false;

 node.SetSharedSet(result); 
 return true;
}

}}
