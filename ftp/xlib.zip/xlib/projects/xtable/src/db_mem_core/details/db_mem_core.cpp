#include "../db_mem_core.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

PoolReadRecs::PoolReadRecs() : table_(NULL) {}

DBMemCoreTPD::DBMemCoreTPD() :
  pool_read_recs_(kNumPoolReadRecs) {}

PoolReadRecs* DBMemCoreTPD::GetPoolReadRec(size_t table_no) {
  std::pair<size_t*, PoolReadRecs**> pool_read_recs = pool_read_recs_.Get(table_no);
  if (unlikely(NULL == pool_read_recs.first)) {
    PoolReadRecs* new_pool_read_recs;
    MEGA_NEW(new_pool_read_recs, PoolReadRecs)

    int ret = (pool_read_recs_.Insert(table_no, new_pool_read_recs)).first;
    if (0!=ret) {
      delete new_pool_read_recs;
      return NULL;
    }
    return new_pool_read_recs;
  }
  return *(pool_read_recs.second);
}

DBMemCore::DBMemCore() :
  lru_(NULL),
  buf_(NULL),
  logic_time_(0),
  read_version_consumed_(true),
  version_for_read_(NULL),
  current_device_pos_(0, 0) {}

bool DBMemCore::Init(const std::string& name, void* init_params) {
  Super::Init_(name);

  db_device_ = RCAST<InitParams*>(init_params)->db_device;

  MEGA_NEW(lru_, LRUQueue(
      RCAST<InitParams*>(init_params)->size_lru_queue))

  size_buf_ = Limits::kMaxSizeRecord;

  MEGA_NEW(buf_, char [size_buf_])
  MEGA_NEW(version_for_read_, Self)
  MEGA_NEW(version_for_read_->lru_, LRUQueue(
      RCAST<InitParams*>(init_params)->size_lru_queue))
  return true;
}

int DBMemCore::CreateTable(const std::string& syntax, LogicTime logic_time) {
  if (unlikely(logic_time<=logic_time_)) return ErrorNo::kSucc;
  if (unlikely(syntax.size() + 1 > Limits::kMaxSizeSyntax)) {
    return ErrorNo::kExceedLimit;
  }

  int ret = CreateTable_(syntax);
  if (unlikely(ErrorNo::kSucc != ret)) return ret;

  FlushMsg flush_msg;
  flush_msg.cmd = Cmd::kCreateTable;
  flush_msg.msg.Reset(syntax.c_str(), syntax.length()+1);

  ret = db_device_->ProcessFlushMsg(flush_msg);
  if (ErrorNo::kSucc != ret) return ret;

  logic_time_=logic_time;
  PublishReadOnlyVersion_();
  return ErrorNo::kSucc;
}

int DBMemCore::AddRecord(
    const std::string& table_name,
    const WeakType& syntax,
    LogicTime logic_time) {
  if (logic_time<=logic_time_) return ErrorNo::kSucc;

  int ret=0;
  Record* record=NULL;
  FlushMsg flush_msg;
  Key key;

  ret = tables_mgr_.ParseRecord(table_name, syntax, record);
  MEGA_FAIL_HANDLE(ErrorNo::kSucc != ret)

  ret = AddRecord_(*record);
  MEGA_FAIL_HANDLE(ErrorNo::kSucc != ret)

  ret = record->Serialize(buf_, size_buf_);
  MEGA_FAIL_HANDLE(ret<=0 && (ret = ErrorNo::kExceedLimit))

  flush_msg.cmd = Cmd::kAddRecord;
  flush_msg.cmd_extra.add_rec.key = record->GetKey();
  flush_msg.msg.Reset(buf_, ret);

  ret = db_device_->ProcessFlushMsg(flush_msg);
  MEGA_FAIL_HANDLE(0!=ret)

  logic_time_=logic_time;
  PublishReadOnlyVersion_();
  return ErrorNo::kSucc;

  ERROR_HANDLE:
  if (NULL!=record) lru_->Erase(key);
  return ret;
}

int DBMemCore::RemoveRecord(
    const std::string& table_name,
    const WeakType& keys_to_remove,
    LogicTime logic_time) {
  if (logic_time<=logic_time_) return ErrorNo::kSucc;

  size_t table_no = tables_mgr_.GetTableNo(table_name);
  if (unlikely(0==table_no)) return ErrorNo::kNoSuchTable;

  if (unlikely(true != keys_to_remove.IsList())) {
    return ErrorNo::kInvalidSyntax;
  }

  ListType list = keys_to_remove.GetList();
  if (unlikely(list.size() > Limits::kMaxNumRemovedKeys)) {
    return ErrorNo::kExceedLimit;
  }

  if (unlikely(0 == list.size())) return ErrorNo::kSucc;

  Key keys[Limits::kMaxNumRemovedKeys];
  for (size_t i=0; i < list.size(); ++i) {
    if (unlikely(true != list[i].IsInt())) {
      return ErrorNo::kInvalidSyntax;
    }
    keys[i] = UnionKey::Encode(table_no, list[i].GetInt());
  }

  RemoveRecord_(keys, list.size());

  FlushMsg flush_msg;
  flush_msg.cmd = Cmd::kRemoveRecord;
  flush_msg.msg.Reset(RCAST<char*>(keys), 
      sizeof(Key) * list.size());

  int ret = db_device_->ProcessFlushMsg(flush_msg);
  if (ErrorNo::kSucc != ret) return ret;

  logic_time_=logic_time;
  PublishReadOnlyVersion_();
  return ErrorNo::kSucc;
}

int DBMemCore::GetRecord(
    const std::string& table_name,
    const WeakType& records,
    ResultsGetRecord*& results) {
  size_t table_no = tables_mgr_.GetTableNo(table_name);

  if (unlikely(true != records.IsList())) {
    return ErrorNo::kInvalidSyntax;
  }

  results = &(GetResultsGetRecs_());
  if (unlikely(NULL==results)) return ErrorNo::kOther;

  PoolReadRecs* pool_read_recs=NULL;
  for (size_t i=0; i < records.GetList().size(); ++i) {
    if (unlikely(true != records.GetList()[i].IsInt())) {
      return ErrorNo::kInvalidSyntax;
    }

    Key key = UnionKey::Encode(table_no, records.GetList()[i].GetInt());
    std::pair<const Key*, const Record*> result = lru_->Get(key);
    if (NULL != result.first) {
      results->states[i] = ErrorNo::kSucc;
      results->records[i] = result.second;
    } else {
      if (unlikely(NULL==pool_read_recs)) {
        pool_read_recs = GetPoolReadRec_(table_no);
        if (NULL==pool_read_recs) return ErrorNo::kOther;

        pool_read_recs->Reset(&(tables_mgr_.GetTable(table_no)));
      }

      Record& record = pool_read_recs->GetRecord();
      int ret = GetRecordFromDevice_(key, record);
      if (ErrorNo::kSucc == ret) {
        results->states[i] = ErrorNo::kSucc;
        results->records[i] = &record;
      } else {
        results->states[i] = ret;
        results->records[i] = NULL;
      }
    }
  }
  results->size_records = records.GetList().size();
  return ErrorNo::kSucc;
}

bool DBMemCore::ReplayDeviceLog(const DeviceLog& device_log) {
  int ret;
  switch (device_log.GetCmd()) {
    case Cmd::kCreateTable : {
      ret = CreateTable_(device_log.GetContent());
      if (ErrorNo::kSucc != ret) {
        FATAL("fail_replay_log create_table logic_time[" 
            << device_log.GetLogicTime() << "]");
        return false;
      }
      break;
    }
    case Cmd::kDropTable : {
      MEGA_BUG_FATAL(true, "drop_table_command_not_implemented");
      break;
    }
    case Cmd::kAddRecord : {
      size_t table_no;
      int64_t table_key;
      UnionKey::Decode(device_log.GetKey(), table_no, table_key);
      Record* record = tables_mgr_.GetTmpRecord(table_no);
      if (NULL==record) return false;

      ret = record->Deserialize(device_log.GetContent(), device_log.GetContentLen());
      if (ret<0) return false;

      ret = AddRecord_(*record);
      if (ErrorNo::kSucc != ret) return false;
      break;
    }
    case Cmd::kRemoveRecord : {
      RemoveRecord_(RCAST<const Key*>(device_log.GetContent()), 
          device_log.GetContentLen() / sizeof(Key));
      break;
    }
    default :
      MEGA_BUG(true);
      break;
  }
  return true;
}

int DBMemCore::Serialize(FILE* fp) {
  int ret = IOHelper::WriteInt(current_device_pos_.index, fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteInt(current_device_pos_.offset, fp);
  if (true!=ret) return -2;

  ret = tables_mgr_.Serialize(fp);
  if (0!=ret) {
    FATAL("fail_serialize_tables_mgr ret[" << ret << "]");
    return -3;
  }

  ret = IOHelper::WriteInt(lru_->Size(), fp);
  if (true!=ret) return -4;

  LRUQueue::Iterator iter;
  for (iter = lru_->Begin(); iter != lru_->End(); ++iter) {
    ret = IOHelper::WriteInt(*((*iter).first), fp);
    if (true!=ret) return -5;

    ret = IOHelper::WriteInt((*iter).second->GetTable().GetTableNo(), fp);
    if (true!=ret) return -6;

    ret = (*iter).second->Serialize(fp);
    if (0!=ret) {
      FATAL("fail_serialize_record ret[" << ret << "]");
      return -7;
    }
  }
  return 0;
}

int DBMemCore::Deserialize(FILE* fp) {
  int64_t tmp;
  int ret = IOHelper::ReadInt(fp, tmp);
  if (true!=ret) return -1;
  current_device_pos_.index = tmp;

  ret = IOHelper::ReadInt(fp, tmp);
  if (true!=ret) return -2;
  current_device_pos_.offset = tmp;

  ret = tables_mgr_.Deserialize(fp);
  if (0!=ret) {
    FATAL("fail_deserialize_tables_mgr ret[" << ret << "]");
    return -3;
  }

  int64_t size_lru;
  ret = IOHelper::ReadInt(fp, size_lru);
  if (true!=ret) return -4;

  for (int64_t i=0; i<size_lru; ++i) {
    int64_t tmp;
    ret = IOHelper::ReadInt(fp, tmp);
    if (true!=ret) return -5;
    Key key=tmp;

    ret = IOHelper::ReadInt(fp, tmp);
    if (true!=ret || tmp<0) return -6;

    Record record(tables_mgr_.GetTable(tmp));
    ret = record.Deserialize(fp);
    if (0!=ret) {
      FATAL("fail_deserialize_record ret[" << ret << "]");
      return -7;
    }

    ret = (lru_->Insert(key, record)).first;
    if (0!=ret) return -8;
  }
  return 0;
}

DBMemCore::~DBMemCore() {
  MEGA_DELETE_ARRAY(buf_)
  MEGA_DELETE(lru_)
  MEGA_DELETE(version_for_read_);
}

int DBMemCore::Dumper_(void* self_arg, FILE* fp) {
  Self& self = *(RCAST<Self*>(self_arg));
  if (false == self.read_version_consumed_) {
    int ret = self.version_for_read_->Serialize(fp);
    self.read_version_consumed_ = true;
    return ret;
  } else {
    return 1;
  }
}

int DBMemCore::CreateTable_(const std::string& syntax) {
  WeakType syntax_wt;
  bool ret = syntax_wt.JsonDecode(syntax.c_str(), syntax.size(), NULL);
  if (true!=ret) return ErrorNo::kInvalidSyntax;

  return tables_mgr_.CreateTable(syntax_wt);
}

int DBMemCore::AddRecord_(const Record& record) {
  int ret = tables_mgr_.AddRecord(record);
  if (ErrorNo::kSucc != ret) return ret;

  Key key = UnionKey(
      record.GetTable().GetTableNo(), 
      record.GetKey()).Encode();

  ret = (lru_->Insert(key, record)).first;
  return 0==ret ? ErrorNo::kSucc : ErrorNo::kDupKey;
}

void DBMemCore::RemoveRecord_(const Key* keys, size_t num_keys) {
  int ret;
  Record* record=NULL;
  size_t table_no;
  int64_t table_key;
  UnionKey::Decode(keys[0], table_no, table_key);
  for (size_t i=0; i<num_keys; ++i) {
    Key key = keys[i];
    if (0 != tables_mgr_.GetNumIndexs(table_no)) {
      std::pair<Key*, Record*> result = lru_->Get(key);
      if (NULL == result.second) {
        DeviceLog* device_log;
        ret = db_device_->GetRecord(key, device_log);
        MEGA_FAIL_HANDLE_CONTINUE(ErrorNo::kSucc != ret)

        record = tables_mgr_.GetTmpRecord(table_no);
        MEGA_FAIL_HANDLE_FATAL_CONTINUE(NULL==record,
            "fail_get_tmp_record") 

        ret = record->Deserialize(device_log->GetContent(), device_log->GetContentLen());
        MEGA_FAIL_HANDLE_FATAL_CONTINUE(0!=ret, 
            "fail_deserialize_record key[" << key << "]")
      } else {
        record = result.second;
      }

      ret = tables_mgr_.RemoveRecord(*record);
      MEGA_FAIL_HANDLE_CONTINUE(0!=ret)
    }
    lru_->Erase(key);
  }
}

bool DBMemCore::Load_(const DataBase& prev_db) {
  const Self& other = RCAST<const DBMemCore&>(prev_db);
  db_device_ = other.db_device_;
  tables_mgr_ = other.tables_mgr_;
  *lru_ = *(other.lru_);
  return true;
}

void DBMemCore::CopyForRead_(const Self& other) {
  version_for_read_->tables_mgr_.CopyForRead(other.tables_mgr_);
  bool ret = version_for_read_->lru_->Copy(*(other.lru_));
  if (true!=ret) FATAL("fail_copy_lru_for_read");
}

}}

