#pragma once

#include "record.h"
#include "../public/cow_lru_queue/cow_lru_queue_hashmap.hpp"

namespace zmt { namespace material_center {

template <typename HashF, typename EqualKeyF, typename AtExitF> 
class CowLRUQueueHashmap<Key, Record, HashF, EqualKeyF, AtExitF> : 
  public BaseCLQHashmap<BaseCLQHashmapParams<
      Key,
      Record, 
      HashF, 
      EqualKeyF,
      AtExitF> > {

 public:
  typedef BaseCLQHashmap<BaseCLQHashmapParams<
      Key, 
      Record, 
      HashF, 
      EqualKeyF,
      AtExitF> > Super;

  typedef typename Super::MapAtExitF MapAtExitF;
 
 public:
  static const size_t kDefaultSizeBuckets=1000;
  static const size_t kDefaultToResize=false;

 public:
  explicit CowLRUQueueHashmap(
      size_t hint_size_buckets=kDefaultSizeBuckets,
      bool to_resize=kDefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const MapAtExitF& at_exit=MapAtExitF()) :
    Super(hint_size_buckets, to_resize, hasher, equal_key, at_exit) {}

  virtual ~CowLRUQueueHashmap() { Super::Clear(); }

 private:
  inline Record* AllocVal_(Record* record);
  inline void FreeVal_(Record* record);
};

template <typename HashF, typename EqualKeyF, typename AtExitF> 
Record* CowLRUQueueHashmap<Key, Record, HashF, EqualKeyF, AtExitF>::AllocVal_(Record* record) { 
  return new (std::nothrow) Record(record->GetTable());
}

template <typename HashF, typename EqualKeyF, typename AtExitF> 
void CowLRUQueueHashmap<Key, Record, HashF, EqualKeyF, AtExitF>::FreeVal_(Record* record) { 
  delete record;
}

}}
