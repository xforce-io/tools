#include "../table_index.h"

namespace zmt { namespace material_center {

TableIndex::TableIndex() :
  init_(false) {}

bool TableIndex::Init(const Table& table, const WeakType& /*conf*/) { 
  table_ = &table;
  return true; 
}

}}
