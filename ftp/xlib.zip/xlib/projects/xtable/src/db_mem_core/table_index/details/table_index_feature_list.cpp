#include "../table_index_feature_list.h"
#include "../../../io_helper.h"

namespace zmt { namespace material_center {

TableIndexFeatureList::TableIndexFeatureList() : 
  Super(),
  category_simple_feature_list_(CategorySimpleFeatureList::kInvertedList),
  index_(kDefaultFanout) {}

bool TableIndexFeatureList::Init(const Table& table, const WeakType& syntax) {
  MEGA_FAIL_HANDLE_WARN(true != Super::Init(table, syntax), "fail_init_table_index") 

  MEGA_FAIL_HANDLE_WARN(true != syntax.IsDict()
        || true != syntax["category"].IsString(), 
      "no_category_in_table_index_syntax")

  MEGA_FAIL_HANDLE_WARN(true != syntax["name"].IsString(), 
      "no_name_in_table_index_syntax")
  name_ = syntax["name"].GetString();

  if ( "index" == syntax["category"].GetString() ) {
    category_simple_feature_list_ = CategorySimpleFeatureList::kInvertedList;
    MEGA_FAIL_HANDLE_WARN(true != syntax["column"].IsInt(),
        "no_inverted_list_column")

    col_ = syntax["column"].GetInt();
    MEGA_FAIL_HANDLE_WARN(col_ > Super::table_->GetCurrentSchema().Size(),
        "invalid_column_of_simple_feature_list col_["
          << col_ 
          << "] max["
          << Super::table_->GetCurrentSchema().Size()
          << "]")

    MEGA_FAIL_HANDLE_WARN(
        Super::table_->GetCurrentSchema().GetType(col_) == RealFieldType::kStr,
        "invalid_col_type_for_table_index_feature_list name[" 
        << Super::name_ 
        << "] col["
        << col_ 
        << "]")
  } else {
    MEGA_FAIL_HANDLE_WARN(true,
        "unknow_simple_feature_list_type[" 
        << syntax["category"].GetString() 
        << "]");
  }
  Super::init_ = true;
  return true;

  ERROR_HANDLE:
  return false;
}

int TableIndexFeatureList::Serialize(FILE* fp) const {
  bool ret = IOHelper::WriteInt(category_simple_feature_list_, fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteInt(col_, fp);
  if (true!=ret) return -2;

  ret = IOHelper::WriteStr(name_, fp);
  if (true!=ret) return -3;

  ret = IOHelper::WriteInt(index_.Size(), fp);
  if (true!=ret) return -4;

  for (Hashlist::Map::ConstIterator iter_map = index_.Begin(); 
      iter_map != index_.End();
      ++iter_map) {
    ret = IOHelper::WriteInt(iter_map.GetKey(), fp);
    if (true!=ret) return -5;

    ret = IOHelper::WriteInt(iter_map.GetVal().Size(), fp);
    if (true!=ret) return -6;

    for (Hashlist::List::ConstIterator iter_list = iter_map.GetVal().Begin();
        iter_list != iter_map.GetVal().End();
        ++iter_list) {
      ret = IOHelper::WriteInt(*iter_list, fp);
      if (true!=ret) return -7;
    }
  }
  return 0;
}

int TableIndexFeatureList::Deserialize(FILE* fp) {
  init_ = false;
  index_.Clear();

  bool ret = IOHelper::ReadInt(fp, 
      RCAST<int64_t&>(category_simple_feature_list_));
  if (true!=ret) return -1;

  ret = IOHelper::ReadInt(fp, RCAST<int64_t&>(col_));
  if (true!=ret) return -2;

  ret = IOHelper::ReadStr(fp, Super::name_);
  if (true!=ret) return -3;

  size_t num_index_items;
  ret = IOHelper::ReadInt(fp, RCAST<int64_t&>(num_index_items));
  if (true!=ret) return -4;

  for (size_t i=0; i<num_index_items; ++i) {
    int64_t feature;
    ret = IOHelper::ReadInt(fp, RCAST<int64_t&>(feature));
    if (true!=ret) return -5;

    size_t num_items;
    ret = IOHelper::ReadInt(fp, RCAST<int64_t&>(num_items));
    if (true!=ret) return -6;

    Hashlist::List list;
    for (size_t j=0; j<num_items; ++j) {
      Key key,
      ret = IOHelper::ReadInt(fp, key);
      if (true!=ret) return -7;

      std::pair<bool, Hashlist::List::Iterator> ret_set = index_.Insert(feature, key);
      if (true != ret_set.first) return -8;
    }
  }
  init_=true;
  return 0;
}

bool TableIndexFeatureList::Copy(const TableIndex& other) {
  const TableIndexFeatureList& table_index_feature_list = 
    SCAST<const TableIndexFeatureList&>(other);
  category_simple_feature_list_ = table_index_feature_list.category_simple_feature_list_;
  col_ = table_index_feature_list.col_;
  return index_.Copy(table_index_feature_list.index_);
}

}}
