#pragma once

#include "../../public/cow_hashlist/cow_hashlist.hpp"
#include "table_index.h"
#include "../record.h"

namespace zmt { namespace material_center {

class Table;

class TableIndexFeatureList : public TableIndex {
 public:
  typedef TableIndex Super;
  typedef CowHashlist<int64_t, Key> Hashlist;

 private:
  static const size_t kCategory=1;
  static const size_t kDefaultFanout=2048;

  struct CategorySimpleFeatureList {
    static const size_t kInvertedList=1;
  };

 public:
  TableIndexFeatureList();
  bool Init(const Table& table, const WeakType& syntax);
  size_t GetCategory() const { return kCategory; }
  inline bool AddRecord(const Record& record);
  inline bool RemoveRecord(const Record& record);

  int Serialize(FILE* fp) const;
  int Deserialize(FILE* fp);

  bool Copy(const TableIndex& table_index);

  virtual ~TableIndexFeatureList() {}
 
 private:
  inline bool AddRecordToInvertedList_(const Record& record);
  inline bool RemoveRecordFromInvertedList_(const Record& record);

  inline static int64_t FeatureHashlistperInvertedList_(
      const TableIndexFeatureList& table_index_feature_list, 
      const Record& record);

 private:
  size_t category_simple_feature_list_;
  size_t col_;

  /*
   * @brief: map from feature to Key
   */
  Hashlist index_;
};

bool TableIndexFeatureList::AddRecord(const Record& record) {
  if (category_simple_feature_list_ == CategorySimpleFeatureList::kInvertedList) {
    return AddRecordToInvertedList_(record);
  } else {
    FATAL("invalid_feature_list_category[" 
        << category_simple_feature_list_ 
        << "]");
    return false;
  }
}

bool TableIndexFeatureList::RemoveRecord(const Record& record) {
  if (category_simple_feature_list_== CategorySimpleFeatureList::kInvertedList) {
    return RemoveRecordFromInvertedList_(record);
  } else {
    FATAL("invalid_simple_feature_list_category[" 
        << category_simple_feature_list_ 
        << "]");
    return false;
  }
}

bool TableIndexFeatureList::AddRecordToInvertedList_(const Record& record) {
  Key key = record.GetKey();
  int64_t feature = FeatureHashlistperInvertedList_(
      static_cast<TableIndexFeatureList&>(*this),
      record);
  return index_.Insert(feature, key).first;
}

bool TableIndexFeatureList::RemoveRecordFromInvertedList_(
    const Record& record) {
  Key key = record.GetKey();
  int64_t feature = FeatureHashlistperInvertedList_(
      static_cast<TableIndexFeatureList&>(*this),
      record);
  return index_.Erase(feature, key);
}

int64_t TableIndexFeatureList::FeatureHashlistperInvertedList_(
    const TableIndexFeatureList& table_index_feature_list, 
    const Record& record) {
  return record.GetInt(table_index_feature_list.col_);
}

}}
