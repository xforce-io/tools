#pragma once

#include "../public.h"
#include "../merger/set/sets/sortedarray_set.hpp"

namespace zmt { namespace material_center {

class Record;
class Table;
class TableScheme;

class TableIndex {
 public:
  typedef int64_t (*FeatureMapper)(const Record& record, void* args);

 public:
  static const size_t kCategory=0;

 public:
  TableIndex();
  virtual bool Init(const Table& table, const WeakType& conf);
  virtual size_t GetCategory() const=0;
  const std::string& GetName() const { return name_; }
  virtual bool AddRecord(const Record& record)=0;
  virtual bool RemoveRecord(const Record& record)=0;

  inline virtual bool SearchRecords(const WeakType& node_wt,
      SortedArrayInt64Set*& result);

  virtual int Serialize(FILE* fp) const=0;
  virtual int Deserialize(FILE* fp)=0;

  virtual bool Copy(const TableIndex& table_index)=0;
  virtual ~TableIndex() {}

 protected:
  //const
  const Table* table_;
  std::string name_;
  ///

  bool init_;
};

bool TableIndex::SearchRecords(const WeakType& /*node_wt*/,
      SortedArrayInt64Set*& result) {
  result=NULL;
  return true;
}

}}
