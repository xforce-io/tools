#include "../set_pool.h"

namespace zmt { namespace material_center {

ThreadPrivacy ThreadPrivateSetPool::thread_private_sets_pool_;

}}
