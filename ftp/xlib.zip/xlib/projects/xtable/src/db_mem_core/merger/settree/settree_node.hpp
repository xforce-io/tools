#pragma once

#include <ostream>
#include "../public.h"
#include "set.h"
#include "set_pool.h"
#include "null_set.h"

namespace zmt { namespace material_center {

template <typename OpInterface>
class Settree;

template <typename OpInterface>
class SettreeNode {
 public:
  typedef SettreeNode<OpInterface> Self; 

 public:
  static const std::string kAnonymousNodeName; 
  static const size_t kNoThreadPrivateStep = 1;
  static const size_t kNoThreadPrivateSet = 2;

 public:
  size_t GetOp() const { return op_; }
  bool GetMountable() const { return is_mountable_; }
  inline Set** GetPrivateSet();
  inline void SetPrivateSet(Set* set);
  Set* GetSharedSet() const { return shared_set_; }
  void SetSharedSet(Set* set) { shared_set_=set; }
  inline Set* GetSet();
  inline size_t* GetStep();
  inline bool IsLeave() const { return 0 == children_.size(); }

  inline void AddChild(Self& child);

  /*
   * @return: which node cause set to be empty 
   */
  inline size_t ResolveAnd();
  inline size_t ResolveOr();
  inline size_t ResolvePriority();
  inline size_t ResolveNot();
  inline size_t ResolveNone() { return ResolveLeave_(); }

  inline void Reset() { children_.clear(); }

  virtual ~SettreeNode() {}
 
 private: 
  inline void SwapChildren_(size_t i, size_t j);
  inline size_t ResolveLeave_();

 private:
  std::string name_;
  size_t mark_;
  size_t op_;
  bool is_mountable_;
  bool is_extra_;    //whether this node is extra node
  SettreeNode* father_;
  Set* shared_set_;

  size_t idx_father_;
  std::vector<SettreeNode*> children_;

  ThreadPrivacy thread_privacy_;

  template <typename op_interface_t>
  friend std::ostream& operator<<(std::ostream& oss, SettreeNode<op_interface_t>&); 
  friend class Settree<OpInterface>;
};

template <typename OpInterface>
const std::string SettreeNode<OpInterface>::kAnonymousNodeName = "anonymous";

template <typename OpInterface>
size_t* SettreeNode<OpInterface>::GetStep() {
  return SCAST<size_t*>(thread_privacy_.Get<size_t>(kNoThreadPrivateStep));
}

template <typename OpInterface>
Set** SettreeNode<OpInterface>::GetPrivateSet() {
  return SCAST<Set**>(thread_privacy_.Get(kNoThreadPrivateSet));
}

template <typename OpInterface>
void SettreeNode<OpInterface>::SetPrivateSet(Set* set) { 
  Set** result = SCAST<Set**>(thread_privacy_.Get<Set*>(kNoThreadPrivateSet));
  if (likely(NULL!=result)) *result = set;
}

template <typename OpInterface>
Set* SettreeNode<OpInterface>::GetSet() { 
  if (unlikely(NULL!=shared_set_)) return shared_set_;

  Set** result = SCAST<Set**>(thread_privacy_.Get(kNoThreadPrivateSet));
  return NULL!=result ? *result : NULL; 
}

template <typename OpInterface>
void SettreeNode<OpInterface>::AddChild(Self& child) {
  child.idx_father_ = children_.size();
  children_.push_back(&child);
  child.father_ = this; 
}

template <typename OpInterface>
size_t SettreeNode<OpInterface>::ResolveAnd() {
  if (unlikely(0 == children_.size())) return ResolveLeave_();

  Set* tmp_set = children_[0]->GetSet();
  SetPrivateSet(tmp_set);
  if (NULL==tmp_set || NULL == tmp_set->GetResult() ) {
    return children_[0]->mark_;
  }

  for (size_t i=1; i < children_.size(); ++i) {
    Set* childs_set = children_[i]->GetSet();
    if ( NULL == childs_set
      || NULL == childs_set->GetResult() ) {
      return children_[i]->mark_;
    }

    (*OpInterface::GetSetOp(
        *(tmp_set->GetResult()), 
        *(childs_set->GetResult())))(
            IndexerOps::And, 
            *(tmp_set->GetResult()), 
            *(childs_set->GetResult()));

    if (NULL == tmp_set->GetResult()) return children_[i]->mark_;
  }
  return 0;
}

template <typename OpInterface>
size_t SettreeNode<OpInterface>::ResolveOr() {
  if (unlikely(0 == children_.size())) return ResolveLeave_();

  size_t i=0;
  Set* tmp_set;
  while (i < children_.size()) {
    tmp_set = children_[i]->GetSet();
    if ( NULL != tmp_set && NULL != tmp_set->GetResult() ) {
      SetPrivateSet(tmp_set);
      ++i;
      break;
    } else {
      ++i;
    }
  }

  for (; i < children_.size(); ++i) {
    Set* childs_set = children_[i]->GetSet();
    if ( NULL != childs_set && NULL != childs_set->GetResult() ) {
      (*OpInterface::GetSetOp(
          *(tmp_set->GetResult()), 
          *(childs_set->GetResult())))(
              IndexerOps::Or, 
              *(tmp_set->GetResult()), 
              *(childs_set->GetResult()));
    }
  }

  if ( NULL==tmp_set || NULL == tmp_set->GetResult() ) {
    return mark_;
  } else {
    return 0;
  }
}

template <typename OpInterface>
size_t SettreeNode<OpInterface>::ResolvePriority() {
  if (unlikely(0 == children_.size())) return ResolveLeave_();

  for (size_t i=0; i < children_.size(); ++i) {
    Set* childs_set = children_[i]->GetSet();
    if (NULL!=childs_set && NULL != childs_set->GetResult()) {
      SetPrivateSet(childs_set);
      return 0;
    }
  }
  return mark_;
}

template <typename OpInterface>
size_t SettreeNode<OpInterface>::ResolveNot() {
  if (unlikely(0 == children_.size())) return ResolveLeave_();

  Set* tmp_set;
  Set* childs_set = children_[0]->GetSet();
  if (NULL != childs_set) {
    tmp_set = childs_set;
  } else {
    tmp_set = ThreadPrivateSetPool::Get<NullSet>();
    if (NULL==tmp_set) return mark_;
  }
  tmp_set->SetNot(true);
  SetPrivateSet(tmp_set);
  return 0;
}

template <typename OpInterface>
void SettreeNode<OpInterface>::SwapChildren_(size_t i, size_t j) {
  SettreeNode* tmp = children_[i];
  children_[i] = children_[j];
  children_[j] = tmp;

  children_[i]->idx_father_ = i;
  children_[j]->idx_father_ = j;
}

template <typename OpInterface>
size_t SettreeNode<OpInterface>::ResolveLeave_() {
  Set* tmp_set = GetSet();
  if (unlikely(NULL==tmp_set)) return mark_;

  tmp_set->Resolve();
  return NULL == tmp_set->GetResult() ? mark_ : 0;
}

template <typename OpInterface>
std::ostream& operator<<(std::ostream& oss, SettreeNode<OpInterface>& node) {
  oss << "{ " 
      << "name:\"" << node.name_ << "\","
      << "mark:" << node.mark_ << ","
      << "op:" << node.op_ << ","
      << "is_mountable:" << node.is_mountable_ << ","
      << "is_extra:" << node.is_extra_ << ","
      << "father:" << node.father_ << ","
      << "set:" << node.GetSet() << ","
      << "index_fathers_children:" << node.idx_father_ << ","
      << "children_size:" << node.children_.size() << ","
      << "children:";

  oss << "[";
  for (size_t i=0; i < node.children_.size(); ++i) oss << *(node.children_[i]) << ",";
  oss << "] }";
  return oss;
}

}}
