#pragma once

#include <memory>
#include "public/common.h"
#include "public/thread_privacy/thread_privacy.h"
#include "public/pool_objs.hpp"
#include "set.h"

namespace zmt { namespace material_center {

class ThreadPrivateSetPool {
 public:
  template <typename SetType>
  inline static SetType* Get();

  inline static void Free(Set* set);

 private:
  static ThreadPrivacy thread_private_sets_pool_;
};

template <typename SetType>
SetType* ThreadPrivateSetPool::Get() {
  PoolObjs<Set>* pool;
  Set* set=NULL;

  pool = RCAST<PoolObjs<Set>*>(
      thread_private_sets_pool_.Get< PoolObjs<Set> >(SetType::kCategory));
  MEGA_FAIL_HANDLE(NULL==pool)

  set = pool->Get();
  MEGA_FAIL_HANDLE(NULL==set)

  if ( likely( NULL!=set && SetType::kCategory == set->GetCategory() ) ) {
    return RCAST<SetType*>(set);
  } 
  
  if ( SetType::kCategory != set->GetCategory() ) delete set;

  MEGA_NEW(set, SetType)
  return RCAST<SetType*>(set);

  ERROR_HANDLE:
  if (NULL!=set) pool->Free(set);
  FATAL("fail_get_set_from_thread_private_set_pool");
  return NULL;
}

void ThreadPrivateSetPool::Free(Set* set) {
  if ( unlikely(NULL==set) ) return;

  PoolObjs<Set>* pool = RCAST<PoolObjs<Set>*>(
      thread_private_sets_pool_.Get< PoolObjs<Set> >(set->GetCategory()));
  if ( unlikely(NULL==pool) ) {
    delete set;
    return;
  }

  set->Clear();
  pool->Free(set);
}

}}
