#include "../dynamic_set.h"

namespace zmt { namespace material_center {

void DynamicSet::Resolve() {
  if ( unlikely(0 == sortedarrayint64_sets_.size()) ) return;

  if (IndexerOps::Or == op_) {
    for (size_t i=1; i < sortedarrayint64_sets_.size(); ++i) {
      sortedarrayint64_sets_[0]->Or(*(sortedarrayint64_sets_[i]));
    }
  } else {
    for (size_t i=1; i < sortedarrayint64_sets_.size(); ++i) {
      sortedarrayint64_sets_[0]->And(*(sortedarrayint64_sets_[i]));
      if ( unlikely( 0 == sortedarrayint64_sets_[0]->Size() ) ) return;
    }
  }
}

DynamicSet::~DynamicSet() { 
  for (size_t i=0; i < sortedarrayint64_sets_.size(); ++i) {
    delete sortedarrayint64_sets_[i];
  }
}

}}
