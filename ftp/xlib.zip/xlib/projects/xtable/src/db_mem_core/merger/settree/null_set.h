#pragma once

#include "set.h"

namespace zmt { namespace material_center {

class NullSet : public Set {
 public:
  typedef Set Super;

 public:
  static const size_t kCategory = 1; 

 public: 
  inline explicit NullSet();

 public:
  uint8_t GetCategory() const { return kCategory; } 
  inline Set* GetResult() { return this; }
  void Clear() { Super::Clear(); }
};

NullSet::NullSet() {
  Set::is_not_ = true;
}

}}
