#pragma once

#include "../public.h"

namespace zmt { namespace material_center {

class Set {
 public:
  static const size_t kCategory = 0;
  
 public: 
  explicit Set() : is_not_(false) {}

  virtual uint8_t GetCategory() const { return kCategory; }
  virtual bool RecycledWhenReset() const { return true; }
  virtual void Resolve() {}

  /*
   * notice: when this Set is empty, must return NULL
   */
  virtual Set* GetResult() { return this; }
  virtual void Clear() { is_not_ = false; }
  virtual void SetNot(bool is_not) { is_not_=is_not; }
  virtual bool GetNot() { return is_not_; }
  virtual ~Set() {}

 protected: 
  bool is_not_;
};

}}
