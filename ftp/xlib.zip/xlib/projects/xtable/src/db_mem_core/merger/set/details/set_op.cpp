#include "../set_op.h"

#include "../set_no.h"

namespace zmt { namespace material_center {

bool SetOpInterface::init_=false;
SetOpInterface::SetOp SetOpInterface::set_ops_[UCHAR_MAX][UCHAR_MAX];

bool SetOpInterface::Init_() {
  for (size_t i=0; i<UCHAR_MAX; ++i) {
    for (size_t j=0; j<UCHAR_MAX; ++j) {
      set_ops_[i][j] = DefaultSetOp;
    }
  }

  set_ops_[SetNo::kNoSortedArrayInt64Set][SetNo::kNoSortedArrayInt64Set] = 
      SortedArrayInt64Op;

  for (size_t i=0; i<UCHAR_MAX; ++i) {
    set_ops_[i][SetNo::kNoNullSet] = SortedArrayInt64OpNull;
  }
  init_=true;
  return true;
}

}}
