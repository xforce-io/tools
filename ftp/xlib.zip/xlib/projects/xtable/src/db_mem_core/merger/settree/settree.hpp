#pragma once

#include <iostream>
#include "../../../public/pool_objs.hpp"
#include "settree_node.hpp"

namespace zmt { namespace material_center {

template <typename OpInterface>
class Settree {
 public:
  typedef Settree<OpInterface> Self;
  typedef SettreeNode<OpInterface> Node;

  typedef bool (*NodeParser)(
      void* arg, 
      const WeakType& node_wt, 
      SettreeNode<OpInterface>& node);

 public:
  explicit Settree(
      NodeParser node_parser=NULL, 
      void* arg=NULL,
      bool to_optimize=true);

  bool Parse(const WeakType& tree_conf_wt);
  bool AddDynamicNode(size_t mark, Set* set);
  size_t Resolve();

  /*
   * @brief : remove extra nodes
   */
  inline void Reset();

  inline Node* GetNode(size_t mark);
  inline Node* GetRoot() { return root_; }
  
  virtual ~Settree() { Clear_(NULL); }

 private:
  bool Parse_(const WeakType& tree_conf_wt);
  Node* ParseNode_(const WeakType& node, Node* father);

  /*
   * @brief : add node at father[index]
   * @notice: 
   *          mark==0 means this node should not be added to 
   *            marked_nodes_
   *          father==NULL means this node should be inserted at root
   *          index<0 means this node should be added to the end of 
   *            father->children_
   */
  Node* AddNode_(
      const std::string& name,
      size_t mark, 
      size_t op,
      bool is_mountable,
      Node* father, 
      int index=-1);

  void DelNode_(Node& node);
  bool Optimize_();

  /*
   * @brief : whether something planished in this call to Planish_
   * @return :
   *           >0 something planished
   *          ==0 nothing planished
   *           <0 error happened
   */
  int Planish_(Node& node);

  /*
   * @brief : whether something adjusted in this call to AdjustChildren_
   * @return :
   *           >0 something adjusted
   *          ==0 nothing adjusted
   *           <0 error happened
   */
  int AdjustChildren_(Node& node);

  int AdjustAndChild_(Node& node);
  int AdjustOrChild_(Node& node);
  int AdjustNotChild_(Node& node);
  int ExtractNotOp_(Node& node);

  void Clear_(Node* node);

 private:
  //const
  NodeParser node_parser_;
  void* arg_;
  bool to_optimize_;
  std::vector<Node*> marked_nodes_;
  ///

  std::vector<Node*> extra_nodes_;
  Node* root_;
  PoolObjs<Node> pool_nodes_;

  template <typename op_interface_t>
  friend std::ostream& operator<<(std::ostream& oss, const Settree<op_interface_t>&); 
};

template <typename OpInterface>
Settree<OpInterface>::Settree(
    NodeParser node_parser,
    void* arg,
    bool to_optimize) : 
  node_parser_(node_parser),
  arg_(arg),
  to_optimize_(to_optimize),
  root_(NULL) {}

template <typename OpInterface>
bool Settree<OpInterface>::Parse(const WeakType& tree_conf_wt) {
  return Parse_(tree_conf_wt);
}

template <typename OpInterface>
bool Settree<OpInterface>::AddDynamicNode(size_t mark, Set* set) {
  Node* node_to_insert;
  Node* new_node=NULL;

  node_to_insert = marked_nodes_[mark];
  MEGA_FAIL_HANDLE_WARN(NULL==node_to_insert, 
      "invalid_node_to_add_node|" << mark)
  
  MEGA_FAIL_HANDLE_WARN(true != node_to_insert->is_mountable_, 
      "invalid_node_to_add_node|" << mark)

  new_node = pool_nodes_.Get();
  MEGA_FAIL_HANDLE(NULL==new_node)

  new_node->name_ = Node::kAnonymousNodeName;
  new_node->mark_ = 0;
  new_node->op_ = IndexerOps::None;
  new_node->is_mountable_ = false;
  new_node->is_extra_ = false;
  new_node->father_ = node_to_insert;
  new_node->SetPrivateSet(set);
  new_node->Reset();

  node_to_insert->AddChild(*new_node);

  extra_nodes_.push_back(new_node);
  return true;

  ERROR_HANDLE:
  pool_nodes_.Free(new_node);
  return false;
}

template <typename OpInterface>
size_t Settree<OpInterface>::Resolve() {
  Node* current_node = root_;
  Node* last_node;
  size_t* step;
  if (unlikely(NULL==current_node)) return 0;

  size_t cause=0;
  while (true) {
    while (0 != current_node->children_.size()) {
      step = current_node->GetStep();
      if (unlikely(NULL==step)) return 0;
      
      *step = 0;
      current_node = current_node->children_[0];
    }

    while (true) {
      size_t ret;
      switch (current_node->op_) {
        case IndexerOps::And :
          ret = current_node->ResolveAnd();
          break;
        case IndexerOps::Or :
          ret = current_node->ResolveOr();
          break;
        case IndexerOps::Priority :
          ret = current_node->ResolvePriority();
          break;
        case IndexerOps::Not :
          ret = current_node->ResolveNot();
          break;  
        default :  
          //assert(IndexerOps::None == current_node->op_)
          ret = current_node->ResolveNone();
          break;
      }

      cause = (0==ret ? 0 : (0==cause ? ret : cause)); 

      last_node = current_node;
      current_node = current_node->father_;
      if (unlikely(NULL==current_node)) return cause;

      step = current_node->GetStep();
      if (unlikely(NULL==step)) return 0;

      if (*step != current_node->children_.size() - 1) {
        Set* last_set = last_node->GetSet();
        if ( ( IndexerOps::And == current_node->op_ 
            && ( NULL==last_set || NULL == last_set->GetResult() ) ) 
          || ( IndexerOps::Priority == current_node->op_
            && ( NULL!=last_set || NULL != last_set->GetResult() ) ) ) {
          continue;
        }

        ++(*step);
        current_node = current_node->children_[*step];
        break;
      }
    }
  }
}

template <typename OpInterface>
void Settree<OpInterface>::Reset() {
  for (size_t i=0; i < marked_nodes_.size(); ++i) {
    if ( likely(NULL == marked_nodes_[i]) ) continue; 

    if ( NULL == marked_nodes_[i]->GetSharedSet() ) {
      Set** tmp_set = marked_nodes_[i]->GetPrivateSet();
      if (NULL!=tmp_set && NULL!=*tmp_set) {
        if ( 0 == marked_nodes_[i]->children_.size() 
            || NullSet::kCategory == (*tmp_set)->GetCategory() ) {
          ThreadPrivateSetPool::Free(*tmp_set);
        }    
        *tmp_set=NULL;
      }
    } else {
      marked_nodes_[i]->GetSharedSet()->Clear();
    }
  }

  for (size_t i=0; i < extra_nodes_.size(); ++i) {
    DelNode_(*(extra_nodes_[i]));
  }
  extra_nodes_.clear();
}

template <typename OpInterface>
SettreeNode<OpInterface>* Settree<OpInterface>::GetNode(size_t mark) {
  if (unlikely(mark >= marked_nodes_.size())) return NULL;
  return marked_nodes_[mark];
}

template <typename OpInterface>
bool Settree<OpInterface>::Parse_(const WeakType& tree_conf_wt) {
  bool ret;
  Clear_(NULL);

  root_ = ParseNode_(tree_conf_wt, NULL);
  MEGA_FAIL_HANDLE(NULL==root_);

  ret = Optimize_();
  MEGA_FAIL_HANDLE(true!=ret);
  return true;

  ERROR_HANDLE:
  WARN("fail_parse_tree_from[" << tree_conf_wt.DumpJson() << "]");
  return false;
}

template <typename OpInterface>
SettreeNode<OpInterface>* Settree<OpInterface>::ParseNode_(
    const WeakType& node,
    Node* father) {
  bool ret;
  std::string tmp_name;
  int64_t tmp_mark;
  size_t tmp_op;
  int64_t tmp_mountable;
  Node* new_node = NULL;
  size_t num_children;

  WeakType tmp = node["name"];
  tmp_name = (true == tmp.IsString() ? 
      tmp.GetString() : 
      SettreeNode<OpInterface>::kAnonymousNodeName); 

  tmp = node["mark"];
  tmp_mark = (true == tmp.IsInt() ? tmp.GetInt() : -1);
  MEGA_FAIL_HANDLE_WARN(tmp_mark<=0, 
      "fail_parse_mark_from[" << node.DumpJson() << "]")

  tmp = node["op"];
  if ( true == tmp.IsString() ) {
    if (tmp.GetString() == "and") {
      tmp_op = IndexerOps::And;
    } else if (tmp.GetString() == "or") {
      tmp_op = IndexerOps::Or;
    } else if (tmp.GetString() == "not") {
      tmp_op = IndexerOps::Not;
    } else if (tmp.GetString() == "priority") {
      tmp_op = IndexerOps::Priority;
    } else if (tmp.GetString() == "none") {
      tmp_op = IndexerOps::None;
    } else {
      MEGA_FAIL_HANDLE_WARN(true, 
          "unknow_op_pattern_from[" << node.DumpJson() << "]");
    }
  } else {
    tmp_op = IndexerOps::None;
  }

  tmp = node["mountable"];
  tmp_mountable = (true == tmp.IsInt() ? tmp.GetInt() : 0);

  new_node = AddNode_(
      tmp_name,
      static_cast<size_t>(tmp_mark), 
      tmp_op,
      static_cast<bool>(tmp_mountable),
      father);
  MEGA_FAIL_HANDLE_WARN(NULL==new_node, "fail_add_node")

  if (NULL!=node_parser_) {
    ret = node_parser_(arg_, node, *new_node);
    MEGA_FAIL_HANDLE_WARN(true!=ret, 
        "fail_parse_node_info_from[" << node.DumpJson() << "]")
  }

  if (true == node["children"].IsList()) {
    num_children = node["children"].GetList().size();
    if (0!=num_children) {
      for (size_t i=0; i<num_children; ++i) {
        Node* child = ParseNode_(node["children"][i], new_node);
        MEGA_FAIL_HANDLE(NULL==child)
      }
    }
  }
  return new_node;

  ERROR_HANDLE:
  if (NULL!=new_node) Clear_(new_node);
  return NULL;
}

template <typename OpInterface>
SettreeNode<OpInterface>* Settree<OpInterface>::AddNode_(
    const std::string& name,
    size_t mark,
    size_t op,
    bool is_mountable,
    Node* father,
    int index) {
  Node* new_node = pool_nodes_.Get();
  if (NULL==new_node) return NULL;

  new_node->name_ = name;
  if (0==mark) mark = marked_nodes_.size();
  new_node->mark_ = mark;
  new_node->op_ = op;
  new_node->is_mountable_ = is_mountable;
  new_node->is_extra_ = false;
  new_node->father_ = father;
  new_node->shared_set_ = NULL;
  new_node->Reset();

  if (marked_nodes_.size() < mark+1) {
    if (mark+1 > marked_nodes_.size()) marked_nodes_.resize(mark+1);
    for (size_t i = marked_nodes_.size(); i<=mark; ++i) {
      marked_nodes_[i] = NULL;
    }
  } else if (NULL != marked_nodes_[mark]) {
    pool_nodes_.Free(new_node);
    WARN("mark_of_node[" << name << "] already_exist");
    return NULL;
  }
  marked_nodes_[mark] = new_node;

  if (NULL==father) {
    if (NULL!=root_) {
      new_node->children_.push_back(root_);
      root_->idx_father_ = 0;
    }
    root_ = new_node;
    return new_node;
  }

  if (index>=0) {
    //adjust children_
    new_node->children_.push_back(father->children_[index]);
    father->children_[index] = new_node;

    //adjust idx_father_
    new_node->idx_father_ = 
        new_node->children_[0]->idx_father_;
    new_node->children_[0]->idx_father_ = 0;

    //adjust father_
    new_node->father_ = father;
    new_node->children_[0]->father_ = new_node;
  } else {
    father->AddChild(*new_node);
  }
  return new_node;
}

template <typename OpInterface>
void Settree<OpInterface>::DelNode_(Node& node) {
  if (NULL != node.father_) {
    //assert(0 == node.children_.size() || 1 == node.children_.size())
    if (0 != node.children_.size()) {
      //adjust children_ 
      if (NULL != node.father_) {
        node.father_->children_[node.idx_father_] = node.children_[0];
      } else {
        root_ = node.children_[0];
      }

      //adjust idx_father_
      node.children_[0]->idx_father_ = node.idx_father_;
   
      //adjust father_
      node.children_[0]->father_ = node.father_;
    } else {
      node.father_->children_[node.idx_father_] = 
          node.father_->children_.back();
      node.father_->children_[node.idx_father_]->idx_father_ = 
          node.idx_father_;
      node.father_->children_.pop_back();
    }
  } else {
    root_ = NULL;
  }

  pool_nodes_.Free(&node);
}

template <typename OpInterface>
bool Settree<OpInterface>::Optimize_() {
  int ret;
  bool has_action;

  do {
    has_action = false;

    ret = Planish_(*root_);
    if (ret>0) {
      has_action = true;
    } else if (ret<0) {
      return false;
    }

    ret = AdjustChildren_(*root_);
    if (ret>0) {
      has_action = true;
    } else if (ret<0) {
      return false;
    }
  } while(true==has_action);
  return true;
}

template <typename OpInterface>
int Settree<OpInterface>::Planish_(Node& node) {
  int ret;
  bool planished=false;
  std::vector<Node*>& children = node.children_;
  for (size_t i=0; i<children.size(); ++i) {
    ret = Planish_(*(children[i]));
    if (ret>0) {
      planished=true;
    } else if (ret<0) {
      return -1;
    }
  }

  if (IndexerOps::And == node.op_ || IndexerOps::Or == node.op_) {
    size_t size_children = children.size();
    for (size_t i=0; i < size_children; ++i) {
      if (false == children[i]->is_mountable_ && children[i]->op_ == node.op_) {
        planished=true;
        for (size_t j=0; j < children[i]->children_.size(); ++j) {
          children[i]->children_[j]->idx_father_ = children.size();
          children[i]->children_[j]->father_ = &node;
          children.push_back(children[i]->children_[j]);
        }

        pool_nodes_.Free(children[i]);
        children[i] = children.back();
        children[i]->idx_father_ = i;
        children.pop_back();
      }
    }
  }
  return true!=planished ? 0 : 1;
}

template <typename OpInterface>
int Settree<OpInterface>::AdjustChildren_(Node& node) {
  if (true == node.is_mountable_) return 0;

  int ret;
  bool adjusted=false;

  for (size_t i=0; i<node.children_.size(); ++i) {
    ret = AdjustChildren_(*(node.children_[i]));
    if (ret>0) {
      adjusted=true;
    } else if (ret<0) {
      return -1;
    }
  }

  switch (node.op_) {
    case IndexerOps::And :
      ret = AdjustAndChild_(node);
      break;
    case IndexerOps::Or :  
      ret = AdjustOrChild_(node);
      break;
    case IndexerOps::Not :  
      ret = AdjustNotChild_(node);
      break;
    default :
      ret=0;
      break;
  }

  if (ret>0) {
    return 1;
  } else if (0==ret) {
    return true==adjusted ? 1 : 0;
  } else {
    return -1;
  }
}

template <typename OpInterface>
int Settree<OpInterface>::AdjustAndChild_(Node& node) {
  std::vector<Node*>& children = node.children_;
  if (0 == children.size()) return 0;

  bool adjusted = false;
  size_t i=1, j=children.size() - 1;
  while (true) {
    while (i < children.size() && IndexerOps::Not == children[i]->op_) ++i;
    while (j>0 && IndexerOps::Not != children[j]->op_) --j;
    if (i<j) {
      node.SwapChildren_(i, j);
      adjusted=true;
    }
    else break;
  }

  if (IndexerOps::Not == children[0]->op_ 
    && IndexerOps::Not != children[children.size() - 1]->op_) {
    node.SwapChildren_(0, children.size() - 1);
    adjusted=true;
  }

  if (IndexerOps::Not != children[0]->op_) {
    return true==adjusted ? 1 : 0;
  } else {
    return ExtractNotOp_(node);
  }
}

template <typename OpInterface>
int Settree<OpInterface>::AdjustOrChild_(Node& node) {
  int ret;
  bool has_not=false;
  std::vector<Node*>& children = node.children_;
  for (size_t i=0; i < children.size(); ++i) {
    if (IndexerOps::Not == children[i]->op_) {
      has_not=true;
      break;
    }
  }

  if (false==has_not) return 0;

  ret = ExtractNotOp_(node);
  if (ret<0) return -1;

  ret = AdjustAndChild_(*(node.children_[0]));
  return ret>=0 ? 1 : -1;
}

template <typename OpInterface>
int Settree<OpInterface>::AdjustNotChild_(Node& node) {
  if (0 == node.children_.size() || IndexerOps::Not != node.children_[0]->op_) return 0;

  if (NULL != node.father_) {
    //adjust children_
    node.father_->children_[node.idx_father_] = 
        node.children_[0]->children_[0];
 
    //adjust idx_father_    
    node.children_[0]->children_[0]->idx_father_ = 
        node.idx_father_;    
  } else {
    root_ = node.children_[0]->children_[0];
  }

  //adjust father_
  node.children_[0]->children_[0]->father_ = 
      node.father_;

  pool_nodes_.Free(&node);    
  pool_nodes_.Free(node.children_[0]);    
  return 1;
}

template <typename OpInterface>
int Settree<OpInterface>::ExtractNotOp_(Node& node) {
  Node* new_node = AddNode_(
      Node::kAnonymousNodeName,
      0,
      IndexerOps::Not,
      false,
      node.father_,
      node.idx_father_);
  if (NULL==new_node) return -1;

  node.op_ = (IndexerOps::And == node.op_ ? IndexerOps::Or : IndexerOps::And);
  node.father_ = new_node;
  for (size_t i=0; i < node.children_.size(); ++i) {
    if (IndexerOps::Not == node.children_[i]->op_) {
      DelNode_(*(node.children_[i]));
    } else {
      new_node = AddNode_(
          Node::kAnonymousNodeName,
          0,
          IndexerOps::Not,
          false,
          &node,
          i);
      if (NULL==new_node) return -1;
    }
  }
  return 1;
}

template <typename OpInterface>
void Settree<OpInterface>::Clear_(Node* node) {
  if (NULL==node) {
    for (size_t i=0; i < marked_nodes_.size(); ++i) {
      if ( NULL!=marked_nodes_[i]
          && 0 == marked_nodes_[i]->children_.size() 
          && NULL!=marked_nodes_[i]->shared_set_ ) {
        ThreadPrivateSetPool::Free(marked_nodes_[i]->shared_set_);
      }
    }

    if (NULL!=root_) Clear_(root_);
    marked_nodes_.clear();
    root_=NULL;
    return;
  }

  size_t size_children = node->children_.size();
  for (size_t i=0; i<size_children; ++i) Clear_(node->children_[i]);
  node->children_.clear();
  DelNode_(*node);
}

template <typename OpInterface>
std::ostream& operator<<(std::ostream& oss, const Settree<OpInterface>& settree) {
  if (NULL != settree.root_) {
    oss << *(settree.root_);
  } else {
    oss << "{}";
  }
  return oss;
}

}}
