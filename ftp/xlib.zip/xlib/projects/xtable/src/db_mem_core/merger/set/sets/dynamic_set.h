#pragma once

#include "public/public.h"
#include "public/settree/set.h"
#include "public/settree/set_pool.h"
#include "merger/set/set_no.h"
#include "merger/set/sets/sortedarray_set.hpp"

namespace zmt { namespace material_center {

class DynamicSet : public Set {
 public:
  typedef Set Super; 

 public:
  static const size_t kCategory = SetNo::kNoDynamicSet;
   
 public:
  explicit DynamicSet(size_t op=IndexerOps::Or) : op_(op) {}
  
 public:
  uint8_t GetCategory() const { return kCategory; } 
  void Resolve();
  inline Set* GetResult();
  inline void Clear();
  virtual ~DynamicSet();

 public:
  void SetOp(size_t op) { op_=op; }
  inline void AddSortedArrayInt64Set(SortedArrayInt64Set& sortedarrayint64_set); 

 private: 
  size_t op_;
  std::vector<SortedArrayInt64Set*> sortedarrayint64_sets_;
};

Set* DynamicSet::GetResult() {
  if ( unlikely(0 == sortedarrayint64_sets_.size() 
      || 0 == sortedarrayint64_sets_[0]->Size() ) ) return NULL;

  return static_cast<Set*>(sortedarrayint64_sets_[0]);
}

void DynamicSet::Clear() {
  Super::Clear();
  for (size_t i=0; i < sortedarrayint64_sets_.size(); ++i) {
    ThreadPrivateSetPool::Free(sortedarrayint64_sets_[i]);
  }
  sortedarrayint64_sets_.clear();
}

void DynamicSet::AddSortedArrayInt64Set(SortedArrayInt64Set& sortedarrayint64_set) {
  sortedarrayint64_sets_.push_back(&sortedarrayint64_set);
}

}}
