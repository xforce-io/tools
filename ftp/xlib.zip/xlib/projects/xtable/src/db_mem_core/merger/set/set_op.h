#pragma once

#include "../public.h"
#include "../settree/set.h"
#include "../set/sets/sortedarray_set.hpp"

namespace zmt { namespace material_center {

class SetOpInterface {
 public:
  typedef void (*SetOp)(IN size_t op, OUT Set&, IN Set&);

 public:
  inline static SetOp GetSetOp(const Set& left, Set& right);

 private:
  static bool Init_();

 private:
  static void DefaultSetOp(size_t /*op*/, Set&, Set&) {}
  inline static void SortedArrayInt64Op(size_t op, Set& left, Set& right);
  inline static void SortedArrayInt64OpNull(size_t op, Set& left, Set& right);

 private:
  static bool init_;
  static SetOp set_ops_[UCHAR_MAX][UCHAR_MAX];
};

SetOpInterface::SetOp SetOpInterface::GetSetOp(const Set& left, Set& right) {
  MEGA_RAII_INIT(DefaultSetOp)
  return set_ops_[left.GetCategory()][right.GetCategory()];
}

void SetOpInterface::SortedArrayInt64Op(size_t op, Set& left, Set& right) {
  SortedArrayInt64Set& left_set = static_cast<SortedArrayInt64Set&>(left); 
  SortedArrayInt64Set& right_set = static_cast<SortedArrayInt64Set&>(right);
  if (IndexerOps::And == op) {
    left_set.And(right_set);
  } else if (IndexerOps::Or == op) {
    left_set.Or(right_set);
  }
}

void SetOpInterface::SortedArrayInt64OpNull(size_t op, Set& left, Set& right) {
  if (unlikely(IndexerOps::And != op)) {
    FATAL("not_and_op_to_operater_null_set");
    return;
  }

  if ( unlikely( false == right.GetNot() ) ) left.Clear();
}

}}
