#pragma once

namespace zmt { namespace material_center {

struct SetNo {
  enum {
    kNoSet,
    kNoNullSet,
    kNoSortedArrayInt64Set,
    kNoThreadPrivacySet,
    kNoDynamicSet,
    kNoTagSet,
    kNoBitmap,
    kNumCategoriesSet,
  };
};

}}
