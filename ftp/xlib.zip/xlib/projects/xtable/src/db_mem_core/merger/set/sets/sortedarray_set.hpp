#pragma once

#include "../../public.h"
#include "../../settree/set.h"
#include "../set_no.h"

namespace zmt { namespace material_center {

class SortedArrayInt64Set : public Set {
 public:
  typedef Set Super;

 public:
  static const size_t kCategory = SetNo::kNoSortedArrayInt64Set; 

 public:
  uint8_t GetCategory() const { return kCategory; }
  inline Set* GetResult();
  inline void Clear();

 public: 
  inline void And(SortedArrayInt64Set& right);
  inline void Or(const SortedArrayInt64Set& right);
  inline bool TryAnd(const SortedArrayInt64Set& right) const;
  inline bool Has(int64_t field) const;

  inline void PushBack(int64_t field, int64_t weight);
  inline std::pair<int64_t, int64_t> operator[](size_t index) const;

  inline const std::vector< std::pair<int64_t, int64_t> >* GetSet() const;
  inline size_t Size() const { return sorted_array_.Size(); }

 private:
  SortedArray<int64_t> sorted_array_;
};

Set* SortedArrayInt64Set::GetResult() { 
  return 0 != sorted_array_.Size() ? this : NULL; 
}

void SortedArrayInt64Set::Clear() { 
  Super::Clear();
  return sorted_array_.Clear(); 
}

void SortedArrayInt64Set::And(SortedArrayInt64Set& right) {
  if (true != right.GetNot()) {
    sorted_array_.And(right.sorted_array_);
  } else {
    sorted_array_.AndNot(right.sorted_array_);
  }
}

void SortedArrayInt64Set::Or(const SortedArrayInt64Set& right) {
  sorted_array_.Or(right.sorted_array_);
}

bool SortedArrayInt64Set::TryAnd(const SortedArrayInt64Set& right) const {
  return sorted_array_.TryAnd(right.sorted_array_);
}

bool SortedArrayInt64Set::Has(int64_t field) const {
  return sorted_array_.Has(field);
}

void SortedArrayInt64Set::PushBack(int64_t field, int64_t weight) {
  sorted_array_.PushBack(field, weight); 
}

std::pair<int64_t, int64_t> SortedArrayInt64Set::operator[](size_t index) const {
  return sorted_array_[index];
}

const std::vector< std::pair<int64_t, int64_t> >*
SortedArrayInt64Set::GetSet() const {
  return sorted_array_.GetArray();
}

}}
