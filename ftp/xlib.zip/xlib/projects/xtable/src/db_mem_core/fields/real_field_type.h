#pragma once

namespace zmt { namespace material_center {

struct RealFieldType {
  enum Type {
    kBool,
    kInt8,
    kInt16,
    kInt32,
    kInt64,
    kStr,
    kSet8,
    kSet16,
    kSet32,
    kSet64,
    kNumTypes,
  };
};

}}
