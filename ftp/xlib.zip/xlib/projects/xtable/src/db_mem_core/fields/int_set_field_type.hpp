#pragma once 

#include "abstract_field_type.hpp"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

template <typename T> struct IsIntSetType {
  static const bool R = 
      IsSame<T, int8_t>::R 
      || IsSame<T, int16_t>::R
      || IsSame<T, int32_t>::R
      || IsSame<T, int64_t>::R;
};

template <typename T>
class IntSetFieldType : public AbstractFieldType {
  MEGA_STATIC_ASSERT(IsIntSetType<T>::R)
 
 public:
  typedef IntSetFieldType<T> Self; 

 public:
  bool ParseDefaultVal(const std::string val, FieldVal& field_val);

  bool IsSet() const { return true; }
  inline RealFieldType::Type GetType() const;
  size_t GetSize() const { return sizeof(void*); }

  bool SetIntSet(void* field, const BaseIntSetField* intset) const;
  bool InsertIntoIntSet(void* field, const std::string& vals) const;
  bool EraseFromIntSet(void* field, const std::string& vals) const;

  inline const BaseIntSetField* GetIntSet(const void* field) const;
  inline BaseIntSetField* GetIntSet(void* field);

  int Serialize(const void* field, char* buf, size_t size_buf) const;
  int Deserialize(const char* buf, size_t size_buf, void* field) const;
  int Serialize(const void* field, FILE* fp) const;
  int Deserialize(FILE* fp, void* field) const;
 
 private:
  bool InsertIntoSet_(void* field, const std::vector<T>& vals) const;
};

template <typename Type> struct SetTypeToNo {
  static const RealFieldType::Type R = RealFieldType::kNumTypes;
};

template <> struct SetTypeToNo<int8_t> {
  static const RealFieldType::Type R = RealFieldType::kSet8;
};

template <> struct SetTypeToNo<int16_t> {
  static const RealFieldType::Type R = RealFieldType::kSet16;
};

template <> struct SetTypeToNo<int32_t> {
  static const RealFieldType::Type R = RealFieldType::kSet32;
};

template <> struct SetTypeToNo<int64_t> {
  static const RealFieldType::Type R = RealFieldType::kSet64;
};

template <typename T>
RealFieldType::Type IntSetFieldType<T>::GetType() const {
  return SetTypeToNo<T>::R;
}

template <typename T>
bool IntSetFieldType<T>::ParseDefaultVal(const std::string val, FieldVal& field_val) {
  std::vector<T> check_vec;
  field_val.set_val = val;
  return IntSetField<T>::StrToVec_(val, check_vec);
}

template <typename T>
bool IntSetFieldType<T>::SetIntSet(void* field, const BaseIntSetField* intset) const {
  if (unlikely(NULL!=intset && sizeof(T) != intset->SizeUnit())) {
    return false;
  }

  BaseIntSetField** int_set_field = RCAST<BaseIntSetField**>(field); 
  if (unlikely(NULL != *int_set_field)) {
    MEGA_DELETE(*int_set_field)
  }

  if (likely(NULL!=intset)) {
    MEGA_NEW(*int_set_field, IntSetField<T>(*SCAST<const IntSetField<T>*>(intset)))
  }
  return true;
}

template <typename T>
bool IntSetFieldType<T>::InsertIntoIntSet(void* field, const std::string& vals) const {
  BaseIntSetField** int_set_field = RCAST<BaseIntSetField**>(field); 
  if (unlikely(NULL == *int_set_field)) {
    MEGA_NEW(*int_set_field, IntSetField<T>)
  }
  return (*int_set_field)->Insert(vals);
}

template <typename T>
bool IntSetFieldType<T>::EraseFromIntSet(void* field, const std::string& vals) const {
  BaseIntSetField** int_set_field = RCAST<BaseIntSetField**>(field); 
  return NULL != *int_set_field ? (*int_set_field)->Erase(vals) : true;
}

template <typename T>
const BaseIntSetField* IntSetFieldType<T>::GetIntSet(const void* field) const {
  return *(RCAST<BaseIntSetField* const*>(field));
}

template <typename T>
BaseIntSetField* IntSetFieldType<T>::GetIntSet(void* field) {
  return *(RCAST<BaseIntSetField**>(field));
}

template <typename T>
int IntSetFieldType<T>::Serialize(const void* field, char* buf, size_t size_buf) const {
  const IntSetField<T>* set = *(RCAST<IntSetField<T>* const*>(field));
  if (NULL==set) {
    return IOHelper::WriteInt(0, buf, size_buf);
  }

  size_t ret = IOHelper::WriteInt(set->Size(), buf, size_buf);
  if (0==ret) return -1;

  size_t pos=ret;
  for (size_t i=0; i < set->Size(); ++i) {
    ret = IOHelper::WriteInt(set->Get(i), buf+pos, size_buf-pos);
    if (0==ret) return -2;

    pos+=ret;
  }
  return pos;
}

template <typename T>
int IntSetFieldType<T>::Deserialize(const char* buf, size_t size_buf, void* field) const {
  int64_t size_set;
  size_t ret = IOHelper::ReadInt(buf, size_buf, size_set);
  if (0==ret || size_set<0) return -1;

  std::vector<T> vals;
  size_t pos=ret;
  for (int64_t i=0; i<size_set; ++i) {
    int64_t member;
    ret = IOHelper::ReadInt(buf, size_buf, member);
    if (0==ret) return -2;

    if (true != IntRange<T>::Check(member)) {
      return -3;
    }

    vals.push_back(member);
    pos+=ret;
  }

  ret = InsertIntoSet_(field, vals);
  if (true!=ret) return -3;
  return pos;
}

template <typename T>
int IntSetFieldType<T>::Serialize(const void* field, FILE* fp) const {
  const IntSetField<T>* set = *(RCAST<IntSetField<T>* const*>(field));
  if (NULL==set) {
    return true == IOHelper::WriteInt(0, fp) ? 0 : -1;
  }

  bool ret = IOHelper::WriteInt(set->Size(), fp);
  if (true!=ret) return -2;

  for (size_t i=0; i < set->Size(); ++i) {
    ret = IOHelper::WriteInt(set->Get(i), fp);
    if (true!=ret) return -3;
  }
  return 0;
}

template <typename T>
int IntSetFieldType<T>::Deserialize(FILE* fp, void* field) const {
  int64_t size_set;
  bool ret = IOHelper::ReadInt(fp, size_set);
  if (true!=ret || size_set<0) {
    return -1;
  }

  std::vector<T> vals;
  for (int64_t i=0; i<size_set; ++i) {
    int64_t member;
    ret = IOHelper::ReadInt(fp, member);
    if (true!=ret) return -2;

    if (true != IntRange<T>::Check(member)) {
      return -3;
    }
    vals.push_back(member);
  }

  ret = InsertIntoSet_(field, vals);
  if (true!=ret) return -3;
  return 0;
}

template <typename T>
bool IntSetFieldType<T>::InsertIntoSet_(void* field, const std::vector<T>& vals) const {
  IntSetField<T>** int_set_field = RCAST<IntSetField<T>**>(field); 
  if (NULL == *int_set_field) {
    MEGA_NEW(*int_set_field, IntSetField<T>)
  }
  return (*int_set_field)->Insert(vals);
}

}}
