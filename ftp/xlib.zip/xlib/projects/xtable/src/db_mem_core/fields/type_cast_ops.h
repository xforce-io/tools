#pragma once

#include "public.h"
#include "field_type.h"

namespace zmt { namespace material_center {

class TypeCastOps {
 public:
  typedef bool (*TypeCaster)(
      const void* old_field, 
      const FieldType& old_type,
      void* new_field,
      const FieldType& new_type);
 
 public:
  static void Init(); 
  inline static TypeCaster GetTypeCaster(
      const FieldType& from, const FieldType& to);
  
 private:
  inline static bool PlainCopy_(
      const void* old_field,
      const FieldType& old_type,
      void* new_field,
      const FieldType& new_type); 

 private:
  static TypeCaster type_caster_[RealFieldType::kNumTypes][RealFieldType::kNumTypes];
  static bool init_;
};

TypeCastOps::TypeCaster TypeCastOps::GetTypeCaster(
    const FieldType& from, const FieldType& to) {
  if (unlikely(true!=init_)) Init();
  return type_caster_[from.GetType()][to.GetType()];
}

bool TypeCastOps::PlainCopy_(
    const void* old_field,
    const FieldType& old_type,
    void* new_field,
    const FieldType& /*new_type*/) {
  memcpy(new_field, old_field, old_type.GetSize());
  return true;
}

}}
