#include "../str_field.h"

namespace zmt { namespace material_center {

void StrField::Assign(const char* str, size_t len) {
  if (len+1 > size_ || size_ > len*kExpansionRatio) {
    str_ = RCAST<char*>(realloc(str_, len+1));
    if (unlikely(NULL==str_)) return;

    size_ = len+1;
  }

  if (len>=size_) {
    //expand
    size_t new_size = (len+1) * kExpansionRatio;
    MEGA_REALLOC(str_, str_, char*, new_size)
    size_=new_size;
  } else if (len>=kThresholdShink && len+1 < size_*kShrinkRatio) {
    //shrink
    size_t new_size = size_*kShrinkRatio*kExpansionRatio;
    MEGA_REALLOC(str_, str_, char*, new_size)
    size_=new_size;
  }

  strcpy(str_, str);
  len_=len;
}

StrField::~StrField() {
  MEGA_FREE(str_)
}

}}
