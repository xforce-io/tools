#include "../field_type.h"

#include "../int_field_type.hpp"
#include "../str_field_type.hpp"
#include "../int_set_field_type.hpp"

namespace zmt { namespace material_center {

FieldType::FieldType() :
  type_(NULL) {}

FieldType::FieldType(const FieldType& type) :
  type_(NULL) {
  operator=(type);
}

bool FieldType::Parse(const std::string& type) {
  MEGA_DELETE(type_)
  if (type == "bool") {
    MEGA_NEW(type_, IntFieldType<bool>)
  } else if (type == "int8") {
    MEGA_NEW(type_, IntFieldType<int8_t>)
  } else if (type == "int16") {
    MEGA_NEW(type_, IntFieldType<int16_t>)
  } else if (type == "int32") {
    MEGA_NEW(type_, IntFieldType<int32_t>)
  } else if (type == "int64") {
    MEGA_NEW(type_, IntFieldType<int64_t>)
  } else if (type == "str") {
    MEGA_NEW(type_, StrFieldType)
  } else if (type == "set8") {
    MEGA_NEW(type_, IntSetFieldType<int8_t>)
  } else if (type == "set16") {
    MEGA_NEW(type_, IntSetFieldType<int16_t>)
  } else if (type == "set32") {
    MEGA_NEW(type_, IntSetFieldType<int32_t>)
  } else if (type == "set64") {
    MEGA_NEW(type_, IntSetFieldType<int64_t>)
  } else {
    WARN("unknown_schema_type[" << type << "]");
    return false;
  }
  return true;
}

bool FieldType::Parse(RealFieldType::Type type) {
  MEGA_DELETE(type_)
  switch (type) {
    case RealFieldType::kBool :
      MEGA_NEW(type_, IntFieldType<bool>)
      break;
    case RealFieldType::kInt8:
      MEGA_NEW(type_, IntFieldType<int8_t>)
      break;
    case RealFieldType::kInt16:
      MEGA_NEW(type_, IntFieldType<int16_t>)
      break;
    case RealFieldType::kInt32:
      MEGA_NEW(type_, IntFieldType<int32_t>)
      break;
    case RealFieldType::kInt64:
      MEGA_NEW(type_, IntFieldType<int64_t>)
      break;
    case RealFieldType::kStr:
      MEGA_NEW(type_, StrFieldType)
      break;
    case RealFieldType::kSet8:
      MEGA_NEW(type_, IntSetFieldType<int8_t>)
      break;
    case RealFieldType::kSet16:
      MEGA_NEW(type_, IntSetFieldType<int16_t>)
      break;
    case RealFieldType::kSet32:
      MEGA_NEW(type_, IntSetFieldType<int32_t>)
      break;
    case RealFieldType::kSet64:
      MEGA_NEW(type_, IntSetFieldType<int64_t>)
      break;
    default :
      WARN("unknown_schema_type[" << type << "]");
      return false;
  }
  return true;
}

int FieldType::Serialize(const void* field, char* buf, size_t size_buf) const {
  return type_->Serialize(field, buf, size_buf);
}

int FieldType::Deserialize(const char* buf, size_t size_buf, void* field) const {
  return type_->Deserialize(buf, size_buf, field);
}

int FieldType::Serialize(const void* field, FILE* fp) const {
  return type_->Serialize(field, fp);
}

int FieldType::Deserialize(FILE* fp, void* field) const {
  return type_->Deserialize(fp, field);
}

FieldType& FieldType::operator=(const Self& other) {
  if (this == &other || NULL == other.type_) return *this;

  Parse(other.GetType());
  return *this;
}

FieldType::~FieldType() {
  MEGA_DELETE(type_)
}

}}
