#pragma once

#include "public.h"
#include "real_field_type.h"
#include "str_field.h"
#include "int_set_field.hpp"

namespace zmt { namespace material_center {

struct FieldVal {
  int64_t int_val;
  std::string str_val;
  std::string set_val;
};

struct DefaultFieldVal {
  bool has_val;
  FieldVal val;
};

class AbstractFieldType {
 public:
  virtual bool ParseDefaultVal(const std::string val, FieldVal& field_val)=0;

  virtual RealFieldType::Type GetType() const=0;
  virtual size_t GetSize() const=0;
  virtual bool IsInt() const { return false; }
  virtual bool IsStr() const { return false; }
  virtual bool IsSet() const { return false; }

  inline bool SetDefaultVal(void* field, const DefaultFieldVal& val) const;
  inline bool SetVal(void* field, const FieldVal& val) const;

  virtual bool SetInt(void* /*field*/, int64_t /*val*/) const { return false; }
  virtual bool SetStr(void* /*field*/, const std::string& /*val*/) const { return false; }
  virtual bool SetIntSet(void* /*field*/, const BaseIntSetField* /*intset*/) const { return false; }
  virtual bool InsertIntoIntSet(void* /*field*/, const std::string& /*val*/) const { return false; }
  virtual bool EraseFromIntSet(void* /*field*/, const std::string& /*val*/) const { return false; }

  virtual int64_t GetInt(const void* /*field*/) const { return LLONG_MIN; }
  virtual const char* GetStr(const void* /*field*/) const { return NULL; }
  virtual StrField* GetStrField(void* /*field*/) { return NULL; }
  virtual const BaseIntSetField* GetIntSet(const void* /*field*/) const { return NULL; }

  /*
   * @return: number of bytes of serialized result
   */
  virtual int Serialize(const void* fields, char* buf, size_t size_buf) const=0;
  virtual int Deserialize(const char* buf, size_t size_buf, void* fields) const=0;

  /*
   * @return: 0 if succ, <0 if fail
   */
  virtual int Serialize(const void* fields, FILE* fp) const=0;
  virtual int Deserialize(FILE* fp, void* fields) const=0;

  virtual ~AbstractFieldType() {}
};

bool AbstractFieldType::SetDefaultVal(
    void* field, const DefaultFieldVal& val) const {
  return true==val.has_val && SetVal(field, val.val);
}

bool AbstractFieldType::SetVal(void* field, const FieldVal& val) const {
  if (RealFieldType::kBool <= GetType() && RealFieldType::kInt64 >= GetType()) {
    return SetInt(field, val.int_val);
  } else if (RealFieldType::kStr == GetType()) {
    return SetStr(field, val.str_val);
  } else if (RealFieldType::kSet8 <= GetType() && RealFieldType::kSet64 >= GetType()){
    return InsertIntoIntSet(field, val.set_val);
  } else {
    return false;
  }
}

}}
