#pragma once

#include "abstract_field_type.hpp"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

template <typename T>
struct IsIntType {
  static const bool R = 
      IsSame<T, bool>::R 
      || IsSame<T, int8_t>::R
      || IsSame<T, int16_t>::R
      || IsSame<T, int32_t>::R
      || IsSame<T, int64_t>::R;
};

template <typename T>
class IntFieldType : public AbstractFieldType {
  MEGA_STATIC_ASSERT(IsIntType<T>::R)

 public:
  bool IsInt() const { return true; }
  inline RealFieldType::Type GetType() const;
  size_t GetSize() const { return sizeof(T); }

  bool ParseDefaultVal(const std::string val, FieldVal& field_val);
  inline bool SetInt(void* field, int64_t val) const;
  inline int64_t GetInt(const void* field) const;

  inline int Serialize(const void* field, char* buf, size_t size_buf) const;
  inline int Deserialize(const char* buf, size_t size_buf, void* field) const;
  inline int Serialize(const void* field, FILE* fp) const;
  inline int Deserialize(FILE* fp, void* field) const;
};

template <>
RealFieldType::Type IntFieldType<bool>::GetType() const {
  return RealFieldType::kBool;
}

template <>
RealFieldType::Type IntFieldType<int8_t>::GetType() const {
  return RealFieldType::kInt8;
}

template <>
RealFieldType::Type IntFieldType<int16_t>::GetType() const {
  return RealFieldType::kInt16;
}

template <>
RealFieldType::Type IntFieldType<int32_t>::GetType() const {
  return RealFieldType::kInt32;
}

template <>
RealFieldType::Type IntFieldType<int64_t>::GetType() const {
  return RealFieldType::kInt64;
}

template <typename T>
bool IntFieldType<T>::ParseDefaultVal(const std::string val, FieldVal& field_val) {
  char* endptr;
  int64_t int64 = strtoll(val.c_str(), &endptr, 10);
  if ('\0' != *endptr || true != IntRange<T>::Check(int64)) {
    return false; 
  }
  
  field_val.int_val = int64;
  return true;
}

template <typename T>
bool IntFieldType<T>::SetInt(void* field, int64_t val) const {
  if (unlikely(true != IntRange<T>::Check(val))) {
    return false;
  }

  *(RCAST<T*>(field)) = SCAST<T>(val);
  return true;
}

template <typename T>
int64_t IntFieldType<T>::GetInt(const void* field) const {
  return *RCAST<const T*>(field);
}

template <typename T>
int IntFieldType<T>::Serialize(const void* field, char* buf, size_t size_buf) const {
  return IOHelper::WriteInt(GetInt(field), buf, size_buf);
}

template <typename T>
int IntFieldType<T>::Deserialize(const char* buf, size_t size_buf, void* field) const {
  int64_t val;
  size_t bytes_read = IOHelper::ReadInt(buf, size_buf, val);
  if (unlikely(0==bytes_read)) return 0;

  bool ret = SetInt(field, val);
  if (unlikely(true!=ret)) return 0;
  return bytes_read;
}

template <typename T>
int IntFieldType<T>::Serialize(const void* field, FILE* fp) const {
  bool ret = IOHelper::WriteInt(GetInt(field), fp);
  return true==ret ? 0 : -1;
}

template <typename T>
int IntFieldType<T>::Deserialize(FILE* fp, void* field) const {
  int64_t val;
  bool ret = IOHelper::ReadInt(fp, val);
  if (unlikely(true!=ret)) return -1;

  ret = SetInt(field, val);
  if (unlikely(true!=ret)) return -2;
  return 0;
}

}}
