#pragma once

#include "public.h"
#include "abstract_field_type.hpp"
#include "int_set_field.hpp"

namespace zmt { namespace material_center {

class FieldType {
 private:
  typedef FieldType Self;
  
 public: 
  FieldType();
  explicit FieldType(const FieldType& type);

  bool Parse(const std::string& type);
  bool Parse(RealFieldType::Type type);
  inline bool ParseDefaultVal(const std::string val, FieldVal& field_val);

  RealFieldType::Type GetType() const { return type_->GetType(); }
  size_t GetSize() const { return type_->GetSize(); }
  bool IsInt() const { return type_->IsInt(); }
  bool IsStr() const { return type_->IsStr(); }
  bool IsSet() const { return type_->IsSet(); }

  inline bool SetDefaultVal(void* field, const DefaultFieldVal& val) const;
  inline bool SetVal(void* field, const FieldVal& val) const;

  inline bool SetInt(void* field, int64_t int64) const;
  inline bool SetStr(void* field, const std::string& val) const;
  inline bool SetIntSet(void* field, const BaseIntSetField* intset) const;
  inline bool InsertIntoIntSet(void* field, const std::string& val) const;
  inline bool EraseFromIntSet(void* field, const std::string& val) const;

  inline int64_t GetInt(const void* field) const;
  inline const char* GetStr(const void* field) const;
  inline StrField* GetStrField(void* field) const;
  inline const BaseIntSetField* GetIntSet(const void* field) const;

  int Serialize(const void* field, char* buf, size_t size_buf) const;
  int Deserialize(const char* buf, size_t size_buf, void* field) const;
  int Serialize(const void* field, FILE* fp) const;
  int Deserialize(FILE* fp, void* field) const;

  Self& operator=(const Self& other);

  virtual ~FieldType();

 private:
  AbstractFieldType* type_; 
};

bool FieldType::ParseDefaultVal(const std::string val, FieldVal& field_val) {
  return type_->ParseDefaultVal(val, field_val);
}

bool FieldType::SetDefaultVal(void* field, const DefaultFieldVal& val) const {
  return type_->SetDefaultVal(field, val);
}

bool FieldType::SetVal(void* field, const FieldVal& val) const {
  return type_->SetVal(field, val);
}

bool FieldType::SetInt(void* field, int64_t int64) const {
  return type_->SetInt(field, int64);
}

bool FieldType::SetStr(void* field, const std::string& val) const {
  return type_->SetStr(field, val);
}

bool FieldType::SetIntSet(void* field, const BaseIntSetField* intset) const {
  return type_->SetIntSet(field, intset);
}

bool FieldType::InsertIntoIntSet(void* field, const std::string& val) const {
  return type_->InsertIntoIntSet(field, val);
}

bool FieldType::EraseFromIntSet(void* field, const std::string& val) const {
  return type_->EraseFromIntSet(field, val);
}

int64_t FieldType::GetInt(const void* field) const {
  return type_->GetInt(field);
}

StrField* FieldType::GetStrField(void* field) const {
  return type_->GetStrField(field);
}

const char* FieldType::GetStr(const void* field) const {
  return type_->GetStr(field);
}

const BaseIntSetField* FieldType::GetIntSet(const void* field) const {
  return type_->GetIntSet(field);
}

}}
