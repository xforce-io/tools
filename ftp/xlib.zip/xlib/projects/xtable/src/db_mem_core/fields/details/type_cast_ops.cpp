#include "../type_cast_ops.h"

namespace zmt { namespace material_center {

TypeCastOps::TypeCaster 
TypeCastOps::type_caster_[RealFieldType::kNumTypes][RealFieldType::kNumTypes];

bool TypeCastOps::init_;

void TypeCastOps::Init() {
  for (size_t i=0; i < RealFieldType::kNumTypes; ++i) {
    for (size_t j=0; j < RealFieldType::kNumTypes; ++j) {
      type_caster_[i][j] = NULL;
    }
  }

  type_caster_[RealFieldType::kBool][RealFieldType::kInt8] = PlainCopy_;
  type_caster_[RealFieldType::kBool][RealFieldType::kInt16] = PlainCopy_;
  type_caster_[RealFieldType::kBool][RealFieldType::kInt32] = PlainCopy_;
  type_caster_[RealFieldType::kBool][RealFieldType::kInt64] = PlainCopy_;
  type_caster_[RealFieldType::kInt8][RealFieldType::kInt16] = PlainCopy_;
  type_caster_[RealFieldType::kInt8][RealFieldType::kInt32] = PlainCopy_;
  type_caster_[RealFieldType::kInt8][RealFieldType::kInt64] = PlainCopy_;
  type_caster_[RealFieldType::kInt16][RealFieldType::kInt32] = PlainCopy_;
  type_caster_[RealFieldType::kInt16][RealFieldType::kInt64] = PlainCopy_;
  type_caster_[RealFieldType::kInt32][RealFieldType::kInt64] = PlainCopy_;

  init_=true;
}

}}
