#pragma once

#include "public.h"

namespace zmt { namespace material_center {

class StrField {
 public:
  inline StrField(const char* str, size_t len);
  void Assign(const char* str, size_t len);
  const char* GetStr() const { return str_; }
  size_t Len() const { return len_; }
  size_t Size() const { return size_; }
  virtual ~StrField();
 
 private:
  //make sure mem wasted not above 1/2 of used mem
  static const double kExpansionRatio= 6.0/5;  
  static const size_t kThresholdShink=10;
  static const double kShrinkRatio = 2.0/3;
   
 private:
  char* str_;
  uint32_t len_;
  uint32_t size_;
};

StrField::StrField(const char* str, size_t len) {
  size_ = len*kExpansionRatio + 1;
  MEGA_MALLOC(str_, char*, size_)
  strcpy(str_, str);
  len_=len;
}

}}
