#pragma once

#include "abstract_field_type.hpp"
#include "str_field.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

class StrFieldType : public AbstractFieldType {
 public: 
  inline bool ParseDefaultVal(const std::string val, FieldVal& field_val);

  inline RealFieldType::Type GetType() const;
  size_t GetSize() const { return sizeof(void*); }

  inline bool SetStr(void* field, const std::string& val) const;

  inline const char* GetStr(const void* field) const;
  inline StrField* GetStrField(void* field);

  inline int Serialize(const void* field, char* buf, size_t size_buf) const;
  inline int Deserialize(const char* buf, size_t size_buf, void* field) const;
  inline int Serialize(const void* field, FILE* fp) const;
  inline int Deserialize(FILE* fp, void* field) const;
};

RealFieldType::Type StrFieldType::GetType() const { 
  return RealFieldType::kStr; 
}

bool StrFieldType::ParseDefaultVal(const std::string val, FieldVal& field_val) {
  field_val.str_val = val;
  return true;
}

bool StrFieldType::SetStr(void* field, const std::string& val) const {
  StrField** str_field = RCAST<StrField**>(field);
  if (NULL != *str_field) {
    (*str_field)->Assign(val.c_str(), val.length());
  } else {
    MEGA_NEW(*str_field, StrField(val.c_str(), val.length()))
  }
  return true;
}

const char* StrFieldType::GetStr(const void* field) const {
  StrField* const* str_field = RCAST<StrField* const*>(field);
  return NULL != *str_field ? (*str_field)->GetStr() : "";
}

StrField* StrFieldType::GetStrField(void* field) {
  return *(RCAST<StrField**>(field));
}

int StrFieldType::Serialize(const void* field, char* buf, size_t size_buf) const {
  return IOHelper::WriteStr(GetStr(field), buf, size_buf);
}

int StrFieldType::Deserialize(const char* buf, size_t /*size_buf*/, void* field) const {
  std::string str;
  size_t num_bytes = IOHelper::ReadStr(buf, str);
  if (unlikely(0==num_bytes)) return -1;

  return true == SetStr(field, str) ? num_bytes : -2;
}

int StrFieldType::Serialize(const void* field, FILE* fp) const {
  bool ret = IOHelper::WriteStr(GetStr(field), fp);
  return true==ret ? 0 : -1;
}

int StrFieldType::Deserialize(FILE* fp, void* field) const {
  std::string str;
  bool ret = IOHelper::ReadStr(fp, str);
  if (unlikely(true!=ret)) return -1;

  return true == SetStr(field, str) ? 0 : -2;
}

}}
