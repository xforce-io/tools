#pragma once

#include "public.h"

namespace zmt { namespace material_center {

class BaseIntSetField {
 public:
  virtual bool Insert(const std::string& vals)=0;
  virtual bool Erase(const std::string& vals)=0;
  virtual void Clear()=0;

  virtual size_t Size() const=0;
  virtual size_t SizeUnit() const=0;
  virtual int64_t Get(size_t idx) const=0;
  virtual ~BaseIntSetField() {}
};

//TODO: change sets to be ordered to make it faster
template <typename T>
class IntSetField : public BaseIntSetField {
 public:
  typedef IntSetField<T> Self;
  
 private:
  static const char kSep = ',';
  
 public:
  explicit IntSetField(size_t hint_len=0);
  explicit IntSetField(const Self& other);
  inline bool Insert(const std::string& vals);
  bool Insert(const std::vector<T>& vals);
  inline bool Erase(const std::string& vals);
  void Erase(const std::vector<T>& vals);
  void Clear();

  size_t Size() const { return num_; }
  size_t SizeUnit() const { return sizeof(T); }
  int64_t Get(size_t idx) const { return set_[idx]; }
  virtual ~IntSetField();
   
 private:
  static const double kExpansionRatio = 6.0/5;  
  static const size_t kThresholdShink=10;
  static const double kShrinkRatio = 2.0/3;

 private:
  void Shrink_(); 
 
 private:
  static bool StrToVec_(const std::string& str, std::vector<T>& val); 

 private:
  T* set_;
  uint32_t num_;
  uint32_t size_;
};

template <typename T>
IntSetField<T>::IntSetField(size_t hint_len) {
  size_ = hint_len*kExpansionRatio;
  MEGA_MALLOC(set_, T*, size_ * sizeof(T))
  num_=0;
}

template <typename T>
IntSetField<T>::IntSetField(const Self& other) {
  num_ = other.num_;
  size_ = other.size_;
  MEGA_MALLOC(set_, T*, size_ * sizeof(T))
  memcpy(set_, other.set_, sizeof(T)*num_);
}

template <typename T>
bool IntSetField<T>::Insert(const std::string& vals) {
  std::vector<T> tmp_vals;
  bool ret = StrToVec_(vals, tmp_vals);
  if (unlikely(true!=ret)) return false;

  return Insert(tmp_vals);
}

template <typename T>
bool IntSetField<T>::Insert(const std::vector<T>& vals) {
  size_t num_vals = vals.size();
  if (unlikely(0==num_vals)) return true;

  if (num_+num_vals > size_) {
    //expand
    size_t new_size = (num_+num_vals) * kExpansionRatio;
    MEGA_REALLOC(set_, set_, T*, new_size * sizeof(T))
    size_=new_size;
  }

  size_t i=0;
  while (i<num_vals) {
    set_[num_+i] = vals[i];
    ++i;
  }
  num_+=num_vals;
  return true;
}

template <typename T>
bool IntSetField<T>::Erase(const std::string& vals) {
  std::vector<T> tmp_vals;
  bool ret = StrToVec_(vals, tmp_vals);
  if (unlikely(true!=ret)) return false;

  Erase(tmp_vals);
  return true;
}

template <typename T>
void IntSetField<T>::Erase(const std::vector<T>& vals) {
  if (unlikely(0 == vals.size())) return;

  for (size_t i=0; i < vals.size(); ++i) {
    size_t iter=0;
    while (iter<num_) {
      if (vals[i] == set_[iter]) {
        set_[iter] = set_[--num_];
        continue;
      }
      ++iter;
    }
  }
  Shrink_();
}

template <typename T>
void IntSetField<T>::Clear() {
  num_=0;
  Shrink_();
}

template <typename T>
IntSetField<T>::~IntSetField() {
  MEGA_FREE(set_)
}

template <typename T>
void IntSetField<T>::Shrink_() {
  if (num_>kThresholdShink && num_ < size_*kShrinkRatio) {
    //shrink
    size_t new_size = size_ * kShrinkRatio * kExpansionRatio;
    MEGA_REALLOC(set_, set_, T*, new_size * sizeof(T))
    size_=new_size;
  }
}

template <typename T>
bool IntSetField<T>::StrToVec_(const std::string& str, std::vector<T>& vals) {
  vals.clear();

  char* buf;
  MEGA_MALLOC(buf, char*, str.length() + 1)
  memcpy(buf, str.c_str(), str.length() + 1);

  int64_t int64;
  char* end_ptr;
  char seps[] = {kSep, '\0'};
  char* tmp_ptr;
  char* ptr = strtok_r(buf, seps, &tmp_ptr);
  while (NULL!=ptr && '\0'!=*ptr) {
    int64 = strtoll(ptr, &end_ptr, 10);
    if ('\0' != *end_ptr || true != IntRange<T>::Check(int64)) {
      MEGA_FREE(buf);
      return false;
    }
    vals.push_back(int64);

    ptr = strtok_r(NULL, seps, &tmp_ptr);
  }
  MEGA_FREE(buf);
  return true;
}

}}
