#pragma once

#include "../public.h"
#include "fields/field_type.h"
#include "fields/str_field.h"
#include "fields/int_set_field.hpp"

namespace zmt { namespace material_center {

class TableSchema {
 private:
  struct Property {
    std::string name;
    FieldType type;
    size_t offset;
    size_t version; //version of schema which this col is introduced
    DefaultFieldVal default_field_val;
  };

 private:
  typedef TableSchema Self;
  typedef std::map<std::string, size_t> NameToIndex;
  typedef std::vector<Property> Schema;
 
 private:
  static const size_t kDefaultSetSize=5; 

 public:
  bool Init(const WeakType& syntax);
  bool AddColumn(
      const std::string& col, 
      const std::string& type, 
      const std::string* default_val,
      size_t version);

  bool RemoveColumn(const std::string& col);
  bool ChangeType(const std::string& col, const std::string& type);

  std::string GetSyntax() const { return syntax_; }
  size_t Size() const { return schema_.size(); }
  inline size_t SizeRecord() const;
  inline RealFieldType::Type GetType(size_t col) const;
  int64_t GetTableKey(const void* fields) const { return GetInt(fields, 0); }

  inline bool SetDefaultVal(
      void* fields, size_t col, const DefaultFieldVal& field_val) const;

  inline bool SetInt(void* fields, size_t col, int64_t val) const;
  inline bool SetStr(void* fields, size_t col, const std::string& val) const;
  inline bool SetIntSet(void* fields, size_t col, const BaseIntSetField* intset) const;
  inline bool InsertIntoIntSet(void* fields, size_t col, const std::string& val) const;
  inline bool EraseFromIntSet(void* fields, size_t col, const std::string& val) const;

  void* Update(const void* fields, const Self& table_schema) const;
  bool Copy(const void* fields_from, void* fields_to) const;

  inline int64_t GetInt(const void* fields, const std::string& col) const;
  inline const char* GetStr(const void* fields, const std::string& col) const;
  inline StrField* GetStrField(void* fields, const std::string& col) const;
  inline const BaseIntSetField* GetIntSet(const void* fields, const std::string& col) const;
  inline int64_t GetInt(const void* fields, size_t col) const;
  inline const char* GetStr(const void* fields, size_t col) const;
  inline StrField* GetStrField(void* fields, size_t col) const;
  inline const BaseIntSetField* GetIntSet(const void* fields, size_t col) const;

  inline const void* GetField(const void* fields, size_t col) const;
  inline void* GetField(void* fields, size_t col) const;

  /*
   * @return: number of bytes of serialized result
   */
  int Serialize(const void* fields, char* buf, size_t size_buf) const;
  int Deserialize(const char* buf, size_t size_buf, void* fields) const;

  /*
   * @return: 0 if succ, <0 if fail
   */
  int Serialize(const void* fields, FILE* fp) const;
  int Deserialize(FILE* fp, void* fields) const;

  /*
   * @brief: Serialize and Deserialize *this
   * @return: 0 if succ, <0 if fail
   */
  int Serialize(FILE* fp) const;
  int Deserialize(FILE* fp);

  Self& operator=(const Self& other);
  inline void Clear();

 private:
  inline size_t GetCurrentOffset_() const;
  inline void CreateNewSet_(BaseIntSetField** set_field, size_t col) const;

 private:
  //const 
  std::string syntax_;
  ///

  NameToIndex name_to_index_;
  Schema schema_;
};

size_t TableSchema::SizeRecord() const {
  if (unlikely(0 == schema_.size())) return 0;

  const Property& last_property = schema_[schema_.size() - 1];
  return last_property.offset + last_property.type.GetSize();
}

RealFieldType::Type TableSchema::GetType(size_t col) const { 
  return schema_[col].type.GetType(); 
}

bool TableSchema::SetDefaultVal(
    void* fields, size_t col, const DefaultFieldVal& field_val) const {
  return schema_[col].type.SetDefaultVal(GetField(fields, col), field_val);
}

bool TableSchema::SetInt(void* fields, size_t col, int64_t val) const {
  return schema_[col].type.SetInt(GetField(fields, col), val);
}

bool TableSchema::SetStr(void* fields, size_t col, const std::string& val) const {
  return schema_[col].type.SetStr(GetField(fields, col), val);
}

bool TableSchema::SetIntSet(void* fields, size_t col, const BaseIntSetField* intset) const {
  return schema_[col].type.SetIntSet(GetField(fields, col), intset);
}

bool TableSchema::InsertIntoIntSet(void* fields, size_t col, const std::string& val) const {
  return schema_[col].type.InsertIntoIntSet(GetField(fields, col), val);
}

bool TableSchema::EraseFromIntSet(void* fields, size_t col, const std::string& val) const {
  return schema_[col].type.EraseFromIntSet(GetField(fields, col), val);
}

int64_t TableSchema::GetInt(const void* fields, const std::string& col) const {
  NameToIndex::const_iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return LLONG_MIN;

  return GetInt(fields, iter->second);
}

const char* TableSchema::GetStr(
    const void* fields, const std::string& col) const {
  NameToIndex::const_iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return NULL;

  return GetStr(fields, iter->second);
}

StrField* TableSchema::GetStrField(void* fields, const std::string& col) const {
  NameToIndex::const_iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return NULL;

  return GetStrField(fields, iter->second);
}

const BaseIntSetField* TableSchema::GetIntSet(const void* fields, const std::string& col) const {
  NameToIndex::const_iterator iter = name_to_index_.find(col);
  if (unlikely(name_to_index_.end() == iter)) return NULL;

  return GetIntSet(fields, iter->second);
}

int64_t TableSchema::GetInt(const void* fields, size_t col) const {
  return schema_[col].type.GetInt(GetField(fields, col));
}

const char* TableSchema::GetStr(const void* fields, size_t col) const {
  return schema_[col].type.GetStr(GetField(fields, col));
}

StrField* TableSchema::GetStrField(void* fields, size_t col) const {
  return schema_[col].type.GetStrField(GetField(fields, col));
}

const BaseIntSetField* TableSchema::GetIntSet(const void* fields, size_t col) const {
  return schema_[col].type.GetIntSet(GetField(fields, col));
}

const void* TableSchema::GetField(const void* fields, size_t col) const {
  return RCAST<const void*>(
      RCAST<const char*>(fields) + schema_[col].offset);
}

void* TableSchema::GetField(void* fields, size_t col) const {
  return RCAST<void*>(
      RCAST<char*>(fields) + schema_[col].offset);
}

void TableSchema::Clear() {
  name_to_index_.clear();
  schema_.clear();
}

void TableSchema::CreateNewSet_(BaseIntSetField** set_field, size_t col) const {
  switch (schema_[col].type.GetType()) {
    case RealFieldType::kSet8 :
      MEGA_NEW(*set_field, IntSetField<int8_t>(kDefaultSetSize))
      break;
    case RealFieldType::kSet16 :
      MEGA_NEW(*set_field, IntSetField<int16_t>(kDefaultSetSize))
      break;
    case RealFieldType::kSet32 :
      MEGA_NEW(*set_field, IntSetField<int32_t>(kDefaultSetSize))
      break;
    case RealFieldType::kSet64 :
      MEGA_NEW(*set_field, IntSetField<int64_t>(kDefaultSetSize))
      break;
    default :
      MEGA_BUG(true)
  }
}

}}
