#pragma once

#include "table_schema.h"
#include "table.h"
#include "record.h"
#include "merger/set/set_op.h"
#include "merger/settree/settree.hpp"

namespace zmt { namespace material_center {

class TablesMgr {
 public:
  typedef TablesMgr Self;
  typedef std::tr1::unordered_map<std::string, size_t> TablesNo;
  typedef std::vector<Table> Tables;
  
 public:
  TablesMgr();

  /*
   * @return: no of table if succ, errno if fail
   */
  int CreateTable(const WeakType& syntax);

  inline int AddRecord(const Record& record);
  inline int ParseRecord(
      IN const std::string& table_name,
      IN const WeakType& syntax,
      OUT Record*& record);

  inline int RemoveRecord(const Record& record);
  bool SearchRecords(const WeakType& syntax,
      SortedArrayInt64Set*& result);

  void Clear();

  /*
   * @brief: get table no according to name
   * @return: 0 if fail
   */
  inline size_t GetTableNo(const std::string& name);
  inline const Table& GetTable(size_t table_no) const;
  inline Table& GetTable(size_t table_no);
  inline Record* GetTmpRecord(size_t tables_no) const;
  inline size_t GetNumIndexs(size_t table_no) const;

  int Serialize(FILE* fp);
  int Deserialize(FILE* fp);

  void CopyForRead(const Self& other);
 
 private:
  bool NodeParse_(const WeakType& node_wt, 
      SettreeNode<SetOpInterface>& node);

 private:
  inline static bool NodeParser_(
      void* arg, 
      const WeakType& node_wt,
      SettreeNode<SetOpInterface>& node);

 private:
  TablesNo tables_no_;
  Tables tables_;
  size_t current_table_no_;

  Settree<SetOpInterface> search_tree_;
};

int TablesMgr::AddRecord(const Record& record) {
  return tables_[record.GetTable().GetTableNo()].AddRecord(record);
}

int TablesMgr::ParseRecord(
    const std::string& table_name,
    const WeakType& syntax,
    Record*& record) {
  size_t table_no = GetTableNo(table_name);
  if (unlikely(0==table_no)) return ErrorNo::kNoSuchTable;
  return tables_[table_no].ParseRecord(syntax, record);
}

int TablesMgr::RemoveRecord(const Record& record) {
  return tables_[record.GetTable().GetTableNo()].RemoveRecord(record);
}

size_t TablesMgr::GetTableNo(const std::string& name) {
  TablesNo::iterator iter = tables_no_.find(name);
  return tables_no_.end() != iter ? iter->second : 0;
}

const Table& TablesMgr::GetTable(size_t table_no) const { 
  return tables_[table_no];
}

Table& TablesMgr::GetTable(size_t table_no) { 
  return tables_[table_no];
}

Record* TablesMgr::GetTmpRecord(size_t table_no) const { 
  return GetTable(table_no).GetTmpRecord(); 
}

size_t TablesMgr::GetNumIndexs(size_t table_no) const { 
  return tables_[table_no].GetNumIndexs();
}

bool TablesMgr::NodeParser_(
    void* arg, 
    const WeakType& node_wt,
    SettreeNode<SetOpInterface>& node) {
  return RCAST<TablesMgr*>(arg)->NodeParse_(node_wt, node);
}

}}
