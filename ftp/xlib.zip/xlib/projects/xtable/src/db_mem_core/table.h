#pragma once

#include "public.h"
#include "../db_device/db_device.h"
#include "versioned_table_schema.h"
#include "table_index/table_index.h"

namespace zmt { namespace material_center {

class Record;
class RoutineFileDumper;

class MapIndexs : public CowHashmap<std::string, TableIndex*> {
 public:
  typedef Super::Node Node;
  typedef Super::Key Key;
  typedef Super::Val Val;

 protected:
  virtual Node* GetNode_(const Key& key, const Val& val); 
  virtual void FreeNode_(Super::Node& node);
};

class Table {
 public:
  typedef Table Self;

 public:
  Table();
  Table(const Self& other);

  int CreateTable(
      const WeakType& syntax, 
      size_t table_no);

  int ChangeSchema(const WeakType& syntax);

  int AddRecord(const Record& record);
  int ParseRecord(
      IN const WeakType& record_syntax,
      OUT Record*& record);

  int RemoveRecord(const Record& record);

  bool SearchRecords(const WeakType& node_wt,
      SortedArrayInt64Set*& result);

  const std::string& GetName() const { return name_; }
  size_t GetTableNo() const { return table_no_; }
  inline const TableSchema* GetSchema(uint32_t version) const;
  inline const TableSchema& GetCurrentSchema() const; 
  inline size_t GetCurrentVersion() const;

  inline Record* GetTmpRecord() const { return tmp_record_; }
  inline TableIndex* GetIndex(const std::string& name) const;
  size_t GetNumIndexs() const { return table_indexs_.Size(); }
  inline bool IsValidSchemaVersion(size_t version) const;

  int Serialize(FILE* fp);
  int Deserialize(FILE* fp);
  void Copy(const Self& other);
  Self& operator=(const Self& other);
  void Clear();

  virtual ~Table();

 private:
  bool Init_();

 private:
  //const
  size_t table_no_;
  std::string name_;
  ///

  VersionedTableSchema table_schemas_; 
  MapIndexs table_indexs_;
  Record* tmp_record_;

  bool init_;
};

const TableSchema* Table::GetSchema(uint32_t version) const { 
  return table_schemas_.GetSchema(version); 
}

const TableSchema& Table::GetCurrentSchema() const {
  return table_schemas_.GetCurrentSchema();
}

size_t Table::GetCurrentVersion() const {
  return table_schemas_.GetCurrentVersion();
}

TableIndex* Table::GetIndex(const std::string& /*name*/) const {
  return NULL;
}

bool Table::IsValidSchemaVersion(size_t version) const {
  return table_schemas_.IsValidVersion(version);
}

}}
