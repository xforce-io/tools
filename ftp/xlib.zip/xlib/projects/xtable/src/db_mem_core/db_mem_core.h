#pragma once

#include "public.h"
#include "cow_lru_queue_hashmap_record_kv.hpp"
#include "../public/cow_lru_queue/cow_lru_queue.hpp"
#include "db_device/db_device.h"
#include "tables_mgr.h"

namespace zmt { namespace material_center {

class PoolReadRecs {
 private:
  typedef std::list<Record*> ContainerTmpRecs;
   
 private: 
  static const size_t kSizePoolReadRecs = 200;

 public:
  PoolReadRecs();
  inline void Reset(const Table* table=NULL);
  inline Record& GetRecord();
  virtual ~PoolReadRecs() { Reset(); }

 private:
  const Table* table_;
  Record records_[kSizePoolReadRecs];
  size_t num_used_;
  ContainerTmpRecs tmp_recs_;
};

/*
 * @note: TPD stands for thread private data
 */
class DBMemCoreTPD {
 private:
  class PoolReadRecsAtExitF {
   public: 
    void operator() (size_t& /*table_no*/, PoolReadRecs*& pool) {
      delete pool;
    }
  };
 
 private:
  static const size_t kNumPoolReadRecs=50;

 public:
  DBMemCoreTPD();
  inline ResultsGetRecord& GetResultsGetRecord();
  PoolReadRecs* GetPoolReadRec(size_t table_no);

 private:
  ResultsGetRecord results_;
  CowLRUQueue<
      size_t,
      PoolReadRecs*,
      std::tr1::hash<size_t>,
      std::equal_to<size_t>,
      PoolReadRecsAtExitF> pool_read_recs_;
};

class DBMemCore : public DataBase {
 public:
  typedef DataBase Super;
  typedef DBMemCore Self;
  typedef CowLRUQueue<Key, Record> LRUQueue;

  struct InitParams {
    DBDevice* db_device;
    size_t size_lru_queue;
    time_t tables_dump_interval;
    RoutineFileDumper* routine_file_dumper;
  };
 
 public:
  static const size_t kNoThreadPrivacy=1; 
  static const size_t kRetryTimesFlush=3;

 public:
  DBMemCore();
  bool Init(const std::string& name, void* init_params);
  int CreateTable(const std::string& syntax, LogicTime logic_time);
  int AddRecord(
      const std::string& table_name,
      const WeakType& syntax,
      LogicTime logic_time);

  int RemoveRecord(
      const std::string& table_name,
      const WeakType& keys_to_remove,
      LogicTime logic_time);

  int GetRecord(
      const std::string& table_name,
      const WeakType& records,
      ResultsGetRecord*& results);

  inline void GetCurrentDevicePos(DevicePos& device_pos) const;
  bool ReplayDeviceLog(const DeviceLog& device_log);
  int Serialize(FILE* fp);
  int Deserialize(FILE* fp);
  virtual ~DBMemCore();

 private:
  static int Dumper_(void* self, FILE* fp);
 
 private:
  int CreateTable_(const std::string& syntax);
  int AddRecord_(const Record& record);
  void RemoveRecord_(const Key* key, size_t num_keys);

  bool Load_(const DataBase& prev_db);

  inline ResultsGetRecord& GetResultsGetRecs_();
  inline PoolReadRecs* GetPoolReadRec_(size_t table_no);
  inline int GetRecordFromDevice_(Key key, Record& record);
  void GetDevicePos(DevicePos& DevicePos);

  void CopyForRead_(const Self& other);
  inline void PublishReadOnlyVersion_();

 private:
  //const
  DBDevice* db_device_;
  ///

  TablesMgr tables_mgr_;
  LRUQueue* lru_;
  char* buf_;
  size_t size_buf_;

  ThreadPrivacy thread_privacy_;
  LogicTime logic_time_;

  bool read_version_consumed_;
  Self* version_for_read_;
  DevicePos current_device_pos_;
};

void PoolReadRecs::Reset(const Table* table) {
  if (unlikely(
      NULL!=table
      && (NULL==table_ 
          || table->GetTableNo() != table_->GetTableNo()))) {
    Record record(*table);
    for (size_t i=0; i < sizeof(records_)/sizeof(records_[0]); ++i) {
      records_[i] = record;
    }
  }

  num_used_=0;
  for (ContainerTmpRecs::iterator iter = tmp_recs_.begin();
      iter != tmp_recs_.end();
      ++iter) {
    delete *iter;
  }
  tmp_recs_.clear();
}

Record& PoolReadRecs::GetRecord() {
  if (likely(num_used_!=kSizePoolReadRecs)) {
    return records_[num_used_++];
  }

  Record* new_rec;
  MEGA_NEW(new_rec, Record(records_[0].GetTable()))
  tmp_recs_.push_back(new_rec);
  return *new_rec;
}

ResultsGetRecord& DBMemCoreTPD::GetResultsGetRecord() {
  return results_;
}

ResultsGetRecord& DBMemCore::GetResultsGetRecs_() {
  void* thread_privacy = thread_privacy_.Get<DBMemCoreTPD>(kNoThreadPrivacy);
  return RCAST<DBMemCoreTPD*>(thread_privacy)->GetResultsGetRecord();
}

PoolReadRecs* DBMemCore::GetPoolReadRec_(size_t table_no) {
  void* thread_privacy = thread_privacy_.Get<DBMemCoreTPD>(kNoThreadPrivacy);
  return RCAST<DBMemCoreTPD*>(thread_privacy)->GetPoolReadRec(table_no);
}

int DBMemCore::GetRecordFromDevice_(Key key, Record& record) {
  DeviceLog* device_log;
  int ret = db_device_->GetRecord(key, device_log);
  if (unlikely(ErrorNo::kSucc != ret)) return ret;

  ret = record.Deserialize(device_log->GetContent(), device_log->GetContentLen());
  if (0!=ret) {
    FATAL("fail_deserialize_record key[" << key << "]");
    return ErrorNo::kOther;
  }
  return ErrorNo::kSucc;
}

void DBMemCore::GetCurrentDevicePos(DevicePos& device_pos) const {
  device_pos=current_device_pos_;
}

void DBMemCore::PublishReadOnlyVersion_() {
  if (unlikely(true==read_version_consumed_)) {
    CopyForRead_(*this);
    db_device_->GetDevicePos(current_device_pos_);
    read_version_consumed_=false;
  }
}

}}
