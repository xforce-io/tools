#pragma once

#include "fields/field_type.h"
#include "fields/str_field.h"
#include "table.h"

namespace zmt { namespace material_center {

class Record {
 private:
  typedef Record Self;
  
 public:
  Record();
  explicit Record(const Table& table);
  explicit Record(const Self& other);
 
  bool Parse(const WeakType& syntax);

  inline const Table& GetTable() const { return *table_; }

  inline bool SetInt(size_t col, int64_t val);
  inline bool SetStr(size_t col, const std::string& val);
  inline bool InsertIntoIntSet(size_t col, const std::string& val);
  inline bool EraseFromIntSet(size_t col, const std::string& val);

  inline int64_t GetTableKey() const;
  inline Key GetKey() const;
  inline int64_t GetInt(size_t col) const;
  inline const char* GetStr(size_t col) const;
  inline StrField* GetStrField(size_t col) const;
  inline const BaseIntSetField* GetIntSet(size_t col) const;
  
  /*
   * @return: number of bytes of serialized result
   */
  inline int Serialize(char* buf, size_t size_buf);
  inline int Deserialize(const char* buf, size_t size_buf);

  /*
   * @return: 0 if succ, <0 if fail
   */
  inline int Serialize(FILE* fp);
  inline int Deserialize(FILE* fp);

  Self& operator=(const Self& other);

  virtual ~Record();

 public:
  inline bool UpdateSchema_();
  inline const TableSchema& GetTableSchema_() const;
  inline void Clear_();
  inline void ClearField_();
  void Init_();

 private:
  //const
  const Table* table_;
  ///

  uint32_t version_schema_;
  void* fields_;

  friend std::ostream& operator<<(std::ostream& os, const Record& record);
};

bool Record::SetInt(size_t col, int64_t val) {
  if (unlikely(true != UpdateSchema_())) return false;
  return GetTableSchema_().SetInt(fields_, col, val);
}

bool Record::SetStr(size_t col, const std::string& val) {
  if (unlikely(true != UpdateSchema_())) return false;
  return GetTableSchema_().SetStr(fields_, col, val);
}

bool Record::InsertIntoIntSet(size_t col, const std::string& vals) {
  if (unlikely(true != UpdateSchema_())) return false;
  return GetTableSchema_().InsertIntoIntSet(fields_, col, vals);
}

bool Record::EraseFromIntSet(size_t col, const std::string& vals) {
  return UpdateSchema_() &&
    GetTableSchema_().EraseFromIntSet(fields_, col, vals);
}

int64_t Record::GetTableKey() const {
  return GetTableSchema_().GetTableKey(fields_);
}

Key Record::GetKey() const { 
  UnionKey union_key(
      table_->GetTableNo(), 
      GetTableSchema_().GetTableKey(fields_)); 
  return union_key.Encode();
}

int64_t Record::GetInt(size_t col) const {
  return GetTableSchema_().GetInt(fields_, col);
}

const char* Record::GetStr(size_t col) const {
  return GetTableSchema_().GetStr(fields_, col);
}

StrField* Record::GetStrField(size_t col) const {
  return GetTableSchema_().GetStrField(fields_, col);
}

const BaseIntSetField* Record::GetIntSet(size_t col) const {
  return GetTableSchema_().GetIntSet(fields_, col);
}

int Record::Serialize(char* buf, size_t size_buf) {
  return GetTableSchema_().Serialize(fields_, buf, size_buf);
}

int Record::Deserialize(const char* buf, size_t size_buf) {
  return GetTableSchema_().Deserialize(buf, size_buf, fields_);
}

int Record::Serialize(FILE* fp) {
  return GetTableSchema_().Serialize(fields_, fp);
}

int Record::Deserialize(FILE* fp) {
  return GetTableSchema_().Deserialize(fp, fields_);
}

bool Record::UpdateSchema_() {
  if (likely(version_schema_ == table_->GetCurrentVersion())) {
    return true;
  }

  void* new_fields = table_->GetCurrentSchema().Update(
      fields_, 
      GetTableSchema_());
  if (NULL==new_fields) return false;

  ClearField_();
  fields_=new_fields;
  return true;
}

const TableSchema& Record::GetTableSchema_() const {
  return *(table_->GetSchema(version_schema_));
}

void Record::Clear_() {
  if (NULL==table_) return;
  ClearField_();
  table_=NULL;
}

void Record::ClearField_() {
  if (NULL==fields_) return;

  for (size_t i=0; i < GetTableSchema_().Size(); ++i) {
    RealFieldType::Type type = GetTableSchema_().GetType(i);
    if (RealFieldType::kStr == type) {
      StrField* str_field = GetStrField(i);
      if (NULL!=str_field) delete str_field; 
    } else if (RealFieldType::kSet8 <= type && RealFieldType::kSet64 >= type) {
      const BaseIntSetField* intset = GetIntSet(i);
      if (NULL!=intset) delete intset;
    }
  }
  MEGA_FREE(fields_)
}

inline std::ostream& operator<<(std::ostream& os, const Record& record) {
  os << "{";
  for (size_t i=0; i < record.GetTableSchema_().Size(); ++i) {
    if (RealFieldType::kStr == record.GetTableSchema_().GetType(i)) {
      os << record.GetStr(i) << ",";
    } else {
      os << record.GetInt(i) << ",";
    }
  }
  os << "}";
  return os;
}

}}
