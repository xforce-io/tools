#pragma once

#include <stddef.h>
#include <stdint.h>
#include <limits.h>
#include "../local_limits.h"

namespace zmt { namespace material_center {

namespace Limits {

static const size_t kMaxNumRemovedKeys = 10000;
static const size_t kMaxSizeSyntax = 10000;

};

}}
