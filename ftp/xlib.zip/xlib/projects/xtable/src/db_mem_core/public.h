#pragma once

#include "../public.h"
#include "local_limits.h"

namespace zmt { namespace material_center {

struct IndexerSeq {
  enum { 
    Inc=0, 
    Dec, 
    kNumIndexSeq,
  };
};

struct IndexerOps {
 public: 
  enum {
    None,
    And,
    Or,
    Not,
    Priority,
    Resolve,
    kNumIndexerOps,
  };
};

}}
