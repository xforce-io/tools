#pragma once

#include "public.h"
#include "device_log.h"

namespace zmt { namespace material_center {

class DBDeviceFile {
 public: 
  static const std::string kDBFileDir;
  static const std::string kDBFilePrefix;
 
 public: 
  static std::string GetDBFilepath(int index);

  /*
   * @brief: get last db file path
   * @return: 
   *    >0: no suitable filepath
   *   ==0: success
   *    <0: error happened
   */
  static int GetLastDBFilePath(int& current_index);
};

class DBDeviceFileWriteHandle {
 public:
  struct FlushUnit {
    char* addr;
    size_t len;
  };

 public:
  static const size_t kTimesFlushRetry=3;
  static char* const kInvalidAddr;

 public:
  DBDeviceFileWriteHandle(size_t max_size_block);

  /*
   * @parameters:
   *    index: index of the db file, if -1, seek to the last file
   */
  bool Reset(int index, off_t offset=0);

  /*
   * @return: 
   *    ==0: valid log here
   *    >0 : uninit log here
   *    <0 : log corrupt
   */
  int HasValidLogHere();

  inline bool HasSpaceForNewLog(const FlushMsg& msg);
  void WriteCurrentLog(const FlushMsg& msg);

  /*
   * @note: can be called only when HasValidLogHere return 0
   */
  inline void PassLog();
  inline bool MapReadLock();
  inline void MapUnlock();

  int GetIndex() const { return index_; }
  inline off_t GetOffset() const;
  DeviceLog* GetCurrentLog() { return cur_log_; }
  inline DeviceLog* GetLog(off_t offset);
  bool IsValid() const { return -1!=index_; }
  void Flush();
  virtual ~DBDeviceFileWriteHandle();

 private:
  ssize_t EnsureFilesize_(int fd);
  void Close_(); 
 
 private:
  //const
  size_t max_size_block_;
  ///

  int index_;
  std::string filepath_;
  int fd_;

  char* start_addr_;
  DeviceLog* cur_log_;
  int room_left_;

  std::list<FlushUnit> flush_units_;
  pthread_rwlock_t rwlock_;
};

class DBDeviceFileReadHandle {
 public:
  DBDeviceFileReadHandle();
  bool Reset(int index, off_t offset=0);

  /*
   * @return: 
   *   ==0: valid log here
   *    >0 : uninit log here
   *    <0 : log corrupt
   */
  inline int ReadLog(DeviceLog& device_log);

  int GetIndex() const { return index_; }
  off_t GetOffset() const { return ftell(fp_); }
  bool IsValid() const { return -1!=index_; }
  virtual ~DBDeviceFileReadHandle();

 private: 
  void Close_();
 
 private:
  int index_;
  std::string filepath_;
  FILE* fp_;
};

bool DBDeviceFileWriteHandle::HasSpaceForNewLog(
    const FlushMsg& msg) {
  return room_left_ >= static_cast<ssize_t>(
      msg.msg.Size() + cur_log_->GetContentOffset() + sizeof(cur_log_->checksum_));
}

void DBDeviceFileWriteHandle::PassLog() {
  cur_log_ = RCAST<DeviceLog*>(
      RCAST<char*>(cur_log_) + cur_log_->GetSize());
}

bool DBDeviceFileWriteHandle::MapReadLock() {
  return 0 == pthread_rwlock_rdlock(&rwlock_);
}

void DBDeviceFileWriteHandle::MapUnlock() {
  pthread_rwlock_unlock(&rwlock_);
}

off_t DBDeviceFileWriteHandle::GetOffset() const {
  return RCAST<char*>(cur_log_) - start_addr_;
}

DeviceLog* DBDeviceFileWriteHandle::GetLog(off_t offset) { 
  return RCAST<DeviceLog*>(start_addr_+offset); 
}

int DBDeviceFileReadHandle::ReadLog(DeviceLog& device_log) {
  int ret = device_log.ReadFrom(fp_);
  if (ret<0) FATAL("fail_read_device_log_from_fp ret[" << ret << "]");
  return ret;
}

}}
