#pragma once

#include "public.h"

namespace zmt { namespace material_center {

class DeviceLog {
 public: 
  typedef DeviceLog Self;
  
 public:
  /*
   * @note: magic number indicates end of a db file, set in checksum
   */
  static const uint32_t kEndMagic = 0x9ED0A676;
   
 public:
  inline DeviceLog& operator=(const Self& other);
  void Assign(const FlushMsg& msg);
  inline bool CheckChecksum() const;

  /*
   * @return:
   *    ==0 : ok
   *    > 0 : end
   *    < = : error
   */
  int ReadFrom(FILE* fp);

  inline void MarkLastLog() { checksum_=kEndMagic; }

  uint32_t GetChecksum() const { return checksum_; }
  Cmd::EnumCmd GetCmd() const { return cmd_; }
  size_t GetLogicTime() const { return logic_time_; }
  Key GetKey() const { return key_; }
  int GetContentLen() const { return len_; }
  const char* GetContent() const { return content_; }
  inline static size_t GetContentOffset();
  size_t GetSize() const { return GetContentOffset() + len_; }
  inline size_t DeviceSpaceAquired() const;

  bool IsEnd() const { return checksum_ == kEndMagic; }
 
 private:
  inline void GenChecksum_();

 private:
  uint32_t checksum_;
  Cmd::EnumCmd cmd_;
  size_t logic_time_;
  Key key_;
  int len_;
  char content_[];
};

DeviceLog& DeviceLog::operator=(const Self& other) {
  memcpy(&checksum_, &(other.checksum_), GetContentOffset() + other.len_);
  return *this;
}

bool DeviceLog::CheckChecksum() const {
  return Crc32Checker::Check(RCAST<const char*>(&checksum_), 
      DeviceLog::GetContentOffset() + len_);
}

void DeviceLog::GenChecksum_() {
  checksum_ = Crc32Checker::Gen(RCAST<const char*>(&cmd_), 
      DeviceLog::GetContentOffset() - sizeof(checksum_) + len_);
}

size_t DeviceLog::GetContentOffset() { 
  return offsetof(DeviceLog, content_); 
}

size_t DeviceLog::DeviceSpaceAquired() const {
  return GetContentOffset() + len_ + sizeof(checksum_);
}

}}
