#pragma once

#include "public.h"
#include "../key.h"

namespace zmt { namespace material_center {

class DBDeviceIndex : public DataBase {
 public:
  typedef DataBase Super;
  typedef CowHashmap<Key, DevicePos> Index;
  typedef Index::ConstIterator ConstIterator;
  typedef Index::Iterator Iterator;
 
 public:
  DBDeviceIndex();
  bool Init(const std::string& db_name, void* /*args*/);
  bool Find(IN Key key, OUT DevicePos& device_pos) const;
  inline std::pair<bool, Iterator> Insert(
      Key key, 
      const DevicePos& device_pos,
      size_t logic_time);

  inline bool Erase(Key key, const DevicePos& device_pos, size_t logic_time);
  int Serialize(FILE* fp);
  int Deserialize(FILE* fp);
  void Clear() { records_pos_.Clear(); }
  bool Copy(const DBDeviceIndex& db_device_index);
  const DevicePos& GetDevicePos() const { return device_pos_; }
  LogicTime GetLogicTime() const { return logic_time_; }
  void Dump(std::ostream& os) { os << records_pos_; }

 private:
  bool Load_(const DataBase& prev_db);

 private:
  CowHashmap<Key, DevicePos> records_pos_;
  DevicePos device_pos_;
  size_t logic_time_; 
};

std::pair<bool, CowHashmap<Key, DevicePos>::Iterator> 
DBDeviceIndex::Insert(
    Key key, 
    const DevicePos& device_pos,
    size_t logic_time) {
  std::pair<bool, CowHashmap<Key, DevicePos>::Iterator> ret = 
    records_pos_.Insert(key, device_pos);
  if (true == ret.first) logic_time_=logic_time;
  device_pos_=device_pos;
  return ret;
}

bool DBDeviceIndex::Erase(Key key, const DevicePos& device_pos, size_t logic_time) { 
  bool ret = records_pos_.Erase(key); 
  if (true==ret) logic_time_=logic_time;
  device_pos_=device_pos;
  return ret;
}

}}
