#pragma once

#include "public.h"
#include "db_device_index.h"
#include "db_device_file.h"

namespace zmt { namespace material_center {

struct DBMem;

/*
 * @note: TPD stands for thread private data
 */
class DBDeviceTPD {
 public:
  DBDeviceTPD();

  DBDeviceFileReadHandle& GetReadHandle() { return read_handle_; }
  inline DeviceLog* GetBufRecord();

  virtual ~DBDeviceTPD();
 
 private:
  bool Init_(); 

 private: 
  DBDeviceFileReadHandle read_handle_;
  DeviceLog* buf_record_;

  bool init_;
};

class DBDevice {
 public:
  typedef bool (*CallbackReplyLog)(DBMem&, const DeviceLog& device_log);

 public:
  static const int kTimesFlushRetry=3; 
  static const size_t kNumVersionsDBDevice=3;
  static const size_t kNoThreadPrivacy=1;
  static const std::string kDeviceIndexFilename;

 public:
  DBDevice();
  bool Init(
      size_t max_size_block,
      time_t index_dump_interval_sec,
      time_t flush_interval_sec,
      RoutineFileDumper& routine_file_dumper,
      DBMem& db_mem,
      CallbackReplyLog callback_reply_log,
      bool& end);

  bool StartDumpThread();

  int ProcessFlushMsg(const FlushMsg& flush_msg);

  int GetRecord(Key key, DeviceLog*& device_log);
  inline void GetDevicePos(DevicePos& device_pos);
  inline bool HasRecord(Key key);

  virtual ~DBDevice();

 private:
  inline static void* DumpIndex_(void* args);
  static int IndexDumper_(void* self, FILE* fp);

 private: 
  bool RestoreDeviceIndex_();
  bool OpenCurrentDBFileWhenInit_();
  bool ReplayDeviceLog_(const DeviceLog& device_log, DevicePos& device_pos);

  void DumpDeviceIndex_();
  bool OpenCurrentDBFileForWrite_();
  bool OpenNewDBFileForWrite_();
  ///

  inline DBDeviceFileReadHandle& GetReadHandle_();
  inline DeviceLog* GetBufRecord_();
  const DBDeviceIndex& GetDBDeviceIndexForDump_() const { return index_for_dump_; }

 private:
  //const
  std::string dir_;
  std::string prefix_;
  std::string device_index_filename_;
  size_t max_size_block_;
  time_t index_dump_interval_sec_;
  time_t flush_interval_sec_;
  DBMem* db_mem_;
  CallbackReplyLog callback_replay_log_;
  bool* end_;
  ///

  int current_index_;
  int max_index_;
  DBDeviceFileWriteHandle* write_handle_;
  time_t last_flush_time_;

  VersionManager<DBDeviceIndex, ReloadAlways> db_device_index_;
  DBDeviceIndex index_for_dump_;
  bool is_index_for_dump_consumed_;

  pthread_t tid_;

  ThreadPrivacy thread_privacy_;
  time_t last_index_dump_time_;
};

DeviceLog* DBDeviceTPD::GetBufRecord() { 
  MEGA_RAII_INIT(buf_record_)
  return buf_record_; 
}

void DBDevice::GetDevicePos(DevicePos& device_pos) {
  device_pos.index = write_handle_->GetIndex();
  device_pos.offset = write_handle_->GetOffset();
}

bool DBDevice::HasRecord(Key key) {
  const DBDeviceIndex& db_device_index = db_device_index_.GetDB();
  DevicePos device_pos;
  return db_device_index.Find(key, device_pos);
}

void* DBDevice::DumpIndex_(void* args) {
  std::cout << "dump_index start" << std::endl;
  DBDevice& db_device = *RCAST<DBDevice*>(args);
  while (false == *db_device.end_) {
    db_device.DumpDeviceIndex_();
  }
  std::cout << "dump_index stop" << std::endl;
  return NULL;
}

DBDeviceFileReadHandle& DBDevice::GetReadHandle_() { 
  void* thread_privacy = thread_privacy_.Get<DBDeviceTPD>(kNoThreadPrivacy); 
  return RCAST<DBDeviceTPD*>(thread_privacy)->GetReadHandle();
}

DeviceLog* DBDevice::GetBufRecord_() {
  void* thread_privacy = thread_privacy_.Get<DBDeviceTPD>(kNoThreadPrivacy); 
  return RCAST<DBDeviceTPD*>(thread_privacy)->GetBufRecord();
}

}}
