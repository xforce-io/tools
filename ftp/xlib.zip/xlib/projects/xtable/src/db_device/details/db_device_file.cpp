#include "../db_device_file.h"

#include <dirent.h>
#include <fcntl.h>
#include <sys/mman.h>

namespace zmt { namespace material_center {

const std::string DBDeviceFile::kDBFileDir = "data";
const std::string DBDeviceFile::kDBFilePrefix= "db";
char* const DBDeviceFileWriteHandle::kInvalidAddr = RCAST<char* const>(-1);

std::string DBDeviceFile::GetDBFilepath(int index) {
  char buf_path[Limits::kMaxSizePath];
  snprintf(
      buf_path, 
      sizeof(buf_path), 
      "%s/%s%u", 
      kDBFileDir.c_str(), 
      kDBFilePrefix.c_str(), 
      index);
  return buf_path;
}

int DBDeviceFile::GetLastDBFilePath(int& current_index) {
  DIR* dp = opendir(kDBFileDir.c_str());
  if (NULL==dp) {
    FATAL("fail_open_dir[" << kDBFileDir << "]");
    return -1;
  }

  current_index=-1;
  dirent* dirp;
  while ( (dirp = readdir(dp)) != NULL ) {
    if ( 0 != strncmp(dirp->d_name, kDBFilePrefix.c_str(), 
        kDBFilePrefix.length()) ) {
      continue;
    }

    int index = atol( dirp->d_name + kDBFilePrefix.length() );
    if (index>current_index) current_index=index;
  }
  closedir(dp);
  return -1!=current_index ? 0 : 1;
}

DBDeviceFileWriteHandle::DBDeviceFileWriteHandle(
    size_t max_size_block) :
  max_size_block_(max_size_block),
  index_(-1),
  fd_(-1),
  start_addr_(kInvalidAddr),
  cur_log_(NULL) {
  MEGA_ASSERT(0 == pthread_rwlock_init(&rwlock_, NULL));
}

bool DBDeviceFileWriteHandle::Reset(int index, off_t offset) {
  int ret;
  int new_fd;
  ssize_t filesize;
  char* new_addr;

  MEGA_FAIL_HANDLE_FATAL(offset > static_cast<off_t>(max_size_block_),
      "offset_too_big_for_write_handle[" << offset << "]");

  if (-1==index) {
    ret = DBDeviceFile::GetLastDBFilePath(index);
    if (ret>0) {
      index=0;
    } else if (ret<0) {
      MEGA_FAIL_HANDLE_FATAL(true,
          "fail_seek_write_handle_to_last_db_file");
    }
  }

  if (index!=index_) {
    std::string new_filepath = DBDeviceFile::GetDBFilepath(index);
    new_fd = open(new_filepath.c_str(), O_RDWR|O_CREAT, 0664);
    MEGA_FAIL_HANDLE_FATAL(new_fd<0,
        "fail_open_file_for_write[" << new_filepath << "]")

    filesize = EnsureFilesize_(new_fd);
    MEGA_FAIL_HANDLE(filesize<0)

    new_addr = RCAST<char*>(
      mmap(0, max_size_block_, PROT_READ|PROT_WRITE, 
          MAP_SHARED, new_fd, 0));
    MEGA_FAIL_HANDLE_FATAL(kInvalidAddr==new_addr,
        "fail_mmap_new_dbfile[" << new_filepath << "]")

    Close_();
    filepath_=new_filepath;
    fd_=new_fd;
    start_addr_=new_addr;
    cur_log_ = RCAST<DeviceLog*>(start_addr_);
    if (0==filesize) cur_log_->MarkLastLog();
    room_left_=max_size_block_;
    index_=index; //set last because it indicates validation
  }

  ret = lseek(fd_, offset, SEEK_SET);
  MEGA_FAIL_HANDLE_FATAL(ret<0, "fail_seek_to_offset[" 
      << offset << "] in_path[" << filepath_ << "]");
  return true;

  ERROR_HANDLE:
  return false;
}

int DBDeviceFileWriteHandle::HasValidLogHere() {
  size_t content_offset = DeviceLog::GetContentOffset();
  ssize_t room_left = max_size_block_ - 
    (RCAST<const char*>(cur_log_) - start_addr_);
  if (room_left < static_cast<ssize_t>(content_offset)
      || true == cur_log_->IsEnd() ) {
    return 1;
  }

  if ( room_left < static_cast<ssize_t>(cur_log_->DeviceSpaceAquired())
      || true != cur_log_->CheckChecksum() ) {
    FATAL("device_log_corrupt_detected index["
        << index_
        << "] offset["
        << GetOffset()
        << "]");
    return -1;
  }
  return 0;
}

void DBDeviceFileWriteHandle::WriteCurrentLog(const FlushMsg& msg) {
  cur_log_->Assign(msg);

  size_t bytes_written = cur_log_->GetSize();
  FlushUnit& last_flush_unit = flush_units_.back();
  if (RCAST<char*>(cur_log_) ==
      last_flush_unit.addr+last_flush_unit.len) {
    last_flush_unit.len += bytes_written;
  } else {
    flush_units_.push_back(
        (struct FlushUnit){
          RCAST<char*>(cur_log_),
          bytes_written});
  }

  cur_log_ = RCAST<DeviceLog*>(
      RCAST<char*>(cur_log_) + bytes_written);
  cur_log_->MarkLastLog();
  room_left_-=bytes_written;
}

DBDeviceFileWriteHandle::~DBDeviceFileWriteHandle() {
  Close_();
  pthread_rwlock_destroy(&rwlock_);
}

ssize_t DBDeviceFileWriteHandle::EnsureFilesize_(int fd) {
  struct stat st;
  char boundary=0;
  ssize_t ret = fstat(fd, &st);
  MEGA_FAIL_HANDLE_FATAL(0!=ret,
      "fail_fstat error[" << strerror(errno) << "]")

  if (st.st_size >= static_cast<ssize_t>(max_size_block_)) {
    return true;
  }

  ret = lseek(fd, max_size_block_, SEEK_SET);
  MEGA_FAIL_HANDLE_FATAL(-1==ret, 
      "fail_lseek error[" << strerror(errno) << "]")

  ret = write(fd, &boundary, sizeof(boundary));
  MEGA_FAIL_HANDLE_FATAL(ret != sizeof(boundary), 
      "fail_write error[" << strerror(errno) << "]")
  return st.st_size;

  ERROR_HANDLE:
  return -1;
}

void DBDeviceFileWriteHandle::Close_() {
  index_=-1;
  Flush();
  if (kInvalidAddr!=start_addr_) {
    pthread_rwlock_wrlock(&rwlock_);
    munmap(start_addr_, max_size_block_);
    start_addr_=kInvalidAddr;
    pthread_rwlock_unlock(&rwlock_);
  }

  if (-1!=fd_) {
    close(fd_);
    fd_=-1;
  }
}

void DBDeviceFileWriteHandle::Flush() {
  int ret;
  FlushUnit flush_unit;
  while (false == flush_units_.empty()) {
    flush_unit = flush_units_.front();
    ret = msync(RCAST<void*>(flush_unit.addr), flush_unit.len, MS_SYNC);
    if (0==ret) {
    } else { 
      size_t i;
      for (i=0; i<kTimesFlushRetry-1; ++i) {
        ret = msync(
            RCAST<void*>(flush_unit.addr), 
            flush_unit.len, 
            MS_SYNC);
        if (0==ret) break;
      }

      if (kTimesFlushRetry-1 == i) {
        FATAL("fail_msync current_index[" 
          << index_ 
          << "] error["
          << strerror(errno)
          << "]");
      }
    }
    flush_units_.pop_front();
  }
}

DBDeviceFileReadHandle::DBDeviceFileReadHandle() :
  index_(-1),
  fp_(NULL) {}

bool DBDeviceFileReadHandle::Reset(int index, off_t offset) {
  if (index!=index_) {
    std::string new_filepath = DBDeviceFile::GetDBFilepath(index);
    FILE* new_fp = fopen(new_filepath.c_str(), "r");
    if (NULL==new_fp) {
      FATAL("fail_open_file_for_read[" << new_filepath << "]");
      return false;
    }

    Close_();
    filepath_=new_filepath;
    fp_=new_fp;
    index_=index; //set last because it indicates validation
  }

  int ret = fseek(fp_, offset, SEEK_SET);
  if (0!=ret) {
    FATAL("filepath[" 
        << filepath_ 
        << "] fail_seek_to["
        << offset
        << "]");
    return false;
  }
  return true;
}

DBDeviceFileReadHandle::~DBDeviceFileReadHandle() {
  Close_();
}

void DBDeviceFileReadHandle::Close_() {
  index_=-1;
  if (NULL!=fp_) {
    fclose(fp_);
    fp_=NULL;
  }
}

}}
