#include "../db_device_index.h"
#include "../../io_helper.h"

namespace zmt { namespace material_center {

DBDeviceIndex::DBDeviceIndex() :
  logic_time_(0) {}

bool DBDeviceIndex::Init(const std::string& db_name, void* /*args*/) {
  Super::Init_(db_name);
  return true;
}

bool DBDeviceIndex::Find(Key key, DevicePos& device_pos) const {
  ConstIterator iterator = records_pos_.Find(key);
  if (unlikely(records_pos_.End() == iterator)) return false;

  device_pos = iterator.GetVal();
  return true;
}

int DBDeviceIndex::Serialize(FILE* fp) {
  bool ret = IOHelper::WriteInt(device_pos_.index, fp);
  if (true!=ret) return -1;

  ret = IOHelper::WriteInt(device_pos_.offset, fp);
  if (true!=ret) return -2;

  ret = IOHelper::WriteInt(logic_time_, fp);
  if (true!=ret) return -3;

  size_t num_records = records_pos_.Size();
  ret = IOHelper::WriteInt(num_records, fp);
  if (true!=ret) return -4;

  for (Index::Iterator iter = records_pos_.Begin(); 
      iter != records_pos_.End();
      ++iter) {
    ret = IOHelper::WriteInt(iter.GetKey(), fp);
    if (true!=ret) return -5;

    ret = IOHelper::WriteInt(iter.GetVal().index, fp);
    if (true!=ret) return -6;

    ret = IOHelper::WriteInt(iter.GetVal().offset, fp);
    if (true!=ret) return -7;
  }
  return 0;
}

int DBDeviceIndex::Deserialize(FILE* fp) {
  if (NULL==fp) {
    records_pos_.Clear();
    device_pos_.index = 0;
    device_pos_.offset = 0;
    return 0;
  }

  int64_t tmp;
  bool ret = IOHelper::ReadInt(fp, tmp);
  if (true!=ret) return -1;
  device_pos_.index = tmp;

  ret = IOHelper::ReadInt(fp, tmp);
  if (true!=ret) return -2;
  device_pos_.offset = tmp;

  ret = IOHelper::ReadInt(fp, tmp);
  if (true!=ret) return -3;
  logic_time_=tmp;

  int64_t num_records;
  ret = IOHelper::ReadInt(fp, num_records);
  if (true!=ret) return -4;

  Key key;
  DevicePos device_pos;
  for (int64_t i=0; i<num_records; ++i) {
    ret = IOHelper::ReadInt(fp, key);
    if (true!=ret) return -5;

    ret = IOHelper::ReadInt(fp, tmp);
    if (true!=ret) return -6;
    device_pos.index = tmp;

    ret = IOHelper::ReadInt(fp, tmp);
    if (true!=ret) return -7;
    device_pos.offset = tmp;

    ret = (records_pos_.Insert(key, device_pos)).first;
    if (true!=ret) return -8;
  }
  return 0;
}

bool DBDeviceIndex::Copy(const DBDeviceIndex& db_device_index) {
  if (this == &db_device_index) return true;

  Super::operator=(db_device_index);
  device_pos_ = db_device_index.device_pos_;
  logic_time_ = db_device_index.logic_time_;
  return records_pos_.Copy(db_device_index.records_pos_);
}

bool DBDeviceIndex::Load_(const DataBase& prev_db) {
  bool ret = records_pos_.Copy(
      static_cast<const DBDeviceIndex&>(prev_db).records_pos_);
  if (unlikely(false==ret)) {
    FATAL("fail_in_copy_cow_hashmap");
    return false;
  }

  logic_time_ = static_cast<const DBDeviceIndex&>(prev_db).logic_time_;
  return true;
}

}}
