#include "../db_device.h"

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/types.h>
#include "../../db_mem.h"

namespace zmt { namespace material_center {

DBDeviceTPD::DBDeviceTPD() : 
  buf_record_(NULL),
  init_(false) {}

bool DBDeviceTPD::Init_() {
  size_t size_buf_record = 
    Limits::kMaxSizeRecord + DeviceLog::GetContentOffset();
  buf_record_ = RCAST<DeviceLog*>(
      new (std::nothrow) char [size_buf_record]);
  if (NULL==buf_record_) return false;

  init_=true;
  return true;
}

DBDeviceTPD::~DBDeviceTPD() {
  if (true!=init_) return;
  char* buf = RCAST<char*>(buf_record_);
  MEGA_DELETE_ARRAY(buf)
}

const std::string DBDevice::kDeviceIndexFilename = "device_index";

DBDevice::DBDevice() :
  write_handle_(NULL),
  is_index_for_dump_consumed_(true),
  tid_(0),
  last_index_dump_time_(clock()) {}

DBDevice::~DBDevice() {
  if (0!=tid_) pthread_join(tid_, NULL);
  MEGA_DELETE(write_handle_)
}

bool DBDevice::Init(
    size_t max_size_block,
    time_t index_dump_interval,
    time_t flush_interval_sec,
    RoutineFileDumper& routine_file_dumper,
    DBMem& db_mem,
    CallbackReplyLog callback_replay_log,
    bool& end) {
  int ret;

  dir_ = DBDeviceFile::kDBFileDir;
  prefix_ = DBDeviceFile::kDBFilePrefix;
  device_index_filename_=kDeviceIndexFilename;
  max_size_block_=max_size_block;
  index_dump_interval_sec_=index_dump_interval;
  flush_interval_sec_=flush_interval_sec;
  db_mem_=&db_mem;
  callback_replay_log_=callback_replay_log;
  end_=&end;

  current_index_=max_index_=-1;
  MEGA_NEW(write_handle_, DBDeviceFileWriteHandle(max_size_block_))
  last_flush_time_=clock();

  ret = db_device_index_.Init("db_device", NULL, NULL, 3);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_init_db_device_index")

  index_for_dump_.Init("index_for_dump", NULL);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_init_index_for_dump")

  //restore index
  ret = db_device_index_.CreateNewVersion();
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_create_db_device_index_version")

  ret = RestoreDeviceIndex_();
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_restore_device_index")

  ret = OpenCurrentDBFileWhenInit_();
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_open_current_dbfile_when_init")

  ret = routine_file_dumper.RegisteDumpTask(
      "db_device_dump",
      IndexDumper_, 
      RCAST<void*>(this), 
      dir_,
      device_index_filename_,
      index_dump_interval);
  MEGA_FAIL_HANDLE_FATAL(true!=ret, "fail_registe_device_file_dump_task")

  db_device_index_.FreezeNewVersion();
  return true;

  ERROR_HANDLE:
  db_device_index_.FreezeNewVersion();
  return false;
}

bool DBDevice::StartDumpThread() {
  return 0 == pthread_create(&tid_, NULL, DumpIndex_, this);
}

int DBDevice::GetRecord(Key key, DeviceLog*& device_log) {
  const DBDeviceIndex& db_device_index = db_device_index_.GetDB();
  DevicePos device_pos;
  bool ret = db_device_index.Find(key, device_pos);
  if (unlikely(true!=ret)) return ErrorNo::kNoSuckKey;

  device_log = GetBufRecord_();
  if ( device_pos.index == write_handle_->GetIndex()
      && true == write_handle_->MapReadLock()
      && true == write_handle_->IsValid()
      && device_pos.index == write_handle_->GetIndex() ) {
    *device_log = *(write_handle_->GetLog(device_pos.offset));
    write_handle_->MapUnlock();
    return ErrorNo::kSucc;
  }

  ret = GetReadHandle_().Reset(device_pos.index, device_pos.offset);
  if (true!=ret) return ErrorNo::kIO;

  ret = GetReadHandle_().ReadLog(*device_log);
  if (0!=ret) return ErrorNo::kIO;
  return ErrorNo::kSucc;
}

int DBDevice::IndexDumper_(void* db_device_arg, FILE* fp) {
  DBDevice& db_device = *RCAST<DBDevice*>(db_device_arg);
  if (true == db_device.is_index_for_dump_consumed_) {
    return 1;
  }

  bool ret = db_device.index_for_dump_.Serialize(fp);
  if (0!=ret) {
    FATAL("fail_serialize");
    return -1;
  }

  db_device.is_index_for_dump_consumed_ = true;
  return 0;
}

bool DBDevice::RestoreDeviceIndex_() {
  //write version already created in Init()
  DBDeviceIndex& db_device_index = db_device_index_.GetWritableDB();
  std::string device_index_filepath = dir_ + "/" + device_index_filename_;
  FILE* fp = fopen(device_index_filepath.c_str(), "r");
  int ret = db_device_index.Deserialize(fp);
  if (0!=ret) {
    if (NULL!=fp) fclose(fp);
    FATAL("fail_deserialize_device_index_from[" 
        << device_index_filepath.c_str() 
        << "]");
    return false;
  }

  if (NULL!=fp) fclose(fp);
  return true;
}

bool DBDevice::OpenCurrentDBFileWhenInit_() {
  //write version already created in Init()

  //get start-replay position
  DevicePos device_pos_tables;
  db_mem_->GetCurrentDevicePos(device_pos_tables);
  DBDeviceIndex& writable_device_index = db_device_index_.GetWritableDB();
  DevicePos device_pos_index = writable_device_index.GetDevicePos();
  DevicePos replay_pos = 
    (device_pos_tables<device_pos_index ?
        device_pos_tables : 
        device_pos_index);

  //set max_index_
  int ret = write_handle_->Reset(-1);
  if (true!=ret) return false;

  max_index_ = write_handle_->GetIndex();

  //replay logs in db files that are not the last
  DBDeviceFileReadHandle& read_handle = GetReadHandle_();
  DeviceLog device_log;
  DevicePos current_pos;
  for (int i = replay_pos.index; i<max_index_; ++i) { 
    ret = read_handle.Reset(i, 
        (i == replay_pos.index ? replay_pos.offset : 0));
    if (true!=ret) return false;
 
    current_pos.index = read_handle.GetIndex();
    current_pos.offset = read_handle.GetOffset();
    ret = read_handle.ReadLog(device_log);
    // adjust return check(all this file)
    while (0==ret) {
      ret = ReplayDeviceLog_(device_log, current_pos);
      if (true!=ret) FATAL("fail_replay_log");

      current_pos.index = read_handle.GetIndex();
      current_pos.offset = read_handle.GetOffset();
      ret = read_handle.ReadLog(device_log);
    }
  }

  //replay logs in latest db file
  ret = write_handle_->Reset(max_index_, 
      (max_index_ == replay_pos.index ? replay_pos.offset : 0));
  if (true!=ret) return false;

  DeviceLog* current_log;
  ret = write_handle_->HasValidLogHere();
  if (ret<0) return false;

  current_log = write_handle_->GetCurrentLog();
  while (0==ret) {
    current_pos.index = write_handle_->GetIndex();
    current_pos.offset = write_handle_->GetOffset();
    ret = ReplayDeviceLog_(*current_log, current_pos);
    if (true!=ret) FATAL("fail_replay_log");

    write_handle_->PassLog();
    ret = write_handle_->HasValidLogHere();
    if (ret<0) return false;

    current_log = write_handle_->GetCurrentLog();
  }
  return true;
}

bool DBDevice::ReplayDeviceLog_(const DeviceLog& device_log, DevicePos& device_pos) {
  //replay to device_index
  DBDeviceIndex& writable_device_index = db_device_index_.GetWritableDB();
  if (device_log.GetCmd() == Cmd::kAddRecord) {
    writable_device_index.Insert(device_log.GetKey(), device_pos, LLONG_MAX);
  } else if (device_log.GetCmd() == Cmd::kRemoveRecord) {
    const Key* keys_tobe_removed = RCAST<const Key*>(device_log.GetContentLen());
    for (size_t i=0; i < device_log.GetContentLen() / sizeof(device_log.key_); ++i) {
      writable_device_index.Erase(keys_tobe_removed[i], device_pos, LLONG_MAX);
    }
  }

  //replay to tables
  return callback_replay_log_(*db_mem_, device_log);
}

int DBDevice::ProcessFlushMsg(const FlushMsg& flush_msg) {
  int ret;
  bool ret_new_version;
  DBDeviceIndex* db_device_index;
  DBDeviceIndex::Iterator iterator;
  time_t current_time;
  DevicePos device_pos;

  ret_new_version = db_device_index_.CreateNewVersion();
  MEGA_FAIL_HANDLE_FATAL(true!=ret_new_version, "fail_create_version")

  db_device_index = &(db_device_index_.GetWritableDB());
  if (true != write_handle_->HasSpaceForNewLog(flush_msg)) {
    ret = OpenNewDBFileForWrite_();
    MEGA_FAIL_HANDLE(false==ret)
  }

  device_pos.index = write_handle_->GetIndex();
  device_pos.offset = write_handle_->GetOffset();
  switch (flush_msg.cmd) {
    case Cmd::kAddRecord : {
      TRACE("db_device_got_add_record key[" 
          << flush_msg.cmd_extra.add_rec.key << "]");

      ret = (db_device_index->Insert(
          flush_msg.cmd_extra.add_rec.key, 
          device_pos,
          flush_msg.logic_time)).first;
      if (true!=ret) return ErrorNo::kDupKey;
      break;
    }
    case Cmd::kRemoveRecord : {
      const Key* keys = RCAST<const Key*>(flush_msg.msg.Data());
      for (size_t i=0; i < flush_msg.msg.Size() / sizeof(Key); ++i) {
        db_device_index->Erase(keys[i], 
            device_pos,
            flush_msg.logic_time);
      }
      break;
    }
    default:
      break;
  }
  write_handle_->WriteCurrentLog(flush_msg);

  current_time = clock();
  if (current_time - last_flush_time_ >= flush_interval_sec_) {
    write_handle_->Flush();
  }

  db_device_index_.FreezeNewVersion();
  TRACE("FreezeNewVersion");
  return ErrorNo::kSucc;

  ERROR_HANDLE:
  TRACE("FreezeNewVersion " << ret_new_version);
  if (true==ret_new_version) db_device_index_.FreezeNewVersion();
  return ErrorNo::kOther;
}

void DBDevice::DumpDeviceIndex_() {
  if (unlikely(true == is_index_for_dump_consumed_ 
      && clock() - last_index_dump_time_ >= 
        index_dump_interval_sec_)) {
    const DBDeviceIndex& db_device_index = db_device_index_.GetDB();
    if (db_device_index.GetDevicePos().index < 0) return;

    bool ret_copy = index_for_dump_.Copy(db_device_index);
    if (unlikely(true!=ret_copy)) {
      FATAL("fail_copy_device_index");
      return;
    }

    last_index_dump_time_ = clock();
    is_index_for_dump_consumed_ = false;
  }
}

bool DBDevice::OpenNewDBFileForWrite_() {
  int next_index = max_index_+1;
  bool ret = write_handle_->Reset(next_index);
  if (true!=ret) return false;

  current_index_=max_index_=next_index;
  return true;
}

}}
