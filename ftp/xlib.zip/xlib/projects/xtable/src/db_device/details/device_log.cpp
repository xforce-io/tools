#include "../device_log.h"

namespace zmt { namespace material_center {

void DeviceLog::Assign(const FlushMsg& msg) {
  logic_time_ = msg.logic_time;
  cmd_ = msg.cmd;
  if (Cmd::kAddRecord == cmd_) {
    key_ = msg.cmd_extra.add_rec.key;
  }
  len_ = msg.msg.Size();
  memcpy(content_, msg.msg.Data(), len_);
  GenChecksum_();
}

int DeviceLog::ReadFrom(FILE* fp) {
  size_t ret = fread(&checksum_, sizeof(checksum_), 1, fp);
  if (1!=ret) return -1;

  if (true == IsEnd()) return 1;

  ret = fread(&cmd_, 
      GetContentOffset() - sizeof(checksum_), 1, fp);
  if (1!=ret) return -2;

  ret = fread(content_, len_, 1, fp);
  if (1!=ret) {
    return -3;
  } else if (true != CheckChecksum()) {
    return -4;
  }
  return 0;
}

}}
