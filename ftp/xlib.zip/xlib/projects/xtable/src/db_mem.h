#pragma once

#include "public/lock_policy.hpp"
#include "public/delay_del_ptr.hpp"
#include "public/db_reloader/db_reloader.h"
#include "db_mem_core/db_mem_core.h"
#include "db_device/db_device.h"

namespace zmt { namespace material_center {

class DBMem {
 private:
  typedef DBMem Self;
  typedef VersionManager<DBMemCore, ReloadPerInterval> VMDBMemCores;

 public:
  static const std::string kQuickloadDir;
  static const std::string kQuickloadFilename;

 private:
  static const size_t kNumVersionsDBMemCores = 3;
   
 public:
  DBMem();
  bool Init(
      DBDevice& db_device,
      size_t size_lru_queue,
      time_t tables_dump_interval,
      time_t tables_reload_interval,
      RoutineFileDumper& routine_file_dumper,
      bool& end);
 
  bool RegisterPipe(int fd);
  inline int GetRecord(
      const std::string& name, 
      const WeakType& records,
      ResultsGetRecord*& results);

  inline void GetCurrentDevicePos(DevicePos& device_pos) const;
  bool ReplayDeviceLog(const DeviceLog& device_log);

  virtual ~DBMem();

 public:
  inline static bool CallbackReplayDeviceLog(
      Self& db_mem, 
      const DeviceLog& device_log);

 private:
  static void* WritesHandler_(void* self);

 private:
  void HandleWrites_();
  int CreateTable_(const std::string& syntax, LogicTime logic_time);
  int AddRecord_(
      const std::string& table_name, 
      const WeakType& record,
      LogicTime logic_time);

  int RemoveRecord_(
      const std::string& table_name,
      const WeakType& keys_to_remove,
      LogicTime logic_time);

  int UpdateRecord_(
      const std::string& table_name,
      const WeakType& keys_to_remove,
      const WeakType& record,
      LogicTime logic_time);

  inline DBMemCore& GetDBMemCoreForWrite_();

 private:
  std::vector<int> fds_;
  ThreadMutex thread_mutex_;
  VMDBMemCores db_mem_cores_;
  bool* end_;

  pthread_t tid_writes_handler_;
};

int DBMem::GetRecord(
    const std::string& name, 
    const WeakType& records,
    ResultsGetRecord*& results) {
  return const_cast<DBMemCore&>(db_mem_cores_.GetDB()).GetRecord(
      name, records, results);
}

void DBMem::GetCurrentDevicePos(DevicePos& device_pos) const {
  return db_mem_cores_.GetDB().GetCurrentDevicePos(device_pos);
}

bool DBMem::CallbackReplayDeviceLog(
    Self& db_mem,
    const DeviceLog& device_log) {
  return db_mem.ReplayDeviceLog(device_log);
}

DBMemCore& DBMem::GetDBMemCoreForWrite_() {
  return db_mem_cores_.GetWritableDB();
}

}}
