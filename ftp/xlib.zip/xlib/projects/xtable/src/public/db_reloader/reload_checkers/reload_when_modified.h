#pragma once

#include <sys/stat.h>
#include "../../public.h"

namespace zmt { namespace material_center {

class ReloadWhenModified {
 public:
  struct InitParams {
    std::string monitored_filepath;
  };

 public: 
  explicit ReloadWhenModified(const void* params) :
      monitored_filepath_(static_cast<const InitParams*>(params)->monitored_filepath),
      last_modified_time_(0) {}

  inline int ToLoad();

 private:
  ///const
  std::string monitored_filepath_; 
  //

  time_t last_modified_time_;
};

int ReloadWhenModified::ToLoad() {
  struct stat filestat;
  int ret = stat(monitored_filepath_.c_str(), &filestat);
  if (0!=ret) {
    WARN("fail_stat_file[" <<  monitored_filepath_.c_str() << "]");
    return -1;
  }

  if (filestat.st_mtime == last_modified_time_) {
    return 1;
  } else {
    last_modified_time_ = filestat.st_mtime;
    return 0;
  }
}

}}
