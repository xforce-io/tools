#pragma once

namespace zmt { namespace material_center {

class ReloadAlways {
 public:
  explicit ReloadAlways(const void* /*params*/) {}
  int ToLoad() { return 0; }
};

}}
