#pragma once

#include "base_cow_lru_queue_hashmap.hpp"

namespace zmt { namespace material_center {

template <
    typename Key, 
    typename Val,
    typename HashF,
    typename EqualKeyF,
    typename AtExitF> 
class CowLRUQueueHashmap : 
  public BaseCLQHashmap<BaseCLQHashmapParams<
      Key, 
      Val, 
      HashF, 
      EqualKeyF,
      AtExitF> > {

 public:
  typedef BaseCLQHashmap<BaseCLQHashmapParams< 
      Key, 
      Val, 
      HashF, 
      EqualKeyF,
      AtExitF> > Super;

  typedef typename Super::MapAtExitF MapAtExitF;

 public:
  CowLRUQueueHashmap(
      size_t hint_size_buckets=Super::DefaultSizeBuckets,
      bool to_resize=Super::DefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const MapAtExitF& at_exit=MapAtExitF()) : 
    Super(hint_size_buckets, to_resize, hasher, equal_key, at_exit) {}

  virtual ~CowLRUQueueHashmap() { Super::Clear(); }
};

}}
