#pragma once

#include <tr1/functional>
#include "../../public.h"
#include "../functors.hpp"
#include "cow_lru_queue_node.h"
#include "cow_lru_queue_hashmap.hpp"

namespace zmt { namespace material_center {

#define MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER \
  template < \
    typename Key, \
    typename Val, \
    typename HashF, \
    typename EqualKeyF, \
    typename AtExitF>

template <
    typename Key, 
    typename Val, 
    typename HashF, 
    typename EqualKeyF,
    typename AtExitF>
class CowLRUQueueIterator;

/* RAII */
/*
 * @note: For the simplicity of code design base on cow_hashmap, this lru is
 *    designed to be just a functional-limited version: once a lru is copied to
 *    several copies, only one copy can be modified again and use iterator, or 
 *    will occur unexpected behavior.
 */
template < 
    typename Key, 
    typename Val, 
    typename HashF=std::tr1::hash<Key>, 
    typename EqualKeyF=std::equal_to<Key>,
    typename AtExitF=DefaultKVAtExitF<Key, Val> >
class CowLRUQueue {
 public:
  typedef CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF> Self;
  typedef CowLRUQueueHashmap<Key, Val, HashF, EqualKeyF, AtExitF> Map;
  typedef typename Map::MapAtExitF MapAtExitF;
  typedef CowLRUQueueNode<Key, Val> Node;
  typedef CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF> Iterator;

 public:
  CowLRUQueue(
      size_t size_queue,
      const HashF& hash=HashF(), 
      const EqualKeyF& comp=EqualKeyF(),
      const AtExitF& at_exit=AtExitF());

  CowLRUQueue(const Self& other);
 
  /*
   * @return :
   *      1  : found
   *      0  : ok 
   *     -1  : error happens
   */
  inline std::pair<int, std::pair<Key*, Val*> > Insert(const Key& key, const Val& val);
  inline bool Touch(const Key& key);
  inline std::pair<const Key*, const Val*> Get(const Key& key) const;
  inline std::pair<Key*, Val*> Get(const Key& key);
  inline std::pair<const Key*, const Val*> GetAndTouch(const Key& key);
  int Erase(const Key& key);
  bool Copy(const Self& other);
  inline Self& operator=(const Self& other);
  inline void Clear();
  inline std::pair<const Key*, const Val*> Head() const;
  size_t Size() const { return map_.Size(); }
  Iterator Begin() const { return Iterator(this, true); }
  Iterator End() const { return Iterator(this, false); }
  virtual ~CowLRUQueue() { Clear(); }

 protected:
  bool Init_();
  std::pair<int, std::pair<Key*, Val*> > 
      Touch_(const Key& key, const Val* val, bool insert);
  inline void RefreshHeadTail_();

 protected: 
  //const
  size_t size_queue_; 
  HashF hash_;
  EqualKeyF equal_key_;
  AtExitF at_exit_;
  ///

  Node *head_, *tail_;
  Map map_;

  bool init_;

  friend class CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>;
};

template <
    typename Key, 
    typename Val, 
    typename HashF=std::tr1::hash<Key>, 
    typename EqualKeyF=std::equal_to<Key>,
    typename AtExitF=DefaultKVAtExitF<Key, Val> >
class CowLRUQueueIterator {
 public:
  typedef CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF> Self;
  typedef CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF> Master;

 public:
  explicit CowLRUQueueIterator(const Master* cow_lru_queue=NULL, bool begin=true) :
      cow_lru_queue_(cow_lru_queue),
      cow_lru_queue_node_( 
          (true==begin && NULL!=cow_lru_queue_) ? cow_lru_queue_->head_ : NULL) {}

  inline bool operator==(const Self& cow_hashmap_iterator) const;
  inline bool operator!=(const Self& cow_hashmap_iterator) const;
  inline const Self& operator++();
  inline const Self& operator++(int);
  inline std::pair<Key*, Val*> operator*() const;

 private:
  void MoveToNext_();

 private:
  //const
  const Master* cow_lru_queue_; 
  ///

  typename Master::Node* cow_lru_queue_node_;
};

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::CowLRUQueue(
    size_t size_queue,
    const HashF& hash, 
    const EqualKeyF& comp,
    const AtExitF& at_exit) :
  size_queue_(size_queue),
  hash_(hash),
  equal_key_(comp),
  at_exit_(at_exit),
  head_(NULL),
  tail_(NULL),
  map_(2*size_queue_, false, hash, comp, MapAtExitF(at_exit_)),
  init_(false) {}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::CowLRUQueue(
    const Self& other) :
  head_(NULL),
  tail_(NULL) { 
  init_=false;
  *this=other; 
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<int, std::pair<Key*, Val*> >
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Insert(
    const Key& key, 
    const Val& val) {
  std::pair<int, std::pair<Key*, Val*> > result;
  result.first=-1;
  MEGA_RAII_INIT(result)

  return Touch_(key, &val, true);
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
bool CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Touch(const Key& key) {
  MEGA_RAII_INIT(false)
  return 0 == Touch_(key, NULL, false).first;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<const Key*, const Val*> 
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Get(const Key& key) const {
  typename Map::ConstIterator iter = map_.Find(key);
  return map_.End() != iter ? 
    std::pair<const Key*, const Val*>(iter.GetVal().key, iter.GetVal().val) : 
    std::pair<const Key*, const Val*>(NULL, NULL);
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<Key*, Val*> 
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Get(const Key& key) {
  typename Map::Iterator iter = map_.Find(key);
  return map_.End() != iter ? 
    std::pair<Key*, Val*>(iter.GetValToWrite()->key, iter.GetValToWrite()->val) : 
    std::pair<Key*, Val*>(NULL, NULL);
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<const Key*, const Val*> 
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::GetAndTouch(const Key& key) { 
  return true == Touch(key) ? Head() : std::pair<const Key*, const Val*>(NULL, NULL); 
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
int CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Erase(const Key& key) {
  MEGA_RAII_INIT(-1)

  typename Map::Iterator iter = map_.Find(key);
  if (unlikely(map_.End() == iter)) return 1;

  Node& node = *(iter.GetValToWrite());
  RefreshHeadTail_();
  if (head_ != &node) {
    node.prev->next = node.next;
  } else {
    head_ = node.next;
    if (NULL!=head_) head_->prev = NULL; 
  }

  if (tail_ != &node) {
    node.next->prev = node.prev;
  } else {
    tail_ = node.prev;
    if (NULL!=tail_) tail_->next = NULL;
  }
  return true == map_.Erase(key) ? 0 : -1;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
bool CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Copy(
    const Self& other) {
  if (unlikely(this == &other)) return true;

  size_queue_ = other.size_queue_;
  hash_ = other.hash_;
  equal_key_ = other.equal_key_;
  at_exit_ = other.at_exit_;

  bool ret = map_.Copy(other.map_);
  if (true==ret) {
    head_ = other.head_;
    tail_ = other.tail_;
  }
  return ret;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>&
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::operator=(const Self& other) {
  if (unlikely(this == &other)) return *this;
  Copy(other);
  return *this;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
void CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Clear() {
  head_=tail_=NULL;
  map_.Clear();
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<const Key*, const Val*> 
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Head() const { 
  return NULL!=head_ ? 
    std::pair<const Key*, const Val*>(head_->key, head_->val) : 
    std::pair<const Key*, const Val*>(NULL, NULL); 
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
bool CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Init_() {
  if (size_queue_ <= 1) return false;
  return true;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<int, std::pair<Key*, Val*> >
CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::Touch_(
    const Key& key, 
    const Val* val, 
    bool insert) {
  std::pair<int, std::pair<Key*, Val*> > ret;
  typename Map::Iterator iter = map_.Find(key);
  if (map_.End() == iter) {
    if (false==insert) {
      ret.first=1;
      return ret;
    }

    if (likely(size_queue_ == Size())) {
      at_exit_(*(tail_->key), *(tail_->val));
      map_.Erase(*(tail_->key));
      tail_->prev->next=NULL;
      tail_ = tail_->prev;
    }
  } else {
    if (true==insert) {
      ret.first=1;
      return ret;
    }

    Node& tmp_node = *(iter.GetValToWrite());
    RefreshHeadTail_();
    if (likely(head_ != &tmp_node)) {
      tmp_node.prev->next = tmp_node.next;
      if (tail_ != &tmp_node) { 
        tmp_node.next->prev = tmp_node.prev; 
      } else {
        tail_ = tail_->prev;
      }
      tmp_node.next = head_;
      tmp_node.prev = NULL;
      head_->prev = &tmp_node;
      head_ = &tmp_node;
    }

    ret.first=0;
    ret.second.first = tmp_node.key;
    ret.second.second = tmp_node.val;
    return ret;
  }

  Node tmp_node_tobe_inserted;
  tmp_node_tobe_inserted.next = head_;
  tmp_node_tobe_inserted.prev = NULL;
  tmp_node_tobe_inserted.key = const_cast<Key*>(&key);
  tmp_node_tobe_inserted.val = const_cast<Val*>(val);

  std::pair<bool, typename Map::Iterator> result_insert =
      map_.Insert(key, tmp_node_tobe_inserted);
  if (unlikely(true != result_insert.first)) {
    ret.first = -1;
    return ret;
  }

  Node& node = *(result_insert.second.GetValToWrite());
  RefreshHeadTail_();
  if (likely(NULL!=head_)) head_->prev = &node;
  head_ = &node;

  if (NULL==head_->next) tail_=head_;

  ret.first=0;
  ret.second.first = node.key;
  ret.second.second = node.val;
  return ret;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
void CowLRUQueue<Key, Val, HashF, EqualKeyF, AtExitF>::RefreshHeadTail_() {
  if (NULL!=head_) head_ = const_cast<Node*>(&(map_.Find(*(head_->key)).GetVal()));
  if (NULL!=tail_) tail_ = const_cast<Node*>(&(map_.Find(*(tail_->key)).GetVal()));
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
bool CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::operator==(
    const Self& cow_hashmap_iterator) const {
  return cow_hashmap_iterator.cow_lru_queue_node_ == cow_lru_queue_node_;    
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
bool CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::operator!=(
    const Self& cow_hashmap_iterator) const {
  return cow_hashmap_iterator.cow_lru_queue_node_ != cow_lru_queue_node_;    
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
const CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>& 
CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::operator++() {
  MoveToNext_();
  return *this;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
const CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>& 
CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::operator++(int) {
  CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF> iterator=*this;
  MoveToNext_();
  return *this;
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
std::pair<Key*, Val*> 
CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::operator*() const {
  if (NULL!=cow_lru_queue_node_) {
    return std::pair<Key*, Val*>(
        cow_lru_queue_node_->key, 
        cow_lru_queue_node_->val);
  } else {
    return std::pair<Key*, Val*>(NULL, NULL);
  }
}

MEGATRON_COW_LRU_QUEUE_TEMPLATE_HEADER
void CowLRUQueueIterator<Key, Val, HashF, EqualKeyF, AtExitF>::MoveToNext_() {
  if (unlikely(NULL==cow_lru_queue_node_)) {
    cow_lru_queue_node_ = cow_lru_queue_->head_;
  } else {
    cow_lru_queue_node_ = cow_lru_queue_node_->next;
  }
}

}}
