#pragma once

namespace zmt { namespace material_center {

template <typename Key, typename Val>
struct CowLRUQueueNode {
  CowLRUQueueNode* next;
  CowLRUQueueNode* prev;
  Key* key;
  Val* val;
};

}}
