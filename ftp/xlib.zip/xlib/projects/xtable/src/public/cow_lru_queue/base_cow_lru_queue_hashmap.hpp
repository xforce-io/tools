#pragma once

#include "cow_lru_queue_node.h"
#include "../cow_hashmap/cow_hashmap.hpp"

namespace zmt { namespace material_center {

/*
 * @note: CLQ stands for CowLRUQueue
 */
template <
    typename KeyParam, 
    typename ValParam, 
    typename HashFParam, 
    typename EqualKeyFParam, 
    typename AtExitFParam>
struct BaseCLQHashmapParams {
  typedef KeyParam Key;
  typedef ValParam Val;
  typedef HashFParam HashF;
  typedef EqualKeyFParam EqualKeyF;
  typedef AtExitFParam AtExitF;
};

template <typename BaseCLQHashmapParams> 
class CowHashmapAtExitF {
 public: 
  explicit CowHashmapAtExitF(
      typename BaseCLQHashmapParams::AtExitF at_exit=
        typename BaseCLQHashmapParams::AtExitF()) :
    at_exit_(at_exit) {}  

  void operator()(
      typename BaseCLQHashmapParams::Key& /*key*/, 
      CowLRUQueueNode<
          typename BaseCLQHashmapParams::Key, 
          typename BaseCLQHashmapParams::Val>& val) {
    at_exit_(*(val.key), *(val.val));
  }

 private:
  typename BaseCLQHashmapParams::AtExitF at_exit_; 
};

template <typename BaseCLQHashmapParams> 
class BaseCLQHashmap : public CowHashmap<
    typename BaseCLQHashmapParams::Key,
    CowLRUQueueNode<
        typename BaseCLQHashmapParams::Key,
        typename BaseCLQHashmapParams::Val>,
    typename BaseCLQHashmapParams::HashF,
    typename BaseCLQHashmapParams::EqualKeyF,
    CowHashmapAtExitF<BaseCLQHashmapParams> > {
 public:
  typedef typename BaseCLQHashmapParams::Key Key;
  typedef typename BaseCLQHashmapParams::Val Val;
  typedef typename BaseCLQHashmapParams::HashF HashF;
  typedef typename BaseCLQHashmapParams::EqualKeyF EqualKeyF;
  typedef typename BaseCLQHashmapParams::AtExitF AtExitF;
  typedef CowHashmapAtExitF<BaseCLQHashmapParams> MapAtExitF;

  typedef CowHashmap<
      Key,
      CowLRUQueueNode<Key, Val>,
      HashF,
      EqualKeyF,
      MapAtExitF> Super;

  typedef typename Super::Node Node;
  typedef typename Super::Bucket Bucket;
  typedef CowLRUQueueNode<Key, Val> lruNode;

 public:
  explicit BaseCLQHashmap(
      size_t hint_size_buckets,
      bool to_resize,
      const HashF& hasher,
      const EqualKeyF& equal_key,
      const MapAtExitF& at_exit) : 
    Super(hint_size_buckets, to_resize, hasher, equal_key, at_exit) {}  

  virtual ~BaseCLQHashmap() { Super::Clear(); }

 protected:
  Node* GetNode_(const Key& key, const CowLRUQueueNode<Key, Val>& val); 
  void FreeNode_(Node& node);
  inline bool CopyBucket_(Bucket** bucket, const Node* except, bool except_node);
  inline bool CopyBucketAndGetNode_(Bucket** bucket, INOUT Node*& node_to_get);

  virtual Val* AllocVal_(Val& val);
  virtual void FreeVal_(Val& val) { return real_val_alloc_.Free(&val); }
  void RefreshBucket_(Bucket& old_bucket, Bucket& new_bucket);

 private:
  PoolObjs<Val> real_val_alloc_;
};

template <typename BaseCLQHashmapParams> 
typename BaseCLQHashmap<BaseCLQHashmapParams>::Node*
BaseCLQHashmap<BaseCLQHashmapParams>::GetNode_(
    const Key& key, 
    const CowLRUQueueNode<Key, Val>& val) {
  CowLRUQueueNode<Key, Val> cow_lru_queue_node=val;
  cow_lru_queue_node.val = NULL;

  Node* node = Super::node_alloc_.Get();
  MEGA_FAIL_HANDLE(NULL==node)

  node->key = key;

  cow_lru_queue_node.key = &(node->key);
  cow_lru_queue_node.val = AllocVal_(*(val.val));
  MEGA_FAIL_HANDLE(NULL==cow_lru_queue_node.val)

  node->val = cow_lru_queue_node;
  return node;

  ERROR_HANDLE:
  if (NULL!=node) FreeNode_(*node);
  return NULL;
}

template <typename BaseCLQHashmapParams>
void BaseCLQHashmap<BaseCLQHashmapParams>::FreeNode_(Node& node) {
  Super::at_exit_(node.key, node.val);
  FreeVal_(*(node.val.val));
  Super::node_alloc_.Free(&node);
}

template <typename BaseCLQHashmapParams>
bool BaseCLQHashmap<BaseCLQHashmapParams>::CopyBucket_(
    Bucket** bucket, 
    const Node* except, 
    bool except_node) {
  Bucket* old_bucket = *bucket;
  if (unlikely(true != Super::CopyBucket_(bucket, except, except_node))) return false;

  RefreshBucket_(*old_bucket, **bucket);
  return true;
}

template <typename BaseCLQHashmapParams>
bool BaseCLQHashmap<BaseCLQHashmapParams>::CopyBucketAndGetNode_(
    Bucket** bucket, 
    Node*& node_to_get) {
  Bucket* old_bucket = *bucket;
  if (unlikely(true != Super::CopyBucketAndGetNode_(bucket, node_to_get))) return false;

  RefreshBucket_(*old_bucket, **bucket);
  return true;
}

template <typename BaseCLQHashmapParams> 
typename BaseCLQHashmapParams::Val* 
BaseCLQHashmap<BaseCLQHashmapParams>::AllocVal_(Val& val) { 
  Val* new_val = real_val_alloc_.Get(); 
  *new_val = val;
  return new_val;
}

template <typename BaseCLQHashmapParams> 
void BaseCLQHashmap<BaseCLQHashmapParams>::RefreshBucket_(
    Bucket& old_bucket, 
    Bucket& new_bucket) {
  if (likely(NULL == new_bucket.head)) return;

  Node* node = new_bucket.head;
  if (NULL == node->next) {
    if (NULL != node->val.prev) node->val.prev->next = &(node->val);
    if (NULL != node->val.next) node->val.next->prev = &(node->val);
    return;
  }

  /*
   * @note: Logic below seems to be slow, but most of hash buckets have size 
   *    le 1, so there should be little influence
   */
  node = new_bucket.head;
  do {
    Node* iter_old = old_bucket.head;
    Node* iter_new = new_bucket.head;
    do {
      if (unlikely(node->val.prev == &(iter_old->val))) {
        node->val.prev = &(iter_new->val);
      }

      if (unlikely(node->val.next == &(iter_old->val))) {
        node->val.next = &(iter_new->val);
      }

      iter_old = iter_old->next;
      iter_new = iter_new->next;
    } while (NULL!=iter_new);

    if (NULL != node->val.prev) node->val.prev->next = &(node->val);
    if (NULL != node->val.next) node->val.next->prev = &(node->val);

    node = node->next;
  } while (NULL!=node);
}

}}
