#pragma once

#include <vector>

namespace zmt { namespace material_center {

template <typename Obj>
class DelayDelPtr {
 public:
  static const time_t kDefaultDelayDelTimeInSec=60;

 public:
  explicit DelayDelPtr(
      Obj& obj, 
      time_t delay_del_time_in_sec=kDefaultDelayDelTimeInSec) :
    obj_(&obj), 
    delay_del_time_in_sec_(delay_del_time_in_sec) {}
  
  Obj& operator*() { return *obj_; }
  Obj* operator->() { return obj_; }
  void Change(Obj& obj);

 private:
  //const
  time_t delay_del_time_in_sec_;
  ///

  Obj* obj_; 
  std::list< std::pair<Obj*, time_t> > delay_del_list_;
};

template <typename Obj>
void DelayDelPtr<Obj>::Change(Obj& obj) {
  time_t current_time = clock();
  while (false == delay_del_list_.empty()) {
    time_t time_passed = current_time - delay_del_list_.back().second();
    if (likely( time_passed <= delay_del_time_in_sec_) ) {
      break;
    } else {
      delay_del_list_.pop_back();
    }
  }

  delay_del_list_.push_front(std::pair<Obj*, time_t>(obj_, current_time));
  //need a mb
  obj_=&obj;
}

}}
