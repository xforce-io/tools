#pragma once

#include <arpa/inet.h>
#include "common.h"
#include "../3rd/crc32/crc.h"

namespace zmt { namespace material_center {

class Crc32Checker {
 public:
  inline static uint32_t Gen(const char* buf, size_t size); 
  inline static bool Check(const char* buf, size_t size, bool from_net=false);
};

uint32_t Crc32Checker::Gen(const char* buf, size_t size) {
  return crc32_ieee_le(
      0xFFFFFFFF, 
      RCAST<const uint8_t*>(buf), size) ^ 
    0xFFFFFFFF;
}

bool Crc32Checker::Check(const char* buf, size_t size, bool from_net) {
  if (unlikely(size<=4)) return false;
  if (true==from_net) {
    return ntohl(*(RCAST<const uint32_t*>(buf))) == 
      Gen(buf+4, size-4);
  } else {
    return *(RCAST<const uint32_t*>(buf)) == Gen(buf+4, size-4);
  }
}

}}
