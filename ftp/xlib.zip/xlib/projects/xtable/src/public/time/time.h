#pragma once

#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <stdint.h>

namespace zmt { namespace material_center {

class Time {
 public:
  inline static int64_t GetCurrentTime(bool update=false);
  inline static int64_t GetCurrentSec(bool update=false);
  inline static int64_t GetCurrentUsec(bool update=false);
  inline static void UpdateTimer();
  static void UninteruptbleSleep(time_t sec);

 private:
  static int64_t time_;
};

class Timer {
 public:
  inline void Start(bool update=true);
  inline void Stop(bool update=true);
  int64_t TimeUs() const { return stop_-start_; }
  int64_t TimeMs() const { return (stop_-start_)/1000; }

 private:
  int64_t start_, stop_;
};

int64_t Time::GetCurrentTime(bool update) { 
  if(true==update || 0==time_) UpdateTimer();
  return time_; 
}

int64_t Time::GetCurrentSec(bool update) { 
  if(true==update || 0==time_) {
    timeval t;
    gettimeofday(&t, NULL);
    return t.tv_sec;
  } else{
    return (int64_t)(time_/1000000); 
  }
}

int64_t Time::GetCurrentUsec(bool update) { 
  if(true==update || 0==time_) {
    timeval t;
    gettimeofday(&t, NULL);
    return t.tv_usec;
  } else{
    return (int64_t)(time_%1000000); 
  }
}

void Time::UpdateTimer() {
  timeval t;
  gettimeofday(&t, NULL);
  time_ = t.tv_sec*1000000 + t.tv_usec;
}

void Timer::Start(bool update) { 
  start_ = Time::GetCurrentTime(update);
}

void Timer::Stop(bool update) { 
  stop_ = Time::GetCurrentTime(update);
}

}}
