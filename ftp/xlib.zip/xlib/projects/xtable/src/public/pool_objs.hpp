#pragma once

#include "common.h"
#include "lock_policy.hpp"

namespace zmt { namespace material_center {

template <
  typename Obj, 
  typename LockPolicy>
class PoolObjsBase {
 public:
  static const size_t kDefaultInitNumObjs=0;
  static const size_t kDefaultMemPerBlock=(1<<16);
  static const bool kDefaultToResize=true;
  static const size_t kDefaultMaxNumBlocks=(1<<18);

 public:
  explicit PoolObjsBase() {}
  explicit PoolObjsBase(
      const Obj& obj,
      size_t init_num_objs=kDefaultInitNumObjs,
      size_t mem_per_block=kDefaultMemPerBlock,
      bool to_resize=kDefaultToResize,
      size_t max_num_blocks=kDefaultMaxNumBlocks);

  Obj* Get();
  inline void Free(Obj* obj);
  inline size_t NumObjsLeft() const;
  inline size_t NumObjsAlloc() const;
  size_t NumObjsPerBlock() const { return num_objs_per_block_; }
  virtual size_t MemCost() const;
  virtual void DumpMemCost(std::ostream& os) const;

  virtual ~PoolObjsBase();

 protected:
  virtual void InitObj_(Obj&) {}

 private:
  bool Init_(); 
  bool AllocABlock_();

 protected:
  ///const
  Obj init_obj_; 

 private:
  ///const 
  size_t init_num_objs_;
  size_t num_objs_per_block_;
  bool to_resize_;
  size_t max_num_blocks_;
  LockPolicy lock_policy_;
  //

  Obj*** pool_objs_;
  size_t current_row_;
  size_t current_col_;
  size_t num_objs_alloc_;
  size_t num_blocks_alloc_;

  bool init_;
};

template <typename Obj, typename LockPolicy=NoLock>
class PoolObjs : public PoolObjsBase<Obj, LockPolicy> {
 private:
  typedef PoolObjsBase<Obj, LockPolicy> Super;
  typedef PoolObjs<Obj, LockPolicy> Self;

 public:
  explicit PoolObjs(
      size_t init_num_objs=Super::kDefaultInitNumObjs,
      size_t mem_per_block=Super::kDefaultMemPerBlock,
      bool to_resize=Super::kDefaultToResize,
      size_t max_num_blocks=Super::kDefaultMaxNumBlocks) :
    Super(Obj(), init_num_objs, mem_per_block, to_resize, max_num_blocks) {}

  size_t MemCost() const;
  void DumpMemCost(std::ostream& os) const;
};

template <
  typename Obj, 
  typename LockPolicy=NoLock>
class PoolObjsInit : public PoolObjsBase<Obj, LockPolicy> {
 private:
  typedef PoolObjsBase<Obj, LockPolicy> Super;
  typedef PoolObjsInit<Obj, LockPolicy> Self;
  
 public:
  explicit PoolObjsInit(
      const Obj& obj,
      size_t init_num_objs=Super::kDefaultInitNumObjs,
      size_t mem_per_block=Super::kDefaultMemPerBlock,
      bool to_resize=Super::kDefaultToResize,
      size_t max_num_blocks=Super::kDefaultMaxNumBlocks):
    Super(obj, init_num_objs, mem_per_block, to_resize, max_num_blocks) {}  

  size_t MemCost() const;
  void DumpMemCost(std::ostream& os) const;

 private:
  void InitObj_(Obj& obj) { obj = Super::init_obj_; }
};

template <typename Obj, typename LockPolicy>
PoolObjsBase<Obj, LockPolicy>::PoolObjsBase(
    const Obj& obj,
    size_t init_num_objs,
    size_t mem_per_block,
    bool to_resize,
    size_t max_num_blocks) :
  init_obj_(obj),
  init_num_objs_(init_num_objs),
  num_objs_per_block_((mem_per_block+sizeof(Obj)-1)/sizeof(Obj)),
  to_resize_(to_resize),
  max_num_blocks_(max_num_blocks),
  pool_objs_(NULL),
  current_row_(0),
  current_col_(0),
  num_objs_alloc_(0),
  num_blocks_alloc_(0),
  init_(false) { }

template <typename Obj, typename LockPolicy>
bool PoolObjsBase<Obj, LockPolicy>::Init_() {
  MEGA_FAIL_HANDLE(0==max_num_blocks_)

  pool_objs_ = new (std::nothrow) Obj** [max_num_blocks_];
  MEGA_FAIL_HANDLE(NULL==pool_objs_)

  bzero(pool_objs_, max_num_blocks_*sizeof(Obj**));
  while (num_blocks_alloc_*num_objs_per_block_ < init_num_objs_) {
    bool ret = AllocABlock_();
    MEGA_FAIL_HANDLE(true!=ret)
  }
  init_=true;
  return true;

  ERROR_HANDLE:
  MEGA_DELETE_ARRAY(pool_objs_)
  return false;
}

template <typename Obj, typename LockPolicy>
bool PoolObjsBase<Obj, LockPolicy>::AllocABlock_() {
  size_t i=0;
  
  if ( unlikely(max_num_blocks_==num_blocks_alloc_) ) return false;

  pool_objs_[num_blocks_alloc_] = new (std::nothrow) Obj* [num_objs_per_block_];
  MEGA_FAIL_HANDLE(NULL==pool_objs_[num_blocks_alloc_])

  for (i=0; i<num_objs_per_block_; ++i) {
    pool_objs_[current_row_][i] = new (std::nothrow) Obj;
    MEGA_FAIL_HANDLE(NULL==pool_objs_[0][i])

    InitObj_(*(pool_objs_[0][i]));
    ++num_objs_alloc_;
  }

  ++num_blocks_alloc_;
  ++current_row_;
  return true;

  ERROR_HANDLE:
  for (size_t j=0; j<i; ++j) MEGA_DELETE(pool_objs_[0][i]);
  MEGA_DELETE_ARRAY(pool_objs_[num_blocks_alloc_])
  return false;
}

template <typename Obj, typename LockPolicy>
Obj* PoolObjsBase<Obj, LockPolicy>::Get() {
  MEGA_RAII_INIT(NULL)

  if ( unlikely(true != lock_policy_.Lock()) ) return NULL;

  Obj* ret;
  if (0!=current_col_) {
    ret = pool_objs_[current_row_][--current_col_];
  } else if (0!=current_row_) {
    current_col_ = num_objs_per_block_-1;
    ret = pool_objs_[--current_row_][current_col_];
  } else {
    if (true==to_resize_ && true==AllocABlock_()) {
      current_row_=0;
      current_col_ = num_objs_per_block_-1;
      ret = pool_objs_[current_row_][current_col_];
    } else {
      ret=NULL;
    }
  }
  lock_policy_.Unlock();
  return ret;
}

template <typename Obj, typename LockPolicy>
void PoolObjsBase<Obj, LockPolicy>::Free(Obj* obj) {
  MEGA_RAII_INIT()
  if ( unlikely(NULL==obj || true != lock_policy_.Lock()) ) return;

  if ( unlikely(num_blocks_alloc_ == current_row_) ) {
    if ( unlikely(max_num_blocks_==num_blocks_alloc_) ) return;

    pool_objs_[num_blocks_alloc_] = new (std::nothrow) Obj* [num_objs_per_block_];
    if ( unlikely(NULL==pool_objs_[num_blocks_alloc_])) return;

    ++num_blocks_alloc_;
  }

  if (num_objs_per_block_-1 != current_col_) {
    pool_objs_[current_row_][current_col_++] = obj;
  } else {
    pool_objs_[current_row_++][current_col_] = obj;
    current_col_=0;
  }
  lock_policy_.Unlock();
}

template <typename Obj, typename LockPolicy>
size_t PoolObjsBase<Obj, LockPolicy>::NumObjsLeft() const {
  return current_row_*num_blocks_alloc_ + current_col_;
} 

template <typename Obj, typename LockPolicy>
size_t PoolObjsBase<Obj, LockPolicy>::NumObjsAlloc() const {
  return num_objs_alloc_ - NumObjsLeft();
} 

template <typename Obj, typename LockPolicy>
size_t PoolObjsBase<Obj, LockPolicy>::MemCost() const {
  return num_objs_alloc_ * sizeof(Obj) +
    num_blocks_alloc_ * num_objs_per_block_ * sizeof(Obj*) +
    sizeof(Obj**) * max_num_blocks_;
}

template <typename Obj, typename LockPolicy>
void PoolObjsBase<Obj, LockPolicy>::DumpMemCost(std::ostream& os) const {
  os << "block buckets cost: " << sizeof(Obj**) * max_num_blocks_ << std::endl;
  os << "blocks cost: " 
      << num_blocks_alloc_ * num_objs_per_block_ * sizeof(Obj*) 
      << std::endl;

  os << "objs cost: " << num_objs_alloc_ * sizeof(Obj) << std::endl;
}

template <typename Obj, typename LockPolicy>
PoolObjsBase<Obj, LockPolicy>::~PoolObjsBase() {
  if (true != lock_policy_.Lock()) return;

  if (NULL!=pool_objs_) {
    for (size_t i=0; i<current_row_; ++i) {
      for (size_t j=0; j<num_objs_per_block_; ++j) {
        MEGA_DELETE(pool_objs_[i][j]);
      }
      MEGA_DELETE_ARRAY(pool_objs_[i])
    }

    if (current_row_!=num_blocks_alloc_) {
      for (size_t i=0; i<current_col_; ++i) {
        MEGA_DELETE(pool_objs_[current_row_][i]);
      }
      MEGA_DELETE_ARRAY(pool_objs_[current_row_])

      for (size_t i=current_row_; i<num_blocks_alloc_; ++i) {
        MEGA_DELETE_ARRAY(pool_objs_[i])
      }
    }
    MEGA_DELETE_ARRAY(pool_objs_)
  }
  lock_policy_.Unlock();
}

template <typename Obj, typename LockPolicy>
size_t PoolObjs<Obj, LockPolicy>::MemCost() const {
  return Super::MemCost() + sizeof(Self);
}

template <typename Obj, typename LockPolicy>
void PoolObjs<Obj, LockPolicy>::DumpMemCost(std::ostream& os) const {
  os << "Self cost: " << sizeof(Self) << std::endl;
}

template <typename Obj, typename LockPolicy>
size_t PoolObjsInit<Obj, LockPolicy>::MemCost() const {
  return Super::MemCost() + sizeof(Self);
}

template <typename Obj, typename LockPolicy>
void PoolObjsInit<Obj, LockPolicy>::DumpMemCost(std::ostream& os) const {
  os << "Self cost: " << sizeof(Self) << std::endl;
}

}}
