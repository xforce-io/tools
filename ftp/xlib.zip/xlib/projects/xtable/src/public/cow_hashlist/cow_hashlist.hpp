#pragma once

#include <tr1/functional>
#include "../functors.hpp"
#include "base_cow_hashlist.hpp"

namespace zmt { namespace material_center {

template <
    typename Key,
    typename KeyOfVal,
    typename Val=Key,
    typename HashF=std::tr1::hash<Key>,
    typename EqualKeyF=std::equal_to<Key>,
    typename KeyExtractor=ReflectorF<Val>,
    typename LessF=std::less<KeyOfVal> >
class CowHashlist :
  public BaseCowHashlist<BaseCowHashlistParams<
      Key, KeyOfVal, Val, HashF, EqualKeyF, KeyExtractor, LessF, false> > {
 public:
  typedef CowHashlist<
      Key, KeyOfVal, Val, HashF, EqualKeyF, KeyExtractor, LessF> Self;

  typedef BaseCowHashlist<BaseCowHashlistParams<
      Key, KeyOfVal, Val, HashF, EqualKeyF, KeyExtractor, LessF, false> > Super;
  
 private:
  static const bool kDefaultToResize=false; 

 public:
  CowHashlist(
      size_t fanout,
      size_t hint_size_buckets=Super::Map::kDefaultSizeBuckets,
      bool to_resize=kDefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const KeyExtractor& key_extractor=KeyExtractor(),
      const LessF& less=LessF()) :
    Super(fanout, hint_size_buckets, to_resize, hasher, equal_key, 
        key_extractor, less) {}
};

template <
    typename Key,
    typename KeyOfVal,
    typename Val=Key,
    typename HashF=std::tr1::hash<Key>,
    typename EqualKeyF=std::equal_to<Key>,
    typename KeyExtractor=ReflectorF<Val>,
    typename LessF=std::less<KeyOfVal> >
class MultiCowHashlist :
  public BaseCowHashlist<BaseCowHashlistParams<
      Key, KeyOfVal, Val, HashF, EqualKeyF, KeyExtractor, LessF, true> > {
 public:
  typedef BaseCowHashlist<BaseCowHashlistParams<
      Key, KeyOfVal, Val, HashF, EqualKeyF, KeyExtractor, LessF, true> > Super;

 private:
  static const bool kDefaultToResize=false; 

 public:
  MultiCowHashlist(
      size_t fanout,
      size_t hint_size_buckets=Super::Map::kDefaultSizeBuckets,
      bool to_resize=kDefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const KeyExtractor& key_extractor=KeyExtractor(),
      const LessF& less=LessF()) :
    Super(fanout, hint_size_buckets, to_resize, hasher, equal_key, 
        key_extractor, less) {}
};

}}
