#pragma once

#include "../cow_hashmap/cow_hashmap.hpp"
#include "../cow_btree/base_cow_btree.hpp"
#include "../mp_tools.hpp"

namespace zmt { namespace material_center {

template <
    typename KeyParam, 
    typename KeyOfValParam,
    typename ValParam, 
    typename HashFParam,
    typename EqualKeyFParam,
    typename KeyExtractorParam,
    typename LessFParam, 
    bool IsMultiParam>
struct BaseCowHashlistParams {
  typedef KeyParam Key;
  typedef KeyOfValParam KeyOfVal;
  typedef ValParam Val;
  typedef HashFParam HashF;
  typedef EqualKeyFParam EqualKeyF;
  typedef KeyExtractorParam KeyExtractor;
  typedef LessFParam LessF;
  static const bool IsMulti=IsMultiParam;
};

template <typename BaseCowHashlistParams>
class BaseCowHashlist {
 public:
  typedef typename BaseCowHashlistParams::Key Key;
  typedef typename BaseCowHashlistParams::KeyOfVal KeyOfVal;
  typedef typename BaseCowHashlistParams::Val Val;
  typedef typename BaseCowHashlistParams::HashF HashF;
  typedef typename BaseCowHashlistParams::EqualKeyF EqualKeyF;
  typedef typename BaseCowHashlistParams::KeyExtractor KeyExtractor;
  typedef typename BaseCowHashlistParams::LessF LessF;

  typedef BaseCowHashlist<BaseCowHashlistParams> Self;

  typedef BaseCowBtree< BaseCowBtreeParams<
      KeyOfVal,
      Val,
      KeyExtractor,
      LessF,
      BaseCowHashlistParams::IsMulti> > List;

  typedef CowHashmap<
      Key,
      List,
      HashF,
      EqualKeyF> Map;

 public:
  BaseCowHashlist(
      size_t fanout,
      size_t hint_size_buckets,
      bool to_resize,
      const HashF& hasher,
      const EqualKeyF& equal_key,
      const KeyExtractor& key_extractor,
      const LessF& less);

  BaseCowHashlist(const Self& other);

  std::pair<bool, typename List::Iterator> Insert(const Key& key, const Val& val);
  inline bool Erase(const Key& key);
  inline bool Erase(const Key& key, const KeyOfVal& key_of_val);
  inline bool Erase(const Key& key, typename List::Iterator iterator);
  inline typename List::ConstIterator Find(
      const Key& key, 
      const KeyOfVal& key_of_val) const;

  inline typename List::Iterator FindToWrite(
      const Key& key, 
      const KeyOfVal& key_of_val);

  inline const List* FindList(const Key& key) const;
  inline List* FindListToWrite(const Key& key);
  bool Copy(const Self& other);
  inline Self& operator=(const Self& other);
  size_t Size() const { return hashlist_.Size(); }
  void Clear() { hashlist_.Clear(); }

  typename Map::ConstIterator Begin() const { return hashlist_.Begin(); }
  typename Map::ConstIterator End() const { return hashlist_.End(); }
  typename Map::Iterator Begin() { return hashlist_.Begin(); }
  typename Map::Iterator End() { return hashlist_.End(); }

  virtual ~BaseCowHashlist() {}

 private:
  //const 
  size_t fanout_;
  KeyExtractor key_extractor_;
  LessF less_;
  ///

  Map hashlist_;

  template <typename base_cow_hashlist_params>
  friend std::ostream& operator<<(
      std::ostream& os,
      const BaseCowHashlist<base_cow_hashlist_params>& base_cow_hashlist);
};

template <typename BaseCowHashlistParams>
BaseCowHashlist<BaseCowHashlistParams>::BaseCowHashlist(
    size_t hint_size_buckets,
    size_t fanout,
    bool to_resize,
    const HashF& hasher,
    const EqualKeyF& equal_key,
    const KeyExtractor& key_extractor,
    const LessF& less) :
  fanout_(fanout),
  key_extractor_(key_extractor),
  less_(less),
  hashlist_(hint_size_buckets, to_resize, hasher, equal_key) {}

template <typename BaseCowHashlistParams>
BaseCowHashlist<BaseCowHashlistParams>::BaseCowHashlist(
    const Self& other) :
  fanout_(other.fanout_),
  key_extractor_(other.key_extractor_),
  less_(other.less_) {
  *this=other;
}

template <typename BaseCowHashlistParams>
std::pair<bool, typename BaseCowHashlist<BaseCowHashlistParams>::List::Iterator> 
BaseCowHashlist<BaseCowHashlistParams>::Insert(const Key& key, const Val& val) {
  std::pair<bool, typename List::Iterator> invalid_ret;
  invalid_ret.first=false;

  std::pair<bool, typename List::Iterator> ret_list_insert;
  typename Map::Iterator iter = hashlist_.Find(key);
  if (unlikely(hashlist_.End() == iter)) {
    List list(fanout_);
    std::pair<bool, typename List::Iterator> ret_list_insert;
    ret_list_insert = list.Insert(val);
    if (true != ret_list_insert.first) return invalid_ret;

    std::pair<bool, typename Map::Iterator> ret_map_insert;
    ret_map_insert = hashlist_.Insert(key, list);
    if (true != ret_map_insert.first) return invalid_ret;

    return std::pair<bool, typename List::Iterator>(true, ret_list_insert.second);
  }

  List* list = iter.GetValToWrite();
  if (unlikely(NULL==list)) return invalid_ret;

  ret_list_insert = list->Insert(val);
  if (true != ret_list_insert.first) return invalid_ret;

  return std::pair<bool, typename List::Iterator>(true, ret_list_insert.second);
}

template <typename BaseCowHashlistParams>
bool BaseCowHashlist<BaseCowHashlistParams>::Erase(const Key& key) {
  return hashlist_.Erase(key);
}

template <typename BaseCowHashlistParams>
bool BaseCowHashlist<BaseCowHashlistParams>::Erase(
    const Key& key, 
    const KeyOfVal& key_of_val) {
  typename Map::Iterator iter = hashlist_.Find(key);
  if (unlikely(iter == hashlist_.End())) {
    return false;
  }

  List* list = iter.GetValToWrite();
  if (unlikely(NULL==list)) return false;
  return list->Erase(key_of_val);
}

template <typename BaseCowHashlistParams>
bool BaseCowHashlist<BaseCowHashlistParams>::Erase(
    const Key& key, 
    typename List::Iterator iterator) {
  typename Map::Iterator iter = hashlist_.Find(key);
  if (unlikely(iter == hashlist_.End())) {
    return false;
  }

  List& list = iter.GetVal();
  return list.Erase(iterator);
}

template <typename BaseCowHashlistParams>
typename BaseCowHashlist<BaseCowHashlistParams>::List::ConstIterator
BaseCowHashlist<BaseCowHashlistParams>::Find(
    const Key& key, 
    const KeyOfVal& key_of_val) const {
  typename Map::ConstIterator iter_map = hashlist_.Find(key);
  if (unlikely(iter_map == hashlist_.End())) {
    return typename List::ConstIterator();
  }

  const List& list = iter_map.GetVal();
  return list.Find(key_of_val);
}

template <typename BaseCowHashlistParams>
typename BaseCowHashlist<BaseCowHashlistParams>::List::Iterator
BaseCowHashlist<BaseCowHashlistParams>::FindToWrite(
    const Key& key, 
    const KeyOfVal& key_of_val) {
  typename Map::Iterator iter_map = hashlist_.Find(key);
  if (unlikely(iter_map == hashlist_.End())) {
    return typename List::Iterator();
  }

  List* list = iter_map.GetValToWrite();
  if (unlikely(NULL==list)) return typename List::Iterator();

  return list->Find(key_of_val);
}

template <typename BaseCowHashlistParams>
const typename BaseCowHashlist<BaseCowHashlistParams>::List* 
BaseCowHashlist<BaseCowHashlistParams>::FindList(const Key& key) const {
  typename Map::ConstIterator iter_map = hashlist_.Find(key);
  return iter_map != hashlist_.End() ? &(iter_map.GetVal()) : NULL;
}

template <typename BaseCowHashlistParams>
typename BaseCowHashlist<BaseCowHashlistParams>::List* 
BaseCowHashlist<BaseCowHashlistParams>::FindListToWrite(const Key& key) {
  typename Map::Iterator iter_map = hashlist_.Find(key);
  return iter_map != hashlist_.End() ? iter_map.GetValToWrite() : NULL;
}

template <typename BaseCowHashlistParams>
bool BaseCowHashlist<BaseCowHashlistParams>::Copy(
    const Self& other) { 
  if (unlikely(this == &other)) return true;
  if (unlikely(fanout_ != other.fanout_)) return false;
  
  key_extractor_ = other.key_extractor_;
  less_ = other.less_;
  return hashlist_.Copy(other.hashlist_); 
}

template <typename BaseCowHashlistParams>
BaseCowHashlist<BaseCowHashlistParams>&
BaseCowHashlist<BaseCowHashlistParams>::operator=(const Self& other) { 
  Copy(other); 
  return *this;
}

template <typename BaseCowHashlistParams>
std::ostream& operator<<(
    std::ostream& os,
    const BaseCowHashlist<BaseCowHashlistParams>& base_cow_hashlist) {
  os << base_cow_hashlist.hashlist_ << std::endl;
  return os;
}

}}
