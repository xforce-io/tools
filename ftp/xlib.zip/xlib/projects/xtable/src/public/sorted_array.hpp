#pragma once

#include "public.h"

namespace zmt { namespace material_center {

template <typename Field>
struct MaxWeightMerger {
  Field Merge(const Field& left, const Field& right) {
    return left >= right ? left : right;
  }
};

template < typename Field, typename WeightMerger=MaxWeightMerger<Field> >
class SortedArray {
 public:
  explicit SortedArray();
  
  /*
   * Fields should be inserted sequencely
   * A simple bubble sort is used here, for sorting should
   * not be a task of SortedArray
   */
  inline bool PushBack(const Field& field, int64_t data);
  inline std::pair<Field, int64_t> operator[](size_t index) const;
  inline Field GetField(size_t index) const;
  inline int64_t GetData(size_t index) const;
  inline size_t Size() const;
  inline void Clear();

  void And(const SortedArray<Field, WeightMerger>& right);
  void AndNot(const SortedArray<Field, WeightMerger>& right);
  void Or(const SortedArray<Field, WeightMerger>& right);
  bool TryAnd(const SortedArray<Field, WeightMerger>& right) const;
  bool Has(int64_t field) const;
  
  inline const std::vector< std::pair<Field, int64_t> >* GetArray() const;

 private:
  //const
  WeightMerger weight_merger_;
  ///

  std::vector< std::pair<Field, int64_t> > array_[2];
  size_t current_array_idx_;

  template <typename field_t, typename weight_merger_t>
  friend std::ostream& operator<<(
      std::ostream& oss, 
      const SortedArray<field_t, weight_merger_t>&);
};

template <typename Field, typename WeightMerger>
SortedArray<Field, WeightMerger>::SortedArray() : 
  current_array_idx_(0) {}

template <typename Field, typename WeightMerger>
bool SortedArray<Field, WeightMerger>::PushBack(const Field& field, int64_t data) {
  array_[current_array_idx_].push_back(std::pair<Field, int64_t>(field, data));
  for (size_t i = array_[current_array_idx_].size() - 1; i!=0; --i) {
    if (array_[current_array_idx_][i-1] < array_[current_array_idx_][i]) {
      break;
    } else {
      std::pair<Field, int64_t> tmp = array_[current_array_idx_][i-1];
      array_[current_array_idx_][i-1] = array_[current_array_idx_][i];
      array_[current_array_idx_][i] = tmp;
    }
  }
  return true;
}

template <typename Field, typename WeightMerger>
std::pair<Field, int64_t> 
SortedArray<Field, WeightMerger>::operator[](size_t index) const {
  return array_[current_array_idx_][index];
}

template <typename Field, typename WeightMerger>
Field SortedArray<Field, WeightMerger>::GetField(size_t index) const {
  return array_[current_array_idx_][index].first;
}

template <typename Field, typename WeightMerger>
int64_t SortedArray<Field, WeightMerger>::GetData(size_t index) const {
  return array_[current_array_idx_][index].second;
}

template <typename Field, typename WeightMerger>
size_t SortedArray<Field, WeightMerger>::Size() const { 
  return array_[current_array_idx_].size();
}

template <typename Field, typename WeightMerger>
void SortedArray<Field, WeightMerger>::Clear() {
  array_[current_array_idx_].clear();
}

template <typename Field, typename WeightMerger>
void SortedArray<Field, WeightMerger>::And(
    const SortedArray<Field, WeightMerger>& right) {
  if ( unlikely(0 == Size() || 0 == right.Size()) ) {
    array_[current_array_idx_].clear();
    return;
  }

  array_[1-current_array_idx_].clear();

  size_t idx_left=0, idx_right=0;
  while (true) {
    if (operator[](idx_left).first > right[idx_right].first) {
      if ( unlikely(++idx_right == right.Size()) ) break;
    } else if (operator[](idx_left).first < right[idx_right].first) {
      if ( unlikely(++idx_left == Size()) ) break;
    } else {
      array_[1-current_array_idx_].push_back(
          std::pair<Field, int64_t>(
              right[idx_right].first,
              weight_merger_.Merge(
                  operator[](idx_left).second,
                  right[idx_right].second)));
      ++idx_left;
      ++idx_right;
      if ( unlikely(idx_left == Size() || idx_right == right.Size()) ) break;
    }
  }
  current_array_idx_ = 1-current_array_idx_;
}

template <typename Field, typename WeightMerger>
void SortedArray<Field, WeightMerger>::AndNot(
    const SortedArray<Field, WeightMerger>& right) {
  if ( unlikely(0 == Size() || 0 == right.Size()) ) return;

  array_[1-current_array_idx_].clear();

  size_t idx_left=0, idx_right=0;
  while (true) {
    if (operator[](idx_left).first > right[idx_right].first) {
      if ( unlikely(++idx_right == right.Size()) ) {
        do {
          array_[1-current_array_idx_].push_back(operator[](idx_left));
        } while(++idx_left != Size());
        break;
      }
    } else if (operator[](idx_left).first < right[idx_right].first) {
      array_[1-current_array_idx_].push_back(operator[](idx_left));
      if ( unlikely(++idx_left == Size()) ) break;
    } else {
      ++idx_left; 
      ++idx_right;
      if (idx_left == Size()) {
        break;
      } else if (idx_right == right.Size()) {
        do {
          array_[1-current_array_idx_].push_back(operator[](idx_left));
        } while(++idx_left != Size());
        break;
      }
    }
  }
  current_array_idx_ = 1-current_array_idx_;
}

template <typename Field, typename WeightMerger>
void SortedArray<Field, WeightMerger>::Or(
    const SortedArray<Field, WeightMerger>& right) {
  if ( unlikely(0 == Size() || 0 == right.Size()) ) {
    if (0 == Size()) array_[current_array_idx_] = right.array_[right.current_array_idx_];
    return;
  }

  array_[1-current_array_idx_].clear();

  size_t idx_left=0, idx_right=0;
  while (true) {
    if (operator[](idx_left).first > right[idx_right].first) {
      array_[1-current_array_idx_].push_back(right[idx_right++]);
    } else if (operator[](idx_left).first < right[idx_right].first) {
      array_[1-current_array_idx_].push_back(operator[](idx_left++));
    } else {
      array_[1-current_array_idx_].push_back(
          std::pair<Field, int64_t>(
              right[idx_right].first,
              weight_merger_.Merge(
                  operator[](idx_left).second, 
                  right[idx_right].second)));
      ++idx_left; 
      ++idx_right;
    }

    if (idx_left == Size()) {
      while(idx_right != right.Size()) {
        array_[1-current_array_idx_].push_back(right[idx_right++]);
      }
      break;
    } else if (idx_right == right.Size()) {
      while(idx_left != Size()) {
        array_[1-current_array_idx_].push_back(operator[](idx_left++));
      } 
      break;
    } 
  }
  current_array_idx_ = 1-current_array_idx_;
}

template <typename Field, typename WeightMerger>
bool SortedArray<Field, WeightMerger>::TryAnd(
    const SortedArray<Field, WeightMerger>& right) const {
  if ( unlikely(0 == Size() || 0 == right.Size()) ) return false;

  size_t idx_left=0, idx_right=0;
  while (true) {
    if (operator[](idx_left).first > right[idx_right].first) {
      if ( unlikely(++idx_right == right.Size()) ) return false;
    } else if (operator[](idx_left).first < right[idx_right].first) {
      if ( unlikely(++idx_left == Size()) ) return false;
    } else {
      return true;
    }
  }
}

template <typename Field, typename WeightMerger>
bool SortedArray<Field, WeightMerger>::Has(int64_t field) const {
  if ( unlikely( 0 == array_[current_array_idx_].size() ) ) return false;

  size_t left=0, right = array_[current_array_idx_].size() - 1;
  while (left < right) {
    size_t mid = ( (left+right) >> 1 );
    if ( field > array_[current_array_idx_][mid].first ) {
      left = mid+1;
    } else if ( field < array_[current_array_idx_][mid].first ) {
      right = mid;
    } else {
      return true;
    }
  }

  return field == array_[current_array_idx_][left].first ? true : false; 
}

template <typename Field, typename WeightMerger>
const std::vector< std::pair<Field, int64_t> >* 
SortedArray<Field, WeightMerger>::GetArray() const {
  return &(array_[current_array_idx_]);
}

template <typename field_t, typename weight_merger_t>
std::ostream& operator<<(
    std::ostream& oss, 
    const SortedArray<field_t, weight_merger_t>& sorted_array) {
  const std::vector< std::pair<field_t, int64_t> >& array = 
      sorted_array.array_[sorted_array.current_array_idx_];
  oss << "[";
  for (size_t i=0; i < array.size(); ++i) {
    oss << "[" << array[i].first << "," << array[i].second << "]";
  }
  oss << "]";
  return oss;
}

}}
