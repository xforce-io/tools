#pragma once 

namespace zmt { namespace material_center {

template <bool cond, typename A, typename B>
struct If{
  typedef A Type;
};

template <typename A, typename B>
struct If<false, A, B> {
  typedef B Type;
};

template <typename A, typename B>
struct IsSame {
  static const bool R=false;
};

template <typename A>
struct IsSame<A, A> {
  static const bool R=true;
};

template <typename T>
struct IntRange {};

template <>
struct IntRange<bool> {
  static const bool H=true;
  static const bool L=false;
  static bool Check(int64_t /*int64*/) { return true; }
};

template <>
struct IntRange<int8_t> {
  static const int8_t H=SCHAR_MAX;
  static const int8_t L=SCHAR_MIN;
  static bool Check(int64_t int64) { return int64<=H && int64>=L; }
};

template <>
struct IntRange<int16_t> {
  static const int16_t H=SHRT_MAX;
  static const int16_t L=SHRT_MIN;
  static bool Check(int64_t int64) { return int64<=H && int64>=L; }
};

template <>
struct IntRange<int32_t> {
  static const int32_t H=INT_MAX;
  static const int32_t L=INT_MIN;
  static bool Check(int64_t int64) { return int64<=H && int64>=L; }
};

template <>
struct IntRange<int64_t> {
  static const int64_t H=LLONG_MAX;
  static const int64_t L=LLONG_MIN;
  static bool Check(int64_t int64) { return int64<=H && int64>=L; }
};

}}
