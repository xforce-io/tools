#pragma once

#include <cstddef>
#include <new>
#include <vector>
#include <list>
#include <tr1/unordered_map>
#include <assert.h>

#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include "allspark/logger.h"
#include "allspark/weaktype.h"

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif

#ifndef INOUT
#define INOUT
#endif

#ifndef UNUSE
#define UNUSE(arg) { (void)(arg); }
#endif

#ifndef DISALLOW_COPY_AND_ASSIGN
#define DISALLOW_COPY_AND_ASSIGN(type_name) \
	type_name(const type_name&); \
	void operator=(const type_name &);
#endif

#ifndef RCAST
#define RCAST reinterpret_cast
#endif

#ifndef SCAST
#define SCAST static_cast
#endif

#ifndef likely
#define likely(x) __builtin_expect ((x), true)
#endif

#ifndef unlikely
#define unlikely(x) __builtin_expect ((x), false)
#endif

#ifndef DEBUG
#define DEBUG(str) LOG_DEBUG(material_center, str)
#endif

#ifndef TRACE
#define TRACE(str) LOG_TRACE(material_center, str)
#endif

#ifndef NOTICE
#define NOTICE(str) LOG_INFO(material_center, str)
#endif

#ifndef WARN
#define WARN(str) LOG_WARN(material_center, str)
#endif

#ifndef FATAL
#define FATAL(str) LOG_FATAL(material_center, str)
#endif

#ifndef MEGA_ASSERT
#define MEGA_ASSERT(op) \
  assert(op);
#endif

#ifndef MEGA_BUG
#define MEGA_BUG(op) \
  MEGA_ASSERT(!(op))
#endif

#ifndef MEGA_BUG_FATAL
#define MEGA_BUG_FATAL(op, str) \
  FATAL(str); \
  MEGA_BUG(op)
#endif

#ifndef MEGA_FAIL_HANDLE
#define MEGA_FAIL_HANDLE(op) \
  do { \
    if (unlikely(op)) goto ERROR_HANDLE; \
  } while(0);
#endif

#ifndef MEGA_FAIL_HANDLE_WARN
#define MEGA_FAIL_HANDLE_WARN(op, str) \
  do { \
    if (unlikely(op)) { \
      WARN(str); \
      goto ERROR_HANDLE; \
    } \
  } while(0);
#endif

#ifndef MEGA_FAIL_HANDLE_FATAL
#define MEGA_FAIL_HANDLE_FATAL(op, str) \
  do { \
    if (unlikely(op)) { \
      FATAL(str); \
      goto ERROR_HANDLE; \
    } \
  } while(0);
#endif

#ifndef MEGA_FAIL_HANDLE_CONTINUE
#define MEGA_FAIL_HANDLE_CONTINUE(op) \
  if (unlikely(op)) { \
    continue; \
  }
#endif

#ifndef MEGA_FAIL_HANDLE_WARN_CONTINUE
#define MEGA_FAIL_HANDLE_WARN_CONTINUE(op, str) \
  if (unlikely(op)) { \
    WARN(str); \
    continue; \
  }
#endif

#ifndef MEGA_FAIL_HANDLE_FATAL_CONTINUE
#define MEGA_FAIL_HANDLE_FATAL_CONTINUE(op, str) \
  if (unlikely(op)) { \
    FATAL(str); \
    continue; \
  }
#endif

#ifndef MEGA_NEW
#define MEGA_NEW(member, type) \
  do { \
    member = ::new (std::nothrow) type; \
    MEGA_ASSERT(NULL!=member) \
  } while(0);
#endif

#ifndef MEGA_MALLOC
#define MEGA_MALLOC(member, type, size) \
  do { \
    member = reinterpret_cast<type>(::malloc(size)); \
    MEGA_ASSERT(NULL!=member) \
  } while(0);
#endif

#ifndef MEGA_REALLOC
#define MEGA_REALLOC(new_member, old_member, type, size) \
  do { \
    new_member = reinterpret_cast<type>(::realloc(old_member, size)); \
    MEGA_ASSERT(NULL!=new_member) \
  } while(0);
#endif

#ifndef MEGA_DELETE
#define MEGA_DELETE(member) \
  do { \
    if (likely(NULL!=member)) { \
        delete member; \
        member=NULL; \
    } \
  } while(0);
#endif

#ifndef MEGA_DELETE_ARRAY
#define MEGA_DELETE_ARRAY(member) \
  do { \
    if (likely(NULL!=member)) { \
        delete [] member; \
        member=NULL; \
    } \
  } while(0);
#endif

#ifndef MEGA_FREE
#define MEGA_FREE(member) \
  do { \
    if(likely(NULL!=member)) { \
        ::free(member); \
        member=NULL; \
    } \
  } while(0);
#endif

#ifndef MEGA_RAII_CHECK
#define MEGA_RAII_CHECK(ret) \
  if (unlikely(!init_)) { return ret; }
#endif

#ifndef MEGA_RAII_INIT
#define MEGA_RAII_INIT(ret) \
  if (unlikely(!init_) && unlikely(!Init_())) { return ret; }
#endif

#ifndef MEGA_RAII_SUPER_INIT
#define MEGA_RAII_SUPER_INIT(ret) \
  if (unlikely(!Super::init_) && unlikely(!Init_())) { return ret; }
#endif

/*
 * static assert, from loki
 */
template<int> struct CompileTimeError;
template<> struct CompileTimeError<true> {};

#ifndef MEGA_CONCAT
#define MEGA_CONCAT(X, Y) X##Y
#endif

#ifndef MEGA_STATIC_ASSERT
#define MEGA_STATIC_ASSERT(expr) \
  enum { \
    Assert = sizeof(CompileTimeError<(expr)!=0>), \
  };
#endif

#ifndef MEGA_STATIC_ASSERT_MSG
#define MEGA_STATIC_ASSERT_MSG(expr, msg) \
  enum { \
    MEGA_CONCAT(ERROR_##msg, __LINE__) = \
      sizeof(CompileTimeError<expr != 0 >) \
  }
#endif
/**/

namespace zmt { namespace material_center {

LOGGER_EXTERN_DECL(material_center);

class NoneType {};

}}
