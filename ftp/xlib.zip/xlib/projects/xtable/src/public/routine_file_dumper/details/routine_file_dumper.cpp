#include "../routine_file_dumper.h"

#include <iostream>

namespace zmt { namespace material_center {

const std::string RoutineFileDumper::kTmpfilePostfix = "_tmpfile";

RoutineFileDumper::RoutineFileDumper(bool& end) :
  tid_(0),
  end_(&end),
  init_(false) {}

bool RoutineFileDumper::RegisteDumpTask(
    const std::string& name,
    RoutineFileDumperCallback dump_callback, 
    void* args, 
    const std::string& dir, 
    const std::string& filename,
    time_t interval) {
  MEGA_RAII_INIT(false)

  mutex_.Lock();
  if (0!=interval) {
    tasks_.push_back(
        (struct RoutineFileDumpTask){
          name, dump_callback, args, dir, filename, interval, 0});
  } else {
    tmp_tasks_.push_back(
        (struct RoutineFileDumpTask){
          name, dump_callback, args, dir, filename, 0, 0});
  }
  mutex_.Unlock();
  return true;
}

RoutineFileDumper::~RoutineFileDumper() {
  if (0!=tid_) pthread_join(tid_, NULL);
}

void* RoutineFileDumper::Run(void* dumper_arg) {
  RoutineFileDumper& dumper = *RCAST<RoutineFileDumper*>(dumper_arg);
  while (false == *(dumper.end_)) {
    dumper.Dump_();
    sleep(kCheckIntervalInSec);
  }
  dumper.Dump_();
  return NULL;
}

bool RoutineFileDumper::Init_() {
  int ret = pthread_create(&tid_, NULL, Run, this);
  if (0!=ret) {
    tid_=0;
    FATAL("fail_spawn_dumper_thread");
    return false;
  }
  init_=true;
  return true;
}

void RoutineFileDumper::Dump_() {
  MEGA_RAII_INIT()

  mutex_.Lock();
  for (TmpTasksContainer::iterator iter = tmp_tasks_.begin();
      iter != tmp_tasks_.end();
      ++iter) {
    DumpTask_(*iter);
  }
  tmp_tasks_.clear();

  time_t current_time = clock();
  for (TasksContainer::iterator iter = tasks_.begin();
      iter != tasks_.end();
      ++iter) {
    RoutineFileDumpTask& routine_file_dump_task = *iter;
    if (current_time - routine_file_dump_task.last_dump_time > 
        routine_file_dump_task.interval) {
      DumpTask_(routine_file_dump_task);
      routine_file_dump_task.last_dump_time=current_time;
    }
  }
  mutex_.Unlock();
}

void RoutineFileDumper::DumpTask_(const RoutineFileDumpTask& routine_file_dump_task) {
  std::string filepath = routine_file_dump_task.dir + "/" + 
    routine_file_dump_task.filename;
  std::string tmp_filepath = routine_file_dump_task.dir + "/" + 
    routine_file_dump_task.filename + kTmpfilePostfix;

  FILE* fp = fopen(tmp_filepath.c_str(), "w");
  if (NULL==fp) {
    FATAL("fail_open_file[" << tmp_filepath << "]");
    return;
  }

  int ret = routine_file_dump_task.callback(routine_file_dump_task.args, fp);
  fclose(fp);

  if (0==ret) {
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "mv %s %s", tmp_filepath.c_str(), filepath.c_str());
    TRACE("dump task[" 
        << routine_file_dump_task.name 
        << "] filepath[" 
        << filepath 
        << "] succ");
    system(cmd);
  } else if (ret<0) {
    FATAL("fail_dump_to[" 
        << tmp_filepath 
        << "] task_name[" 
        << routine_file_dump_task.name
        << "]");
  }
}

}}
