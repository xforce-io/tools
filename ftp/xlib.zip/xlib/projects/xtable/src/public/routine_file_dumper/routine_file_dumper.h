#pragma once

#include "../common.h"
#include "../lock_policy.hpp"

namespace zmt { namespace material_center {

/*
 * @return:
 *    > 0: no need to dump file 
 *    ==0: succ in dump file
 *    < 0: fail in dump file
 */
typedef int (*RoutineFileDumperCallback)(void*, FILE*);

struct RoutineFileDumpTask {
  std::string name;
  RoutineFileDumperCallback callback;
  void* args;
  std::string dir;
  std::string filename;
  time_t interval;
  time_t last_dump_time;
};

class RoutineFileDumper {
 public:
  typedef std::vector<RoutineFileDumpTask> TasksContainer;
  typedef std::list<RoutineFileDumpTask> TmpTasksContainer;
  
 public:
  static const size_t kCheckIntervalInSec=1; 
  static const std::string kTmpfilePostfix;

 public:
  explicit RoutineFileDumper(bool& end);

  /*
   * @parameters:
   *    interval: 0 if dumper should be called once
   */
  bool RegisteDumpTask(
      const std::string& name,
      RoutineFileDumperCallback dump_callback, 
      void* args, 
      const std::string& dir, 
      const std::string& filename,
      time_t interval);

  virtual ~RoutineFileDumper();
 
 private:
  static void* Run(void* dumper); 

 private:
  bool Init_();

  void Dump_(); 
  void DumpTask_(const RoutineFileDumpTask& routine_file_dump_task);

 private: 
  TasksContainer tasks_;
  TmpTasksContainer tmp_tasks_;

  pthread_t tid_;
  ThreadMutex mutex_;
  bool* end_;

  bool init_;
};

}}
