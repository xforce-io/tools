#pragma once

#include <functional>
#include "base_cow_btree.hpp"

namespace zmt { namespace material_center {

template <
  typename Key,
  typename Val=Key,
  typename LessF=std::less<Key> >
class CowBtreeMap : 
  public BaseCowBtree< BaseCowBtreeParams< 
      Key, 
      std::pair<Key, Val>, 
      std::_Select1st< std::pair<Key, Val> >, 
      LessF, 
      false> > {
 public:
  typedef BaseCowBtree< BaseCowBtreeParams<
      Key, 
      std::pair<Key, Val>, 
      std::_Select1st< std::pair<Key, Val> >, 
      LessF, 
      false> > Super;

  typedef typename Super::Iterator Iterator;
 
 public:
  explicit CowBtreeMap(size_t fanout, LessF less = LessF()) :
    Super(fanout, std::_Select1st< std::pair<Key, Val> >(), less) {}

  std::pair<bool, Iterator> Insert(const Key& key, const Val& val);
};

template <
  typename Key,
  typename Val=Key,
  typename LessF=std::less<Key> >
class MultiCowBtreeMap : 
  public BaseCowBtree< BaseCowBtreeParams< 
      Key, 
      std::pair<Key, Val>, 
      std::_Select1st< std::pair<Key, Val> >, 
      LessF, 
      true> > {
 public:
  typedef BaseCowBtree< BaseCowBtreeParams<
      Key,
      std::pair<Key, Val>, 
      std::_Select1st< std::pair<Key, Val> >, 
      LessF, 
      true> > Super;
  typedef typename Super::Iterator Iterator;
 
 public:
  explicit MultiCowBtreeMap(size_t fanout, LessF less = LessF()) :
    Super(fanout, std::_Select1st< std::pair<Key, Val> >(), less) {}

  std::pair<bool, Iterator> Insert(const Key& key, const Val& val);
};

template <typename Key, typename Val, typename LessF>
std::pair<bool, typename CowBtreeMap<Key, Val, LessF>::Iterator> 
CowBtreeMap<Key, Val, LessF>::Insert(const Key& key, const Val& val) {
  return Super::Insert(std::pair<Key, Val>(key, val));
}

template <typename Key, typename Val, typename LessF>
std::pair<bool, typename MultiCowBtreeMap<Key, Val, LessF>::Iterator> 
MultiCowBtreeMap<Key, Val, LessF>::Insert(const Key& key, const Val& val) {
  return Super::Insert(std::pair<Key, Val>(key, val));
}

}}
