#pragma once

#include <ostream>
#include "..//common.h"
#include "..//functors.hpp"

namespace zmt { namespace material_center {

#define MEGA_SORTED_OBJS_TPL_HEADER \
template < \
    typename Key, \
    typename Val, \
    typename KeyExtractor, \
    typename LessF>

template <
    typename Key,
    typename Val=Key,
    typename KeyExtractor=ReflectorF<Val>,
    typename LessF=std::less<Key> >
class SortedObjs {
 public:
  typedef SortedObjs<Key, Val, KeyExtractor, LessF> Self;
   
 public:
  SortedObjs(
      size_t size,
      KeyExtractor key_extractor=KeyExtractor(),
      LessF less=LessF()) :
    size_(size),
    key_extractor_(key_extractor),
    less_(less),
    vals_(NULL),
    begin_(0),
    end_(0),
    init_(false) {}

 public:
  /*
   * @return:
   *  ret.first: the insert pos of Val, -1 if error happens
   */
  inline std::pair<int, Val*> Insert(const Val& val);

  /*
   * @brief: client should make sure that pos is the position to insert
   */
  std::pair<int, Val*> Insert(size_t pos, const Val& val);
  inline ssize_t Find(const Key& key) const;
  inline ssize_t FindFirstOf(const Key& key) const;

  /*
   * @return: the index of interval seped by vals which val belongs to
   */
  size_t LowBound(const Key& key) const;
  inline void Remove(size_t index);

  /*
   * @return: the num of objs removed
   */
  size_t RemoveObj(const Key& key);

  /*
   * @brief: client should make sure that there is enough space in dest
   */
  inline void MoveBackToFront(size_t size, Self& dest);
  inline void MoveFrontToBack(size_t size, Self& dest);

  size_t Size() const { return end_-begin_; }
  size_t Capacity() const { return size_; }
  const Val& operator[] (size_t index) const { return vals_[index+begin_]; }
  Val& operator[](size_t index) { return vals_[index+begin_]; }
  inline bool Copy(const SortedObjs& sorted_objs);
  inline void Clear() { end_=begin_; }

  /*
   * @notice : the following interfaces should be used when there is enough 
   *           space and user should make sure that val is in right position
   */
  Val& Front() { return vals_[begin_]; }
  Val& Back() { return vals_[end_-1]; }
  inline void PushBack(const Val& val);
  inline void PushFront(const Val& val);
  inline void PopFront() { ++begin_; }
  inline void PopBack() { --end_; }
  inline void ReserveSpaceAtHead(size_t size);
  inline void ReserveSpaceAtTail(size_t size);
  inline size_t MemCost() const;

  virtual ~SortedObjs();

 private:
  bool Init_();

  inline ssize_t Find_(const Key& key) const;

 private: 
  //const
  size_t size_;
  KeyExtractor key_extractor_;
  LessF less_;
  ///

  Val* vals_;
  size_t begin_;
  size_t end_;

  bool init_;

  template <
      typename key, 
      typename val, 
      typename key_extractor, 
      typename less>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const SortedObjs<key, val, key_extractor, less>& sorted_objs);
};

MEGA_SORTED_OBJS_TPL_HEADER
std::pair<int, Val*> 
SortedObjs<Key, Val, KeyExtractor, LessF>::Insert(const Val& val) { 
  return Insert(LowBound(key_extractor_(val)), val); 
}

MEGA_SORTED_OBJS_TPL_HEADER
std::pair<int, Val*>
SortedObjs<Key, Val, KeyExtractor, LessF>::Insert(size_t pos, const Val& val) {
  std::pair<int, Val*> invalid_res(-1, NULL);
  MEGA_RAII_INIT(invalid_res)

  if (unlikely(0==pos || pos+begin_ == end_)) {
    if (0==pos && 0!=begin_) {
      vals_[--begin_] = val;
      return std::pair<int, Val*>(0, vals_+begin_);
    } else if (end_-begin_ == pos && size_!=end_) {
      vals_[end_++] = val;
      return std::pair<int, Val*>(end_-begin_-1, vals_+end_-1);
    }
  }

  size_t absolute_pos = pos+begin_;
  if (pos <= end_-absolute_pos) {
    if (0!=begin_) {
      memmove(vals_+begin_-1, vals_+begin_, sizeof(Val) * (absolute_pos-begin_));
      --begin_;
      --absolute_pos;
    } else if (size_!=end_) {
      memmove(
          vals_+absolute_pos+1, 
          vals_+absolute_pos,
          sizeof(Val) * (end_-absolute_pos));
      ++end_;
    } else {
      return invalid_res;
    }
  } else {
    if (size_!=end_) {
      memmove(
          vals_+absolute_pos+1, 
          vals_+absolute_pos,
          sizeof(Val) * (end_-absolute_pos));
      ++end_;
    } else if (0!=begin_) {
      memmove(vals_+begin_-1, vals_+begin_, sizeof(Val) * (absolute_pos-begin_));
      --begin_;
      --absolute_pos;
    } else {
      return invalid_res;
    }
  }

  vals_[absolute_pos] = val;
  return std::pair<int, Val*>(pos, vals_+absolute_pos);
}

MEGA_SORTED_OBJS_TPL_HEADER
ssize_t SortedObjs<Key, Val, KeyExtractor, LessF>::Find(const Key& key) const {
  ssize_t ret = Find_(key);
  return ret>=0 ? ret-begin_ : ret;
}

MEGA_SORTED_OBJS_TPL_HEADER
ssize_t SortedObjs<Key, Val, KeyExtractor, LessF>::FindFirstOf(
    const Key& key) const {
  ssize_t index = Find_(key);
  if (unlikely(index<0)) return -1;

  size_t target_begin=index;
  while( begin_!=target_begin && key == key_extractor_(vals_[target_begin-1]) ) {
    --target_begin;
  }
  return target_begin-begin_;
}

MEGA_SORTED_OBJS_TPL_HEADER
size_t SortedObjs<Key, Val, KeyExtractor, LessF>::LowBound(const Key& key) const {
  if (unlikely(begin_==end_)) return 0;

  if (unlikely(key < key_extractor_(vals_[begin_]))) return 0;
  if (unlikely(key >= key_extractor_(vals_[end_-1]))) return end_-begin_;

  ssize_t iter_left=begin_;
  ssize_t iter_right=end_;
  size_t iter_mid;
  Key key_mid;
  while (iter_left+1 < iter_right) {
    iter_mid = ((iter_left+iter_right)>>1);
    key_mid = key_extractor_(vals_[iter_mid]);
    if (key<key_mid) {
      iter_right=iter_mid;
    } else {
      iter_left=iter_mid;
    }  
  }
  return iter_left-begin_+1;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::Remove(size_t index) {
  index+=begin_;
  if (index!=begin_ && index != end_-1) {
    memmove( vals_+index, vals_+index+1, sizeof(Val) * (Size() - index - 1) );
    --end_;
  } else {
    if (index==begin_) {
      ++begin_;
    } else if (index == end_-1) {
      --end_;
    }
  }
}

MEGA_SORTED_OBJS_TPL_HEADER
size_t SortedObjs<Key, Val, KeyExtractor, LessF>::RemoveObj(const Key& key) {
  ssize_t index = Find_(key);
  if (unlikely(index<0)) return 0;

  size_t target_begin=index;
  while( begin_!=target_begin && key == key_extractor_(vals_[target_begin-1]) ) {
    --target_begin;
  }

  size_t target_end=index;
  while( end_-1 != target_end && key == key_extractor_(vals_[target_end+1]) ) { 
    ++target_end;
  }

  if (end_ != target_end+1) {
    if (begin_!=target_begin) {
      if (end_-target_end >= target_begin-begin_) {
        memmove(
            vals_+begin_+target_end+1-target_begin,
            vals_+begin_,
            sizeof(Val) * (target_begin-begin_));
        begin_ += target_end+1-target_begin;
      } else {
        memmove(
            vals_+target_begin, 
            vals_+target_end+1, 
            sizeof(Val) * (end_-target_end-1));
        end_ -= target_end+1-target_begin;
      }
    } else {
      begin_ += target_end+1-target_begin;
    }
  } else {
    end_ -= target_end+1-target_begin;
  }
  return target_end+1-target_begin;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::MoveBackToFront(
    size_t size, 
    Self& dest) {
  dest.ReserveSpaceAtHead(size);
  memcpy(dest.vals_ + dest.begin_ - size, vals_+end_-size, size * sizeof(Val));
  end_-=size;
  dest.begin_ -= size;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::MoveFrontToBack(
    size_t size, 
    Self& dest) {
  dest.ReserveSpaceAtTail(size);
  memcpy(dest.vals_ + dest.end_, vals_+begin_, size * sizeof(Val));
  begin_+=size;
  dest.end_ += size;
}

MEGA_SORTED_OBJS_TPL_HEADER
bool SortedObjs<Key, Val, KeyExtractor, LessF>::Copy(
    const SortedObjs& sorted_objs) {
  MEGA_RAII_INIT(false)

  if (true!=sorted_objs.init_) {
    Clear();
    return true;
  }

  key_extractor_ = sorted_objs.key_extractor_;
  less_ = sorted_objs.less_;

  if (size_ < sorted_objs.Size()) {
    void* new_mem = realloc( vals_, sizeof(Val) * sorted_objs.Size() );
    if (NULL==new_mem) return false;

    vals_ = RCAST<Val*>(new_mem);
  }

  memcpy( 
      vals_, 
      sorted_objs.vals_+sorted_objs.begin_, 
      sizeof(Val) * sorted_objs.Size() );
  begin_=0;
  end_ = sorted_objs.Size();
  return true;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::PushBack(
    const Val& val) {
  ReserveSpaceAtTail(1);
  vals_[end_++] = val;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::PushFront(
    const Val& val) {
  ReserveSpaceAtHead(1);
  vals_[--begin_] = val;
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::ReserveSpaceAtHead(size_t size) {
  MEGA_RAII_INIT()

  if (likely(begin_>=size)) return;

  size_t old_begin=begin_;
  size_t len = Size();
  begin_=(size+size_-len)/2;
  end_ = begin_+len; 

  if (likely(0!=len)) {
    memmove(vals_+begin_, vals_+old_begin, sizeof(Val)*len);
  }
}

MEGA_SORTED_OBJS_TPL_HEADER
void SortedObjs<Key, Val, KeyExtractor, LessF>::ReserveSpaceAtTail(size_t size) {
  MEGA_RAII_INIT()

  if (likely(size_-end_ >= size)) return;

  size_t old_begin=begin_;
  size_t len = Size();
  begin_ = (size_-size-len)/2;
  end_ = begin_+len;

  if (likely(0!=len)) {
    memmove(vals_+begin_, vals_+old_begin, sizeof(Val)*len);
  }
}

MEGA_SORTED_OBJS_TPL_HEADER
size_t SortedObjs<Key, Val, KeyExtractor, LessF>::MemCost() const {
  return sizeof(Self) + sizeof(Val)*size_;
}

MEGA_SORTED_OBJS_TPL_HEADER
SortedObjs<Key, Val, KeyExtractor, LessF>::~SortedObjs() {
  if (NULL!=vals_) free(vals_);
}

MEGA_SORTED_OBJS_TPL_HEADER
bool SortedObjs<Key, Val, KeyExtractor, LessF>::Init_() {
  if (0==size_) return false;

  vals_ = RCAST<Val*>(malloc(size_ * sizeof(Val)));
  if (NULL!=vals_) {
    init_=true;
    return true;
  } else {
    return false;
  }
}

MEGA_SORTED_OBJS_TPL_HEADER
ssize_t SortedObjs<Key, Val, KeyExtractor, LessF>::Find_(const Key& key) const {
  ssize_t iter_left=begin_;
  ssize_t iter_right=end_;
  while (iter_left<iter_right) {
    size_t iter_mid = ((iter_left+iter_right)>>1);
    Key key_mid = key_extractor_(vals_[iter_mid]);
    if (key<key_mid) {
      iter_right = iter_mid-1;
    } else if (key>key_mid) {
      iter_left = iter_mid+1;
    } else {
      return iter_mid;
    }
  }

  return ( static_cast<ssize_t>(end_) != iter_left 
      && key == key_extractor_(vals_[iter_left]) ) ? 
        iter_left : -1; 
}

MEGA_SORTED_OBJS_TPL_HEADER
std::ostream& operator<<(
    std::ostream& os, 
    const SortedObjs<Key, Val, KeyExtractor, LessF>& sorted_objs) {
  os << "{ begin:" 
      << sorted_objs.begin_ 
      << ", end:" 
      << sorted_objs.end_
      << ", content:\"";
  for (size_t i=0; i < sorted_objs.Size(); ++i) {
    os << sorted_objs[i] << "|";
  }
  os << "\"}";
  return os;
}

}}
