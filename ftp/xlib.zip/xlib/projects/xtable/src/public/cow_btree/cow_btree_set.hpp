#pragma once

#include "base_cow_btree.hpp"

namespace zmt { namespace material_center {

template <
  typename Key,
  typename Val=Key,
  typename KeyExtractor=ReflectorF<Val>,
  typename LessF=std::less<Key> >
class CowBtreeSet : public BaseCowBtree< BaseCowBtreeParams<
    Key, 
    Val, 
    KeyExtractor, 
    LessF, 
    false> {
 public:
  typedef BaseCowBtree< BaseCowBtreeParams<
      Key, 
      Val, 
      KeyExtractor, 
      LessF, 
      false> > Super;
 
 public:
  explicit CowBtreeSet(
      size_t fanout,
      LessF less=LessF(),
      KeyExtractor key_extractor=KeyExtractor() ) :
    Super(fanout, key_extractor, less) {}
};

template <
  typename Key,
  typename Val=Key,
  typename KeyExtractor=ReflectorF<Val>,
  typename LessF=std::less<Key> >
class MultiCowBtreeSet : public BaseCowBtree< BaseCowBtreeParams<
    Key, 
    Val, 
    KeyExtractor, 
    LessF, 
    true> {
 public:
  typedef BaseCowBtree< BaseCowBtreeParams<
      Key, 
      Val,
      KeyExtractor, 
      LessF, 
      true> Super;
 
 public:
  explicit MultiCowBtreeSet(
      size_t fanout, 
      LessF less=LessF(),
      KeyExtractor key_extractor=KeyExtractor() ) :
    Super(fanout, key_extractor, less) {}
};

}}
