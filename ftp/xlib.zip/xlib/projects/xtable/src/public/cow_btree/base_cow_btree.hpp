#pragma once

#include "../common.h"
#include "../pool_objs.hpp"
#include "../functors.hpp"
#include "sorted_objs.hpp"

namespace zmt { namespace material_center {

template <typename BaseCowBtreeParams> class BaseCowBtreeNonLeaveNode;
template <typename BaseCowBtreeParams> class BaseCowBtreeLeaveNode;
template <typename BaseCowBtreeParams> class BaseCowBtree;
template <typename BaseCowBtreeParams> class BaseCowBtreeBaseIterator;
template <typename BaseCowBtreeParams> class BaseCowBtreeConstIterator;
template <typename BaseCowBtreeParams> class BaseCowBtreeIterator;

template <
    typename KeyParam, 
    typename ValParam, 
    typename KeyExtractorParam, 
    typename LessFParam, 
    bool IsMultiParam>
struct BaseCowBtreeParams {
  typedef KeyParam Key;
  typedef ValParam Val;
  typedef KeyExtractorParam KeyExtractor;
  typedef LessFParam LessF;
  static const bool IsMulti=IsMultiParam;
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeNode {
 public:
  typedef BaseCowBtreeNode<BaseCowBtreeParams> Self;
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> 
    NonLeaveNode;

  typedef BaseCowBtree<BaseCowBtreeParams> Tree;
  typedef SortedObjs<
      typename BaseCowBtreeParams::Key, 
      typename BaseCowBtreeParams::Val, 
      typename BaseCowBtreeParams::KeyExtractor, 
      typename BaseCowBtreeParams::LessF> Block;

  typedef typename BaseCowBtreeParams::Val Val;

 public:
  struct SharedSortedObjs {
    explicit SharedSortedObjs(size_t size) : 
      sorted_objs(size),
      shared_count(1) {}

    Block sorted_objs;
    size_t shared_count;
  };

 public: 
  BaseCowBtreeNode() {}
  explicit BaseCowBtreeNode(Tree& tree);

 public:
  inline bool NeedSplit() const;
  inline bool NeedMerge() const;
  virtual bool IsLeave() const=0;
  const Block& GetSortedObjs() const { return shared_sorted_objs_->sorted_objs; }
  Block& GetSortedObjs() { return shared_sorted_objs_->sorted_objs; }
  inline bool Normalize(bool reset);
  const Val& Value(size_t index) const { return GetSortedObjs()[index]; }
  Val& Value(size_t index) { return GetSortedObjs()[index]; }
  size_t LenVals() const { return GetSortedObjs().Size(); }
  virtual void Split(Self& new_node, NonLeaveNode* root_node);
  virtual Self* Merge();
  virtual void Clear();
  virtual void Reset();
  virtual size_t MemCost() const;
  virtual ~BaseCowBtreeNode();

 private:
  virtual bool Init_();

 private:
  //const
  Tree* tree_; 
  ///

  SharedSortedObjs* shared_sorted_objs_;
  NonLeaveNode* father_;
  size_t index_fathers_;

  bool init_;

  friend class BaseCowBtree<BaseCowBtreeParams>;

  template <typename base_cow_btree_params>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const BaseCowBtreeNode<base_cow_btree_params>& base_cow_btree_node);
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeNonLeaveNode : 
  public BaseCowBtreeNode<BaseCowBtreeParams> {
 public:
  typedef BaseCowBtreeNode<BaseCowBtreeParams> Super;
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> Self;
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> LeaveNode;
  typedef BaseCowBtree<BaseCowBtreeParams> Tree;
  
 public: 
  BaseCowBtreeNonLeaveNode() {}
  explicit BaseCowBtreeNonLeaveNode(Tree& tree);

 public:
  bool IsLeave() const { return false; }
  void Split(Super& new_node, Self* root_node);
  Super* Merge();
  bool Copy(const Self& node);
  size_t MemCost() const;
  virtual ~BaseCowBtreeNonLeaveNode();

 protected:
  Super* GetChild_(size_t index) { return children_[index]; } 

 private:
  bool Init_();

 private:
  Super** children_;

  friend class BaseCowBtree<BaseCowBtreeParams>;

  template <typename base_cow_btree_params>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const BaseCowBtreeNonLeaveNode<base_cow_btree_params>& 
        base_cow_btree_non_leave_node);
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeLeaveNode : 
  public BaseCowBtreeNode<BaseCowBtreeParams> {
 public:
  typedef BaseCowBtreeNode<BaseCowBtreeParams> Super;
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> Self;
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> 
    NonLeaveNode;

  typedef BaseCowBtree<BaseCowBtreeParams> Tree;
  typedef typename BaseCowBtreeParams::Val Val;
   
 public:
  BaseCowBtreeLeaveNode() {}
  explicit BaseCowBtreeLeaveNode(Tree& tree);

 public:
  bool IsLeave() const { return true; }
  void Split(Super& new_node, NonLeaveNode* root_node);
  Super* Merge();
  size_t MemCost() const;
  virtual ~BaseCowBtreeLeaveNode() {}
 
 private:
  bool Init_() { return Super::Init_(); }

 private:
  Self* next_;
  Self* prev_;

  friend class BaseCowBtree<BaseCowBtreeParams>;

  template <typename base_cow_btree_params>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const BaseCowBtreeLeaveNode<base_cow_btree_params>& 
        base_cow_btree_leave_node);
};

template <typename BaseCowBtreeParams>
class BaseCowBtree {
 public:
  typedef typename BaseCowBtreeParams::Key Key;
  typedef typename BaseCowBtreeParams::Val Val;
  typedef typename BaseCowBtreeParams::KeyExtractor KeyExtractor;
  typedef typename BaseCowBtreeParams::LessF LessF;

  typedef BaseCowBtree<BaseCowBtreeParams> Self;
  typedef BaseCowBtreeNode<BaseCowBtreeParams> Node;
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> LeaveNode;
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> NonLeaveNode;
  typedef BaseCowBtreeConstIterator<BaseCowBtreeParams> ConstIterator;
  typedef BaseCowBtreeIterator<BaseCowBtreeParams> Iterator;

 public:
  static const size_t kDefaultFanout=1024;
  static const size_t kMinFanout=5; 

 public:
  BaseCowBtree(
      size_t fanout=kDefaultFanout,
      KeyExtractor key_extractor=KeyExtractor(),
      LessF less=LessF());

  BaseCowBtree(const Self& other);

  /*
   * @note: iterator in return value should never be used after a Copy
   */
  std::pair<bool, Iterator> Insert(const Val& val);
  bool Erase(const Key& key);
  bool Erase(Iterator iterator);
  inline ConstIterator Find(const Key& key) const;
  inline Iterator Find(const Key& key);
  bool Copy(const Self& base_cow_btree);
  inline Self& operator=(const Self& other);
  inline void Clear();
  size_t Size() const { return num_elms_; }
  bool Empty() const { return 0==num_elms_; }

  inline ConstIterator Begin() const;
  inline ConstIterator End() const;
  inline Iterator Begin();
  inline Iterator End();
  inline ConstIterator RBegin() const;
  inline ConstIterator REnd() const;
  inline Iterator RBegin(); 
  inline Iterator REnd();

  const KeyExtractor GetKeyExtractor() const { return key_extractor_; }
  virtual ~BaseCowBtree();

 protected:
  size_t GetFanout_() const { return fanout_; }
  size_t GetHighWater_() const { return high_water_; }
  size_t GetLowWater_() const { return low_water_; }
  void SetHead_(LeaveNode& node) { head_=&node; }
  void SetTail_(LeaveNode& node) { tail_=&node; }
  LeaveNode* GetHead_() { return head_; }
  LeaveNode* GetTail_() { return tail_; }

 private:
  bool Init_();

  inline LeaveNode* Find_(const Key& key) const;

  /*
   * @return:
   *    ==0: succ in lend
   *    > 0: still need split
   *    < 0: error happens
   */
  inline int TryLendToBrother_(LeaveNode& node);
  inline int TryBorrowFromBrother_(LeaveNode& node);

  inline bool Split_(Node* current_node);
  inline bool Merge_(Node* current_node);

  /*
   * @return: <0 => error | >0 => can not balance | ==0 => succ in balance
   */
  inline int TryLendToLeftBrother_(LeaveNode& node);
  inline int TryLendToRightBrother_(LeaveNode& node);
  inline int TryBorrowFromLeftBrother_(LeaveNode& node);
  inline int TryBorrowFromRightBrother_(LeaveNode& node);

  inline void ShareValsLeftPointing_(LeaveNode& pooler, LeaveNode& richer);
  inline void ShareValsRightPointing_(LeaveNode& richer, LeaveNode& pooler);

 private:
  //const
  size_t fanout_;
  KeyExtractor key_extractor_;
  LessF less_;
  size_t high_water_;
  size_t low_water_;
  ///

  Node* root_;
  size_t num_elms_;
  LeaveNode* head_;
  LeaveNode* tail_;

  PoolObjsInit<NonLeaveNode> pool_nonleave_nodes_;
  PoolObjsInit<LeaveNode> pool_leave_nodes_;

  bool init_;

  friend class BaseCowBtreeNode<BaseCowBtreeParams>;
  friend class BaseCowBtreeLeaveNode<BaseCowBtreeParams>;
  friend class BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>;
  friend class BaseCowBtreeBaseIterator<BaseCowBtreeParams>;

  template <typename base_cow_btree_params>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const BaseCowBtree<base_cow_btree_params>& base_cow_btree);
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeBaseIterator {
 public:
  typedef typename BaseCowBtreeParams::Key Key;
  typedef typename BaseCowBtreeParams::Val Val;

  typedef BaseCowBtreeBaseIterator<BaseCowBtreeParams> Self;
  typedef BaseCowBtree<BaseCowBtreeParams> Master; 
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> LeaveNode; 

 public:
  BaseCowBtreeBaseIterator();
  BaseCowBtreeBaseIterator(Master& base_cow_btree, bool begin=true, bool ord=true);
  BaseCowBtreeBaseIterator(
      Master& base_cow_btree, 
      bool ord, 
      LeaveNode* current, 
      size_t index);

  inline bool operator==(const Self& btree_cow_btree_iterator) const;
  inline bool operator!=(const Self& btree_cow_btree_iterator) const;
  inline Self& operator++();
  inline Self operator++(int);
  inline const Val& operator*() const;
  inline const Key& GetKey() const;
  inline const Val& GetVal() const;

 protected:
  inline void Move_();

 private: 
  inline void MoveForward_();
  inline void MoveBackward_();

 protected:
  //const
  Master* base_cow_btree_;
  bool ord_;
  ///

  LeaveNode* current_;
  size_t index_;

  friend class BaseCowBtree<BaseCowBtreeParams>;
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeConstIterator :
  public BaseCowBtreeBaseIterator<BaseCowBtreeParams> {
 public:
  typedef typename BaseCowBtreeParams::Key Key;
  typedef typename BaseCowBtreeParams::Val Val;

  typedef BaseCowBtreeBaseIterator<BaseCowBtreeParams> Super;
  typedef BaseCowBtreeConstIterator<BaseCowBtreeParams> Self;
  typedef BaseCowBtree<BaseCowBtreeParams> Master; 
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> LeaveNode; 

 public:
  BaseCowBtreeConstIterator();
  BaseCowBtreeConstIterator(
      Master& base_cow_btree,
      bool begin=true,
      bool ord=true);

  BaseCowBtreeConstIterator(
      Master& base_cow_btree, 
      bool ord, 
      LeaveNode* current, 
      size_t index);

  BaseCowBtreeConstIterator(
      const BaseCowBtreeIterator<BaseCowBtreeParams>& iter);
};

template <typename BaseCowBtreeParams>
class BaseCowBtreeIterator :
  public BaseCowBtreeBaseIterator<BaseCowBtreeParams> {
 public:
  typedef typename BaseCowBtreeParams::Key Key;
  typedef typename BaseCowBtreeParams::Val Val;
  typedef typename BaseCowBtreeParams::KeyExtractor KeyExtractor;

  typedef BaseCowBtreeBaseIterator<BaseCowBtreeParams> Super;
  typedef BaseCowBtreeIterator<BaseCowBtreeParams> Self;
  typedef BaseCowBtree<BaseCowBtreeParams> Master; 
  typedef BaseCowBtreeLeaveNode<BaseCowBtreeParams> LeaveNode; 

 public:
  BaseCowBtreeIterator();
  BaseCowBtreeIterator(Master& base_cow_btree, bool begin=true, bool ord=true);
  BaseCowBtreeIterator(
      Master& base_cow_btree,
      bool ord, 
      LeaveNode* current, 
      size_t index) :
    Super(base_cow_btree, ord, current, index) {}

  inline Key* GetKeyToWrite();
  inline Val* GetValToWrite();
};

template <typename BaseCowBtreeParams>
BaseCowBtreeNode<BaseCowBtreeParams>::BaseCowBtreeNode(Tree& tree) :
  tree_(&tree),
  shared_sorted_objs_(NULL),
  father_(NULL),
  init_(false) {}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNode<BaseCowBtreeParams>::NeedSplit() const { 
  return shared_sorted_objs_->sorted_objs.Size() >= tree_->GetFanout_();
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNode<BaseCowBtreeParams>::NeedMerge() const { 
  return NULL!=father_ && 
    shared_sorted_objs_->sorted_objs.Size() < tree_->GetLowWater_() ;
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNode<BaseCowBtreeParams>::Normalize(bool reset) {
  MEGA_RAII_INIT(false)

  if (unlikely(shared_sorted_objs_->shared_count > 1)) {
    SharedSortedObjs* shared_sorted_objs =
      new (std::nothrow) SharedSortedObjs(tree_->GetFanout_() + 1);
    if (unlikely(NULL==shared_sorted_objs)) return false;

    if (likely(false==reset)) {
      bool ret = shared_sorted_objs->sorted_objs.Copy(GetSortedObjs());
      if (unlikely(false==ret)) {
        delete shared_sorted_objs;
        return false;
      }
    }

    --shared_sorted_objs_->shared_count;
    shared_sorted_objs_=shared_sorted_objs;
  } 
  return true;
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeNode<BaseCowBtreeParams>::Split(
    Self& new_node,
    NonLeaveNode* root_node) {
  MEGA_RAII_INIT()

  if (unlikely(true != Normalize(false))) return;

  //vals of new node
  size_t num_objs_moved = (LenVals() >> 1) + 1;
  GetSortedObjs().MoveBackToFront(num_objs_moved, new_node.GetSortedObjs());

  //father
  if (NULL!=father_) {
    if (unlikely(true != father_->Normalize(false))) return;

    father_->GetSortedObjs().Insert(
        index_fathers_,
        new_node.GetSortedObjs().Front());
    new_node.father_ = father_;
    new_node.index_fathers_ = index_fathers_+1;
  } else {
    if (unlikely(true != root_node->Normalize(false))) return;

    root_node->GetSortedObjs().PushBack(new_node.GetSortedObjs().Front());
    new_node.father_ = root_node;
    new_node.index_fathers_ = 1;
    father_=root_node;
    index_fathers_=0;
    father_->children_[0] = this;
  }

  if (false == IsLeave()) new_node.GetSortedObjs().PopFront();

  //father's childrens
  ssize_t end = static_cast<ssize_t>(father_->LenVals()) - 1;
  size_t len = end-index_fathers_;
  for (size_t i=0; i<len; ++i) {
    ++(father_->children_[end-i]->index_fathers_);
  }
  memmove(
      father_->children_ + index_fathers_ + 2,
      father_->children_ + index_fathers_ + 1,
      sizeof(father_->children_[0]) * len);

  father_->children_[new_node.index_fathers_] = &new_node;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNode<BaseCowBtreeParams>*
BaseCowBtreeNode<BaseCowBtreeParams>::Merge() {
  MEGA_RAII_INIT(NULL)

  Self* heir;
  size_t old_index_fathers = index_fathers_;
  size_t old_father_len_vals = father_->LenVals();
  if (0!=index_fathers_) {
    //move to left brother
    heir = static_cast<Self*>(father_->children_[index_fathers_-1]);
    if (unlikely(true != heir->Normalize(false))) return NULL;

    if (unlikely(false == IsLeave())) {
      heir->GetSortedObjs().PushBack(father_->Value(index_fathers_-1));
    }

    for (size_t i=0; i<LenVals(); ++i) {
      heir->GetSortedObjs().PushBack(Value(i));
    }

    if (unlikely(true != father_->Normalize(false))) return NULL;
    father_->GetSortedObjs().Remove(index_fathers_-1);
  } else {
    //move to right brother
    heir = static_cast<Self*>(father_->children_[index_fathers_+1]);
    if (unlikely(true != heir->Normalize(false))) return NULL;

    if (unlikely(false == IsLeave())) {
      heir->GetSortedObjs().PushFront(father_->Value(index_fathers_));
    }

    for (ssize_t i=LenVals()-1; i>=0; --i) {
      heir->GetSortedObjs().PushFront(Value(i));
    }

    if (unlikely(true != father_->Normalize(false))) return NULL;
    father_->GetSortedObjs().Remove(index_fathers_);

    for (size_t i = index_fathers_+1; i<=old_father_len_vals; ++i) {
      --father_->children_[i]->index_fathers_;
    }
  }

  if (likely(old_index_fathers < old_father_len_vals)) {
    memmove(
        &(father_->children_[old_index_fathers]),
        &(father_->children_[old_index_fathers+1]),
        sizeof(father_->children_[0]) * (old_father_len_vals-index_fathers_) );
  }
  return heir;
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeNode<BaseCowBtreeParams>::Clear() {
  MEGA_RAII_INIT()

  if (1 != shared_sorted_objs_->shared_count) {
    --shared_sorted_objs_->shared_count;
  } else {
    delete shared_sorted_objs_;
  }

  shared_sorted_objs_=NULL;
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeNode<BaseCowBtreeParams>::Reset() {
  MEGA_RAII_INIT()

  if (unlikely(NULL==shared_sorted_objs_)) {
    shared_sorted_objs_ = 
      new (std::nothrow) SharedSortedObjs(tree_->GetFanout_() + 1);
  }
}

template <typename BaseCowBtreeParams>
size_t BaseCowBtreeNode<BaseCowBtreeParams>::MemCost() const {
  return shared_sorted_objs_->sorted_objs.MemCost();
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNode<BaseCowBtreeParams>::~BaseCowBtreeNode() {
  if (NULL!=shared_sorted_objs_) {
    if (1 != shared_sorted_objs_->shared_count) {
      --shared_sorted_objs_->shared_count;
    } else {
      delete shared_sorted_objs_;
    }
  }
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNode<BaseCowBtreeParams>::Init_() {
  init_=true;
  return true;
}

template <typename BaseCowBtreeParams>
std::ostream& operator<<(
    std::ostream& os,
    const BaseCowBtreeNode<BaseCowBtreeParams>& base_cow_btree_node) {
  os << "{addr:"
      << &base_cow_btree_node
      << ",tree:"
      << base_cow_btree_node.tree_
      << ",index_father:"
      << base_cow_btree_node.index_fathers_
      << ",father_:"
      << base_cow_btree_node.father_;
  if (NULL != base_cow_btree_node.shared_sorted_objs_) {
    os << ",shared_count:"
        << base_cow_btree_node.shared_sorted_objs_->shared_count
        << ",sorted_objs:";
    os << base_cow_btree_node.shared_sorted_objs_->sorted_objs;
    os << ",";
  }
  return os;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::BaseCowBtreeNonLeaveNode(Tree& tree) :
  Super(tree),
  children_(NULL) {}

template <typename BaseCowBtreeParams>
void BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::Split(
    Super& new_node,
    Self* root_node) {
  Super::Split(new_node, root_node);

  size_t new_pos=0;
  for (size_t pos = Super::LenVals() + 1; pos<=Super::tree_->GetFanout_(); ++pos) {
    static_cast<Self&>(new_node).children_[new_pos] = children_[pos];
    static_cast<Self&>(new_node).children_[new_pos]->father_ = 
      static_cast<Self*>(&new_node);
    static_cast<Self&>(new_node).children_[new_pos]->index_fathers_ = new_pos;
    ++new_pos;
  }
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNode<BaseCowBtreeParams>*
BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::Merge() {
  if (0!=Super::index_fathers_) {
    //move to left brother
    Self* left_brother = static_cast<Self*>(
        Super::father_->children_[Super::index_fathers_-1]);
    for (size_t i=0; i <= Super::LenVals(); ++i) {
      children_[i]->index_fathers_ = i + left_brother->LenVals() + 1;
      children_[i]->father_ = left_brother;
    }

    memcpy(
        &(left_brother->children_[left_brother->LenVals()+1]),
        children_,
        sizeof(children_[0]) * (Super::LenVals() + 1) );

  } else {
    //move to right brother
    Self* right_brother = static_cast<Self*>(
        Super::father_->children_[Super::index_fathers_+1]);
    for (size_t i=0; i <= right_brother->LenVals(); ++i) {
      right_brother->children_[i]->index_fathers_ += Super::LenVals() + 1;
    }
    for (size_t i=0; i <= Super::LenVals(); ++i) {
      children_[i]->father_ = right_brother;
    }

    memmove(
        &(right_brother->children_[Super::LenVals() + 1]),
        right_brother->children_,
        sizeof(children_[0]) * (right_brother->LenVals() + 1) );
    memcpy(
        right_brother->children_,
        children_,
        sizeof(children_[0]) * (Super::LenVals() + 1) );
  }
  return Super::Merge();
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::Copy(
    const Self& node) {
  MEGA_RAII_SUPER_INIT(false)

  if (NULL != Super::shared_sorted_objs_) {
    MEGA_ASSERT(1 == Super::shared_sorted_objs_->shared_count);
    delete Super::shared_sorted_objs_;
  }

  Super::shared_sorted_objs_ = node.shared_sorted_objs_;
  ++Super::shared_sorted_objs_->shared_count;
  if (true== node.children_[0]->IsLeave()) {
    for (size_t i=0; i <= node.LenVals(); ++i) {
      children_[i] = Super::tree_->pool_leave_nodes_.Get();
      if (unlikely(NULL == children_[i])) return false;

      children_[i]->father_ = this;
      children_[i]->index_fathers_ = i;

      if (NULL != children_[i]->shared_sorted_objs_) {
        MEGA_ASSERT(1 == children_[i]->shared_sorted_objs_->shared_count);
        delete children_[i]->shared_sorted_objs_;
      }

      children_[i]->shared_sorted_objs_ = node.children_[i]->shared_sorted_objs_;
      ++children_[i]->shared_sorted_objs_->shared_count;
    }

    static_cast<LeaveNode*>(children_[0])->prev_ = NULL;
    static_cast<LeaveNode*>(children_[0])->next_ = 
      static_cast<LeaveNode*>(children_[1]);

    static_cast<LeaveNode*>(children_[node.LenVals()])->prev_ = 
      static_cast<LeaveNode*>(children_[node.LenVals() - 1]);

    static_cast<LeaveNode*>(children_[node.LenVals()])->next_ = NULL;
    for (size_t i=1; i < node.LenVals(); ++i) {
      static_cast<LeaveNode*>(children_[i])->prev_ = 
        static_cast<LeaveNode*>(children_[i-1]);

      static_cast<LeaveNode*>(children_[i])->next_ = 
        static_cast<LeaveNode*>(children_[i+1]);
    }
  } else {
    for (size_t i=0; i <= node.LenVals(); ++i) {
      children_[i] = Super::tree_->pool_nonleave_nodes_.Get();
      if (unlikely(NULL == children_[i])) return false;

      children_[i]->father_ = this;
      children_[i]->index_fathers_ = i;

      bool ret = static_cast<Self*>(children_[i])->Copy(
          static_cast<Self&>(*(node.children_[i])));
      if (unlikely(false==ret)) return false;
    }
  }
  return true;
}

template <typename BaseCowBtreeParams>
size_t BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::MemCost() const {
  return Super::MemCost() + 
    sizeof(Self) +
    sizeof(children_[0]) * (Super::tree_->fanout_ + 1);
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::~BaseCowBtreeNonLeaveNode() {
  MEGA_DELETE_ARRAY(children_)
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>::Init_() { 
  bool ret;
  MEGA_NEW(children_, Super* [Super::tree_->fanout_+1])

  ret = Super::Init_(); 
  MEGA_FAIL_HANDLE(false==ret)
  return true;

  ERROR_HANDLE:
  MEGA_DELETE_ARRAY(children_)
  return false;
}

template <typename BaseCowBtreeParams>
std::ostream& operator<<(
    std::ostream& os, 
    const BaseCowBtreeNonLeaveNode<BaseCowBtreeParams>& non_leave_node) {
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> Super;
  os << static_cast<const Super&>(non_leave_node);
  if (NULL != non_leave_node.children_) {
    os << "childrens:[";
    for (size_t i=0; i <= non_leave_node.LenVals(); ++i) {
      os << non_leave_node.children_[i] << ",";
    }
    os << "]";
  }
  os << "}";
  return os;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeLeaveNode<BaseCowBtreeParams>::BaseCowBtreeLeaveNode(Tree& tree) :
  Super(tree),
  next_(NULL),
  prev_(NULL) {} 

template <typename BaseCowBtreeParams>
void BaseCowBtreeLeaveNode<BaseCowBtreeParams>::Split(
    Super& new_node,
    NonLeaveNode* root_node) {
  Super::Split(new_node, root_node);

  static_cast<Self&>(new_node).next_=next_;
  static_cast<Self&>(new_node).prev_=this;
  if (NULL!=next_) next_->prev_ = static_cast<Self*>(&new_node);
  next_ = static_cast<Self*>(&new_node);

  if (NULL == static_cast<Self&>(new_node).next_) {
    Super::tree_->SetTail_(static_cast<Self&>(new_node));
  }
}

template <typename BaseCowBtreeParams>
BaseCowBtreeNode<BaseCowBtreeParams>*
BaseCowBtreeLeaveNode<BaseCowBtreeParams>::Merge() {
  if (NULL!=next_) {
    next_->prev_ = prev_;
  } else {
    Super::tree_->SetTail_(*prev_);
  }

  if (NULL!=prev_) {
    prev_->next_ = next_;
  } else {
    Super::tree_->SetHead_(*next_);
  }
  return Super::Merge();
}

template <typename BaseCowBtreeParams>
size_t BaseCowBtreeLeaveNode<BaseCowBtreeParams>::MemCost() const {
  return Super::MemCost() + sizeof(Self);
}

template <typename BaseCowBtreeParams>
std::ostream& operator<<(
    std::ostream& os, 
    const BaseCowBtreeLeaveNode<BaseCowBtreeParams>& leave_node) {
  typedef BaseCowBtreeNonLeaveNode<BaseCowBtreeParams> Super;
  os << static_cast<const Super&>(leave_node)
     << "next:\""
     << leave_node.next_
     << "\",prev:\""
     << leave_node.prev_
     << "\"}";
  return os;
}

template <typename BaseCowBtreeParams>
BaseCowBtree<BaseCowBtreeParams>::BaseCowBtree(
    size_t fanout,
    KeyExtractor key_extractor,
    LessF less) :
  fanout_(fanout),
  key_extractor_(key_extractor),
  less_(less),
  high_water_(fanout-1),
  low_water_(((fanout_+1) >> 1) - 1),
  root_(NULL),
  num_elms_(0),
  head_(NULL),
  tail_(NULL),
  pool_nonleave_nodes_(NonLeaveNode(*this)),
  pool_leave_nodes_(LeaveNode(*this)),
  init_(false) {}

template <typename BaseCowBtreeParams>
BaseCowBtree<BaseCowBtreeParams>::BaseCowBtree(
    const Self& other) :
  fanout_(other.fanout_),
  key_extractor_(other.key_extractor_),
  less_(other.less_),
  high_water_(other.high_water_),
  low_water_(other.low_water_),
  root_(NULL),
  num_elms_(0),
  head_(NULL),
  tail_(NULL),
  pool_nonleave_nodes_(NonLeaveNode(*this)),
  pool_leave_nodes_(LeaveNode(*this)) { 
  init_=false;
  *this=other; 
}

template <typename BaseCowBtreeParams>
std::pair< bool, BaseCowBtreeIterator<BaseCowBtreeParams> > 
BaseCowBtree<BaseCowBtreeParams>::Insert(const Val& val) {
  std::pair<bool, Iterator> invalid_res(false, End());
  MEGA_RAII_INIT(invalid_res)

  if (unlikely(NULL==root_)) {
    root_ = pool_leave_nodes_.Get();
    if (NULL==root_) return invalid_res;

    root_->Reset();
  }

  Key key = key_extractor_(val);
  LeaveNode* iter_node = Find_(key);
  if (false == BaseCowBtreeParams::IsMulti) {
    ssize_t ret = iter_node->GetSortedObjs().Find(key);
    if (ret>=0) return invalid_res;
  }

  if (unlikely(true != iter_node->Normalize(false))) return invalid_res;
  std::pair<int, Val*> val_res = iter_node->GetSortedObjs().Insert(val);
  if (unlikely(val_res.first < 0)) return invalid_res;

  if (likely(false == iter_node->NeedSplit())) {
    if (unlikely(0==num_elms_++)) {
      SetHead_(*iter_node);
      SetTail_(*iter_node);
    }
    return std::pair<bool, Iterator>(
        true, 
        Iterator(*this, 0, iter_node, val_res.first));
  }

  int ret = TryLendToBrother_(static_cast<LeaveNode&>(*iter_node));
  if (0==ret) {
    return std::pair<bool, Iterator>(
        true, 
        Iterator(*this, 0, iter_node, val_res.first));
  } else if (ret>0) {
  } else {
    return invalid_res;
  }

  if ( true == Split_(iter_node) ) {
    ++num_elms_;
    return std::pair<bool, Iterator>(
        true, 
        Iterator(*this, 0, iter_node, val_res.first));
  } else {
    return invalid_res;
  }
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Erase(const Key& key) {
  MEGA_RAII_INIT(false)

  if (unlikely(NULL==root_)) return false;

  bool has_item_removed=false;
  for (;;) {
    Node* iter_node = Find_(key);
    ssize_t ret_find = iter_node->GetSortedObjs().Find(key);
    if (ret_find<0) {
      return true==has_item_removed ? true : false;
    } else {
      if (unlikely(true != iter_node->Normalize(false))) return false;

      size_t items_removed = iter_node->GetSortedObjs().RemoveObj(key);
      MEGA_ASSERT(0!=items_removed);
      has_item_removed=true;
      num_elms_-=items_removed;
      if (unlikely(0==num_elms_)) {
        pool_leave_nodes_.Free(static_cast<LeaveNode*>(root_));
        root_ = head_ = tail_ = NULL;
        return true;
      }
    }

    Node* father = iter_node->father_;
    if (unlikely( 0 != iter_node->index_fathers_
        && NULL != father
        && key == key_extractor_(
            father->GetSortedObjs()[iter_node->index_fathers_ - 1]))) {
      if (unlikely(true != father->Normalize(false))) return false;

      father->GetSortedObjs()[iter_node->index_fathers_ - 1] = 
        iter_node->GetSortedObjs().Front();
    }

    if (likely(false == iter_node->NeedMerge())) continue;


    int ret = TryBorrowFromBrother_(static_cast<LeaveNode&>(*iter_node));
    if (0==ret) {
      continue;
    } else if (ret>0) {
    } else {
      return false;
    }

    if (true != Merge_(iter_node)) {
      return false;
    }
  }
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Erase(Iterator iterator) {
  MEGA_RAII_INIT(false)

  if (unlikely(NULL==root_)) return false;

  LeaveNode* iter_node = iterator.current_;
  if (unlikely(true != iter_node->Normalize(false))) return false;

  iter_node->GetSortedObjs().Remove(iterator.index_);
  --num_elms_;

  Node* father = iter_node->father_;
  if (unlikely(0 != iter_node->index_fathers_
      && NULL!=father
      && 0 == iterator.index_)) {
    if (unlikely(true != father->Normalize(false))) return false;

    father->GetSortedObjs()[iter_node->index_fathers_ - 1] = 
      iter_node->GetSortedObjs().Front();
  }

  if (likely(false == iter_node->NeedMerge())) return true;;

  int ret = TryBorrowFromBrother_(*iter_node);
  if (0==ret) {
    return true;
  } else if (ret>0) {
  } else {
    return false;
  }

  if (true != Merge_(iter_node)) {
    return false;
  }
  return true;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeConstIterator<BaseCowBtreeParams>
BaseCowBtree<BaseCowBtreeParams>::Find(const Key& key) const {
  LeaveNode* leave_node = Find_(key);
  if (NULL==leave_node) return End();

  ssize_t index = leave_node->GetSortedObjs().FindFirstOf(key); 
  if (index<0) return End();
  
  return ConstIterator(const_cast<Self&>(*this), true, leave_node, index);
}

template <typename BaseCowBtreeParams>
BaseCowBtreeIterator<BaseCowBtreeParams> 
BaseCowBtree<BaseCowBtreeParams>::Find(const Key& key) {
  LeaveNode* leave_node = Find_(key);
  if (NULL==leave_node) return End();

  ssize_t index = leave_node->GetSortedObjs().FindFirstOf(key); 
  if (index<0) return End();
  
  return Iterator(*this, true, leave_node, index);
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Copy(
    const Self& other) {
  if (unlikely(this == &other)) return true;
  if (unlikely(fanout_ != other.fanout_ 
      && true==init_)) {
    return false;
  }

  fanout_ = other.fanout_;
  key_extractor_ = other.key_extractor_;
  less_ = other.less_;

  if (unlikely(true != other.init_)) {
    Clear();
    return true;
  }

  if (unlikely(true==init_)) {
    Clear();
  }

  Node* tmp_head;
  Node* tmp_tail;
  MEGA_ASSERT(NULL==root_);
  if (true == other.root_->IsLeave()) {
    root_ = pool_leave_nodes_.Get();
    MEGA_FAIL_HANDLE(NULL==root_)

    LeaveNode* leave_node = static_cast<LeaveNode*>(root_);
    leave_node->shared_sorted_objs_ = other.root_->shared_sorted_objs_;
    ++leave_node->shared_sorted_objs_->shared_count;
    leave_node->father_ = NULL;
    leave_node->next_ = leave_node->prev_ = NULL;
  } else {
    root_ = pool_nonleave_nodes_.Get();
    MEGA_FAIL_HANDLE(NULL==root_)

    NonLeaveNode* non_leave_node = static_cast<NonLeaveNode*>(root_);
    bool ret = non_leave_node->Copy(
        static_cast<NonLeaveNode&>(*(other.root_)));
    MEGA_FAIL_HANDLE(true!=ret)
  }

  root_->father_=NULL;

  num_elms_ = other.num_elms_;

  tmp_head=root_;
  while (false == tmp_head->IsLeave()) {
    tmp_head = static_cast<NonLeaveNode*>(tmp_head)->GetChild_(0);
  }
  head_ = static_cast<LeaveNode*>(tmp_head);

  tmp_tail=root_;
  while (false == tmp_tail->IsLeave()) {
    tmp_tail= static_cast<NonLeaveNode*>(tmp_tail)->GetChild_(tmp_tail->LenVals());
  }
  tail_ = static_cast<LeaveNode*>(tmp_tail);

  init_=true;
  return true;

  ERROR_HANDLE:
  if (NULL!=root_) {
    root_->Clear();
    if (true == root_->IsLeave()) {
      pool_leave_nodes_.Free(static_cast<LeaveNode*>(root_));
    } else {
      pool_nonleave_nodes_.Free(static_cast<NonLeaveNode*>(root_));
    }
  }
  return false;
}

template <typename BaseCowBtreeParams>
BaseCowBtree<BaseCowBtreeParams>& 
BaseCowBtree<BaseCowBtreeParams>::operator=(const Self& other) {
  Copy(other);
  return *this;
}

template <typename BaseCowBtreeParams>
void BaseCowBtree<BaseCowBtreeParams>::Clear() {
  MEGA_RAII_INIT()

  std::list<Node*> nodes_tobe_handled;
  size_t num_nodes_tobe_handled=0;
  if (unlikely(NULL==root_)) return;

  nodes_tobe_handled.push_back(root_);
  ++num_nodes_tobe_handled;
  while (false == nodes_tobe_handled.empty()) {
    size_t tmp_num_nodes_tobe_handled=0;
    for (size_t i=0; i<num_nodes_tobe_handled; ++i) {
      Node* node = nodes_tobe_handled.front();
      if (false == node->IsLeave()) {
        NonLeaveNode* non_leave_node = RCAST<NonLeaveNode*>(node);
        for (size_t j=0; j <= node->LenVals(); ++j) {
          nodes_tobe_handled.push_back(non_leave_node->GetChild_(j));
        }
        tmp_num_nodes_tobe_handled += non_leave_node->LenVals() + 1;
        non_leave_node->Clear();
        pool_nonleave_nodes_.Free(non_leave_node);
      } else {
        LeaveNode* leave_node = RCAST<LeaveNode*>(node);
        leave_node->Clear();
        pool_leave_nodes_.Free(leave_node);
      }
      nodes_tobe_handled.pop_front();
    }

    num_nodes_tobe_handled=tmp_num_nodes_tobe_handled;
  }
  root_=NULL;
  num_elms_=0;
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::ConstIterator 
BaseCowBtree<BaseCowBtreeParams>::Begin() const { 
  return ConstIterator(const_cast<Self&>(*this), true, true); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::ConstIterator 
BaseCowBtree<BaseCowBtreeParams>::End() const { 
  return ConstIterator(const_cast<Self&>(*this), false, true); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::Iterator 
BaseCowBtree<BaseCowBtreeParams>::Begin() { 
  return Iterator(*this, true, true); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::Iterator 
BaseCowBtree<BaseCowBtreeParams>::End() { 
  return Iterator(*this, false, true); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::ConstIterator 
BaseCowBtree<BaseCowBtreeParams>::RBegin() const { 
  return ConstIterator(const_cast<Self&>(*this), true, false); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::ConstIterator 
BaseCowBtree<BaseCowBtreeParams>::REnd() const { 
  return ConstIterator(const_cast<Self&>(*this), false, false);
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::Iterator 
BaseCowBtree<BaseCowBtreeParams>::RBegin() { 
  return Iterator(*this, true, false); 
}

template <typename BaseCowBtreeParams>
typename BaseCowBtree<BaseCowBtreeParams>::Iterator 
BaseCowBtree<BaseCowBtreeParams>::REnd() { 
  return Iterator(*this, false, false); 
}

template <typename BaseCowBtreeParams>
BaseCowBtree<BaseCowBtreeParams>::~BaseCowBtree() {
  Clear();
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Init_() {
  MEGA_FAIL_HANDLE(fanout_<kMinFanout);

  init_=true;
  return true;

  ERROR_HANDLE:
  return false;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeLeaveNode<BaseCowBtreeParams>* 
BaseCowBtree<BaseCowBtreeParams>::Find_(const Key& key) const {
  Node* iter_node = root_;
  while ( false == iter_node->IsLeave() ) {
    size_t index_to_insert = iter_node->GetSortedObjs().LowBound(key);
    iter_node = static_cast<NonLeaveNode*>(
        iter_node)->children_[index_to_insert];
  }
  return static_cast<LeaveNode*>(iter_node);
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryLendToBrother_(LeaveNode& node) {
  if (unlikely(NULL != node.father_)) {
    int ret = TryLendToLeftBrother_(node);
    if (0==ret) {
      ++num_elms_;
      return 0;
    } else if (ret>0) {
      ret = TryLendToRightBrother_(node);
      if (0==ret) {
        ++num_elms_;
        return 0;
      } else if (ret<0) {
        return -1;
      }
    } else {
      return -1;
    }
  }
  return 1;
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryBorrowFromBrother_(LeaveNode& node) {
  if (unlikely(NULL != node.father_
      && true == node.IsLeave())) {
    int ret = TryBorrowFromLeftBrother_(static_cast<LeaveNode&>(node));
    if (0==ret) {
      return 0;
    } else if (ret>0) {
      ret = TryBorrowFromRightBrother_(static_cast<LeaveNode&>(node));
      if (0==ret) {
        return 0;
      } else if (ret<0) {
        --num_elms_;
        return -1;
      }
    } else {
      --num_elms_;
      return -1;
    }
  }
  return 1;
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Split_(Node* iter_node) {
  Node* new_node=NULL;
  NonLeaveNode* new_root_node=NULL;
  Node* start_node=iter_node;
  
  new_node = pool_leave_nodes_.Get();
  MEGA_FAIL_HANDLE(NULL==new_node)

  new_node->Reset();

  if (unlikely(NULL==iter_node->father_)) {
    new_root_node = pool_nonleave_nodes_.Get();
    MEGA_FAIL_HANDLE(NULL==new_root_node)

    new_root_node->Reset();
    root_=new_root_node;
  }

  iter_node->Split(
      *new_node, 
      NULL!=iter_node->father_ ? NULL : new_root_node);
  iter_node=iter_node->father_;
  while ( NULL!=iter_node && true == iter_node->NeedSplit() ) {
    new_node=NULL;
    new_root_node=NULL;

    new_node = pool_nonleave_nodes_.Get();
    MEGA_FAIL_HANDLE(NULL==new_node)

    new_node->Reset();
    if (unlikely(NULL==iter_node->father_)) {
      new_root_node = pool_nonleave_nodes_.Get();
      MEGA_FAIL_HANDLE(NULL==new_root_node)

      new_root_node->Reset();
      root_=new_root_node;
    }

    iter_node->Split(
        *new_node, 
        NULL!=iter_node->father_ ? NULL : new_root_node);
    iter_node=iter_node->father_;
  }
  return true;

  ERROR_HANDLE:
  if (NULL!=new_node) {
    new_node->Clear();
    if (start_node==iter_node) {
      pool_leave_nodes_.Free(static_cast<LeaveNode*>(new_node));
    } else {
      pool_nonleave_nodes_.Free(static_cast<NonLeaveNode*>(new_node));
    }
  }
  if (NULL!=new_root_node) {
    new_root_node->Clear();
    pool_nonleave_nodes_.Free(new_root_node);
  }
  return false;
}

template <typename BaseCowBtreeParams>
bool BaseCowBtree<BaseCowBtreeParams>::Merge_(Node* current_node) {
  do {
    if (unlikely(true != current_node->Normalize(false))) return false;

    Node* heir = current_node->Merge();
    if (unlikely(0 == current_node->father_->LenVals())) {
      MEGA_ASSERT(root_ == current_node->father_);
      root_->Clear();
      pool_nonleave_nodes_.Free(static_cast<NonLeaveNode*>(root_));
      root_=heir;
      root_->father_ = NULL;
    }

    Node* node_tobe_discarded = current_node;
    if (current_node!=root_) current_node = current_node->father_;

    node_tobe_discarded->Clear();
    if (true == node_tobe_discarded->IsLeave()) {
      pool_leave_nodes_.Free(static_cast<LeaveNode*>(node_tobe_discarded));
    } else {
      pool_nonleave_nodes_.Free(static_cast<NonLeaveNode*>(node_tobe_discarded));
    }
  } while (true == current_node->NeedMerge());
  return true;
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryLendToLeftBrother_(
    LeaveNode& node) {
  if (0 != node.index_fathers_) {
    LeaveNode* brother = node.prev_;
    if ( brother->LenVals() < high_water_ ) {
      if (unlikely(true != brother->Normalize(false))) return -1;

      ShareValsLeftPointing_(*brother, node);
      return 0;
    }
  } 
  return 1;
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryLendToRightBrother_(
    LeaveNode& node) {
  if ( node.father_->LenVals() != node.index_fathers_) {
    LeaveNode* brother = node.next_;
    if ( brother->LenVals() < high_water_ ) {
      if (unlikely(true != brother->Normalize(false))) return -1;

      ShareValsRightPointing_(node, *brother);
      return 0;
    }
  } 
  return 1;
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryBorrowFromLeftBrother_(
    LeaveNode& node) {
  if (0 != node.index_fathers_) {
    LeaveNode* brother = node.prev_;
    if ( brother->LenVals() > low_water_ ) {
      if (unlikely(true != brother->Normalize(false))) return -1;

      ShareValsRightPointing_(*brother, node);
      return 0;
    }
  } 
  return 1;
}

template <typename BaseCowBtreeParams>
int BaseCowBtree<BaseCowBtreeParams>::TryBorrowFromRightBrother_(
    LeaveNode& node) {
  if ( node.father_->LenVals() != node.index_fathers_) {
    LeaveNode* brother = node.next_;
    if ( brother->LenVals() > low_water_ ) {
      if (unlikely(true != brother->Normalize(false))) return -1;

      ShareValsLeftPointing_(node, *brother);
      return 0;
    }
  } 
  return 1;
}

template <typename BaseCowBtreeParams>
void BaseCowBtree<BaseCowBtreeParams>::ShareValsLeftPointing_(
    LeaveNode& pooler,
    LeaveNode& richer) {
  richer.GetSortedObjs().MoveFrontToBack(
      ( richer.LenVals() - pooler.LenVals() )>>1, 
      pooler.GetSortedObjs());
  richer.father_->Value((richer.index_fathers_ + pooler.index_fathers_)>>1) = 
    richer.GetSortedObjs().Front();
}

template <typename BaseCowBtreeParams>
void BaseCowBtree<BaseCowBtreeParams>::ShareValsRightPointing_(
    LeaveNode& richer,
    LeaveNode& pooler) {
  richer.GetSortedObjs().MoveBackToFront(
      ( richer.LenVals() - pooler.LenVals() )>>1, 
      pooler.GetSortedObjs());
  richer.father_->Value((richer.index_fathers_ + pooler.index_fathers_)>>1) = 
    pooler.GetSortedObjs().Front();
}

template <typename BaseCowBtreeParams>
std::ostream& operator<<(
    std::ostream& os, 
    const BaseCowBtree<BaseCowBtreeParams>& base_cow_btree) {
  os << "{fanout:" 
      << base_cow_btree.fanout_ 
      << ",num_elms:"
      << base_cow_btree.num_elms_
      << ",root:";

  if (NULL != base_cow_btree.root_) {
    os << *base_cow_btree.root_;
  } else {
    os << "NULL";
  }
  os << "}";
  return os;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::BaseCowBtreeBaseIterator() :
  base_cow_btree_(NULL),
  current_(NULL) {}

template <typename BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::BaseCowBtreeBaseIterator(
    Master& base_cow_btree, 
    bool begin,
    bool ord) :
  base_cow_btree_(&base_cow_btree),
  ord_(ord),
  current_(
      true==begin ?
        ( true==ord_ ? 
          base_cow_btree.GetHead_() : 
          base_cow_btree.GetTail_() ) : NULL),
  index_(true==begin && false==ord ? current_->LenVals() - 1 : 0) {}

template <typename BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::BaseCowBtreeBaseIterator(
    Master& base_cow_btree, bool ord, LeaveNode* current, size_t index) :
  base_cow_btree_(&base_cow_btree),
  ord_(ord), 
  current_(current), 
  index_(index) {}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeBaseIterator<BaseCowBtreeParams>::operator==(
    const Self& btree_cow_btree_iterator) const {
  if (NULL!=current_) {
    return ord_ == btree_cow_btree_iterator.ord_
      && current_ == btree_cow_btree_iterator.current_
      && index_ == btree_cow_btree_iterator.index_;
  } else {
    return NULL==btree_cow_btree_iterator.current_;
  }
}

template <typename BaseCowBtreeParams>
bool BaseCowBtreeBaseIterator<BaseCowBtreeParams>::operator!=(
    const Self& btree_cow_btree_iterator) const {
  return !(operator==(btree_cow_btree_iterator));
}

template <typename BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>&
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::operator++() {
  Move_();
  return *this;
}

template <typename BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::operator++(int) {
  Self tmp=*this;
  Move_();
  return tmp;
}

template <typename BaseCowBtreeParams>
const typename BaseCowBtreeParams::Val& 
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::operator*() const {
  return current_->Value(index_);
}

template <typename BaseCowBtreeParams>
const typename BaseCowBtreeParams::Key& 
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::GetKey() const { 
  return base_cow_btree_->GetKeyExtractor()(current_->Value(index_));
}

template <typename BaseCowBtreeParams>
const typename BaseCowBtreeParams::Val& 
BaseCowBtreeBaseIterator<BaseCowBtreeParams>::GetVal() const { 
  return current_->Value(index_); 
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeBaseIterator<BaseCowBtreeParams>::Move_() {
  if (true==ord_) {
    MoveForward_();
  } else {
    MoveBackward_();
  }
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeBaseIterator<BaseCowBtreeParams>::MoveForward_() {
  if (unlikely(NULL==current_)) return;

  if (unlikely( ++index_ == current_->LenVals() )) {
    if (NULL != current_->next_) { 
      current_ = current_->next_;
      index_=0;
    } else {
      current_=NULL;
    }
  }
}

template <typename BaseCowBtreeParams>
void BaseCowBtreeBaseIterator<BaseCowBtreeParams>::MoveBackward_() {
  if (unlikely(NULL==current_)) return;

  if (0!=index_) {
    --index_;
  } else {
    if (NULL != current_->prev_) { 
      current_ = current_->prev_;
      index_ = current_->LenVals() - 1;
    } else {
      current_=NULL;
    }
  }
}

template <typename BaseCowBtreeParams>
BaseCowBtreeConstIterator<BaseCowBtreeParams>::BaseCowBtreeConstIterator() :
  Super() {}

template <typename BaseCowBtreeParams>
BaseCowBtreeConstIterator<BaseCowBtreeParams>::BaseCowBtreeConstIterator(
    Master& base_cow_btree,
    bool begin,
    bool ord) :
      Super(base_cow_btree, begin, ord) {}

template <typename BaseCowBtreeParams>
BaseCowBtreeConstIterator<BaseCowBtreeParams>::BaseCowBtreeConstIterator(
    Master& base_cow_btree, 
    bool ord, 
    LeaveNode* current, 
    size_t index) :
      Super(base_cow_btree, ord, current, index) {}

template <typename BaseCowBtreeParams>
BaseCowBtreeConstIterator<BaseCowBtreeParams>::BaseCowBtreeConstIterator(
    const BaseCowBtreeIterator<BaseCowBtreeParams>& iter) :
      Super(iter.ord_, iter.current_, iter.index_) {}

template <typename BaseCowBtreeParams>
BaseCowBtreeIterator<BaseCowBtreeParams>::BaseCowBtreeIterator() :
  Super() {}

template <typename BaseCowBtreeParams>
BaseCowBtreeIterator<BaseCowBtreeParams>::BaseCowBtreeIterator(
    Master& base_cow_btree,
    bool begin,
    bool ord) :
  Super(base_cow_btree, begin, ord) {}

template <typename BaseCowBtreeParams>
typename BaseCowBtreeParams::Key*
BaseCowBtreeIterator<BaseCowBtreeParams>::GetKeyToWrite() {
  bool ret = Super::current_->Normalize();
  if (unlikely(true!=ret)) return NULL;

  return Super::base_cow_btree_->GetKeyExtractor()(
      Super::current_->Value(Super::index_));
}

template <typename BaseCowBtreeParams>
typename BaseCowBtreeParams::Val*
BaseCowBtreeIterator<BaseCowBtreeParams>::GetValToWrite() {
  bool ret = Super::current_->Normalize();
  if (unlikely(true!=ret)) return NULL;

  return Super::current_->Value(Super::index_);
}

}}
