#pragma once

#include <iostream>
#include <ostream>
#include <bits/stl_function.h>
#include <backward/hash_fun.h>
#include <algorithm>

#include "../common.h"
#include "../pool_objs.hpp"

/*
 * copy-on-write hashmap, not optimized for traversal. 
 * Once needed, just link buckets_ to a list, and this will occur 
 * extra 2*sizeof(*) for each non-empty bucket
 */

namespace zmt { namespace material_center {

template <typename BaseCowHashmapParams> class BaseCowHashmapConstIterator;
template <typename BaseCowHashmapParams> class BaseCowHashmapIterator;

template <
    typename KeyParam, 
    typename ValParam, 
    typename HashFParam, 
    typename EqualKeyFParam, 
    typename AtExitFParam,
    bool IsMultiParam>
struct BaseCowHashmapParams {
  typedef KeyParam Key;
  typedef ValParam Val;
  typedef HashFParam HashF;
  typedef EqualKeyFParam EqualKeyF;
  typedef AtExitFParam AtExitF;
  static const bool IsMulti=IsMultiParam;
};

template <typename BaseCowHashmapParams>
struct BaseCowHashmapNode {
  typedef typename BaseCowHashmapParams::Key Key;
  typedef typename BaseCowHashmapParams::Val Val;

  BaseCowHashmapNode<BaseCowHashmapParams>* next;
  Key key;
  Val val;
};

template <typename BaseCowHashmapParams>
class BaseCowHashmap {
 public:
  typedef typename BaseCowHashmapParams::Key Key;
  typedef typename BaseCowHashmapParams::Val Val;
  typedef typename BaseCowHashmapParams::HashF HashF;
  typedef typename BaseCowHashmapParams::EqualKeyF EqualKeyF;
  typedef typename BaseCowHashmapParams::AtExitF AtExitF;

  typedef BaseCowHashmap<BaseCowHashmapParams> Self;
  typedef BaseCowHashmapNode<BaseCowHashmapParams> Node;
  typedef BaseCowHashmapConstIterator<BaseCowHashmapParams> ConstIterator;
  typedef BaseCowHashmapIterator<BaseCowHashmapParams> Iterator;

 public:
  struct Bucket {
    explicit Bucket() : head(NULL), shared_count(1) {}

    Node* head;
    uint32_t shared_count;
  };

 public:
  static const size_t kDefaultSizeBuckets=1000;
  static const bool kDefaultToResize=false;

  static const double kDefaultResizeThreshold=2;
  static const size_t kDefaultMempoolBlock=(1<<20);

 public:
  BaseCowHashmap(
      size_t hint_size_buckets,
      bool to_resize,
      const HashF& hasher,
      const EqualKeyF& equal_key,
      const AtExitF& at_exit);

  BaseCowHashmap(const Self& other);

  /*
   * @note: iterator in return value should never be used after a Copy
   */
  std::pair<bool, Iterator> Insert(const Key& key, const Val& val);
  bool Erase(const Key& key);
  bool Erase(Iterator iterator);
  inline ConstIterator Find(const Key& key) const;
  inline Iterator Find(const Key& key);
  bool Copy(const Self& other);
  inline Self& operator=(const Self& other);
  void Clear();
  size_t Size() const { return num_items_; }
  bool Empty() const { return 0==num_items_; }

  inline ConstIterator Begin() const;
  ConstIterator End() const { return ConstIterator(*this, false); }
  inline Iterator Begin();
  Iterator End() { return Iterator(*this, false); }

  inline size_t MemCost() const;
  inline void DumpMemCost(std::ostream& oss) const;

  virtual ~BaseCowHashmap();

 private:
  //imported from std::hashtable
  static const size_t kNumPrimes_=29;
  static const size_t kPrimeList_[kNumPrimes_];

 protected: 
  virtual Node* GetNode_(const Key& key, const Val& val); 
  virtual void FreeNode_(Node& node);
  virtual bool CopyBucket_(Bucket** bucket, const Node* except, bool except_node);
  virtual bool CopyBucketAndGetNode_(Bucket** bucket, INOUT Node*& node_to_get);

 private:
  inline bool Init_();

  inline static size_t NextPrime_(size_t hint_size_buckets);
  bool Resize_();
  inline bool NormalizeBucket_(
      Bucket** bucket_addr,
      const Node* except=NULL, 
      bool except_node=false);

  inline bool NormalizeBucketAndGetNode_(
      Bucket** bucket_addr,
      Node*& node_to_get);

  inline void FreeBucket_(Bucket& bucket);
  inline Node** FindNodeBefore_(Bucket* bucket, const Key& key) const;

 protected:
  //const 
  size_t hint_size_buckets_;
  bool to_resize_;
  double resize_threshold_;
  HashF hasher_;
  EqualKeyF equal_key_;
  AtExitF at_exit_;

  PoolObjs<Node> node_alloc_;
  ///

  size_t size_buckets_;
  Bucket** buckets_;
  size_t num_items_;
  size_t num_buckets_allocated_;

  bool init_;

  friend class BaseCowHashmapIterator<BaseCowHashmapParams>;
  friend class BaseCowHashmapConstIterator<BaseCowHashmapParams>;

  template <typename base_cow_hashmap_params>
  friend std::ostream& operator<<(
      std::ostream& os, 
      const BaseCowHashmap<base_cow_hashmap_params>& base_cow_hashmap);
};

template <typename BaseCowHashmapParams>
class BaseCowHashmapBaseIterator {
 public:
  typedef typename BaseCowHashmapParams::Key Key;
  typedef typename BaseCowHashmapParams::Val Val;
  typedef BaseCowHashmapBaseIterator<BaseCowHashmapParams> Self;
  typedef BaseCowHashmap<BaseCowHashmapParams> Master;

 public:
  BaseCowHashmapBaseIterator() {}
  BaseCowHashmapBaseIterator(const Master& base_cow_hashmap, bool begin) : 
    base_cow_hashmap_(&base_cow_hashmap),
    bucket_index_(true==begin ? 0 : -1),
    node_(NULL) {}

  BaseCowHashmapBaseIterator(
      const Master& base_cow_hashmap,
      size_t bucket_index,
      typename Master::Node** node) :
    base_cow_hashmap_(&base_cow_hashmap),
    bucket_index_(bucket_index), 
    node_(node) {}

  inline bool operator==(
      const BaseCowHashmapBaseIterator& base_cow_hashmap_base_iterator) const;
  inline bool operator!=(
      const BaseCowHashmapBaseIterator& base_cow_hashmap_base_iterator) const;
  inline Self& operator++();
  inline Self operator++(int);

  const Key& GetKey() const { return (*node_)->key; }
  const Val& GetVal() const { return (*node_)->val; }

 private:
  void MoveToNext_();

 private: 
  //const
  const Master* base_cow_hashmap_;
  ///

  ssize_t bucket_index_;
  typename Master::Node** node_;

  friend class BaseCowHashmap<BaseCowHashmapParams>;
};

template <typename BaseCowHashmapParams>
class BaseCowHashmapConstIterator : 
  public BaseCowHashmapBaseIterator<BaseCowHashmapParams> {
 public:
  typedef BaseCowHashmapBaseIterator<BaseCowHashmapParams> Super;

 public:
  BaseCowHashmapConstIterator() {}
  BaseCowHashmapConstIterator(
      const typename Super::Master& base_cow_hashmap, 
      bool begin=true) : 
    Super(base_cow_hashmap, begin) {}

  BaseCowHashmapConstIterator(
      const typename Super::Master& base_cow_hashmap,
      size_t bucket_index,
      typename Super::Master::Node** node) :
    Super(base_cow_hashmap, bucket_index, node) {}

  BaseCowHashmapConstIterator(
      const BaseCowHashmapIterator<BaseCowHashmapParams>& iterator) :
    Super(static_cast<const Super&>(iterator)) {}
};

template <typename BaseCowHashmapParams>
class BaseCowHashmapIterator : 
  public BaseCowHashmapBaseIterator<BaseCowHashmapParams> {
 public:
  typedef typename BaseCowHashmapParams::Key Key;
  typedef typename BaseCowHashmapParams::Val Val;
  typedef BaseCowHashmapBaseIterator<BaseCowHashmapParams> Super;
  typedef BaseCowHashmap<BaseCowHashmapParams> Master;

 public:
  BaseCowHashmapIterator() {}
  BaseCowHashmapIterator(
      const typename Super::Master& base_cow_hashmap, 
      bool begin=true) : 
    Super(base_cow_hashmap, begin) {}

  BaseCowHashmapIterator(
      const typename Super::Master& base_cow_hashmap,
      size_t bucket_index,
      typename Super::Master::Node** node) :
    Super(base_cow_hashmap, bucket_index, node) {}

  inline Key* GetKeyToWrite();
  inline Val* GetValToWrite();
};

template <typename BaseCowHashmapParams>
const size_t 
BaseCowHashmap<BaseCowHashmapParams>::kPrimeList_[ kNumPrimes_] = {
  5,          53,         97,         193,       389,
  769,        1543,       3079,       6151,      12289,
  24593,      49157,      98317,      196613,    393241,
  786433,     1572869,    3145739,    6291469,   12582917,
  25165843,   50331653,   100663319,  201326611, 402653189,
  805306457,  1610612741, 3221225473, 4294967291
};

template <typename BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>::BaseCowHashmap(
    size_t hint_size_buckets,
    bool to_resize,
    const HashF& hasher,
    const EqualKeyF& equal_key,
    const AtExitF& at_exit) : 
  hint_size_buckets_(hint_size_buckets),
  to_resize_(to_resize),  
  hasher_(hasher),
  equal_key_(equal_key),
  at_exit_(at_exit),
  node_alloc_(0, kDefaultMempoolBlock),
  size_buckets_(0),
  buckets_(NULL),
  num_items_(0),
  num_buckets_allocated_(0),
  init_(false) {}

template <typename BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>::BaseCowHashmap(
    const Self& other) :
  hint_size_buckets_(other.hint_size_buckets_),
  to_resize_(other.to_resize_),  
  hasher_(other.hasher_),
  equal_key_(other.equal_key_),
  at_exit_(other.at_exit_),
  size_buckets_(0),
  buckets_(NULL),
  num_items_(0),
  num_buckets_allocated_(0) {
  init_=false;
  *this=other; 
}

template <typename BaseCowHashmapParams>
std::pair< bool, BaseCowHashmapIterator<BaseCowHashmapParams> > 
BaseCowHashmap<BaseCowHashmapParams>::Insert(
    const Key& key, 
    const Val& val) {
  std::pair<bool, Iterator> result;
  result.first=false;
  MEGA_RAII_INIT(result)

  size_t bucket_index;
  Bucket** bucket_addr;
  Bucket* bucket_src;
  Bucket* new_bucket;
  Node** target_node=NULL;
  Node* new_node=NULL;

  if( true==to_resize_
      && static_cast<double>(num_items_)/size_buckets_ >= resize_threshold_ ) {
    MEGA_FAIL_HANDLE(true!=Resize_())
  }

  bucket_index = hasher_(key) % size_buckets_;
  bucket_addr = buckets_+bucket_index;
  bucket_src=*bucket_addr;

  if (NULL==bucket_src) {
    MEGA_NEW(new_bucket, Bucket)
    new_bucket->shared_count=1;
    new_bucket->head=NULL;
    ++num_buckets_allocated_;

    *bucket_addr=new_bucket;
  } else {
    target_node = FindNodeBefore_(bucket_src, key); 
    if (NULL!=target_node) {
      if (false==BaseCowHashmapParams::IsMulti) return result;
    }

    if (1 != bucket_src->shared_count) {
      MEGA_FAIL_HANDLE(true != NormalizeBucket_(bucket_addr))
    }
  }

  new_node = GetNode_(key, val);
  MEGA_FAIL_HANDLE(NULL==new_node)

  if (unlikely(NULL==target_node)) target_node = &((*bucket_addr)->head);

  new_node->next = *target_node;
  *target_node = new_node;
  new_node=NULL;
  ++num_items_;
  result.first=true;
  result.second = Iterator(*this, bucket_index, target_node);
  return result;

  ERROR_HANDLE:
  if (NULL!=new_node) FreeNode_(*new_node);
  return result;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::Erase(const Key& key) {
  MEGA_RAII_INIT(false)

  Bucket** bucket_addr = &(buckets_[hasher_(key) % size_buckets_]);
  Bucket* bucket_src=*bucket_addr;
  Node** pre_obj_node;

  pre_obj_node = FindNodeBefore_(*bucket_addr, key);
  if ( unlikely(NULL==pre_obj_node) ) return false;

  if (1==bucket_src->shared_count) {
    Node* iter = *pre_obj_node;
    Node* tmp;
    do {
      tmp=iter;
      iter = iter->next;
      FreeNode_(*tmp);
      --num_items_;
    } while ( NULL!=iter && key == iter->key );
    *pre_obj_node=iter;
  } else {
    MEGA_FAIL_HANDLE(true != NormalizeBucket_(bucket_addr, *pre_obj_node, false))
  }
  return true;

  ERROR_HANDLE:
  return false;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::Erase(Iterator iterator) {
  MEGA_RAII_INIT(false)

  Bucket** bucket_addr = &(buckets_[hasher_(iterator.GetKey()) % size_buckets_]);
  Bucket* bucket_src=*bucket_addr;
  Node** pre_obj_node = iterator.node_;

  if (unlikely(NULL==pre_obj_node)) return false;

  if (1==bucket_src->shared_count) {
    Node* tmp = *pre_obj_node;
    *pre_obj_node = (*pre_obj_node)->next;
    FreeNode_(*tmp);
    --num_items_;
  } else {
    MEGA_FAIL_HANDLE(true != NormalizeBucket_(bucket_addr, *pre_obj_node, true))
  }
  return true;

  ERROR_HANDLE:
  return false;
}

template <typename BaseCowHashmapParams>
BaseCowHashmapConstIterator<BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>::Find(const Key& key) const {
  MEGA_RAII_CHECK(ConstIterator(*this, false))

  size_t bucket_index = hasher_(key) % size_buckets_;
  Node** pre_obj_node = FindNodeBefore_(buckets_[bucket_index], key);
  return NULL!=pre_obj_node ?
    ConstIterator(*this, bucket_index, pre_obj_node) :
    ConstIterator(*this, false);
}

template <typename BaseCowHashmapParams>
BaseCowHashmapIterator<BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>::Find(const Key& key) {
  MEGA_RAII_INIT(Iterator(*this, false))

  size_t bucket_index = hasher_(key) % size_buckets_;
  Node** pre_obj_node = FindNodeBefore_(buckets_[bucket_index], key);
  return NULL!=pre_obj_node ?
    Iterator(*this, bucket_index, pre_obj_node) :
    Iterator(*this, false);
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::Copy(const Self& other) {
  if (unlikely(this == &other)) return true;

  if (true==to_resize_ 
      || true == other.to_resize_ 
      || hint_size_buckets_ != other.hint_size_buckets_) {
    return false;
  }

  hasher_ = other.hasher_;
  equal_key_ = other.equal_key_;
  at_exit_ = other.at_exit_;

  if (unlikely(true != other.init_)) {
    Clear();
    return true;
  }

  if (true==init_) {
    Clear();
    init_=false;
    if (size_buckets_ != other.size_buckets_) {
      MEGA_DELETE_ARRAY(buckets_)
      size_buckets_ = other.size_buckets_;
      MEGA_NEW(buckets_, Bucket* [size_buckets_])
    }
  } else {
    buckets_=NULL;
    size_buckets_ = other.size_buckets_;
    MEGA_NEW(buckets_, Bucket* [size_buckets_])
  }

  to_resize_ = other.to_resize_;
  resize_threshold_ = other.resize_threshold_;

  for (size_t i=0; i<size_buckets_; ++i) {
    buckets_[i] = other.buckets_[i];
    if (NULL != buckets_[i]) ++(buckets_[i]->shared_count);
  }

  num_items_ = other.num_items_;
  init_=true;
  return true;
}

template <typename BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>&
BaseCowHashmap<BaseCowHashmapParams>::operator=(
    const Self& other) {
  Copy(other);
  return *this;
}

template <typename BaseCowHashmapParams>
void BaseCowHashmap<BaseCowHashmapParams>::Clear() {
  MEGA_RAII_INIT()

  for (size_t i=0; i<size_buckets_; ++i) {
    if (NULL!=buckets_[i]) {
      FreeBucket_(*(buckets_[i]));
      buckets_[i] = NULL;
    }
  }
  num_items_=0;
}

template <typename BaseCowHashmapParams>
size_t BaseCowHashmap<BaseCowHashmapParams>::MemCost() const { 
  return node_alloc_.MemCost() + 
    sizeof(Bucket) * num_buckets_allocated_ +
    sizeof(Bucket*) * size_buckets_; 
}

template <typename BaseCowHashmapParams>
void BaseCowHashmap<BaseCowHashmapParams>::DumpMemCost(
    std::ostream& oss) const {
  oss << std::endl << "node alloc: " << std::endl;
  node_alloc_.DumpMemCost(oss);
  oss << std::endl 
      << "buckets cost: " 
      << sizeof(Bucket) * num_buckets_allocated_
      << sizeof(Bucket)
      << std::endl
      << "buckets slots cost: " 
      << sizeof(Bucket*) * size_buckets_ 
      << std::endl
      << "all: "
      << MemCost()
      << std::endl;
}

template <typename BaseCowHashmapParams>
BaseCowHashmapConstIterator<BaseCowHashmapParams> 
BaseCowHashmap<BaseCowHashmapParams>::Begin() const {
  ConstIterator iter(*this, true);
  ++iter;
  return iter;
}

template <typename BaseCowHashmapParams>
BaseCowHashmapIterator<BaseCowHashmapParams> 
BaseCowHashmap<BaseCowHashmapParams>::Begin() {
  Iterator iter(*this, true);
  ++iter;
  return iter;
}

template <typename BaseCowHashmapParams>
BaseCowHashmap<BaseCowHashmapParams>::~BaseCowHashmap() {
  Clear();
  MEGA_DELETE_ARRAY(buckets_);
  init_=false;
}

template <typename BaseCowHashmapParams>
typename BaseCowHashmap<BaseCowHashmapParams>::Node* 
BaseCowHashmap<BaseCowHashmapParams>::GetNode_(
    const Key& key, 
    const Val& val) {
  Node* node = node_alloc_.Get();
  MEGA_FAIL_HANDLE(NULL==node)

  node->key = key;
  node->val = val;
  return node;

  ERROR_HANDLE:
  if (NULL!=node) FreeNode_(*node);
  return NULL;
}

template <typename BaseCowHashmapParams>
void BaseCowHashmap<BaseCowHashmapParams>::FreeNode_(Node& node) {
  at_exit_(node.key, node.val);
  node_alloc_.Free(&node);
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::CopyBucket_(
    Bucket** bucket,
    const Node* except,
    bool except_node) {
  Bucket* new_bucket=NULL;
  Node* new_node=NULL;
  Node* iter;
  Node** tmp_node;

  MEGA_NEW(new_bucket, Bucket)
  new_bucket->shared_count = 1;
  new_bucket->head = NULL;
  ++num_buckets_allocated_;

#define GET_NODE_AND_INSERT() \
  new_node = GetNode_(iter->key, iter->val); \
  MEGA_FAIL_HANDLE(NULL==new_node) \
  \
  *tmp_node = new_node; \
  tmp_node = &(new_node->next); \
  new_node=NULL;

  iter = (*bucket)->head;
  tmp_node = &(new_bucket->head);
  if (NULL==except) {
    while(NULL!=iter) {
      GET_NODE_AND_INSERT()
      iter = iter->next;
    }
  } else {
    if (true==except_node) {
      while(NULL!=iter) {
        if (except==iter) {
          iter=iter->next;
          --num_items_;
          continue;
        }
        GET_NODE_AND_INSERT()
        iter=iter->next;
      }
    } else {
      while(NULL!=iter) {
        if (except->key == iter->key) {
          iter=iter->next;
          --num_items_;
          continue;
        }
        GET_NODE_AND_INSERT()
        iter=iter->next;
      }
    }
  }

#undef GET_NODE_AND_INSERT
  *tmp_node=NULL;
  *bucket = new_bucket;
  return true;

  ERROR_HANDLE:
  if (NULL!=new_bucket) FreeBucket_(*new_bucket);
  if (NULL!=new_node) FreeNode_(*new_node);
  return false;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::CopyBucketAndGetNode_(
    Bucket** bucket,
    Node*& node_to_get) {
  Bucket* new_bucket=NULL;
  Node* new_node=NULL;
  Node* iter;
  Node* node_to_return=NULL;
  Node** tmp_node;

  MEGA_NEW(new_bucket, Bucket)
  new_bucket->shared_count = 1;
  new_bucket->head = NULL;
  ++num_buckets_allocated_;

  iter = (*bucket)->head;
  tmp_node = &(new_bucket->head);
  while(NULL!=iter) {
    new_node = GetNode_(iter->key, iter->val);
    MEGA_FAIL_HANDLE(NULL==new_node)

    if (node_to_get == iter) node_to_return=new_node;

    *tmp_node = new_node;
    tmp_node = &(new_node->next);
    new_node=NULL;

    iter = iter->next;
  }
  *tmp_node=NULL;
  *bucket=new_bucket;
  node_to_get=node_to_return;
  return true;

  ERROR_HANDLE:
  if (NULL!=new_bucket) FreeBucket_(*new_bucket);
  if (NULL!=new_node) FreeNode_(*new_node);
  return false;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::Init_() {
  if ( unlikely(true==init_) ) return true;

  buckets_=NULL;
  resize_threshold_=kDefaultResizeThreshold;

  size_buckets_ = NextPrime_(hint_size_buckets_);
  MEGA_NEW(buckets_, Bucket* [size_buckets_])
  memset(buckets_, 0, sizeof(Bucket*)*size_buckets_);

  num_items_=0;
  init_=true;
  return true;
}

template <typename BaseCowHashmapParams>
size_t BaseCowHashmap<BaseCowHashmapParams>::NextPrime_(
    size_t hint_size_buckets) {
  const size_t* first = kPrimeList_;
  const size_t* last = kPrimeList_+kNumPrimes_;
  const size_t* pos = std::lower_bound(first, last, hint_size_buckets+1);
  return pos == last ? *(last-1) : *pos;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::Resize_() {
  size_t new_size_buckets=NextPrime_(size_buckets_);
  Bucket** new_buckets=NULL;
  Iterator iter;
  Bucket** bucket_addr;
  Bucket* new_bucket=NULL;
  Node* node=NULL;
  
  MEGA_NEW(new_buckets, Bucket* [new_size_buckets])
  memset(new_buckets, 0, new_size_buckets*sizeof(*new_buckets));

  iter = Begin();
  while (iter!=End()) {
    bucket_addr = &(new_buckets[hasher_(iter.GetKey()) % new_size_buckets]);
    if (NULL==*bucket_addr) {
      MEGA_NEW(new_bucket, Bucket)
      new_bucket->shared_count=1;
      new_bucket->head=NULL;
      ++num_buckets_allocated_;

      *bucket_addr=new_bucket;
      new_bucket=NULL;
    }

    node = GetNode_(iter.GetKey(), iter.GetVal());
    MEGA_FAIL_HANDLE(NULL==node)

    node->next=(*bucket_addr)->head;
    (*bucket_addr)->head=node;
    node=NULL;

    ++iter;
  }

  for (size_t i=0; i<size_buckets_; ++i) {
    if (NULL!=buckets_[i]) FreeBucket_(*(buckets_[i]));
  }
  MEGA_DELETE_ARRAY(buckets_)

  size_buckets_=new_size_buckets;
  buckets_=new_buckets;
  return true;

  ERROR_HANDLE:
  if (NULL!=node) FreeNode_(*node);
  if (NULL!=new_bucket) FreeBucket_(*new_bucket);
  for (size_t i=0; i<new_size_buckets; ++i) {
    if (NULL!=new_buckets[i]) FreeBucket_(*(new_buckets[i]));
  }
  return false;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::NormalizeBucket_(
    Bucket** bucket_addr,
    const Node* except, 
    bool except_node) {
  MEGA_ASSERT((*bucket_addr)->shared_count > 1);
  --(*bucket_addr)->shared_count;
  return CopyBucket_(bucket_addr, except, except_node);
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmap<BaseCowHashmapParams>::NormalizeBucketAndGetNode_(
    Bucket** bucket_addr,
    Node*& node_to_get) {
  MEGA_ASSERT((*bucket_addr)->shared_count > 1);
  --(*bucket_addr)->shared_count;
  return CopyBucketAndGetNode_(bucket_addr, node_to_get);
}

template <typename BaseCowHashmapParams>
void BaseCowHashmap<BaseCowHashmapParams>::FreeBucket_(
    Bucket& bucket) {
  if (likely(bucket.shared_count > 1)) {
    --bucket.shared_count;
    return;
  }

  Node* iter = bucket.head;
  Node* post;
  while(NULL!=iter) {
    post = iter->next;
    FreeNode_(*iter);
    iter=post;
  }
  delete &bucket;
}

template <typename BaseCowHashmapParams>
BaseCowHashmapNode<BaseCowHashmapParams>** 
BaseCowHashmap<BaseCowHashmapParams>::FindNodeBefore_(
    Bucket* bucket, 
    const Key& key) const {
  if (unlikely(NULL==bucket)) return NULL;

  Node** iter=&(bucket->head);
  while (NULL!=*iter) {
    if (true == equal_key_((*iter)->key, key)) return iter;
    iter=&((*iter)->next);
  }
  return NULL;
}

template <typename BaseCowHashmapParams>
std::ostream& operator<<(
    std::ostream& os, 
    const BaseCowHashmap<BaseCowHashmapParams>& base_cow_hashmap) {
  typedef BaseCowHashmap<BaseCowHashmapParams> Self;
  typename Self::ConstIterator iter = base_cow_hashmap.Begin();
  while (iter != base_cow_hashmap.End()) {
    os << iter.GetKey() << '\t' << iter.GetVal() << std::endl;
    ++iter;
  }
  os << std::endl;
  return os;
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmapBaseIterator<BaseCowHashmapParams>::operator==(
    const BaseCowHashmapBaseIterator& iterator) const {
  if (unlikely(this == &iterator)) return true;

  if (-1==bucket_index_ && -1==iterator.bucket_index_) {
    return true;
  }

  return (bucket_index_==iterator.bucket_index_ 
      && node_==iterator.node_);
}

template <typename BaseCowHashmapParams>
bool BaseCowHashmapBaseIterator<BaseCowHashmapParams>::operator!=(
    const BaseCowHashmapBaseIterator& iterator) const { 
  return !(*this==iterator); 
}

template <typename BaseCowHashmapParams>
BaseCowHashmapBaseIterator<BaseCowHashmapParams>& 
BaseCowHashmapBaseIterator<BaseCowHashmapParams>::operator++() {
  MoveToNext_();
  return *this;
}

template <typename BaseCowHashmapParams>
BaseCowHashmapBaseIterator<BaseCowHashmapParams>
BaseCowHashmapBaseIterator<BaseCowHashmapParams>::operator++(int) {
  Self iter = *this;
  MoveToNext_();
  return iter;
}

template <typename BaseCowHashmapParams>
void BaseCowHashmapBaseIterator<BaseCowHashmapParams>::MoveToNext_() {
  if (unlikely(bucket_index_<0)) return;

  if (NULL!=node_) {
    node_=&((*node_)->next);
    if (NULL!=*node_) {
      return;
    } else {
      ++bucket_index_;
    }
  }

  while (bucket_index_ < static_cast<ssize_t>(base_cow_hashmap_->size_buckets_)
    && (NULL==base_cow_hashmap_->buckets_[bucket_index_] 
      || NULL==base_cow_hashmap_->buckets_[bucket_index_]->head)) {
      ++bucket_index_;
  }

  if (bucket_index_ != static_cast<ssize_t>(base_cow_hashmap_->size_buckets_)) {
    node_ = &(base_cow_hashmap_->buckets_[bucket_index_]->head);
  } else {
    bucket_index_=-1;
  }
}

template <typename BaseCowHashmapParams>
typename BaseCowHashmapIterator<BaseCowHashmapParams>::Key* 
BaseCowHashmapIterator<BaseCowHashmapParams>::GetKeyToWrite() {
  Master* base_cow_hashmap = const_cast<Master*>(Super::base_cow_hashmap_);
  typename Master::Bucket** bucket_addr = 
    base_cow_hashmap->buckets_ + Super::bucket_index_;
  if (1 != (*bucket_addr)->shared_count) {
    typename Master::Node* tmp_node = *Super::node_;
    bool ret = base_cow_hashmap->NormalizeBucketAndGetNode_(bucket_addr, tmp_node);
    if (unlikely(true!=ret)) return NULL;

    Super::node_ = &tmp_node;
  }
  return &((*Super::node_)->key);
}

template <typename BaseCowHashmapParams>
typename BaseCowHashmapIterator<BaseCowHashmapParams>::Val*
BaseCowHashmapIterator<BaseCowHashmapParams>::GetValToWrite() {
  Master* base_cow_hashmap = const_cast<Master*>(Super::base_cow_hashmap_);
  typename Master::Bucket** bucket_addr = 
    base_cow_hashmap->buckets_ + Super::bucket_index_;
  if (1 != (*bucket_addr)->shared_count) {
    typename Master::Node* tmp_node = *Super::node_;
    bool ret = base_cow_hashmap->NormalizeBucketAndGetNode_(bucket_addr, tmp_node);
    if (unlikely(true!=ret)) return NULL;

    Super::node_ = &tmp_node;
  }
  return &((*Super::node_)->val);
}

}}
