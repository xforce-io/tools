#pragma once

#include <tr1/functional>
#include "base_cow_hashmap.hpp"
#include "../functors.hpp"

namespace zmt { namespace material_center {

template <
    typename Key,
    typename Val=Key,
    typename HashF=std::tr1::hash<Key>,
    typename EqualKeyF=std::equal_to<Key>,
    typename AtExitF=DefaultKVAtExitF<Key, Val> >
class CowHashmap : 
  public BaseCowHashmap<BaseCowHashmapParams< 
      Key, Val, HashF, EqualKeyF, AtExitF, false> > {
 public:
  typedef BaseCowHashmap<BaseCowHashmapParams<
      Key, Val, HashF, EqualKeyF, AtExitF, false> > Super;

 public:
  CowHashmap(
      size_t hint_size_buckets=Super::kDefaultSizeBuckets,
      bool to_resize=Super::kDefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const AtExitF& at_exit=AtExitF()) :
    Super(hint_size_buckets, to_resize, hasher, equal_key, at_exit) {}
};

template <
    typename Key,
    typename Val=Key,
    typename HashF=std::tr1::hash<Key>,
    typename EqualKeyF=std::equal_to<Key>,
    typename AtExitF=DefaultKVAtExitF<Key, Val> >
class MultiCowHashmap : public BaseCowHashmap<BaseCowHashmapParams<
    Key, Val, HashF, EqualKeyF, AtExitF, true> > {
 public:
  typedef BaseCowHashmap<BaseCowHashmapParams<
      Key, Val, HashF, EqualKeyF, AtExitF, true> > Super;

 public:
  MultiCowHashmap(
      size_t hint_size_buckets=Super::kDefaultSizeBuckets,
      bool to_resize=Super::kDefaultToResize,
      const HashF& hasher=HashF(),
      const EqualKeyF& equal_key=EqualKeyF(),
      const AtExitF& at_exit=AtExitF()) :
    Super(hint_size_buckets, to_resize, hasher, equal_key, at_exit) {}
};

}}
