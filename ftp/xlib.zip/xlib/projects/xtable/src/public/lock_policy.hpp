#pragma once

#include <pthread.h>
#include "common.h"

namespace zmt { namespace material_center {

class NoLock {
 public:
  bool Lock() const { return true; }
  void Unlock() const {}
};

/* RAII */
class ThreadMutex {
 public:
  explicit ThreadMutex() : init_(false) {}

  inline bool Lock();
  inline void Unlock();

 private:
  inline bool Init_();

 private:
  pthread_mutex_t mutex_;

  bool init_;
};

bool ThreadMutex::Lock() { 
  MEGA_RAII_INIT(false)
  return 0 == pthread_mutex_lock(&mutex_); 
}

void ThreadMutex::Unlock() { 
  MEGA_RAII_INIT()
  pthread_mutex_unlock(&mutex_); 
}

bool ThreadMutex::Init_() { 
  if (0 == pthread_mutex_init(&mutex_, NULL)) {
    init_=true;
    return true;
  } else {
    return false;
  }
}

}}
