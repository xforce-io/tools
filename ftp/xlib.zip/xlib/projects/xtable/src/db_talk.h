#pragma once 

#include "public.h"

namespace zmt { namespace material_center {

struct DBMsgHeader {
  uint32_t cmd;
  LogicTime logic_time;
  int ret_code;
  int magic;
};

struct DBMsgCreateTable : public DBMsgHeader {
  static const uint32_t kCmd=2;

  //request
  const std::string* syntax;
};

struct DBMsgAddRecord : public DBMsgHeader {
  static const uint32_t kCmd=3;

  //request
  const std::string* table_name;
  const WeakType* record;
};

struct DBMsgRemoveRecord : public DBMsgHeader {
  static const uint32_t kCmd=4;

  DBMsgHeader db_msg_header;

  //request
  const std::string* table_name;
  const WeakType* keys_to_remove;
};

struct DBMsgUpdateRecord : public DBMsgHeader {
  static const uint32_t kCmd=5;

  //request
  const std::string* table_name;
  const WeakType* keys_to_remove;
  const WeakType* record;
};

class DBTalk {
 public:
  static const int kMagic = 1234; 

 public:
  static int WriteDBMsgRequest(int fd, const DBMsgHeader& db_msg);
  static int ReadDBMsgResponse(int fd);
  static int ReadDBMsgRequest(IN int fd, OUT DBMsgHeader*& db_msg);
  static int WriteDBMsgResponse(int fd);

 private:
  static int Write_(int fd, const char* buf, size_t count);
  static int Read_(int fd, const char* buf, size_t count);
};

}}
