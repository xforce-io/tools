#pragma once 

#include "db.h"
#include "db_device/db_device.h"
#include "db_mem.h"

namespace zmt { namespace material_center {

/*
 * @note: TPD stands for thread private data
 */
class DBTPD {
 public:
  bool ResetPipe();
  inline bool RegisterPipe(DBMem& db_mem);
  int GetFdPipeDBMem() const { return fd_[0]; }

 private:
  int fd_[2];
};

class DB {
 private:
  static const size_t kNoThreadPrivacy=1; 

 public:
  DB();
  bool Init(
      size_t max_size_device_block,
      time_t device_index_dump_interval,
      time_t device_flush_interval,
      size_t size_lru_queue,
      time_t tables_dump_interval,
      time_t tables_reload_interval,
      //size_t size_flush_pipe,
      RoutineFileDumper& routine_file_dumper, //TODO: should be member for deletion
      size_t num_writer,
      bool& end);

  //write interfaces
  int CreateTable(const std::string& command);
  int AddRecord(const std::string& command);
  int RemoveRecord(const std::string& command);
  int UpdateRecord(const std::string& command);

  //read interfaces
  inline int GetRecord(
      const std::string& table_name, 
      const WeakType& records,
      ResultsGetRecord*& results);
 
  virtual ~DB();

 private:
  inline bool WaitForStart_();
  bool ResetPipe_();
  bool RegisterPipe_();
  inline int GetFdPipeDBMem_();

 private:
  DBDevice* db_device_;
  DBMem* db_mem_;
  pthread_barrier_t thread_barrier_;
  bool start_;

  ThreadPrivacy thread_privacy_;
};

bool DBTPD::RegisterPipe(DBMem& db_mem) {
  bool ret = ResetPipe();
  if (true!=ret) return false;
    
  ret = db_mem.RegisterPipe(fd_[1]);
  if (true!=ret) return false;
  return true;
}

int DB::GetRecord(
    const std::string& table_name, 
    const WeakType& records,
    ResultsGetRecord*& results) {
  return db_mem_->GetRecord(table_name, records, results);
}

bool DB::WaitForStart_() {
  if (unlikely(false==start_)) {
    bool ret = RegisterPipe_();
    if (true!=ret) return false;

    pthread_barrier_wait(&thread_barrier_);
    start_=true;
  }
  return true;
}

int DB::GetFdPipeDBMem_() {
  void* thread_privacy = thread_privacy_.Get<DBTPD>(kNoThreadPrivacy);
  return RCAST<DBTPD*>(thread_privacy)->GetFdPipeDBMem();
}

}}
